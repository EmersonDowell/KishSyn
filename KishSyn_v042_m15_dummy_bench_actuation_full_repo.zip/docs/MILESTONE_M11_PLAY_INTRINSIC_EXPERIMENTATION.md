# Milestone M11: Play and Intrinsic Experimentation

M11 defines play as safe-enough developmental experimentation. It is not random behavior, not personality theater, and not a hidden command layer.

## Law

Play is safe-enough experimentation that improves prediction, controllability, and learning progress. It may propose bounded probes. It may not command action.

## Why this exists

After M8, M9, and M10, KishSyn can separate context-bound affordances, object identity, and retention pressure. M11 gives that substrate a developmental reason to test the world when survival pressure is low enough. This is the bridge between passive learning and organism-like curiosity.

## Design pattern commitments

- **Contract Object:** `PlayIntent` is an inspectable proposal, not a motor command.
- **Strategy:** `IntrinsicPlayDrive.propose()` decides when curiosity/uncertainty and body safety allow a probe.
- **Repository:** `IntrinsicPlayDrive` stores bounded play history.
- **Flyweight:** repeated experiments strengthen `PlayPattern` records instead of creating tick-specific play nodes.
- **Observer:** completed organism-loop outcomes are observed after action and scored for learning value.

## Safety boundaries

Play is inhibited when body pressure is unsafe. The current safety gate uses energy, hydration, integrity, and fatigue to compute a body safety margin. If safety margin is too low, play is not allowed to propose.

Play does not access the external embodiment interface. OS/program interaction remains governed by the external embodiment doctrine: observe first, dummy-safe benches first, supervised gates later, explicit approval before write-like actions.

Play does not choose actions directly. The action selector ranks the proposal against survival pressure, learned affordances, route memory, body map, priority arbitration, and normal fallback behavior.

## Memory economy

Play writes reusable anatomy as `play_pattern:*` nodes. It must never write tick-specific `play:t*` nodes. Completed probes compress into `PlayPattern` summaries with evidence count, safety ratio, mean learning delta, and outcome counts.

## Lock command

```powershell
python -m kishsyn_core.tools.run_milestone_m11_lock --steps 180 --seeds 337,171,23 --out stores/_demo/milestone_m11_lock_report.json
```

## Lock requirements

M11 is locked only if:

- unsafe body states inhibit play proposals,
- safe body states produce bounded proposals,
- loop play produces reusable patterns,
- play safety ratio stays above threshold,
- no `play:t*` tick-specific node leak appears,
- no consciousness claim is made.

## Next milestone

M12 should be Grounded Language and Teaching. Language must attach to object files, contextual affordances, play traces, body outcomes, and memory summaries. It must not become the mind itself.
