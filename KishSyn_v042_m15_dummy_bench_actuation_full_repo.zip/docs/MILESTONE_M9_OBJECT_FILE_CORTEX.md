# Milestone M9: Object-File Cortex

M9 separates **same kind** from **same individual**.

The active law is:

```text
same kind does not mean same individual
```

Apple A and Apple B may both activate apple-like category anatomy, but they must keep separate object files. Category sharing lets KishSyn generalize. Object files prevent over-collapse.

## Why this exists

M8 taught that object use depends on actor, body, world context, action, provenance, and outcome. M9 adds the missing identity layer: a perceived thing can persist as itself across time while still belonging to a reusable kind.

Without M9, the system risks either:

- treating every sighting as a brand-new object, causing memory bloat, or
- collapsing distinct objects into one concept, losing common-sense distinctions.

M9 creates the middle path.

## Approved representation

An object file stores:

- persistent object id
- shared object-kind signature
- first and last observation tick
- observation count
- stable feature distributions
- recent feature state
- location history
- action history
- outcome history
- transformation history
- mean prediction error

The graph receives object-file anatomy nodes such as `object_file:*`, but tick observations remain compact event summaries. The object file is the durable identity. Individual sightings are not durable identities.

## Required separation

Object kind answers:

```text
what kind of thing does this resemble?
```

Object file answers:

```text
which individual thing is this, and what has happened to it?
```

Contextual affordance answers:

```text
what does this kind/thing tend to do for this actor in this world under this action?
```

These surfaces must remain separate.

## Example

Apple A:

```text
kind: red + round fruit-like object
file: apple_A
size: small
blemish: none
quantity: depleted after interaction
location: grove cell
history: inspected, eaten, relief outcome
```

Apple B:

```text
kind: red + round fruit-like object
file: apple_B
size: large
blemish: present
quantity: available
location: plain cell
history: inspected, novelty outcome
```

They share kind anatomy, but they are not the same object.

## Lock command

```powershell
python -m kishsyn_core.tools.run_milestone_m9_lock --steps 180 --seeds 337,171,23 --out stores/_demo/milestone_m9_lock_report.json
```

## Non-claims

M9 is not object consciousness, visual object segmentation, or real-world recognition. It is a governed identity-memory layer for currently perceived target features.

## Next milestone

M10 should add Retention Pressure and Memory Economy so object files, affordance records, and traces can be summarized, retained, consolidated, or allowed to decay based on value and pressure.


## Forward Link

Object files support M11 play by giving experimentation stable targets. Play can test an object without confusing its category, identity, and contextual affordance history.
