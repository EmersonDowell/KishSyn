# Sensory-Motor Contract

Everything enters the organism as a `SensoryFrame`.

A future camera, microphone, keyboard, game world, browser, robot sensor, or file stream must be adapted into the same contract:

```text
RawSample -> SensoryFeature -> SensoryFrame
```

The organism may then:

1. read body pressure
2. predict consequence
3. choose an action
4. record efference copy
5. observe outcome
6. update plastic pathways
7. store trace memory
8. replay important traces

## Motor authority stages

1. simulation only
2. recorded replay
3. dummy-safe bench
4. supervised dummy field
5. read-only telemetry
6. adapter quarantine
7. certified physical actuation

No live hardware control enters this repo without staged safety documentation and tests.


## M4 external adapter rule

External surfaces are not special. A screen frame, image description, audio event, math expression, console text, file event, or hardware reading must become a `SensoryPacket`, then `SensoryFeature` tokens, then enter the same focus/moment/action/consequence pathway.

Expression is motor output. Console expression may be emitted only by `ExpressionSurface` from current organism evidence. Later sound, speech, cursor, keyboard, robotics, and tool output must follow the same pattern: output is an inspectable motor act, not an external mind.
