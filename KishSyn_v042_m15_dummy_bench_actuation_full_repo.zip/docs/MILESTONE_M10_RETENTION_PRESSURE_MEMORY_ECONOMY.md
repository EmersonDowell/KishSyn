# Milestone M10: Retention Pressure and Memory Economy

M10 prevents the organism from becoming a junk drawer.

The graph is reusable anatomy. The trace ledger is bounded event history. Retention pressure decides what earns durable memory.

## Core law

```text
graph = reusable anatomy
ledger = bounded event history
retention pressure = promotion policy
```

A tick is not automatically a durable memory. A plan instance, object encounter, sensory moment, or expression event may remain transient. It may compress into a summary. It may be preserved. It may consolidate. That decision is based on pressure, not raw existence.

## New substrate

`kishsyn_core/memory_economy.py` adds:

- `RetentionPressure`
- `MemorySummary`
- `MemoryPressureGovernor`

The governor observes only completed traces after lived outcome. It cannot choose actions. It cannot rewrite the past. It cannot become a hidden reward oracle.

## Retention signals

Retention pressure currently considers:

- prediction error / surprise
- pain, relief, novelty, blocked/depleted/communication outcomes
- dominant body need pressure
- instruction-like cues such as remember, study, recall, page, teach
- self-causation
- utility and world-event evidence

## Decisions

```text
transient   -> do not write durable graph anatomy
summarize   -> update reusable memory_summary bucket
preserve    -> update summary and mark as high-value evidence
consolidate -> update summary and strengthen consolidated retention anatomy
```

## What M10 does not claim

M10 does not claim consciousness, autobiographical selfhood, or human-like memory. It only adds a governed memory-economy surface so repeated experience compresses into reusable structure and high-pressure experience can be inspected.

## Lock command

```powershell
python -m kishsyn_core.tools.run_milestone_m10_lock --steps 180 --seeds 337,171,23 --out stores/_demo/milestone_m10_lock_report.json
```

## Required invariants

- Repeated experience must reuse summary buckets.
- No durable `memory:t...` tick-id nodes.
- No regression to `plan:t...` tick-id nodes.
- Save/load must preserve memory-economy summaries.
- Low-pressure events may vanish or compress.
- High-pressure instruction/surprise must be inspectable.


## Forward Link to M11

M10 decides what deserves retention. M11 uses that economy during safe-enough play so exploratory traces strengthen reusable patterns instead of becoming permanent tick spam.
