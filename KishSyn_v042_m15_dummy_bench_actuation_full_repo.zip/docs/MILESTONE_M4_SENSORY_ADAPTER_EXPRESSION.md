# Milestone M4: Sensory Adapter and Expression Surface

M4 locks the first external-surface bridge. The goal is not to make KishSyn talk like a chatbot and not to attach a second intelligence layer. The goal is to prove that outside signals can enter the same organism contract and that expression can leave through a governed motor surface.

## Locked target

```text
external packet
-> SensoryAdapterHub
-> normalized SensoryFeature tokens
-> FocusGate
-> MomentFrame
-> binding/anatomy/graph plasticity
-> grounded ExpressionSurface
-> NeuralAtlas projection
```

## Doctrine

All future sensory and motor surfaces must use the adapter/expression contract. Screen, image, audio, math, console, files, tools, hardware sensors, and robotics signals may not bypass focus, moments, prediction, action, outcome, plasticity, memory, or atlas inspection.

GPT/API services may later serve as tutors, curriculum generators, evaluators, or external oracles. They are not KishSyn's mind.

## New surfaces

`kishsyn_core/sensory.py` defines `SensoryAdapterHub`, `SensoryPacket`, and `AdapterReport`.

Supported initial modalities:

- `console`
- `math`
- `screen`
- `image`
- `audio`
- `sensor`

`kishsyn_core/expression.py` defines `ExpressionSurface` and `ExpressionAct`. Expression is a motor channel. Console text is emitted only from graph/body/action/outcome evidence.

`kishsyn_core/atlas.py` defines `NeuralAtlasProjector`. The GUI reads this standardized projection so every touched surface can be seen as neural/synaptic activity.

## Lock criteria

M4 locks only when:

- M3 remains locked.
- external packets normalize into sensory features.
- adapter features pass through FocusGate.
- expression output is graph-grounded.
- the neural atlas mirrors math/screen/image/audio/text/expression surfaces.
- the formal benchmark suite has no watch/fail tasks.

## Command

```powershell
python -m kishsyn_core.tools.run_milestone_m4_lock --steps 96 --seeds 337 --out stores/_demo/milestone_m4_lock_report.json
```

## Storage call

Do not bring the old database back for M4. JSON brain-state remains correct while the adapter, expression, and atlas contracts are still forming. KishDB or a stronger store returns later as a storage-scale milestone after anatomy contracts stabilize.
