# M8: Contextual Affordance Cognition

M8 is the course correction that prevents KishSyn from treating a concept as a universal command.

The central law is:

```text
concept + actor/body + world context + action + provenance + outcome = meaning-in-use
```

An apple is not absolutely edible. In one game it may heal a player body. In another game it may be scenery. In a crafting game it may be an ingredient. In a robot-body context it is not food for KishSyn, but it may be food for humans or animals, a seed source, a physical object to handle carefully, or a thing to plant for ecological abundance.

## Locked doctrine

- Concepts are anchors, not commands.
- Use is context-bound.
- The graph stores reusable anatomy. The ledger stores event history.
- Tick-specific plans and object encounters should strengthen reusable structures unless retention pressure promotes an episode.
- Cross-context transfer is allowed only as a weak hypothesis until local evidence confirms it.
- Provenance matters. Game evidence, language evidence, self-action evidence, and real-world sensor evidence must not collapse into one truth field.

## New code surface

`kishsyn_core/contextual_affordance.py` adds the first conservative M8 layer.

It introduces:

- `ActorProfile`: the acting body whose capabilities shape valid affordances.
- `WorldContext`: the local rule field where the action happens.
- `RealityProvenance`: the source of the learned claim.
- `ObjectKindSignature`: a reusable sensory object-kind signature that ignores instance spam like object id, distance, quantity, and cell.
- `AffordanceRecord`: a reusable record keyed by actor, context, object kind, action, outcome, and provenance.
- `TransferHypothesis`: a weak reuse proposal across contexts, not a belief.
- `ContextualAffordanceCortex`: the Repository/Strategy layer that records lived affordance evidence and inhibits unsafe over-transfer.

The current loop records M8 evidence after each completed tick. v034 also adds `AffordanceBiasContract`, an inspectable non-command contract that may report small local ranking pressure while keeping cross-context transfer inhibited. It still does **not** command actions.

## Apple-across-worlds benchmark

The benchmark now exposes the same apple-like object kind in four contexts:

```text
Game A: apple + avatar + eat/use -> relief or HP gain
Game B: apple + avatar + interact -> neutral/scenery
Game C: apple + avatar + gather/craft -> ingredient value
Robot world: apple + robot + inspect/handle -> food-for-others / seed-source, not self-food
```

The pass condition is not that KishSyn knows human facts about apples. The pass condition is structural:

- The object kind is reused across contexts.
- Actor and body differences are preserved.
- Local world rules are kept separate.
- Cross-context transfer is weaker than same-context reuse.
- No one-off apple instance spam becomes durable cognition anatomy.
- Local evidence can override prior context assumptions.



## v034 hardening status

Implemented:

- `AffordanceBiasContract` for governed, non-command affordance pressure.
- Apple Across Worlds benchmark task inside `BenchmarkPlaygroundSuite`.
- M8 lock CLI: `python -m kishsyn_core.tools.run_milestone_m8_lock`.
- Tests proving a healing-game apple does not become robot-body self-food.

The lock condition is structural, not a consciousness claim: one reusable apple-like object kind, multiple preserved actor/world contexts, local bias stronger than cross-context transfer, cross-context transfer inhibited, and no tick-specific plan-node leaks.

## Why this matters

Without M8, KishSyn risks becoming a confused association machine: `apple -> edible`, `apple -> heal`, `apple -> scenery`, and `apple -> ingredient` all blur together.

With M8, KishSyn can eventually say the equivalent of:

```text
This resembles an apple. In one game, apples restored a player body. In another, they were non-interactable. In a robot-body context, I cannot eat it, but it may matter to humans, animals, gardening, or seed propagation. I should test local rules before acting strongly.
```

That is the beginning of common-sense transfer.
# KishSyn Forward Milestone Roadmap: M8 to M12

This roadmap keeps the project aligned with the new course: KishSyn should grow world-understanding through reusable anatomy, object files, contextual affordances, retention pressure, and play, not through fake personality scripts or universal concept commands.

## M8: Contextual Affordance Cognition

Status: started in v033.

Goal: store meaning-in-use as actor + body + world context + object kind + action + provenance + outcome.

Current implementation:

- `ContextualAffordanceCortex` records lived conditional affordance evidence.
- Object-kind signatures reuse color/shape/glyph/symbol patterns while ignoring object id, distance, quantity, and cell.
- Cross-context transfer is inhibited until target-context evidence exists.
- Snapshot and persistence surfaces expose contextual affordance records.

Next hardening:

- Add the Apple Across Worlds benchmark.
- Add a governed action-bias contract that can use contextual affordance records without commanding behavior.
- Add context switching for game/simulation/robot/language surfaces.

## M9: Object-File Cortex

Goal: separate individual object identity from shared category attractors.

Apple A and Apple B should activate overlapping category anatomy but preserve individual differences: size, blemish, location, interaction history, freshness, ownership, and transformation state.

Required surfaces:

- `ObjectFile` for persistent individual objects.
- `ObjectKind` / category attractor reuse.
- Object permanence across moments.
- Property deltas: same kind, different instance.
- Tests proving two similar objects share category pathways without merging identity.

## M10: Retention Pressure and Memory Economy

Goal: make remembering and forgetting lawful.

The system should not retain every glyph, object, tick plan, or micro-event forever. It should preserve what is useful, surprising, instructed, emotionally intense, socially relevant, repeatedly rehearsed, dangerous, beautiful, or compression-rich.

Required surfaces:

- Retention score per trace.
- Memory lifecycle: fresh trace -> working memory -> episodic candidate -> consolidated memory -> semantic summary -> decayed summary -> forgotten.
- Instruction pressure: “remember this page” temporarily increases retention and rehearsal.
- Summary compression: “many glyphs, many colors, low pressure to preserve each one.”
- Gates proving graph growth scales with meaningful novelty instead of raw tick count.

## M11: Play and Intrinsic Experimentation

Goal: make play a developmental pressure, not random action.

Play emerges when survival pressure is low, novelty remains, and small experiments can improve prediction, controllability, and competence.

Required surfaces:

- Safe-play governor.
- Experiment variation memory.
- Learning-progress reward.
- Curiosity without runaway node growth.
- Tests proving repeated play strengthens reusable affordances and motor confidence.

## M12: Grounded Language and Teaching

Goal: attach words to lived object/action/context structures instead of treating language as the mind.

Language should become a compression and tutoring surface over grounded experience.

Required surfaces:

- Words bind to object files, affordance records, body outcomes, and context rules.
- “Apple” becomes a handle for context-sensitive lived knowledge, not a token definition.
- Teacher instructions can raise attention and retention pressure, but cannot overwrite lived evidence.
- Tests proving language transfer is ablation-sensitive and context-aware.

## Non-negotiable architecture rules

- One organism loop.
- No second mind stack.
- No fake personality engine.
- No universal concept-to-action shortcuts.
- No tick-id graph bloat.
- All new biasing surfaces must be governed contracts.
- Every regression fix adds or tightens a gate.
- Full gates remain available; per-patch gates run only the touched mandatory surfaces plus smoke checks.

## M9 handoff note

M8 must not absorb object identity. M8 stores context-bound meaning-in-use. M9 stores individual object continuity. Future affordance decisions should be able to ask both questions separately:

```text
what kind is this?
which individual file is this?
what has this kind or this individual done for this actor in this world?
```
