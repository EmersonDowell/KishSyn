# Milestone M1: Focused Moment Substrate

Milestone M1 locks the next controlled surface for KishSyn Core.

The milestone target is not consciousness, conversation, or a finished mind. The target is narrower and testable:

> Raw sensory flow must be selected into focused moments, focused moments must stabilize cross-feature bindings, and repeated bindings must promote provisional circuit anatomy inside the synapse graph.

## Why this milestone exists

Earlier versions proved a small living loop could sense, act, predict, receive consequence, grow a synapse graph, preserve traces, replay, ground simple symbols, and pass controlled evidence probes.

That was necessary, but not enough. A nervous system does not become useful by storing every signal equally. It must decide what matters, bind selected signals into moments, and let repeated moments become reusable anatomy.

M1 creates that developmental bridge.

## Locked M1 flow

```text
raw SensoryFrame
-> FocusGate
-> focused SensoryFrame
-> MomentFrame
-> BindingEngine
-> AnatomyGrowthEngine
-> graph circuit nodes
-> benchmark and evidence gates
```

## M1 components

### FocusGate

`kishsyn_core/focus.py`

The FocusGate scores raw sensory features by body relevance, novelty, active symbol relevance, danger relevance, place relevance, text relevance, and overload cost. It emits a bounded focused frame plus a replayable focus report.

Design patterns: Strategy, Memento, Specification.

### MomentFrame

`kishsyn_core/moment.py`

A MomentFrame is the active experiential slice of a tick. It records raw tokens, focused tokens, target tokens, dominant need, body pressure, action, prediction, outcome, prediction error, self/world causation, and workspace notes.

Design patterns: Memento, Immutable Value Object.

### BindingEngine

`kishsyn_core/binding.py`

The BindingEngine converts repeated focused co-activations into provisional event binding handles. Bindings grow graph nodes only after focused experience, not from a hidden dictionary.

Design patterns: Repository, Factory.

### AnatomyGrowthEngine

`kishsyn_core/anatomy.py`

The AnatomyGrowthEngine promotes stable bindings into provisional circuit nodes. These circuits are not a finished brain map. They are the first locked anatomy surface: repeated focused experience becoming reusable structure.

Design patterns: State Machine, Promoter.

## What counts as passing M1

A normal run must show:

- bounded focus selectivity
- retained MomentFrames
- stable bindings
- provisional circuit promotions
- graph nodes of kind `binding` and `circuit`
- persistence through save/load
- benchmark task `focused moment substrate` not failing
- evidence criterion `focused moment substrate` not failing

## Storage decision

Do not reintroduce the old database yet.

For M1, explicit JSON brain-state is the correct store because the state surface is still changing quickly and must remain readable, diffable, and easy to audit. A heavier database can return at a later storage milestone when the anatomy contracts are stable and the graph becomes too large for explicit JSON.

The current doctrine is:

```text
M1 storage: explicit JSON state plus append-only JSONL reports
Future storage milestone: repository-backed KishDB or SQLite adapter only after contracts stabilize
```

## Forbidden shortcuts

M1 must not add a hidden planner, hidden language model mind, hidden answer table, or fake emotional persona. All improvements must enter through signal, focus, moment, binding, anatomy, graph, memory, action, consequence, or evidence gates.

## v026 lock command

M1 is formally locked by this command:

```powershell
python -m kishsyn_core.tools.run_milestone_m1_lock --steps 240 --seeds 337,171,23 --out stores/_demo/milestone_m1_lock_report.json
```

The command succeeds only when all M1 lock criteria pass and the controlled benchmark suite has zero watch/fail tasks.

Lock criteria:

- focus selectivity
- MomentFrame ledger retention
- binding stability
- provisional circuit growth
- synapse graph support
- live finite-resource interaction
- benchmark lock
- focused substrate score

The depletion-aware foraging task uses cumulative depletion events, not final currently-depleted resources. This is intentional because M1 measures lived interaction pressure across time, while endpoint resources can migrate/regrow before the report is generated.

Current lock status for v026:

```text
M1 locked: Focused Moment Substrate is controlled and repeatable
```



## M2 build-on rule

M2 may not weaken M1. Cross-modal binding and intent persistence are allowed only after focus-selected moments remain intact, replayable, and graph-backed.
