# M7: Emotion-Biased Attention and Expression

M7 allows the emotional regulation field to influence the next moment only through a governed bias contract. This is not a personality engine, not a reward oracle, and not an action selector.

The lawful chain is:

```text
completed tick -> emotion sample -> bounded bias contract -> next FocusGate score component -> grounded expression evidence
```

## Contract

`EmotionalRegulationField.bias_contract()` exports a previous-sample `EmotionBiasContract` with bounded values for focus, expression, safety, curiosity, and frustration. The contract is inspectable in snapshots and persists through the JSON state store.

The bias may:

- add a small `emotion` component to focus scoring;
- let expression include regulation evidence such as `emotion_bias:settled:0.119`;
- make danger, novelty, blocked-intent, or recovery evidence slightly more likely to enter the active moment.

The bias may not:

- select an action;
- invent a goal;
- overwrite memory;
- speak as a fake personality;
- bypass body pressure, symbol arbitration, sensory adapters, FocusGate, MomentFrame, graph plasticity, or the atlas.

## Memory economy correction

M7 also corrects the M3 planning trace leak. Tick-specific plan instances are audit history, not durable brain anatomy. The graph now stores reusable `plan_template:*` neurons, while individual planning reports stay in bounded replay history.

This implements the doctrine:

```text
The graph stores reusable anatomy. The ledger stores events. Consolidation decides what becomes structure.
```

Repeated instances like `plan:t1143:move:soft_gray_2` now strengthen a reusable template such as `plan_template:move:soft_gray` instead of creating a permanent one-off node.

## Lock expectation

M7 is locked only if:

- emotion exports bounded bias contracts;
- FocusGate exposes the bias as a visible score component;
- expression records emotion bias only as grounded evidence;
- reusable plan templates replace tick-specific durable plan nodes;
- existing benchmark tasks remain non-failing;
- no consciousness, personhood, or fake personality claim is introduced.

Run:

```powershell
python -m kishsyn_core.tools.run_milestone_m7_lock --steps 160 --seeds 337 --out stores/_demo/milestone_m7_lock_report.json
```
