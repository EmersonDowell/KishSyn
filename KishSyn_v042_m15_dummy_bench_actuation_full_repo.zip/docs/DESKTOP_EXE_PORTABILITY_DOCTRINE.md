# Desktop Executable Portability Doctrine

KishSyn must not become a web-page-only organism. The current browser Observatory is a useful shell, not the mind, not the runtime, and not the durable brain.

## Core law

```text
UI shells render and transport. The organism loop and stores/ brain state remain shell-independent.
```

The official future `.exe` should wrap the same organism loop, same adapter contracts, same stores path, same milestone gates, and same graph/memory/state surfaces. It should not fork cognition into a separate desktop-only implementation.

## Approved shell roles

A runtime shell may:

- render the Observatory or desktop UI
- start and stop the organism loop
- inspect brain-state snapshots
- forward sensory packets through governed adapters
- display graph/atlas/memory/attention state
- host a packaged Windows executable process

A runtime shell may not:

- own cognition
- own brain state
- bypass `stores/`
- bypass FocusGate, MomentFrame, graph plasticity, memory economy, or adapter safety
- implement hidden desktop automation outside the external-interface contract

## Current contract

`kishsyn_core/runtime_shell.py` defines `RuntimeShellContract` and `RuntimeShellPolicy`.

The default policy includes:

- `observatory_web`, the current browser shell using HTTP/JSON
- `kishsyn_desktop_exe_future`, the future packaged desktop executable shell using an in-process transport
- `headless_cli`, the gate/test/development shell

This keeps HTML useful without letting it become architectural gravity.

## Packaging direction

When the project is ready for official desktop release, the executable shell should package the Python runtime or a compiled service wrapper around the existing organism loop. The first release candidate should prove:

- same `stores/` brain-state file loads under CLI, web observatory, and desktop shell
- same patch gates run outside the browser
- desktop shell has no special cognition path
- OS observation remains read-only until later certified actuation milestones
- all desktop actions are auditable and reversible where possible

The future `.exe` is a body shell. The organism remains the organism.
