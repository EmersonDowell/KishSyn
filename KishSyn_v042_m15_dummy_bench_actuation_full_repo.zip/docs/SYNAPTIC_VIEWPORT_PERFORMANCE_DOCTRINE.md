# Synaptic Viewport Performance Doctrine

The synaptic graph panel is a camera over KishSyn's growing anatomy, not the anatomy itself.

As the organism develops, the neural graph may contain thousands or millions of durable structures. The Observatory and future desktop `.exe` shell must not try to render every neuron and synapse every frame. That would confuse visualization with cognition and would punish healthy growth.

## Core law

```text
stores/graph = full brain anatomy
viewport graph = budgeted camera projection
```

The runtime keeps full graph state. The viewport receives a deterministic read-model with explicit node and edge budgets.

## Rules

- Full graph persistence remains in `stores/` and state save/load paths.
- Programmatic organism snapshots may still expose full graph anatomy for tests and tooling.
- Web/desktop visual shells should request a budgeted viewport graph by default.
- The viewport must preserve honest total counts: total nodes, total edges, rendered nodes, rendered edges, and omitted counts.
- Rendering budgets are not memory deletion. They are camera limits.
- Panning and zooming must not mutate topology.
- Click inspection must continue to resolve through read-only atlas endpoints.
- No UI shell may become the source of cognitive truth.

## Implemented surface

`kishsyn_core/graph_viewport.py` adds:

- `GraphViewportBudget`
- `GraphViewportProjector`

The Observatory `/api/snapshot` endpoint now defaults to a budgeted graph view:

```text
/api/snapshot?graph=viewport&node_limit=420&edge_limit=760
```

Full graph snapshots remain available for diagnostics:

```text
/api/snapshot?graph=full
```

## Frontend behavior

The canvas renderer now:

- receives a bounded graph projection by default
- throttles graph renders through `requestAnimationFrame`
- avoids resizing the canvas unless the viewport size or device pixel ratio changed
- skips weak edges at low zoom
- caps hit-test edge records
- shows rendered/total/omitted counts in the viewport footer

This keeps the synaptic panel usable as the brain grows while preserving the full graph in the runtime and stores.
