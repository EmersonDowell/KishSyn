# Persistent Symbol Goal Doctrine

v012 adds a short-lived symbolic intention surface. A cue token may remain active after the organism physically interacts with a cue object, but it is not a command and it is not a lookup table.

A persistent symbol goal can bias later action only when the neural graph already contains learned symbol-to-concept pathways from embodied symbol teaching. If the graph has no grounded pathway for a token, the token has no useful control authority.

The lawful loop is:

```text
cue surface encountered -> token enters working pressure -> learned symbol/concept pathway scores candidate targets -> action is biased -> outcome updates plasticity -> goal expires or strengthens
```

This preserves the project rule: create conditions for symbolic control to emerge, do not directly assign meanings.

## Scientific intent

The surface approximates a primitive working-memory cue. It lets a recently encountered token remain behaviorally available after the original cue is no longer visible. This is a necessary bridge toward instruction following, delayed matching, and eventually language-guided behavior.

## Rejection rule

Do not add a direct dictionary such as `red = color red` or `A = glyph A` into the action layer. Tokens must influence behavior through neural graph weights grown by sensorimotor traces.


## v013 arbitration constraint

An active symbol goal cannot directly command action. It must be honored by priority arbitration before its token enters the action selector. Under survival pressure the goal is deferred and its TTL is extended slightly so the organism can return to it later instead of forgetting immediately.
