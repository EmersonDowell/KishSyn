# M14: Interface Affordance Discovery

M14 teaches KishSyn that observed interface elements have reusable roles and possible interaction shapes, without giving her control of the operating system.

## Core law

```text
observed UI element + role + label + application + surface context -> proposal-only affordance contract
```

A button, text field, menu, console, file row, webview, or game HUD element is an environment object first. It may become a reusable object-like interface signature and an affordance proposal, but it is not a live automation handle.

## New surface

`kishsyn_core/interface_affordance.py` adds:

- `UIElementSignature`
- `InterfaceAffordanceRecord`
- `InterfaceAffordanceContract`
- `InterfaceAffordanceCortex`

The cortex uses a Flyweight/Repository pattern: repeated observations of the same kind of button, field, menu, or console update one reusable record instead of creating per-frame durable nodes.

## Safety boundary

M14 may:

- infer inspect/read/click/type/scroll-shaped affordance candidates from observed roles
- bind those candidates to reusable graph anatomy such as `ui_element_kind:*`, `interface_affordance:*`, and `interface_contract:proposal_only`
- expose contracts for review and future dummy benches
- persist interface-affordance memory under `stores/`

M14 may not:

- move the mouse
- click
- type
- scroll
- issue shell commands
- write files
- call APIs
- control browsers, games, consoles, or apps

Write-like candidates must remain proposal-only. `may_actuate` must stay `false` until later dummy-bench, supervised, certified, and explicit-grant milestones exist.

## Why this matters

M13 made desktop/program surfaces observable. M14 makes them learnable. This is how KishSyn can eventually understand a computer organically: windows and controls become object files and contextual affordance candidates before any action is allowed.

This prevents brittle automation. We are not scripting app tricks. We are giving her the sensory substrate to learn interface structure.

## Lock criteria

M14 is locked only when:

- UI element signatures form from desktop observation frames
- inspect/read/write-like affordance records form as reusable anatomy
- repeated frames strengthen existing records
- write-like candidates remain blocked/proposal-only
- no `ui:t...` tick-specific durable nodes leak into the graph
- interface-affordance state persists through save/load
- runtime-shell policy remains desktop `.exe` capable and not HTML-locked

Run:

```powershell
python -m kishsyn_core.tools.run_milestone_m14_lock --steps 180 --seeds 337,171,23 --out stores/_demo/milestone_m14_lock_report.json
```


## Forward link to M15

M14 records remain proposal-only. M15 may consume those proposals only when they target a sealed dummy bench surface. This preserves the distinction between interface understanding and real-world authority.
