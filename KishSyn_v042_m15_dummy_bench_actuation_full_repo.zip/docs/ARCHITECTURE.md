# Architecture

KishSyn Core is a reflex-first synthetic nervous system substrate. The active system is one persistent loop, not a pile of side modules.

## Loop order

1. Sense a replayable `SensoryFrame`.
2. Drift and read `BodyState` pressure.
3. Compute developmental focus from pressure, prediction error, learning progress, and stability.
4. Propose a bounded motor experiment when pressure is low enough and controllability remains uncertain.
5. Select an action from need, curiosity, risk, distance, primitive priors, learned affordance pathways, route memory, comfort basins, proto-body confidence, developmental focus, and optional motor-probe pressure.
6. Predict the likely outcome from the neural graph.
7. Record an efference copy.
8. Act in the world.
9. Estimate self-caused versus world-caused change.
10. Apply body consequence.
11. Update route, comfort-attractor, proto-body-binding, motor-experiment, and developmental pathways from the same trace.
12. Store trace memory and periodically replay important traces.
13. Broadcast only scarce high-value events through the workspace.

## Living ecology

The world is larger and alive enough to teach: terrain, zones, renewable resources, moving hazards, scheduled spawns, object quantities, and ambient effects. The organism is not given affordance labels in its sensory frame. It learns from consequence.

## Place and route memory

`place:*`, `terrain:*`, and `route:*` pathways provide the first hippocampal-style scaffold. Consequences are bound not only to object color/shape, but also to where and under what terrain they occurred. Route memory is not a planner; it is bounded bias from place/action/outcome history.

## Emergent attractors and body binding

Comfort is not a hardcoded home behavior. `ComfortAttractorMemory` scores places from repeated pressure relief, safety, familiarity, and predictability. A region may become home-like only if the organism's own experience makes it a reliable pressure reducer.

Body binding is not a labeled avatar body. `ProtoBodyMap` scores motor channels from self-causation, sensory change, body-state change, and prediction reliability. A channel becomes mine-like only when repeated efference/action/consequence traces support that binding.

## Developmental regulation

`DevelopmentalRegulator` is a small state machine, not a mind. It senses recent prediction error, body pressure, and learning progress, then biases the same action selector toward one of four modes:

- `stabilize`: protect integrity and recover pressure before novelty.
- `explore`: seek learnable novelty while pressure is manageable.
- `verify`: revisit uncertain associations when prediction mismatch stays high.
- `consolidate`: pause and replay when the loop is stable enough to strengthen useful traces.

Developmental focus becomes visible in the neural graph through `development:*` neurons and synapses. It does not command behavior directly and does not claim consciousness.


## Prediction-driven motor experimentation

`MotorExperimenter` is a bounded probe regulator. It does not define body parts and does not command behavior. When survival pressure is manageable, it may propose a safe action-channel probe such as move, inspect, touch, or wait. The normal action selector still arbitrates the proposal. After outcome, the same trace updates motor controllability evidence from self-causation, reliability, usefulness, and harm.

This is the first step toward body discovery: action channels become mine-like only when repeated probe/efference/consequence traces make them predictable and useful.


## v008 finite foraging ecology

The ecology is now designed to prevent false intelligence from camping. Objects are finite and gatherable; depleted objects migrate/regrow in underexplored cells. Restorative terrain has local charge that depletes under repeated occupation and recharges only while the organism is away. The action selector receives local targets plus bounded environmental-gradient candidates, and the loop preserves a short-lived goal trace so the organism can finish routes instead of oscillating between attractive targets.

This is still not a scripted survival strategy. The physics create scarcity, consequence, and movement pressure; learned route, comfort, feature, body, motor, and developmental pathways decide what becomes useful.

## v009 sensory abstraction and proto-symbol grounding

Alphabet, color naming, shape naming, and arithmetic must not enter the core as lookup tables. v009 prepares the substrate by adding trace-grounded concept hubs. The world may expose sensory regularities such as `vision:color=red`, `vision:shape=round`, `vision:glyph=A`, and `vision:count=3`, but the organism is not told what these mean.

Concept nodes such as `concept:dimension=color`, `concept:glyph=A`, `concept:numerosity`, or `concept:parity=odd` form only after the organism acts and receives an outcome. These abstractions can then weakly bias prediction and action selection. This is the proper bridge toward later language and arithmetic: first the organism learns that sensory regularities predict consequences; later a teaching surface can attach human labels to already-grounded regularities.

The rule remains: symbols are sensory events before they are words. Numbers are countable sensory regularities before they are arithmetic.


## v010 embodied symbol teaching

Symbols now enter as world events, not as definitions. A teacher surface may expose `vision:symbol_token=red` beside paired sensory evidence such as `vision:paired_color=red`, but the organism does not receive a parser table. During real interaction traces, plasticity grows `symbol:token=*` neurons and binds them to already-grounded `concept:*` hubs.

This is the correct bridge toward alphabet, color words, shape words, numerosity, and later arithmetic. A token is useful only if the organism has experienced it as predictive structure. If symbol bindings are removed, the token should become just another visual pattern again.


## v012 Persistent symbol goal surface

The cue surface is a bounded working-memory pressure. It receives a token only after an embodied cue interaction and then passes that token into the normal action selector. The selector may use the token only through graph-grown symbol/concept weights. This makes delayed symbolic influence measurable without creating a parser or semantic lookup table.


## v013 Priority arbitration

The active symbol-goal surface is now gated by a priority arbiter. The arbiter does not define token meanings. It only decides whether a token pressure can influence the action selector on this tick. This prevents the symbolic layer from overriding survival while still allowing learned symbols to guide behavior when the body is stable.


## v014 Persistent brain state

`kishsyn_core.state` stores the active organism as explicit JSON. This is not a screenshot. It persists the developmental substrate: neural graph, synapses, body pressure, world ecology, memory traces, route memory, comfort basins, proto-body bindings, developmental regulator, motor experiments, symbol goals, priority arbitration, and workspace events. State files are versioned so future brain-shape migrations can be handled deliberately.

Body decay was slowed to one-eighth of the v013 drift constants to keep the organism out of permanent crisis mode and allow longer exploration/consolidation arcs.


## v016 tutor boundary

The tutor surface is intentionally outside the organism boundary. It may introduce lesson pressure, weak label/concept hints, and text exposure, but it cannot select actions, overwrite memories, claim consciousness, or generate a personality for KishSyn. Its outputs are stored as ordinary graph evidence and must remain ablation-visible.

The living loop remains the owner of learning: sensory/text/tutor exposure -> body pressure -> priority/action -> outcome -> plasticity -> memory/replay/workspace.


## v017 autonomous curriculum

`AutonomousTutorCurriculum` is an environmental teacher loop, not a cognitive organ. It periodically selects weakly learned symbol lessons only when body pressure is stable enough, then injects them through `TutorSurface` and `TextCribMemory`. This lets KishSyn keep receiving structured sensory teaching without operator babysitting while preserving the rule that only graph plasticity and later behavior count as learning.


## M4 surface bridge

External sensory data now enters through `SensoryAdapterHub`. This is the only approved doorway for console, math, screen, image, audio, and future hardware sensory packets. The hub produces `SensoryFeature` tokens, then the normal loop handles focus, moments, prediction, action, outcome, plasticity, binding, anatomy, and memory.

`ExpressionSurface` is the first governed motor-output surface. It emits compact console phrases from graph/body/action/outcome evidence.

`NeuralAtlasProjector` is the standard read model for the GUI. Visualization code should read the atlas projection instead of reverse-engineering private module state.

## v032 Forward Architecture: Context, Memory Economy, and Emotion Bias

The active organism line now treats durable graph growth as reusable anatomy, not raw event storage. One-off tick plans and object encounters are traces first. Only repeated usefulness, surprise, instruction pressure, or consolidation pressure should promote experience into durable structure.

Planning now uses `plan_template:*` nodes so repeated plan instances strengthen a reusable template instead of creating permanent `plan:t...` nodes. This keeps growth tied to meaningful novelty and learned affordances rather than tick count.

Emotion now exports a bounded bias contract into focus and expression. This contract is derived from the previous completed tick and is explicitly capped. It may shift salience slightly toward safety, curiosity, or unresolved frustration evidence, and expression may cite the bias as evidence. It cannot select an action or become a personality layer.

The next architecture phase should add contextual affordance cognition:

```text
object category + object file + actor/body + world context + action + provenance -> expected outcome
```

This is required for common-sense distinctions such as an apple healing a game avatar in one context, being scenery in another, serving as an ingredient in another, or being food-for-others and seed-source when KishSyn is embodied as a robot.

## v033 Contextual Affordance Architecture

The living loop now includes `ContextualAffordanceCortex` after counterfactual replay records its outcome and before expression/emotional observation. This placement is intentional: the cortex receives completed lived evidence, not fantasy or hidden labels.

The layer records:

```text
actor profile + world context + sensory object kind + action + outcome + provenance
```

This prevents universal concept-to-action collapse. A red round object can share an object-kind signature across moments while still learning separate affordance records for a game avatar, a robot body, a simulation body, a decorative game world, or a physical ecology.

The first implementation is observational. It writes graph-visible `actor:*`, `context:*`, `object_kind:*`, `provenance:*`, and `affordance:*` neurons and reinforces them from lived outcomes. It also exposes snapshot and persistence state. It does not select actions.

Design patterns:

- Context Object: `WorldContext`
- Value Object: `ActorProfile`, `RealityProvenance`, `ObjectKindSignature`
- Flyweight: `AffordanceRecord`
- Repository: `ContextualAffordanceCortex.records`
- Strategy: weak transfer hypotheses with cross-context inhibition

This is the approved bridge toward common sense, object files, retention pressure, play, and grounded language.


## M14 Interface Affordance Discovery

Desktop/program observation does not become automation. `InterfaceAffordanceCortex` reads replayable observation frames and turns UI roles into reusable signatures and proposal-only affordance contracts. This keeps future OS learning organic and portable across web, CLI, and official desktop `.exe` shells.
