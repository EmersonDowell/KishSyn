# M13: Desktop/OS Observation Substrate

M13 is the first safe embodiment step toward operating-system and program interaction. It does not move the mouse, press keys, write files, browse, call APIs, or control external applications. It lets KishSyn observe desktop/program surfaces as replayable sensory evidence.

## Core law

```text
OS/program surface -> read-only observation frame -> sensory packet -> FocusGate -> MomentFrame -> graph/memory
```

A visible window, button, text field, console line, browser surface, game HUD, or file view is an environment object. It is not a command channel. It must enter through an adapter and become normal sensory evidence before it may affect attention, binding, object files, contextual affordances, memory economy, play, or grounded language.

## New surfaces

`kishsyn_core/desktop_observation.py` adds:

- `DesktopElement`
- `DesktopObservationFrame`
- `DesktopObservationReport`
- `OSObservationSubstrate`

`OSObservationSubstrate` is a facade over future platform-specific capture code. Today it accepts compact deterministic observation frames. Later, Windows screen capture, accessibility APIs, console readers, browser surfaces, and game observers can feed the same frame contract.

## Safety boundary

M13 is observation only.

The substrate may:

- register read-only external surfaces
- propose inspect affordances
- emit sensory packets through `SensoryAdapterHub`
- write reusable graph anatomy such as `external_surface:*`, `external_app:*`, `ui_role:*`, and `ui_label:*`
- persist observation history and adapter registry state under `stores/`

The substrate may not:

- move the pointer
- click
- type
- press keys
- scroll
- write files
- call APIs
- issue shell commands
- control games, browsers, consoles, or apps

Write-like affordances may be proposed for audit, but `AdapterSafetyContract` must block them until later certified dummy/supervised stages exist.

## Why this matters

KishSyn eventually needs to live inside a computer environment, but organic learning requires perception before action. If we jump straight to automation scripts, we create brittle app tricks instead of a developmental nervous system. M13 makes windows, controls, text areas, consoles, and game HUDs visible as objects first.

## Lock criteria

M13 is locked only when:

- desktop observation frames create sensory packets
- external surfaces are registered read-only
- inspect affordances are allowed
- write-like affordances remain blocked
- reusable graph anatomy forms without `os:t...` tick-node leaks
- observation and registry state persist
- runtime-shell policy confirms the project is not HTML-locked and can support a future desktop executable shell

Run:

```powershell
python -m kishsyn_core.tools.run_milestone_m13_lock --steps 180 --seeds 337,171,23 --out stores/_demo/milestone_m13_lock_report.json
```
