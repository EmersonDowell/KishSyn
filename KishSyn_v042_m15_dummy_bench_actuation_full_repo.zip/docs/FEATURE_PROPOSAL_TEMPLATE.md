# Feature Proposal Template

Before adding a living-core feature, answer this.

## Feature name

## Problem

What behavior cannot be learned or measured without this?

## Four-question gate

What does it sense?

What does it predict?

What action can it bias?

What plastic change happens after the result?

## Contracts touched

## Design pattern used

## Ablation proof

What fails when this feature is removed?

## Observatory evidence

What visible trace proves it did something causal?

## Scope impact

Does this add files? If yes, why can it not fit existing files?
