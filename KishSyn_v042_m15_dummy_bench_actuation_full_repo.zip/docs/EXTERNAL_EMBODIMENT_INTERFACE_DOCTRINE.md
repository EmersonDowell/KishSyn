# External Embodiment Interface Doctrine

KishSyn is intended to eventually observe and interact with operating systems, programs, games, consoles, APIs, websites, files, and hardware. That path must stay organic and governed.

The organism should not receive app-specific command shortcuts. It should learn through surfaces, affordances, prediction, action, consequence, trace, memory, and correction.

## Core law

```text
external programs are environments, not hidden control channels
```

Every external surface must become sensory evidence and affordance proposals. It may not bypass focus, MomentFrame capture, contextual affordance memory, object files, prediction, consequence, retention pressure, atlas inspection, or persistence.

## Graduated embodiment stages

```text
simulation
-> dummy_safe_bench
-> supervised_dummy_field
-> read_only_telemetry
-> adapter_quarantine
-> static_inspection
-> certified_actuation
-> approved_physical_actuation
```

Mouse movement, keyboard typing, file writes, API calls, robot movement, or real OS actuation belong only beyond certification and explicit session grants. Until then, adapters may expose observations and proposals, not uncontrolled actions.

## Added contract surface

`kishsyn_core/external_interface.py` defines:

- `ExternalSurface`
- `ExternalAffordance`
- `AdapterSafetyContract`
- `ExternalAdapterRegistry`

This module is intentionally non-actuating. It does not move the mouse, type keys, browse, read private files, write files, call APIs, or control programs. It is the governed shape future adapters must obey.

## Organic learning requirement

Future OS/program learning must preserve the current doctrine:

```text
concept + actor/body + world context + action + provenance + outcome = meaning-in-use
```

A button, menu, text field, game item, browser tab, command prompt, file, or API endpoint is an object/surface in a world context. KishSyn should learn what it can do by observation, safe proposals, simulated/dummy execution, consequences, and retention pressure.

## Release rule

Before real OS write-like control exists, the repo needs:

- a dummy desktop/game/program bench
- read-only telemetry adapters
- adapter quarantine tests
- affordance risk scoring
- explicit human session grants
- action replay logs
- rollback or no-op safety modes
- atlas inspection of external-surface neurons and synapses
- patch gates proving no unsafe default actuation


## M11 Interaction Boundary

Intrinsic play does not grant OS/program control. Future screen, mouse, keyboard, console, browser, game, and API adapters must remain behind the external embodiment quarantine ladder. Play may eventually propose dummy-safe interface experiments only after adapter certification and explicit governance, but M11 itself is non-actuating inside the toy ecology.


## M15 clarification: dummy execution is not real OS execution

The dummy bench is an in-memory developmental sandbox. It may execute fake clicks, fake typing, fake reading, and fake scrolling against fake elements only. It does not weaken the external-interface rule: real OS/program surfaces remain non-actuating.
