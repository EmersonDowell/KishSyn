# Milestone M2: Cross-Modal Binding and Intent Persistence

M2 builds on locked M1. M1 proves raw sensory flow can be focus-selected into MomentFrames and stabilized into provisional circuit anatomy. M2 proves those focused moments can bind across multiple signal kinds and sustain a selected target across time.

## Lock target

```text
focused MomentFrame
-> cross-modal event/object binding
-> persistent intent state
-> action consequence
-> graph-backed reuse
-> benchmark/evidence proof
```

## What M2 is aiming for

M2 does not add a persona layer, planner, or language model. It adds two developmental surfaces:

1. Cross-modal binding: repeated focused moments bind vision, place, terrain, action, outcome, need, and self-causation into reusable event assemblies.
2. Intent persistence: selected targets can remain active across multiple moments while they remain useful, reachable, and safe.

## Locked surfaces

- `kishsyn_core/binding.py` now exposes modality span, cross-modal counts, and stable cross-modal binding counts.
- `kishsyn_core/intent.py` owns explicit start/continue/complete/abandon/expire intent states.
- `kishsyn_core/loop.py` routes selected candidates through the intent model before action consequence.
- `kishsyn_core/state.py` persists intent state and cross-modal binding metadata through JSON brain-state storage.
- `kishsyn_core/benchmark.py` includes `cross-modal binding` and `intent persistence` tasks.
- `kishsyn_core/milestone.py` includes `MilestoneM2LockEvaluator`.

## Lock command

```powershell
python -m kishsyn_core.tools.run_milestone_m2_lock --out stores/_demo/milestone_m2_lock_report.json
```

## Storage decision

The old database layer still does not return in M2. JSON brain-state and JSONL reports remain the source of truth because the anatomy contracts are still evolving. A database returns only as a dedicated storage milestone when we need indexed, append-only graph scale, not before.
