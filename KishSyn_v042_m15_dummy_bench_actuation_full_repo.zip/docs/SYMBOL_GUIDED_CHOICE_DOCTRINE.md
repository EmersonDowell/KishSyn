# Symbol-Guided Choice Doctrine

v011 adds the first proof that grounded symbols can bias action under uncertainty.

The organism still does not receive a parser table. A token becomes useful only when a previous interaction links `symbol:token=*` neurons to `concept:*` hubs through plasticity. When that token later appears as a cue in the sensory frame, it may bias target choice only through those learned graph pathways.

## Law

A symbol may guide choice only if all four conditions hold:

1. The token exists as a sensory feature, such as `vision:symbol_token=red`.
2. Prior interaction has linked that token to one or more grounded `concept:*` nodes.
3. Candidate targets expose sensory features that can enter the same concept family.
4. Removing symbol pathways reduces or eliminates the cue advantage.

This keeps symbol learning downstream of sensory regularity, consequence, plasticity, and replay.

## What this proves

The v011 symbol-choice probe asks whether a learned token prefers a matching sensory candidate over a distractor. It then repeats the score with symbol pathways ablated. A pass means the token is not merely displayed in the GUI; it is causally contributing to a choice preference.

This is still not language comprehension. It is the seed mechanism language needs: symbols as learned control signals over grounded concepts.

## Forbidden shortcut

Do not add dictionaries such as `red = color red`, `A = glyph A`, or `two = count 2` to the organism core. Those mappings may appear as teacher surfaces in the world, but the organism must earn the association through the loop.
