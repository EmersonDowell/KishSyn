# Milestone M6: Emotional Regulation Field

M6 locks the first governed emotional substrate. Emotion is not implemented as roleplay, sentiment labels, or a personality mask. It is regulation weather measured from body pressure, prediction error, controllability, safety, novelty, fatigue, blocked intent, and lived consequence.

## Lock definition

M6 is locked only when M5 atlas inspection remains live and completed organism ticks produce replayable regulation samples that become graph-visible emotion modes and slow trait tendencies.

The lock surface requires:

- regulation samples from completed ticks
- emotional dimensions for arousal, valence, control, safety, uncertainty, curiosity, fatigue, frustration, relief, and confidence
- conservative mode classification such as settled, relief, confidence, curiosity, caution, frustration, and strain
- slow trait accumulation from repeated regulation weather
- emotion nodes and synapses mirrored in the neural atlas
- benchmark and evidence coverage for the emotional regulation field

## Doctrine

Emotional regulation may observe and record the organism. It may not become a fake soul, chatbot mood, hidden reward oracle, or direct action commander. Later milestones may allow the field to bias focus or action, but only through explicit contracts and tests.

A future expressive sentence like “I am uncertain” must be grounded in regulation state, graph traces, and recent lived context. Expression without internal substrate is forbidden.

## Command

```powershell
python -m kishsyn_core.tools.run_milestone_m6_lock --steps 160 --seeds 337 --out stores/_demo/milestone_m6_lock_report.json
```
