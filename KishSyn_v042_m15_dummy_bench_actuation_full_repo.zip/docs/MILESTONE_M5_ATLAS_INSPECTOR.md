# Milestone M5: Neural Atlas Inspector and Synapse Introspection

M5 locks the first usable brain-mirror inspection surface. The neural graph is not a decorative visualization; it is the standardized read-model for KishSyn's growing associative anatomy. Every sensory, focus, moment, binding, anatomy, intent, planning, expression, route, body, and motor surface must become visible as inspectable graph activity.

## Lock definition

M5 is locked only when M4 remains locked and the Observatory can inspect both neurons and synapses through a governed read-only contract.

The lock surface requires:

- atlas surface coverage across multiple organism systems
- a read-only atlas index of active neurons and synapses
- node inspection with surface, kind, label, activation, age, inbound edges, outbound edges, connected nodes, and recent plasticity
- synapse inspection with source/target provenance, weight, update count, polarity, connected endpoint nodes, and recent plasticity
- clickable GUI support for node/synapse selection
- benchmark/evidence coverage for the inspector surface

## Doctrine

Atlas inspection may witness the organism, but it may not steer it. It cannot mutate neurons, rewrite synapses, choose actions, create hidden goals, or act as a reward oracle. It is a read-only witness surface for human understanding and debugging.

The Observatory should increasingly become a neural atlas: click a node, inspect what it is; click a synapse, inspect why it exists; watch activation and plasticity update as KishSyn touches new sensory and motor surfaces.

## Command

```powershell
python -m kishsyn_core.tools.run_milestone_m5_lock --steps 128 --seeds 337 --out stores/_demo/milestone_m5_lock_report.json
```
