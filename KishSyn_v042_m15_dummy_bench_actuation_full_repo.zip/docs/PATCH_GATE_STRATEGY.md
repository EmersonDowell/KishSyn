# Per-Patch Gate Strategy

The full `dev_gates` command remains the release-grade spine check, but it is no longer the only acceptable patch check. Small patches should run the gates for the surfaces they touched, plus an always-run smoke gate.

This prevents the project from wasting minutes rerunning expensive historical locks when the patch did not touch those surfaces.

## Rule

Every patch must run one of these profiles:

```powershell
python -m kishsyn_core.tools.patch_gates --profile quick --run
python -m kishsyn_core.tools.patch_gates --profile current --run
python -m kishsyn_core.tools.patch_gates --profile full --run
```

Use `quick` for docs-only or tiny local changes. Use `current` for the active patch surface. Use `full` before milestone locks, release candidates, or wide architectural changes.

To list commands without running them:

```powershell
python -m kishsyn_core.tools.patch_gates --profile current
```

## Doctrine

A passed gate from a prior patch does not need to be rerun if the new patch did not touch its contract surface, dependencies, persistence path, benchmark path, or shared schema. If any of those changed, rerun the affected gate.

Full `dev_gates` should still be run periodically and before official handoff zips when time allows. Per-patch gates are for disciplined velocity, not lower standards.

## v033 contextual affordance gate addition

The current patch profile now includes `kishsyn_core/tests/test_contextual_affordance.py`. This proves that object-kind signatures reuse patterns instead of object-id noise, that the same object kind can split by actor/context/action/outcome, that cross-context transfer is inhibited, and that contextual affordance state persists.

## v034 M8 hardening gate addition

The contextual affordance test now includes Apple Across Worlds and `AffordanceBiasContract`. The current profile continues to run `test_contextual_affordance.py`, which is enough for this patch surface. Official M8 handoff should also run:

```powershell
python -m kishsyn_core.tools.run_milestone_m8_lock --steps 180 --seeds 337,171,23 --out stores/_demo/milestone_m8_lock_report.json
```


## v035 M9 gate addition

The current patch profile includes the M9 object-file smoke test. Any patch touching object identity, target features, loop persistence, benchmark tasks, or state save/load must preserve:

```text
same kind does not mean same individual
```

The object-file smoke test proves that two apple-like objects may share one object-kind signature while keeping separate object files, distinct feature histories, and transformation evidence.

## v036 M10 gate addition

The current patch profile now covers retention pressure and future external embodiment contracts. Any patch touching memory, persistence, trace compression, stores, adapters, OS/program surfaces, input/output control, or external affordance proposals must preserve:

```text
experience compresses into reusable summaries; external control is observe/propose by default
```

Focused tests:

```powershell
python -m pytest kishsyn_core/tests/test_memory_economy.py -q
python -m pytest kishsyn_core/tests/test_external_interface.py -q
python -m kishsyn_core.tools.run_milestone_m10_lock --steps 180 --seeds 337,171,23 --out stores/_demo/milestone_m10_lock_report.json
```


## M11 Gate Addition

The current patch profile now includes intrinsic-play smoke coverage. It verifies that play proposals form under safe-enough body pressure, reusable play patterns persist, and no `play:t*` node leak turns experimentation history into durable anatomy.


## M12 Gate Addition

The current patch profile now includes grounded-language smoke coverage. It verifies that words bind to lived anchors, language contracts remain non-commanding, grounded-language records persist, and no `language:t*` node leak turns text history into durable graph anatomy.

Focused commands:

```powershell
python -m pytest kishsyn_core/tests/test_grounded_language.py -q
python -m kishsyn_core.tools.run_milestone_m12_lock --steps 180 --seeds 337,171,23 --out stores/_demo/milestone_m12_lock_report.json
```


## M14 Gate Addition

Patches touching desktop/program observation, interface affordance discovery, external adapters, UI element roles, or future desktop `.exe` surfaces must preserve:

- UI element signatures form from observation frames.
- Interface affordance records are reusable and do not create `ui:t*` durable node leaks.
- Write-like candidates remain proposal-only and blocked by contract.
- Interface-affordance state persists through save/load.
- Runtime shells remain portable and not HTML-locked.

Focused gates:

```powershell
python -m pytest kishsyn_core/tests/test_milestone_m14_interface_affordance.py -q
python -m kishsyn_core.tools.run_milestone_m14_lock --steps 180 --seeds 337,171,23 --out stores/_demo/milestone_m14_lock_report.json
```


## M15 gate addition

Patch gates now include a dummy-bench smoke path: a fake desktop frame is observed, dummy actions execute inside the sealed bench, sensory/graph evidence is produced, and real OS authority remains zero.
