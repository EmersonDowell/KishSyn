# M15: Dummy Bench Actuation

M15 is the first consequence-bearing interface practice layer. It does **not** grant real desktop, file, shell, browser, network, API, mouse, keyboard, or physical control.

The doctrine is simple:

```text
observe real surfaces first; execute only inside sealed dummy benches; learn from consequence before supervised real-world grants
```

## Why this exists

M13 allowed desktop/program observation. M14 allowed interface affordance discovery. M15 gives those proposal-only affordances a safe place to become lived outcomes. A button can be clicked in a fake app. A text field can receive fake text. A console can be read. The result can feed sensory packets and reusable graph anatomy.

This gives KishSyn organic interaction learning without brittle app automation and without touching Emerson's real operating system.

## Hard boundaries

Allowed in M15:

- observe the dummy bench as a desktop-like surface
- propose dummy actions from interface affordance records
- execute inspect/read/click/type/scroll-like actions inside the in-memory bench
- write dummy sensory feedback
- write reusable graph anatomy such as `dummy_action_template:*`
- persist dummy bench state into `stores/` brain-state JSON

Blocked in M15:

- real mouse movement
- real clicking
- real typing
- real scrolling
- shell commands
- file writes
- browser automation
- network/API calls
- process/window handles
- physical actuation

## Design patterns

- **Command**: `DummyActionProposal` is inert until the dummy actuator executes it.
- **Contract Object**: `DummyActuationContract` proves dummy-only authority and denies real OS authority.
- **Sandbox Adapter**: `DummyBenchActuator` mutates only `DummyBenchSurface`.
- **Aggregate Root**: `DummyBenchSurface` owns all fake UI state.
- **Flyweight anatomy**: graph writes reusable `dummy_action_template:*` and `dummy_element_kind:*`, never tick-specific nodes.
- **Memento**: dummy state persists and restores through explicit JSON brain state.

## Lock command

```powershell
python -m kishsyn_core.tools.run_milestone_m15_lock --steps 180 --seeds 337,171,23 --out stores/_demo/milestone_m15_lock_report.json
```

The lock passes only if dummy actions execute, change the fake surface, produce sensory and graph evidence, bridge from interface affordance records, and keep real OS authority at zero.
