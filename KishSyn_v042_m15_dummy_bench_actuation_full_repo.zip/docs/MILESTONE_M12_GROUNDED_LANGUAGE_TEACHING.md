# M12 Grounded Language and Teaching

M12 adds grounded language as a recall and teaching surface, not a chatbot mind. Words are allowed to become useful only when they bind to lived organism anchors: concepts, object-kind signatures, object files, contextual affordance records, outcomes, action history, memory pressure, and retained summaries.

## Law

Language is grounded recall evidence. It may not command action, overwrite goals, fake understanding, become KishSyn's personality, or bypass the organism loop.

The approved M12 formula is:

```text
word + lived anchor + actor/body + world context + provenance + outcome = grounded recall route
```

This is deliberately weaker than direct semantic truth. A word like `apple` may recall a red round object-kind, an individual object file, an affordance seen in a game, or a memory summary. It does not universally mean `edible`, `heal`, `ingredient`, or `plant seed` until those meanings are learned in a specific actor/body/world context.

## What M12 adds

- `kishsyn_core/grounded_language.py`
- `GroundedLexemeRecord`
- `LanguageGroundingContract`
- `GroundedLanguageCortex`
- loop integration after lived outcome and memory-economy scoring
- state persistence for grounded-language records
- graph-visible `language_word:*` and lived-anchor pathways
- M12 tests and lock tooling

## Design patterns

- Repository: `GroundedLanguageCortex` stores reusable word-anchor records.
- Flyweight: repeated exposures strengthen one record instead of creating tick-specific language nodes.
- Adapter: text tokens are read from existing sensory frames; language does not become a separate parser brain.
- Contract Object: `LanguageGroundingContract` exposes evidence and explicitly states `may_command_action=False`.

## Boundaries

M12 may:

- bind words to concepts, object kinds, object files, affordance records, actions, outcomes, and memory summaries;
- expose inspectable recall evidence;
- persist grounded word-anchor records in the brain state;
- help future tutor/API surfaces teach through sensory and memory routes.

M12 may not:

- select actions;
- issue OS/program commands;
- act as a language model persona;
- treat external tutor text as truth without lived anchors;
- collapse game rules, robot-world rules, and human/animal affordances into one universal meaning.

## Lock command

```powershell
python -m kishsyn_core.tools.run_milestone_m12_lock --steps 180 --seeds 337,171,23 --out stores/_demo/milestone_m12_lock_report.json
```

M12 is locked only when the probe proves language binds to lived anchors, contracts remain non-commanding, records persist through the loop, and no `language:t*` tick-id node leak appears.
