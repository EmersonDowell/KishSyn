# Route Memory and Observatory Doctrine

v004 adds the first route-memory surface. Route memory is not a planning mind and not a new consciousness module. It is a hippocampal-inspired trace scaffold that binds places, movements, needs, and outcomes into plastic graph edges.

A place becomes useful only when experience repeatedly connects it to relief, novelty, pain, blockage, or depletion. The action selector may bias toward or away from target places using those learned route values, but the reflex loop remains the authority.

The observatory is the main scientific instrument. It must show the living world and neural/synaptic growth side by side, full-screen, with zoom controls. It should make intelligence formation visible as changing action, prediction, outcome, plasticity, replay, route bias, and graph growth. It must not become a decorative dashboard.

Rules:

1. Route memory must only update from real tick traces.
2. Route bias may influence action selection, but it may not override body pressure or safety gates absolutely.
3. The neural graph must expose route, place, terrain, target, action, need, and outcome nodes.
4. The observatory must prioritize live causal evidence over aesthetic effects.
5. Future navigation work must add ablation proof before claiming improved intelligence.


## v005 continuation

Route memory is now joined by comfort-attractor memory and proto-body binding. These are still not named mind modules. They are trace scaffolds: places become valuable through repeated recovery/safety/predictability, and actions become body-like through repeated self-caused sensory and body-state consequences.
