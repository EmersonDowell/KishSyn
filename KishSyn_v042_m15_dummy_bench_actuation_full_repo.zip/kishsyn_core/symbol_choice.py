"""Symbol-guided choice probes for grounded token use.

This module does not teach definitions. It asks whether symbol bindings that
already grew inside the neural graph can bias a choice between matching and
mismatching sensory candidates. A token is useful only when graph pathways make
it predictive over grounded concept hubs.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .neural_graph import NeuralGrowthGraph


FAMILY_TO_FEATURE = {
    "color": "vision:color",
    "shape": "vision:shape",
    "glyph": "vision:glyph",
    "count": "vision:count",
}


@dataclass(frozen=True)
class SymbolChoiceTrial:
    token: str
    concept: str
    matching_features: tuple[str, ...]
    distractor_features: tuple[str, ...]
    matching_score: float
    distractor_score: float
    ablated_matching_score: float
    passed: bool
    evidence: tuple[str, ...] = ()


@dataclass(frozen=True)
class SymbolChoiceReport:
    trial_count: int
    passed_count: int
    accuracy: float
    ablation_delta: float
    trials: tuple[SymbolChoiceTrial, ...] = field(default_factory=tuple)

    def as_dict(self) -> dict[str, object]:
        return {
            "trial_count": self.trial_count,
            "passed_count": self.passed_count,
            "accuracy": round(self.accuracy, 4),
            "ablation_delta": round(self.ablation_delta, 4),
            "trials": [
                {
                    "token": trial.token,
                    "concept": trial.concept,
                    "matching_features": list(trial.matching_features),
                    "distractor_features": list(trial.distractor_features),
                    "matching_score": round(trial.matching_score, 4),
                    "distractor_score": round(trial.distractor_score, 4),
                    "ablated_matching_score": round(trial.ablated_matching_score, 4),
                    "passed": trial.passed,
                    "evidence": list(trial.evidence),
                }
                for trial in self.trials
            ],
        }


class SymbolChoiceProbe:
    """Probe whether learned tokens can bias choices under uncertainty."""

    def evaluate(self, graph: NeuralGrowthGraph, *, limit: int = 12) -> SymbolChoiceReport:
        trials: list[SymbolChoiceTrial] = []
        ablated = graph.symbol_ablated_copy(keep_neurons=True)
        for token, concept, weight in self._strong_symbol_bindings(graph):
            if weight <= 0.01:
                continue
            matching = self._features_for_concept(concept)
            distractor = self._distractor_for_concept(graph, concept)
            if not matching or not distractor:
                continue
            scene = (f"vision:symbol_token={token}",)
            matching_score, evidence = graph.symbol_cue_score(scene, matching)
            distractor_score, _ = graph.symbol_cue_score(scene, distractor)
            ablated_matching_score, _ = ablated.symbol_cue_score(scene, matching)
            trials.append(
                SymbolChoiceTrial(
                    token=token,
                    concept=concept,
                    matching_features=matching,
                    distractor_features=distractor,
                    matching_score=matching_score,
                    distractor_score=distractor_score,
                    ablated_matching_score=ablated_matching_score,
                    passed=matching_score > distractor_score + 0.015 and matching_score > ablated_matching_score + 0.015,
                    evidence=evidence[:4],
                )
            )
            if len(trials) >= limit:
                break
        passed = sum(1 for trial in trials if trial.passed)
        accuracy = 0.0 if not trials else passed / len(trials)
        delta = 0.0 if not trials else sum(trial.matching_score - trial.ablated_matching_score for trial in trials) / len(trials)
        return SymbolChoiceReport(
            trial_count=len(trials),
            passed_count=passed,
            accuracy=accuracy,
            ablation_delta=delta,
            trials=tuple(trials),
        )

    def _strong_symbol_bindings(self, graph: NeuralGrowthGraph) -> list[tuple[str, str, float]]:
        rows: list[tuple[str, str, float]] = []
        for (source, target), synapse in graph.synapses.items():
            if not source.startswith("symbol:token=") or not target.startswith("concept:"):
                continue
            token = source.split("=", 1)[1]
            rows.append((token, target, synapse.weight))
        rows.sort(key=lambda item: (-item[2], item[0], item[1]))
        return rows

    def _features_for_concept(self, concept: str) -> tuple[str, ...]:
        family, value = self._family_and_value(concept)
        prefix = FAMILY_TO_FEATURE.get(family)
        if prefix is None:
            return ()
        return (f"{prefix}={value}", "vision:quantity=available")

    def _distractor_for_concept(self, graph: NeuralGrowthGraph, concept: str) -> tuple[str, ...]:
        family, value = self._family_and_value(concept)
        prefix = FAMILY_TO_FEATURE.get(family)
        if prefix is None:
            return ()
        alternatives = sorted(
            node.node_id.split("=", 1)[1]
            for node in graph.neurons.values()
            if node.kind == "concept" and node.node_id.startswith(f"concept:{family}=") and node.node_id.split("=", 1)[1] != value
        )
        if not alternatives:
            fallback = {
                "color": "not_" + value,
                "shape": "not_" + value,
                "glyph": "Z" if value != "Z" else "A",
                "count": "9" if value != "9" else "1",
            }.get(family)
            if fallback is None:
                return ()
            alternatives = [fallback]
        return (f"{prefix}={alternatives[0]}", "vision:quantity=available")

    def _family_and_value(self, concept: str) -> tuple[str, str]:
        payload = concept.split(":", 1)[1]
        if "=" not in payload:
            return payload, ""
        family, value = payload.split("=", 1)
        return family, value
