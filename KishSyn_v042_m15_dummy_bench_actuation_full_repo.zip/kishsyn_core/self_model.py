"""Self/world boundary model for the reflex-first core.

This is not a selfhood claim. It is a causal accounting layer: did the world
change because of the organism's own action, or did the world change around it?
"""

from __future__ import annotations

from dataclasses import dataclass

from .contracts import EfferenceCopy, Outcome


@dataclass(frozen=True)
class SelfBoundaryAssessment:
    """A tiny causal estimate for one tick."""

    self_causation: float
    world_causation: float
    label: str
    reason: str


class SelfBoundaryModel:
    """Compares efference copy, outcome, and unsought world events."""

    def __init__(self) -> None:
        self.samples: list[SelfBoundaryAssessment] = []

    def evaluate(
        self,
        *,
        efference: EfferenceCopy,
        outcome: Outcome,
        world_events: tuple[str, ...] = (),
    ) -> SelfBoundaryAssessment:
        action = efference.action
        acted_on_world = action.kind in {"move", "inspect", "touch", "eat", "drink", "rest", "avoid"} and outcome.kind != "blocked"
        if acted_on_world and world_events:
            assessment = SelfBoundaryAssessment(
                self_causation=0.70,
                world_causation=0.45,
                label="mixed",
                reason="own motor command caused an outcome while the world also changed",
            )
        elif acted_on_world:
            assessment = SelfBoundaryAssessment(
                self_causation=0.92,
                world_causation=0.05,
                label="self_caused",
                reason="efference copy matched a controllable action outcome",
            )
        elif world_events:
            assessment = SelfBoundaryAssessment(
                self_causation=0.08,
                world_causation=0.90,
                label="world_caused",
                reason="environment changed without useful motor consequence",
            )
        else:
            assessment = SelfBoundaryAssessment(
                self_causation=0.24 if action.kind != "wait" else 0.04,
                world_causation=0.18,
                label="uncertain",
                reason="weak or blocked consequence leaves causation unresolved",
            )
        self.samples.append(assessment)
        return assessment

    def snapshot(self) -> dict[str, object]:
        recent = self.samples[-12:]
        if not recent:
            return {"sample_count": 0, "last": None, "mean_self_causation": 0.0, "mean_world_causation": 0.0}
        return {
            "sample_count": len(self.samples),
            "last": recent[-1].__dict__,
            "mean_self_causation": round(sum(s.self_causation for s in recent) / len(recent), 4),
            "mean_world_causation": round(sum(s.world_causation for s in recent) / len(recent), 4),
        }
