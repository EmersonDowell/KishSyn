"""Developmental anatomy growth for focused binding candidates.

The anatomy engine marks repeated useful bindings as provisional circuits. It is
not a finished brain map; it is the first controlled surface for letting the
organism grow reusable internal structure from focused moments.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from .binding import BindingCandidate
from .contracts import PlasticityEvent
from .moment import MomentFrame
from .neural_graph import NeuralGrowthGraph


@dataclass
class CircuitCandidate:
    circuit_id: str
    source_binding_id: str
    signature: str
    first_tick: int
    last_tick: int
    reuse_count: int = 0
    strength: float = 0.0
    role: str = "event"

    def as_dict(self) -> dict[str, Any]:
        return {
            "circuit_id": self.circuit_id,
            "source_binding_id": self.source_binding_id,
            "signature": self.signature,
            "first_tick": self.first_tick,
            "last_tick": self.last_tick,
            "reuse_count": self.reuse_count,
            "strength": round(float(self.strength), 4),
            "role": self.role,
        }


class AnatomyGrowthEngine:
    """Promotes stable focused bindings into provisional circuit anatomy.

    Pattern: State Machine. Candidates move from observed binding to provisional
    circuit only after repeated coactivation and stability thresholds are met.
    """

    def __init__(self, *, promote_count: int = 2, promote_stability: float = 0.34) -> None:
        self.promote_count = max(1, int(promote_count))
        self.promote_stability = max(0.05, min(1.0, float(promote_stability)))
        self.circuits: dict[str, CircuitCandidate] = {}
        self.promotion_count = 0
        self.update_count = 0
        self.last_circuit_id: str | None = None

    def observe(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph,
        moment: MomentFrame,
        binding: BindingCandidate | None,
    ) -> tuple[PlasticityEvent, ...]:
        if binding is None:
            return ()
        self.update_count += 1
        if binding.count < self.promote_count or binding.stability < self.promote_stability:
            return ()
        circuit_id = "circuit:" + binding.binding_id.split("=", 1)[-1]
        circuit = self.circuits.get(circuit_id)
        if circuit is None:
            circuit = CircuitCandidate(
                circuit_id=circuit_id,
                source_binding_id=binding.binding_id,
                signature=binding.signature,
                first_tick=tick,
                last_tick=tick,
                role=self._role_for(moment),
            )
            self.circuits[circuit_id] = circuit
            self.promotion_count += 1
        circuit.reuse_count += 1
        circuit.last_tick = tick
        circuit.strength = min(1.0, max(circuit.strength, binding.stability) + 0.035)
        self.last_circuit_id = circuit_id
        graph.ensure_neuron(circuit_id, kind="circuit", label=f"{circuit.role}:{binding.signature[:72]}", tick=tick)
        graph.activate(circuit_id, amount=max(0.35, circuit.strength), tick=tick)
        outcome_node = f"outcome:{moment.outcome}"
        need_node = f"need:{moment.dominant_need}"
        events = [
            graph.reinforce(binding.binding_id, circuit_id, amount=0.030, tick=tick, reason="binding promoted into provisional circuit"),
            graph.reinforce(circuit_id, outcome_node, amount=0.018, tick=tick, reason="circuit consequence reuse"),
            graph.reinforce(need_node, circuit_id, amount=0.014, tick=tick, reason="need recruits provisional circuit"),
        ]
        return tuple(events)

    def snapshot(self) -> dict[str, Any]:
        circuits = sorted(self.circuits.values(), key=lambda item: (-item.strength, -item.reuse_count, item.circuit_id))
        return {
            "circuit_count": len(circuits),
            "promotion_count": self.promotion_count,
            "update_count": self.update_count,
            "last_circuit_id": self.last_circuit_id,
            "top": [circuit.as_dict() for circuit in circuits[:12]],
        }

    def state(self) -> dict[str, Any]:
        return {
            "promote_count": self.promote_count,
            "promote_stability": self.promote_stability,
            "promotion_count": self.promotion_count,
            "update_count": self.update_count,
            "last_circuit_id": self.last_circuit_id,
            "circuits": [circuit.as_dict() for circuit in self.circuits.values()],
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "AnatomyGrowthEngine":
        engine = cls(
            promote_count=int(data.get("promote_count", 2)),
            promote_stability=float(data.get("promote_stability", 0.34)),
        )
        engine.promotion_count = int(data.get("promotion_count", 0))
        engine.update_count = int(data.get("update_count", 0))
        engine.last_circuit_id = data.get("last_circuit_id")
        for item in data.get("circuits", []):
            circuit = CircuitCandidate(
                circuit_id=str(item.get("circuit_id", "")),
                source_binding_id=str(item.get("source_binding_id", "")),
                signature=str(item.get("signature", "")),
                first_tick=int(item.get("first_tick", 0)),
                last_tick=int(item.get("last_tick", 0)),
                reuse_count=int(item.get("reuse_count", 0)),
                strength=float(item.get("strength", 0.0)),
                role=str(item.get("role", "event")),
            )
            if circuit.circuit_id:
                engine.circuits[circuit.circuit_id] = circuit
        return engine

    def _role_for(self, moment: MomentFrame) -> str:
        if moment.outcome == "relief":
            return "regulation"
        if moment.outcome == "pain":
            return "avoidance"
        if moment.outcome == "novelty":
            return "exploration"
        if moment.prediction_error >= 0.65:
            return "mismatch"
        return "event"
