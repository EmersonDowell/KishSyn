"""Attention and focus gating for the focused-moment substrate.

The focus gate is the first locked surface of Milestone M1. It does not decide
what the organism should think. It selects which incoming sensory features earn
entry into the active moment, based on body pressure, novelty, goal relevance,
and overload cost.
"""

from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass
from statistics import mean
from typing import Any

from .contracts import BodyState, SensoryFeature, SensoryFrame
from .neural_graph import NeuralGrowthGraph


@dataclass(frozen=True)
class FocusSignal:
    """One sensory feature after salience scoring.

    Pattern: Specification. The signal keeps component scores visible so focus
    can be tested and inspected instead of becoming an invisible heuristic.
    """

    token: str
    kind: str
    intensity: float
    salience: float
    selected: bool
    reason: str
    components: dict[str, float]

    def as_dict(self) -> dict[str, Any]:
        return {
            "token": self.token,
            "kind": self.kind,
            "intensity": round(float(self.intensity), 4),
            "salience": round(float(self.salience), 4),
            "selected": self.selected,
            "reason": self.reason,
            "components": {key: round(float(value), 4) for key, value in self.components.items()},
        }


@dataclass(frozen=True)
class FocusReport:
    """A replayable attention decision for one raw sensory frame."""

    tick: int
    raw_count: int
    selected_count: int
    rejected_count: int
    selectivity: float
    overload: float
    dominant_need: str
    active_symbol_tokens: tuple[str, ...]
    selected_signals: tuple[FocusSignal, ...]
    rejected_signals: tuple[FocusSignal, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "tick": self.tick,
            "raw_count": self.raw_count,
            "selected_count": self.selected_count,
            "rejected_count": self.rejected_count,
            "selectivity": round(float(self.selectivity), 4),
            "overload": round(float(self.overload), 4),
            "dominant_need": self.dominant_need,
            "active_symbol_tokens": list(self.active_symbol_tokens),
            "selected": [signal.as_dict() for signal in self.selected_signals],
            "rejected": [signal.as_dict() for signal in self.rejected_signals[:10]],
        }

    def to_frame(self, original: SensoryFrame) -> SensoryFrame:
        selected_tokens = [signal.token for signal in self.selected_signals]
        features = []
        used = [False for _ in selected_tokens]
        for feature in original.features:
            for index, token in enumerate(selected_tokens):
                if not used[index] and feature.token == token:
                    features.append(feature)
                    used[index] = True
                    break
            if len(features) >= len(selected_tokens):
                break
        if not features and original.features:
            features = [max(original.features, key=lambda item: item.intensity)]
        raw = dict(original.raw)
        raw["focus"] = self.as_dict()
        return SensoryFrame(tick=original.tick, features=tuple(features), raw=raw)


class FocusGate:
    """Selects a bounded active sensory frame from raw incoming features.

    Pattern: Strategy + Memento. The scoring policy is explicit and swappable;
    recent focus reports are retained for observatory/test inspection.
    """

    def __init__(self, *, max_features: int = 24, history: int = 96) -> None:
        self.max_features = max(4, int(max_features))
        self.history: deque[FocusReport] = deque(maxlen=max(8, int(history)))
        self.total_selected = 0
        self.total_rejected = 0

    def select(
        self,
        *,
        tick: int,
        frame: SensoryFrame,
        body: BodyState,
        graph: NeuralGrowthGraph,
        active_symbol_tokens: tuple[str, ...] = (),
        learning_focus: object | None = None,
        emotion_bias: object | None = None,
    ) -> FocusReport:
        dominant_need = body.dominant_need()
        scored = [
            self._score_feature(
                feature,
                body=body,
                dominant_need=dominant_need,
                graph=graph,
                active_symbol_tokens=active_symbol_tokens,
                learning_focus=learning_focus,
                emotion_bias=emotion_bias,
            )
            for feature in frame.features
        ]
        ranked = sorted(scored, key=lambda signal: (-signal.salience, signal.token))
        selected_raw = ranked[: self.max_features]
        rejected_raw = ranked[self.max_features :]
        selected = tuple(
            FocusSignal(
                token=signal.token,
                kind=signal.kind,
                intensity=signal.intensity,
                salience=signal.salience,
                selected=True,
                reason=signal.reason,
                components=signal.components,
            )
            for signal in selected_raw
        )
        rejected = tuple(
            FocusSignal(
                token=signal.token,
                kind=signal.kind,
                intensity=signal.intensity,
                salience=signal.salience,
                selected=False,
                reason=signal.reason,
                components=signal.components,
            )
            for signal in rejected_raw
        )
        raw_count = len(frame.features)
        selected_count = len(selected)
        rejected_count = max(0, raw_count - selected_count)
        selectivity = 0.0 if raw_count <= 0 else round(rejected_count / raw_count, 4)
        overload = max(0.0, (raw_count - self.max_features) / max(1.0, float(raw_count)))
        report = FocusReport(
            tick=tick,
            raw_count=raw_count,
            selected_count=selected_count,
            rejected_count=rejected_count,
            selectivity=selectivity,
            overload=round(overload, 4),
            dominant_need=dominant_need,
            active_symbol_tokens=active_symbol_tokens,
            selected_signals=selected,
            rejected_signals=rejected,
        )
        self.history.append(report)
        self.total_selected += selected_count
        self.total_rejected += rejected_count
        return report

    def snapshot(self) -> dict[str, Any]:
        reports = list(self.history)
        return {
            "max_features": self.max_features,
            "report_count": len(reports),
            "total_selected": self.total_selected,
            "total_rejected": self.total_rejected,
            "mean_selectivity": round(mean([item.selectivity for item in reports]) if reports else 0.0, 4),
            "last": reports[-1].as_dict() if reports else None,
            "recent": [item.as_dict() for item in reports[-8:]],
        }

    def state(self) -> dict[str, Any]:
        return {
            "max_features": self.max_features,
            "total_selected": self.total_selected,
            "total_rejected": self.total_rejected,
            "history": [item.as_dict() for item in self.history],
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "FocusGate":
        gate = cls(max_features=int(data.get("max_features", 24)))
        gate.total_selected = int(data.get("total_selected", 0))
        gate.total_rejected = int(data.get("total_rejected", 0))
        for item in data.get("history", [])[-gate.history.maxlen :]:
            gate.history.append(_focus_report_from_dict(item))
        return gate

    def _score_feature(
        self,
        feature: SensoryFeature,
        *,
        body: BodyState,
        dominant_need: str,
        graph: NeuralGrowthGraph,
        active_symbol_tokens: tuple[str, ...],
        learning_focus: object | None,
        emotion_bias: object | None,
    ) -> FocusSignal:
        token = feature.token
        base = max(0.0, min(1.0, feature.intensity)) * 0.30
        body_relevance = self._body_relevance(feature, dominant_need)
        novelty = 0.20 if token not in graph.neurons else 0.0
        if getattr(learning_focus, "mode", "") in {"explore", "verify"}:
            novelty *= 1.25
        goal_relevance = self._goal_relevance(feature, active_symbol_tokens, graph)
        danger = self._danger_relevance(feature, body)
        emotion_relevance = self._emotion_relevance(feature, emotion_bias)
        place_relevance = 0.08 if feature.kind in {"place", "terrain"} else 0.0
        text_relevance = (0.58 if feature.kind == "text" and feature.key in {"word", "surface"} else 0.24 if feature.kind == "text" else 0.0)
        adapter_relevance = 0.0
        if feature.kind in {"screen", "image", "audio", "math", "console", "sensor"}:
            adapter_relevance = 0.30
            if feature.kind == "math" and feature.key in {"operator", "truth", "result"}:
                adapter_relevance = 0.56
            if feature.kind in {"screen", "image"} and feature.key in {"descriptor", "surface"}:
                adapter_relevance = 0.38
            if feature.kind == "audio" and feature.key in {"descriptor", "surface"}:
                adapter_relevance = 0.36
        overload_cost = 0.012 * max(0, len(token) - 34)
        components = {
            "base": base,
            "body": body_relevance,
            "novelty": novelty,
            "goal": goal_relevance,
            "danger": danger,
            "emotion": emotion_relevance,
            "place": place_relevance,
            "text": text_relevance,
            "adapter": adapter_relevance,
            "overload_cost": overload_cost,
        }
        salience = max(0.0, min(2.0, sum(value for key, value in components.items() if key != "overload_cost") - overload_cost))
        reason = self._dominant_component_reason(components)
        return FocusSignal(
            token=token,
            kind=feature.kind,
            intensity=feature.intensity,
            salience=round(salience, 4),
            selected=False,
            reason=reason,
            components=components,
        )

    def _body_relevance(self, feature: SensoryFeature, need: str) -> float:
        if feature.kind == "body":
            return 0.42
        if need == "energy" and feature.key == "shape" and feature.value == "round":
            return 0.30
        if need == "hydration" and feature.key == "shape" and feature.value == "tall":
            return 0.32
        if need == "fatigue" and feature.key == "shape" and feature.value == "soft":
            return 0.30
        if need in {"curiosity", "uncertainty"} and feature.key in {"glyph", "symbol_token", "teaches"}:
            return 0.34
        if need == "integrity" and feature.value in {"spike", "jagged", "dark", "black", "crimson"}:
            return 0.40
        return 0.0

    def _goal_relevance(self, feature: SensoryFeature, active_symbol_tokens: tuple[str, ...], graph: NeuralGrowthGraph) -> float:
        if not active_symbol_tokens:
            return 0.0
        if feature.value in active_symbol_tokens:
            return 0.42
        feature_concepts = set(graph.concepts_for_feature(feature.token))
        for token in active_symbol_tokens:
            symbol_node = f"symbol:token={token}"
            for concept in feature_concepts:
                if graph.weight(symbol_node, concept) > 0.02:
                    return 0.22
        return 0.0

    def _emotion_relevance(self, feature: SensoryFeature, emotion_bias: object | None) -> float:
        if emotion_bias is None:
            return 0.0
        safety_bias = float(getattr(emotion_bias, "safety_bias", 0.0) or 0.0)
        curiosity_bias = float(getattr(emotion_bias, "curiosity_bias", 0.0) or 0.0)
        frustration_bias = float(getattr(emotion_bias, "frustration_bias", 0.0) or 0.0)
        value = 0.0
        if feature.value in {"spike", "jagged", "dark", "black", "crimson"} or feature.key in {"integrity", "hazard"}:
            value += safety_bias
        if feature.key in {"glyph", "symbol_token", "teaches"} or feature.kind in {"text", "screen", "image", "audio", "math"}:
            value += curiosity_bias
        if feature.kind in {"body", "action", "outcome"} or feature.key in {"blocked", "depleted"}:
            value += frustration_bias
        return max(0.0, min(0.32, value))

    def _danger_relevance(self, feature: SensoryFeature, body: BodyState) -> float:
        if feature.value not in {"spike", "jagged", "dark", "black", "crimson"}:
            return 0.0
        integrity_need = 1.0 - body.integrity
        return 0.22 + integrity_need * 0.40

    def _dominant_component_reason(self, components: dict[str, float]) -> str:
        candidates = {key: value for key, value in components.items() if key != "overload_cost"}
        key, value = max(candidates.items(), key=lambda item: item[1])
        return key if value > 0.0 else "ambient"


def _focus_report_from_dict(data: dict[str, Any]) -> FocusReport:
    selected = tuple(_focus_signal_from_dict(item, selected=True) for item in data.get("selected", []))
    rejected = tuple(_focus_signal_from_dict(item, selected=False) for item in data.get("rejected", []))
    return FocusReport(
        tick=int(data.get("tick", 0)),
        raw_count=int(data.get("raw_count", 0)),
        selected_count=int(data.get("selected_count", len(selected))),
        rejected_count=int(data.get("rejected_count", len(rejected))),
        selectivity=float(data.get("selectivity", 0.0)),
        overload=float(data.get("overload", 0.0)),
        dominant_need=str(data.get("dominant_need", "unknown")),
        active_symbol_tokens=tuple(str(item) for item in data.get("active_symbol_tokens", [])),
        selected_signals=selected,
        rejected_signals=rejected,
    )


def _focus_signal_from_dict(data: dict[str, Any], *, selected: bool) -> FocusSignal:
    return FocusSignal(
        token=str(data.get("token", "")),
        kind=str(data.get("kind", "unknown")),
        intensity=float(data.get("intensity", 0.0)),
        salience=float(data.get("salience", 0.0)),
        selected=bool(data.get("selected", selected)),
        reason=str(data.get("reason", "ambient")),
        components={str(key): float(value) for key, value in dict(data.get("components", {})).items()},
    )
