"""Dummy-bench actuation for safe interface learning.

M15 is the first place KishSyn may execute interface-like actions, but only
inside a sealed in-memory bench. The bench is not the desktop, not the file
system, not a browser, and not a program automation handle. It exists so
proposal-only interface affordances can produce consequences, traces, and
plasticity before any real OS action is ever considered.
"""

from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass, field
from typing import Any, Literal

from .contracts import PlasticityEvent
from .desktop_observation import DesktopElement, DesktopObservationFrame
from .neural_graph import NeuralGrowthGraph
from .sensory import SensoryAdapterHub

DummyBenchActionKind = Literal["inspect", "read", "click", "type_text", "press_key", "scroll", "unknown"]
_WRITE_LIKE = {"click", "type_text", "press_key", "scroll"}


@dataclass
class DummyBenchElement:
    """Mutable fake UI element in a sealed dummy surface.

    Pattern: Entity. This represents sandbox state only. It never stores live OS
    handles, coordinates from a real desktop, window handles, file handles, or
    process identifiers.
    """

    element_id: str
    role: str
    label: str = ""
    bounds: tuple[int, int, int, int] = (0, 0, 0, 0)
    interactable: bool = False
    text: str = ""
    clicked_count: int = 0
    focused: bool = False
    scroll_position: int = 0

    def observation(self) -> DesktopElement:
        label = self.label
        if self.role in {"text_field", "console"} and self.text:
            label = f"{label}: {self.text}"[:120]
        return DesktopElement(
            element_id=self.element_id,
            role=self.role,  # type: ignore[arg-type]
            label=label,
            bounds=self.bounds,
            interactable=self.interactable,
            confidence=0.92,
        )

    def as_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["bounds"] = list(self.bounds)
        return payload

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "DummyBenchElement":
        bounds = data.get("bounds", (0, 0, 0, 0))
        return cls(
            element_id=str(data.get("element_id", "element")),
            role=str(data.get("role", "unknown")),
            label=str(data.get("label", "")),
            bounds=tuple(int(v) for v in tuple(bounds)[:4]) if len(tuple(bounds)) >= 4 else (0, 0, 0, 0),
            interactable=bool(data.get("interactable", False)),
            text=str(data.get("text", "")),
            clicked_count=int(data.get("clicked_count", 0)),
            focused=bool(data.get("focused", False)),
            scroll_position=int(data.get("scroll_position", 0)),
        )


@dataclass
class DummyBenchSurface:
    """A fake desktop/program surface for supervised developmental practice.

    Pattern: Aggregate Root. All mutable dummy UI state is contained here. If a
    proposal targets any surface outside this aggregate, the actuator blocks it.
    """

    surface_id: str = "dummy_desktop_practice_app"
    title: str = "Dummy Practice App"
    active_application: str = "dummy_practice.exe"
    elements: dict[str, DummyBenchElement] = field(default_factory=dict)
    event_log: list[str] = field(default_factory=list)

    @classmethod
    def default(cls) -> "DummyBenchSurface":
        surface = cls()
        surface.elements = {
            "main_window": DummyBenchElement("main_window", "window", "Dummy Practice App", (0, 0, 900, 620), False),
            "note_field": DummyBenchElement("note_field", "text_field", "note input", (24, 96, 560, 260), True),
            "send_button": DummyBenchElement("send_button", "button", "Send", (610, 96, 96, 42), True),
            "file_menu": DummyBenchElement("file_menu", "menu", "File", (4, 26, 48, 22), True),
            "output_console": DummyBenchElement("output_console", "console", "output", (0, 540, 900, 80), False, text="ready"),
            "canvas_area": DummyBenchElement("canvas_area", "canvas", "practice canvas", (24, 380, 660, 120), True),
        }
        return surface

    def frame(self, *, tick: int, source: str = "dummy_bench_adapter") -> DesktopObservationFrame:
        text_fragments = tuple(_clip(element.text, 120) for element in self.elements.values() if element.text)
        return DesktopObservationFrame(
            tick=int(tick),
            surface_id=self.surface_id,
            title=self.title,
            active_application=self.active_application,
            elements=tuple(element.observation() for element in self.elements.values()),
            text_fragments=text_fragments + tuple(self.event_log[-4:]),
            source=source,
            screenshot_digest=f"dummy:{len(self.event_log)}:{sum(e.clicked_count for e in self.elements.values())}",
            metadata={"bench": "dummy_safe", "real_os": "false"},
        )

    def digest(self) -> str:
        parts = []
        for element in sorted(self.elements.values(), key=lambda item: item.element_id):
            parts.append(f"{element.element_id}:{element.role}:{element.text}:{element.clicked_count}:{element.scroll_position}:{int(element.focused)}")
        return "|".join(parts)

    def as_dict(self) -> dict[str, Any]:
        return {
            "surface_id": self.surface_id,
            "title": self.title,
            "active_application": self.active_application,
            "elements": [element.as_dict() for element in sorted(self.elements.values(), key=lambda item: item.element_id)],
            "event_log": list(self.event_log[-64:]),
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "DummyBenchSurface":
        surface = cls(
            surface_id=str(data.get("surface_id", "dummy_desktop_practice_app")),
            title=str(data.get("title", "Dummy Practice App")),
            active_application=str(data.get("active_application", "dummy_practice.exe")),
        )
        elements = data.get("elements", [])
        surface.elements = {
            element.element_id: element
            for element in (DummyBenchElement.from_state(item) for item in elements if isinstance(item, dict))
        }
        if not surface.elements:
            surface = cls.default()
        surface.event_log = [str(item) for item in data.get("event_log", [])[-64:]]
        return surface


@dataclass(frozen=True)
class DummyActuationContract:
    """Inspectably proves a proposal is sandbox-only.

    Pattern: Contract Object. M15 may execute only when this contract states the
    target is a dummy surface. It explicitly denies real OS authority.
    """

    bench_id: str
    surface_id: str
    action_kind: DummyBenchActionKind
    dummy_only: bool
    may_execute_dummy: bool
    real_os_allowed: bool = False
    file_system_allowed: bool = False
    network_allowed: bool = False
    reason: str = "M15 permits execution only inside the sealed dummy bench."

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class DummyActionProposal:
    """A proposed fake UI action.

    Pattern: Command. The command is serializable, inspectable, and inert until
    a DummyBenchActuator applies it to a DummyBenchSurface.
    """

    proposal_id: str
    surface_id: str
    element_id: str
    action_kind: DummyBenchActionKind
    payload: str = ""
    source: str = "manual_dummy_proposal"
    risk: float = 0.05
    contract: DummyActuationContract | None = None

    @property
    def write_like(self) -> bool:
        return self.action_kind in _WRITE_LIKE

    def as_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["write_like"] = self.write_like
        payload["contract"] = None if self.contract is None else self.contract.as_dict()
        return payload


@dataclass(frozen=True)
class DummyActionOutcome:
    """Result of executing a dummy proposal inside the sandbox."""

    tick: int
    proposal_id: str
    executed: bool
    changed: bool
    blocked: bool
    action_kind: DummyBenchActionKind
    element_id: str
    message: str
    before_digest: str
    after_digest: str
    real_os_touched: bool = False

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class DummyBenchActuator:
    """Executes interface-like proposals only in a sealed dummy bench.

    Pattern: Facade + Command Processor + Sandbox Adapter. The actuator turns
    proposal-only interface learning into consequence-bearing practice without
    crossing into real OS control.
    """

    def __init__(self, *, bench_id: str = "m15_dummy_bench", history_limit: int = 96) -> None:
        self.bench_id = bench_id
        self.surface = DummyBenchSurface.default()
        self.proposals: deque[DummyActionProposal] = deque(maxlen=max(16, int(history_limit)))
        self.outcomes: deque[DummyActionOutcome] = deque(maxlen=max(16, int(history_limit)))
        self.proposal_count = 0
        self.executed_count = 0
        self.blocked_count = 0
        self.changed_count = 0
        self.real_os_touch_count = 0
        self.graph_event_count = 0
        self.sensory_feedback_count = 0

    def observe_frame(self, *, tick: int) -> DesktopObservationFrame:
        return self.surface.frame(tick=tick)

    def propose(
        self,
        *,
        tick: int,
        element_id: str,
        action_kind: DummyBenchActionKind,
        payload: str = "",
        source: str = "dummy_bench",
    ) -> DummyActionProposal:
        surface_id = self.surface.surface_id
        proposal = DummyActionProposal(
            proposal_id=f"dummy:{_safe(action_kind)}:{_safe(element_id)}:{self.proposal_count + 1}",
            surface_id=surface_id,
            element_id=_safe(element_id),
            action_kind=action_kind,
            payload=_clip(payload, 240),
            source=source,
            risk=0.02 if action_kind in {"inspect", "read"} else 0.08,
            contract=DummyActuationContract(
                bench_id=self.bench_id,
                surface_id=surface_id,
                action_kind=action_kind,
                dummy_only=True,
                may_execute_dummy=True,
                reason="proposal targets the sealed M15 dummy bench only",
            ),
        )
        self.proposal_count += 1
        self.proposals.append(proposal)
        return proposal

    def propose_from_interface_record(self, *, tick: int, record: Any, payload: str = "test") -> DummyActionProposal | None:
        """Convert a proposal-only UI affordance record into a dummy command.

        This is intentionally narrow: the record must point at the dummy surface
        and its role/label must match a fake element. It does not use live OS
        handles and does not bypass the dummy contract.
        """

        surface_id = str(getattr(record, "surface_id", ""))
        if surface_id != self.surface.surface_id:
            return None
        action_kind = str(getattr(record, "action_kind", "unknown"))
        element_id = self._match_element(role=str(getattr(record, "role", "")), label=str(getattr(record, "label", "")))
        if element_id is None:
            return None
        return self.propose(tick=tick, element_id=element_id, action_kind=action_kind, payload=payload, source="interface_affordance_record")  # type: ignore[arg-type]

    def execute(
        self,
        proposal: DummyActionProposal,
        *,
        tick: int,
        graph: NeuralGrowthGraph | None = None,
        sensory_hub: SensoryAdapterHub | None = None,
    ) -> DummyActionOutcome:
        before = self.surface.digest()
        blocked_reason = self._block_reason(proposal)
        if blocked_reason:
            outcome = DummyActionOutcome(
                tick=int(tick),
                proposal_id=proposal.proposal_id,
                executed=False,
                changed=False,
                blocked=True,
                action_kind=proposal.action_kind,
                element_id=proposal.element_id,
                message=blocked_reason,
                before_digest=before,
                after_digest=before,
            )
            self.blocked_count += 1
            self.outcomes.append(outcome)
            if graph is not None:
                self.graph_event_count += len(self._write_graph(tick=tick, proposal=proposal, outcome=outcome, graph=graph))
            return outcome

        element = self.surface.elements[proposal.element_id]
        message = "observed"
        if proposal.action_kind == "inspect":
            message = f"inspected {element.role} {element.label}".strip()
        elif proposal.action_kind == "read":
            message = element.text or element.label or "nothing readable"
        elif proposal.action_kind == "click":
            element.clicked_count += 1
            for other in self.surface.elements.values():
                other.focused = False
            element.focused = True
            console = self.surface.elements.get("output_console")
            if console is not None:
                console.text = f"clicked {element.label or element.element_id}"
            message = f"dummy click changed {element.element_id}"
        elif proposal.action_kind == "type_text":
            if element.role not in {"text_field", "console"}:
                message = f"type blocked by role {element.role}"
            else:
                element.text = (element.text + proposal.payload)[:500]
                element.focused = True
                message = f"dummy typed into {element.element_id}"
        elif proposal.action_kind == "press_key":
            element.text = (element.text + f"<{proposal.payload or 'key'}>")[:500]
            message = f"dummy keypress on {element.element_id}"
        elif proposal.action_kind == "scroll":
            element.scroll_position += 1
            message = f"dummy scrolled {element.element_id}"
        else:
            message = "unknown dummy action"
        self.surface.event_log.append(message)
        after = self.surface.digest()
        changed = before != after
        outcome = DummyActionOutcome(
            tick=int(tick),
            proposal_id=proposal.proposal_id,
            executed=True,
            changed=changed,
            blocked=False,
            action_kind=proposal.action_kind,
            element_id=proposal.element_id,
            message=message,
            before_digest=before,
            after_digest=after,
        )
        self.executed_count += 1
        if changed:
            self.changed_count += 1
        self.outcomes.append(outcome)
        if sensory_hub is not None:
            sensory_hub.receive_screen_probe(
                tick=tick,
                description=f"dummy bench outcome {proposal.action_kind} {proposal.element_id}: {message}",
                source="dummy_bench_feedback",
                ttl=18,
                intensity=0.62,
            )
            self.sensory_feedback_count += 1
        if graph is not None:
            self.graph_event_count += len(self._write_graph(tick=tick, proposal=proposal, outcome=outcome, graph=graph))
        return outcome

    def execute_script(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph | None = None,
        sensory_hub: SensoryAdapterHub | None = None,
    ) -> tuple[DummyActionOutcome, ...]:
        """Run a tiny deterministic practice script against the dummy bench."""

        proposals = (
            self.propose(tick=tick, element_id="note_field", action_kind="inspect", source="m15_script"),
            self.propose(tick=tick + 1, element_id="note_field", action_kind="type_text", payload="apple note", source="m15_script"),
            self.propose(tick=tick + 2, element_id="send_button", action_kind="click", source="m15_script"),
            self.propose(tick=tick + 3, element_id="output_console", action_kind="read", source="m15_script"),
        )
        return tuple(self.execute(proposal, tick=tick + index, graph=graph, sensory_hub=sensory_hub) for index, proposal in enumerate(proposals))

    def snapshot(self) -> dict[str, Any]:
        return {
            "bench_id": self.bench_id,
            "surface_id": self.surface.surface_id,
            "proposal_count": self.proposal_count,
            "executed_count": self.executed_count,
            "blocked_count": self.blocked_count,
            "changed_count": self.changed_count,
            "real_os_touch_count": self.real_os_touch_count,
            "graph_event_count": self.graph_event_count,
            "sensory_feedback_count": self.sensory_feedback_count,
            "element_count": len(self.surface.elements),
            "recent_outcomes": [outcome.as_dict() for outcome in list(self.outcomes)[-8:]],
            "recent_proposals": [proposal.as_dict() for proposal in list(self.proposals)[-8:]],
            "surface": self.surface.as_dict(),
            "law": "M15 executes only inside the sealed dummy bench; real OS actuation remains blocked.",
        }

    def state(self) -> dict[str, Any]:
        return {
            "bench_id": self.bench_id,
            "surface": self.surface.as_dict(),
            "proposal_count": self.proposal_count,
            "executed_count": self.executed_count,
            "blocked_count": self.blocked_count,
            "changed_count": self.changed_count,
            "real_os_touch_count": self.real_os_touch_count,
            "graph_event_count": self.graph_event_count,
            "sensory_feedback_count": self.sensory_feedback_count,
            "proposals": [proposal.as_dict() for proposal in self.proposals],
            "outcomes": [outcome.as_dict() for outcome in self.outcomes],
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "DummyBenchActuator":
        actuator = cls(bench_id=str(data.get("bench_id", "m15_dummy_bench")))
        actuator.surface = DummyBenchSurface.from_state(dict(data.get("surface", {})))
        actuator.proposal_count = int(data.get("proposal_count", 0))
        actuator.executed_count = int(data.get("executed_count", 0))
        actuator.blocked_count = int(data.get("blocked_count", 0))
        actuator.changed_count = int(data.get("changed_count", 0))
        actuator.real_os_touch_count = int(data.get("real_os_touch_count", 0))
        actuator.graph_event_count = int(data.get("graph_event_count", 0))
        actuator.sensory_feedback_count = int(data.get("sensory_feedback_count", 0))
        for item in data.get("proposals", [])[-actuator.proposals.maxlen :]:
            if isinstance(item, dict):
                actuator.proposals.append(_proposal_from_state(item))
        for item in data.get("outcomes", [])[-actuator.outcomes.maxlen :]:
            if isinstance(item, dict):
                actuator.outcomes.append(_outcome_from_state(item))
        return actuator

    def _block_reason(self, proposal: DummyActionProposal) -> str:
        contract = proposal.contract
        if contract is None or not contract.dummy_only or not contract.may_execute_dummy:
            return "blocked: missing dummy-only actuation contract"
        if contract.real_os_allowed or contract.file_system_allowed or contract.network_allowed:
            return "blocked: contract attempted non-dummy authority"
        if proposal.surface_id != self.surface.surface_id or not proposal.surface_id.startswith("dummy"):
            return "blocked: proposal target is not the sealed dummy surface"
        if proposal.element_id not in self.surface.elements:
            return "blocked: unknown dummy element"
        element = self.surface.elements[proposal.element_id]
        if proposal.write_like and not element.interactable:
            return f"blocked: element {proposal.element_id} is not interactable in dummy bench"
        return ""

    def _match_element(self, *, role: str, label: str) -> str | None:
        role = _safe(role)
        label_slug = _safe(label)
        candidates = sorted(self.surface.elements.values(), key=lambda item: item.element_id)
        for element in candidates:
            if _safe(element.role) == role and (_safe(element.label) == label_slug or label_slug in _safe(element.label) or _safe(element.label) in label_slug):
                return element.element_id
        for element in candidates:
            if _safe(element.role) == role:
                return element.element_id
        return None

    def _write_graph(self, *, tick: int, proposal: DummyActionProposal, outcome: DummyActionOutcome, graph: NeuralGrowthGraph) -> tuple[PlasticityEvent, ...]:
        surface_node = f"dummy_bench_surface:{_safe(self.surface.surface_id)}"
        element = self.surface.elements.get(proposal.element_id)
        role = _safe(element.role if element else "unknown")
        label = _safe(element.label if element else proposal.element_id)
        element_kind_node = f"dummy_element_kind:{role}:{label}"
        action_node = f"dummy_action_template:{_safe(proposal.action_kind)}:{role}"
        outcome_node = "dummy_outcome:blocked" if outcome.blocked else "dummy_outcome:changed" if outcome.changed else "dummy_outcome:observed"
        graph.ensure_neuron(surface_node, kind="dummy_bench_surface", label=self.surface.surface_id, tick=tick)
        graph.ensure_neuron(element_kind_node, kind="dummy_element_kind", label=f"{role}:{label}", tick=tick)
        graph.ensure_neuron(action_node, kind="dummy_action_template", label=f"{proposal.action_kind}:{role}", tick=tick)
        graph.ensure_neuron(outcome_node, kind="dummy_outcome", label=outcome_node.split(":", 1)[1], tick=tick)
        for node, amount in ((surface_node, 0.58), (element_kind_node, 0.56), (action_node, 0.60), (outcome_node, 0.52)):
            graph.activate(node, amount=amount, tick=tick)
        events = [
            graph.reinforce(surface_node, element_kind_node, amount=0.026, tick=tick, reason="dummy bench surface-element binding"),
            graph.reinforce(element_kind_node, action_node, amount=0.032, tick=tick, reason="dummy bench action template binding"),
            graph.reinforce(action_node, outcome_node, amount=0.040 if outcome.executed else -0.018, tick=tick, reason="dummy bench action consequence"),
        ]
        return tuple(events)


def _proposal_from_state(data: dict[str, Any]) -> DummyActionProposal:
    contract_data = data.get("contract")
    contract = None
    if isinstance(contract_data, dict):
        contract = DummyActuationContract(
            bench_id=str(contract_data.get("bench_id", "m15_dummy_bench")),
            surface_id=str(contract_data.get("surface_id", "dummy_desktop_practice_app")),
            action_kind=str(contract_data.get("action_kind", "unknown")),  # type: ignore[arg-type]
            dummy_only=bool(contract_data.get("dummy_only", True)),
            may_execute_dummy=bool(contract_data.get("may_execute_dummy", False)),
            real_os_allowed=bool(contract_data.get("real_os_allowed", False)),
            file_system_allowed=bool(contract_data.get("file_system_allowed", False)),
            network_allowed=bool(contract_data.get("network_allowed", False)),
            reason=str(contract_data.get("reason", "")),
        )
    return DummyActionProposal(
        proposal_id=str(data.get("proposal_id", "dummy:unknown")),
        surface_id=str(data.get("surface_id", "dummy_desktop_practice_app")),
        element_id=str(data.get("element_id", "element")),
        action_kind=str(data.get("action_kind", "unknown")),  # type: ignore[arg-type]
        payload=str(data.get("payload", "")),
        source=str(data.get("source", "state")),
        risk=float(data.get("risk", 0.05)),
        contract=contract,
    )


def _outcome_from_state(data: dict[str, Any]) -> DummyActionOutcome:
    return DummyActionOutcome(
        tick=int(data.get("tick", 0)),
        proposal_id=str(data.get("proposal_id", "dummy:unknown")),
        executed=bool(data.get("executed", False)),
        changed=bool(data.get("changed", False)),
        blocked=bool(data.get("blocked", False)),
        action_kind=str(data.get("action_kind", "unknown")),  # type: ignore[arg-type]
        element_id=str(data.get("element_id", "element")),
        message=str(data.get("message", "")),
        before_digest=str(data.get("before_digest", "")),
        after_digest=str(data.get("after_digest", "")),
        real_os_touched=bool(data.get("real_os_touched", False)),
    )


def _safe(value: object) -> str:
    text = "".join(ch.lower() if ch.isalnum() else "_" for ch in str(value).strip())
    text = "_".join(piece for piece in text.split("_") if piece)
    return (text or "unknown")[:96]


def _clip(value: object, limit: int) -> str:
    return str(value or "")[: max(0, int(limit))]
