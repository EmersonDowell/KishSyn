"""Counterfactual replay and proto-planning for KishSyn Core.

M3 adds a governed imagination precursor: the organism may rehearse a small set
of currently available action candidates before committing, but the rehearsal is
not a hidden mind and not a symbolic expert system. It is a bounded Strategy over
existing contracts: candidate action, body pressure, graph prediction, distance,
known affordance/risk hints, and prior confidence.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from .action import ActionCandidate
from .contracts import Action, BodyState, PlasticityEvent, Prediction
from .neural_graph import NeuralGrowthGraph
from .predictor import PredictiveModel
from .world import MiniEcologyWorld


@dataclass(frozen=True)
class CounterfactualOption:
    """One imagined action consequence over an existing visible candidate."""

    action_kind: str
    target_id: str | None
    base_score: float
    predicted_outcome: str
    predicted_confidence: float
    projected_delta: float
    distance_after: float
    risk: float
    value: float
    reason: str

    def as_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        for key in ("base_score", "predicted_confidence", "projected_delta", "distance_after", "risk", "value"):
            payload[key] = round(float(payload[key]), 4)
        return payload


@dataclass(frozen=True)
class PlanningReport:
    """Audit record for one proto-planning pass."""

    tick: int
    dominant_need: str
    evaluated_count: int
    selected_target: str | None
    selected_action: str
    changed_action: bool
    best_value: float
    options: tuple[CounterfactualOption, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "tick": self.tick,
            "dominant_need": self.dominant_need,
            "evaluated_count": self.evaluated_count,
            "selected_target": self.selected_target,
            "selected_action": self.selected_action,
            "changed_action": self.changed_action,
            "best_value": round(float(self.best_value), 4),
            "options": [option.as_dict() for option in self.options],
        }


@dataclass
class PlanTemplateStats:
    """Reusable plan anatomy strengthened by many lived plan instances.

    Pattern: Flyweight + Memento. Tick-specific planning reports remain audit
    history, while durable graph anatomy is compressed into reusable templates
    keyed by action and coarse target signature.
    """

    template_id: str
    action_kind: str
    target_signature: str
    predicted_outcome: str
    evidence_count: int = 0
    success_count: int = 0
    failure_count: int = 0
    total_value: float = 0.0
    total_prediction_error: float = 0.0
    last_tick: int = 0

    def observe(self, *, tick: int, value: float, prediction_error: float, aligned: bool) -> None:
        self.evidence_count += 1
        self.success_count += 1 if aligned else 0
        self.failure_count += 0 if aligned else 1
        self.total_value += float(value)
        self.total_prediction_error += float(prediction_error)
        self.last_tick = int(tick)

    def as_dict(self) -> dict[str, Any]:
        return {
            "template_id": self.template_id,
            "action_kind": self.action_kind,
            "target_signature": self.target_signature,
            "predicted_outcome": self.predicted_outcome,
            "evidence_count": self.evidence_count,
            "success_count": self.success_count,
            "failure_count": self.failure_count,
            "alignment_ratio": round(float(self.success_count / max(1, self.evidence_count)), 4),
            "total_value": round(float(self.total_value), 6),
            "total_prediction_error": round(float(self.total_prediction_error), 6),
            "mean_value": round(float(self.total_value / max(1, self.evidence_count)), 4),
            "mean_prediction_error": round(float(self.total_prediction_error / max(1, self.evidence_count)), 4),
            "last_tick": self.last_tick,
        }


class CounterfactualReplayEngine:
    """Bounded proto-planner over the current action candidate set.

    Pattern: Strategy + Memento. The engine produces an explicit report and may
    swap the candidate only when a counterfactual option has meaningfully better
    projected value. It cannot invent new targets, cannot bypass safety, and
    cannot access hidden world affordances as semantic truth during prediction;
    known world properties enter only as risk/cost hints for this toy ecology.
    """

    def __init__(self, *, horizon: int = 3) -> None:
        self.horizon = max(1, int(horizon))
        self.report_count = 0
        self.evaluated_options = 0
        self.plan_switches = 0
        self.predicted_relief_count = 0
        self.predicted_risk_count = 0
        self.replay_successes = 0
        self.replay_failures = 0
        self.plan_template_updates = 0
        self.plan_templates: dict[str, PlanTemplateStats] = {}
        self.last_report: PlanningReport | None = None
        self.history: list[dict[str, Any]] = []

    def plan(
        self,
        *,
        tick: int,
        candidate: ActionCandidate,
        decision_snapshot: dict[str, Any],
        body: BodyState,
        world: MiniEcologyWorld,
        graph: NeuralGrowthGraph,
        predictor: PredictiveModel,
    ) -> ActionCandidate:
        """Return a counterfactual-adjusted candidate when the imagined value wins."""

        top_candidates = decision_snapshot.get("top_candidates", [])
        options: list[CounterfactualOption] = []
        for item in top_candidates[:4] if isinstance(top_candidates, list) else []:
            if not isinstance(item, dict):
                continue
            option = self._option_from_view(item, body=body, world=world, predictor=predictor)
            if option is not None:
                options.append(option)
        seen = {option.target_id for option in options}
        risk_probe_count = 0
        for obj in sorted((item for item in world.objects.values() if item.affordance == "hazard"), key=lambda item: (world.distance_to(item.object_id), item.object_id)):
            if obj.object_id in seen:
                continue
            if risk_probe_count >= 2:
                break
            options.append(self._build_option(action_kind="avoid", target_id=obj.object_id, base_score=-0.05, body=body, world=world, predictor=predictor, reason="counterfactual risk probe"))
            seen.add(obj.object_id)
            risk_probe_count += 1
        if not options:
            options.append(self._option_from_candidate(candidate, body=body, world=world, predictor=predictor))
        ranked = sorted(options, key=lambda option: option.value, reverse=True)
        best = ranked[0]
        selected_target = candidate.action.target_id
        selected_kind = candidate.action.kind
        changed = False
        chosen = candidate
        candidate_value = next((option.value for option in ranked if option.target_id == selected_target and option.action_kind == selected_kind), candidate.score)
        if best.target_id != selected_target and best.value >= candidate_value + 0.10 and best.risk < 0.82:
            reason = f"counterfactual replay preferred {best.predicted_outcome} value {best.value:.2f}; {best.reason}"
            chosen = ActionCandidate(Action(str(best.action_kind), best.target_id, reason), best.value, reason)
            changed = True
            self.plan_switches += 1
        self.report_count += 1
        self.evaluated_options += len(options)
        self.predicted_relief_count += sum(1 for option in options if option.predicted_outcome == "relief")
        self.predicted_risk_count += sum(1 for option in options if option.risk >= 0.45 or option.predicted_outcome == "pain")
        self.last_report = PlanningReport(
            tick=tick,
            dominant_need=body.dominant_need(),
            evaluated_count=len(options),
            selected_target=chosen.action.target_id,
            selected_action=chosen.action.kind,
            changed_action=changed,
            best_value=best.value,
            options=tuple(ranked[:6]),
        )
        self.history.append(self.last_report.as_dict())
        self.history = self.history[-64:]
        return chosen

    def record_outcome(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph,
        action: Action,
        outcome_kind: str,
        prediction: Prediction,
        prediction_error: float,
    ) -> tuple[PlasticityEvent, ...]:
        """Write graph traces connecting imagined consequence to lived consequence."""

        report = self.last_report
        if report is None:
            return ()
        target_signature = _target_signature(report.selected_target)
        template_node = f"plan_template:{report.selected_action}:{target_signature}"
        predicted_node = f"predicted:{prediction.expected_outcome}"
        outcome_node = f"outcome:{outcome_kind}"
        graph.ensure_neuron(template_node, kind="plan_template", label=f"{report.selected_action}->{target_signature}", tick=tick)
        graph.ensure_neuron(predicted_node, kind="prediction", label=prediction.expected_outcome, tick=tick)
        graph.ensure_neuron(outcome_node, kind="outcome", label=outcome_kind, tick=tick)
        graph.activate(template_node, amount=max(0.18, min(1.0, report.best_value * 0.18)), tick=tick)
        aligned = prediction.expected_outcome == outcome_kind or (prediction.expected_outcome == "relief" and outcome_kind in {"relief", "depleted"})
        stats = self.plan_templates.get(template_node)
        if stats is None:
            stats = PlanTemplateStats(
                template_id=template_node,
                action_kind=report.selected_action,
                target_signature=target_signature,
                predicted_outcome=prediction.expected_outcome,
            )
            self.plan_templates[template_node] = stats
        stats.observe(tick=tick, value=report.best_value, prediction_error=prediction_error, aligned=aligned and prediction_error <= 0.72)
        self.plan_template_updates += 1
        if aligned and prediction_error <= 0.72:
            self.replay_successes += 1
            amount = 0.018
            reason = "counterfactual replay template aligned with lived consequence"
        else:
            self.replay_failures += 1
            amount = -0.010
            reason = "counterfactual replay template mismatch corrected by lived consequence"
        return (
            graph.reinforce(template_node, predicted_node, amount=0.012, tick=tick, reason="plan template stores imagined outcome"),
            graph.reinforce(template_node, outcome_node, amount=amount, tick=tick, reason=reason),
        )

    def snapshot(self) -> dict[str, Any]:
        total = max(1, self.replay_successes + self.replay_failures)
        return {
            "horizon": self.horizon,
            "report_count": self.report_count,
            "evaluated_options": self.evaluated_options,
            "plan_switches": self.plan_switches,
            "predicted_relief_count": self.predicted_relief_count,
            "predicted_risk_count": self.predicted_risk_count,
            "replay_successes": self.replay_successes,
            "replay_failures": self.replay_failures,
            "alignment_ratio": round(float(self.replay_successes / total), 4),
            "mean_options": round(float(self.evaluated_options / max(1, self.report_count)), 4),
            "plan_template_count": len(self.plan_templates),
            "plan_template_updates": self.plan_template_updates,
            "top_plan_templates": self._template_snapshot(limit=8),
            "last_report": None if self.last_report is None else self.last_report.as_dict(),
            "history": self.history[-12:],
        }

    def state(self) -> dict[str, Any]:
        return {
            "horizon": self.horizon,
            "report_count": self.report_count,
            "evaluated_options": self.evaluated_options,
            "plan_switches": self.plan_switches,
            "predicted_relief_count": self.predicted_relief_count,
            "predicted_risk_count": self.predicted_risk_count,
            "replay_successes": self.replay_successes,
            "replay_failures": self.replay_failures,
            "plan_template_updates": self.plan_template_updates,
            "plan_templates": [stats.as_dict() for stats in self.plan_templates.values()],
            "last_report": None if self.last_report is None else self.last_report.as_dict(),
            "history": self.history[-64:],
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "CounterfactualReplayEngine":
        engine = cls(horizon=int(data.get("horizon", 3)))
        engine.report_count = int(data.get("report_count", 0))
        engine.evaluated_options = int(data.get("evaluated_options", 0))
        engine.plan_switches = int(data.get("plan_switches", 0))
        engine.predicted_relief_count = int(data.get("predicted_relief_count", 0))
        engine.predicted_risk_count = int(data.get("predicted_risk_count", 0))
        engine.replay_successes = int(data.get("replay_successes", 0))
        engine.replay_failures = int(data.get("replay_failures", 0))
        engine.plan_template_updates = int(data.get("plan_template_updates", 0))
        for item in data.get("plan_templates", []):
            stats = _plan_template_from_dict(item)
            engine.plan_templates[stats.template_id] = stats
        engine.last_report = _report_from_dict(data.get("last_report"))
        engine.history = [dict(item) for item in data.get("history", [])][-64:]
        return engine

    def _template_snapshot(self, *, limit: int = 8) -> list[dict[str, Any]]:
        templates = [stats.as_dict() for stats in self.plan_templates.values()]
        templates.sort(key=lambda item: (-int(item["evidence_count"]), -float(item["alignment_ratio"]), str(item["template_id"])))
        return templates[: max(0, int(limit))]

    def _option_from_view(
        self,
        item: dict[str, Any],
        *,
        body: BodyState,
        world: MiniEcologyWorld,
        predictor: PredictiveModel,
    ) -> CounterfactualOption | None:
        target_id = item.get("target")
        action_kind = str(item.get("action") or "wait")
        if target_id is not None:
            target_id = str(target_id)
        if target_id not in world.objects and target_id is not None:
            return None
        base_score = float(item.get("score", 0.0))
        return self._build_option(action_kind=action_kind, target_id=target_id, base_score=base_score, body=body, world=world, predictor=predictor, reason=str(item.get("reason", "candidate")))

    def _option_from_candidate(
        self,
        candidate: ActionCandidate,
        *,
        body: BodyState,
        world: MiniEcologyWorld,
        predictor: PredictiveModel,
    ) -> CounterfactualOption:
        return self._build_option(action_kind=candidate.action.kind, target_id=candidate.action.target_id, base_score=candidate.score, body=body, world=world, predictor=predictor, reason=candidate.reason)

    def _build_option(
        self,
        *,
        action_kind: str,
        target_id: str | None,
        base_score: float,
        body: BodyState,
        world: MiniEcologyWorld,
        predictor: PredictiveModel,
        reason: str,
    ) -> CounterfactualOption:
        features = world.target_features(target_id)
        prediction = predictor.predict(features)
        distance = float(world.distance_to(target_id)) if target_id in world.objects else 0.0
        distance_after = max(0.0, distance - float(self.horizon if action_kind == "move" else 0.0))
        projected_delta = self._projected_need_delta(body=body, target_id=target_id, world=world, predicted_outcome=prediction.expected_outcome)
        risk = self._risk_hint(target_id=target_id, world=world, predicted_outcome=prediction.expected_outcome, body=body)
        confidence_bonus = prediction.confidence * 0.20
        distance_cost = distance_after * 0.018
        value = base_score + projected_delta + confidence_bonus - risk - distance_cost
        return CounterfactualOption(
            action_kind=action_kind,
            target_id=target_id,
            base_score=base_score,
            predicted_outcome=prediction.expected_outcome,
            predicted_confidence=prediction.confidence,
            projected_delta=projected_delta,
            distance_after=distance_after,
            risk=risk,
            value=value,
            reason=reason[:180],
        )

    def _projected_need_delta(self, *, body: BodyState, target_id: str | None, world: MiniEcologyWorld, predicted_outcome: str) -> float:
        need = body.dominant_need()
        if target_id not in world.objects:
            return -0.03 if predicted_outcome == "blocked" else 0.0
        obj = world.objects[target_id]
        if obj.quantity <= 0:
            return -0.18
        if obj.affordance == "hazard" or predicted_outcome == "pain":
            return -0.62 - max(0.0, 0.55 - body.integrity)
        if obj.affordance == "food" and need == "energy":
            return 0.42
        if obj.affordance == "water" and need == "hydration":
            return 0.44
        if obj.affordance == "rest" and need in {"fatigue", "integrity"}:
            return 0.36
        if obj.affordance == "novelty" and need in {"curiosity", "uncertainty"}:
            return 0.34
        if obj.affordance == "symbol" and need in {"curiosity", "uncertainty"}:
            return 0.26
        if predicted_outcome == "relief":
            return 0.22
        if predicted_outcome == "novelty":
            return 0.16
        return 0.0

    def _risk_hint(self, *, target_id: str | None, world: MiniEcologyWorld, predicted_outcome: str, body: BodyState) -> float:
        if target_id not in world.objects:
            return 0.06 if predicted_outcome == "blocked" else 0.0
        obj = world.objects[target_id]
        risk = 0.0
        if obj.affordance == "hazard" or obj.shape in {"spike", "jagged"} or predicted_outcome == "pain":
            risk += 0.78
        if obj.quantity <= 0:
            risk += 0.22
        if body.integrity < 0.35 and risk > 0.0:
            risk += 0.25
        terrain = world.terrain_at(obj.x, obj.y)
        if terrain == "rough":
            risk += 0.08
        return min(1.0, risk)


def _target_signature(target_id: str | None) -> str:
    """Return a coarse target signature for reusable plan templates.

    Current playground object ids commonly end in a spawn index. Stripping only
    that terminal index keeps useful categories like soft_gray and
    teacher_color_red while avoiding durable per-tick/per-spawn plan neurons.
    """

    if not target_id:
        return "none"
    pieces = str(target_id).split("_")
    if len(pieces) > 1 and pieces[-1].isdigit():
        pieces = pieces[:-1]
    return "_".join(piece for piece in pieces if piece)[:64] or "unknown"


def _plan_template_from_dict(data: dict[str, Any]) -> PlanTemplateStats:
    stats = PlanTemplateStats(
        template_id=str(data.get("template_id", "plan_template:unknown:none")),
        action_kind=str(data.get("action_kind", "wait")),
        target_signature=str(data.get("target_signature", "none")),
        predicted_outcome=str(data.get("predicted_outcome", "neutral")),
        evidence_count=int(data.get("evidence_count", 0)),
        success_count=int(data.get("success_count", 0)),
        failure_count=int(data.get("failure_count", 0)),
        last_tick=int(data.get("last_tick", 0)),
    )
    stats.total_value = float(data.get("total_value", float(data.get("mean_value", 0.0)) * max(1, stats.evidence_count)))
    stats.total_prediction_error = float(data.get("total_prediction_error", float(data.get("mean_prediction_error", 0.0)) * max(1, stats.evidence_count)))
    return stats


def _report_from_dict(data: dict[str, Any] | None) -> PlanningReport | None:
    if not data:
        return None
    return PlanningReport(
        tick=int(data.get("tick", 0)),
        dominant_need=str(data.get("dominant_need", "unknown")),
        evaluated_count=int(data.get("evaluated_count", 0)),
        selected_target=None if data.get("selected_target") is None else str(data.get("selected_target")),
        selected_action=str(data.get("selected_action", "wait")),
        changed_action=bool(data.get("changed_action", False)),
        best_value=float(data.get("best_value", 0.0)),
        options=tuple(CounterfactualOption(**option) for option in data.get("options", [])),
    )
