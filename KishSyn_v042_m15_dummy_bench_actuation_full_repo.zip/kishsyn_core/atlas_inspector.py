"""Clickable neural atlas inspection for KishSyn Core.

This module is a read-only GUI contract. It does not compute cognition and it
must never mutate the organism. It explains what graph nodes/synapses are,
where they came from, what surfaces they belong to, when they activated, and
what recent plasticity touched them.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from .contracts import TickTrace
from .neural_graph import NeuralGrowthGraph, Neuron, Synapse


@dataclass(frozen=True)
class AtlasInspection:
    """Read-only explanation payload for one atlas item.

    Pattern: Read Model / DTO. The GUI can render this object directly without
    reaching into private graph internals.
    """

    item_type: str
    found: bool
    item_id: str
    summary: str
    surface: str
    kind: str
    activation: float = 0.0
    weight: float = 0.0
    created_at: int | None = None
    last_active: int | None = None
    last_updated: int | None = None
    updates: int = 0
    provenance: dict[str, object] = field(default_factory=dict)
    top_inbound: tuple[dict[str, object], ...] = ()
    top_outbound: tuple[dict[str, object], ...] = ()
    recent_plasticity: tuple[dict[str, object], ...] = ()
    connected_nodes: tuple[dict[str, object], ...] = ()

    def as_dict(self) -> dict[str, object]:
        payload = asdict(self)
        payload["activation"] = round(float(self.activation), 4)
        payload["weight"] = round(float(self.weight), 4)
        return payload


class NeuralAtlasInspector:
    """Explains neurons/synapses for the Observatory.

    Pattern: Facade over NeuralGrowthGraph. All GUI inspection should flow
    through this surface so screen, text, image, math, motor, planning, and
    future hardware activity stay standardized.
    """

    doctrine = "Atlas inspection is read-only: click a neuron or synapse, see what formed it, what it connects to, and how recent experience changed it."

    def inspect_node(
        self,
        *,
        graph: NeuralGrowthGraph,
        node_id: str,
        tick: int,
        last_trace: TickTrace | None = None,
    ) -> AtlasInspection:
        node = graph.neurons.get(node_id)
        if node is None:
            return AtlasInspection(
                item_type="node",
                found=False,
                item_id=node_id,
                summary="Node is not present in the living atlas.",
                surface=self._surface_for_id(node_id),
                kind="missing",
                provenance={"doctrine": self.doctrine},
            )
        inbound = self._edge_views(graph, node_id=node_id, direction="inbound")
        outbound = self._edge_views(graph, node_id=node_id, direction="outbound")
        recent = self._recent_plasticity(last_trace=last_trace, node_id=node_id)
        connected = self._connected_nodes(graph=graph, node_id=node_id, inbound=inbound, outbound=outbound)
        surface = self._surface_for_node(node)
        return AtlasInspection(
            item_type="node",
            found=True,
            item_id=node.node_id,
            summary=self._node_summary(node, tick=tick, inbound=inbound, outbound=outbound),
            surface=surface,
            kind=node.kind,
            activation=node.activation,
            created_at=node.created_at,
            last_active=node.last_active,
            provenance={
                "label": node.label,
                "age_ticks": max(0, tick - node.created_at),
                "inactive_ticks": max(0, tick - node.last_active),
                "surface": surface,
                "contract": "neuron inspection",
                "doctrine": self.doctrine,
            },
            top_inbound=tuple(inbound[:8]),
            top_outbound=tuple(outbound[:8]),
            recent_plasticity=tuple(recent[:12]),
            connected_nodes=tuple(connected[:12]),
        )

    def inspect_synapse(
        self,
        *,
        graph: NeuralGrowthGraph,
        source: str,
        target: str,
        tick: int,
        last_trace: TickTrace | None = None,
    ) -> AtlasInspection:
        synapse = graph.synapses.get((source, target))
        item_id = f"{source}->{target}"
        if synapse is None:
            return AtlasInspection(
                item_type="synapse",
                found=False,
                item_id=item_id,
                summary="Synapse is not present in the living atlas.",
                surface=f"{self._surface_for_id(source)}->{self._surface_for_id(target)}",
                kind="missing",
                provenance={"source": source, "target": target, "doctrine": self.doctrine},
            )
        recent = self._recent_plasticity(last_trace=last_trace, source=source, target=target)
        source_node = graph.neurons.get(source)
        target_node = graph.neurons.get(target)
        return AtlasInspection(
            item_type="synapse",
            found=True,
            item_id=item_id,
            summary=self._synapse_summary(synapse=synapse, source_node=source_node, target_node=target_node, tick=tick),
            surface=f"{self._surface_for_id(source)}->{self._surface_for_id(target)}",
            kind="synapse",
            weight=synapse.weight,
            last_updated=synapse.last_updated,
            updates=synapse.updates,
            provenance={
                "source": source,
                "target": target,
                "source_label": source_node.label if source_node else source,
                "target_label": target_node.label if target_node else target,
                "inactive_ticks": max(0, tick - synapse.last_updated),
                "contract": "synapse inspection",
                "doctrine": self.doctrine,
            },
            top_inbound=tuple(self._edge_views(graph, node_id=source, direction="inbound")[:5]),
            top_outbound=tuple(self._edge_views(graph, node_id=target, direction="outbound")[:5]),
            recent_plasticity=tuple(recent[:12]),
            connected_nodes=tuple(
                item for item in (
                    self._node_ref(source_node) if source_node else None,
                    self._node_ref(target_node) if target_node else None,
                ) if item is not None
            ),
        )

    def atlas_index(self, *, graph: NeuralGrowthGraph, tick: int, limit: int = 120) -> dict[str, object]:
        nodes = sorted(
            graph.neurons.values(),
            key=lambda node: (-node.activation, -(tick - max(0, tick - node.last_active)), node.node_id),
        )[:limit]
        edges = sorted(
            (syn for syn in graph.synapses.values() if abs(syn.weight) > 0.01),
            key=lambda syn: (-syn.last_updated, -abs(syn.weight), syn.source, syn.target),
        )[:limit]
        return {
            "tick": tick,
            "doctrine": self.doctrine,
            "node_count": len(graph.neurons),
            "edge_count": len([syn for syn in graph.synapses.values() if abs(syn.weight) > 0.01]),
            "nodes": [self._node_ref(node) for node in nodes],
            "synapses": [self._synapse_ref(syn) for syn in edges],
        }

    def _edge_views(self, graph: NeuralGrowthGraph, *, node_id: str, direction: str) -> list[dict[str, object]]:
        rows: list[dict[str, object]] = []
        for syn in graph.synapses.values():
            if abs(syn.weight) <= 0.01:
                continue
            if direction == "inbound" and syn.target != node_id:
                continue
            if direction == "outbound" and syn.source != node_id:
                continue
            other_id = syn.source if direction == "inbound" else syn.target
            other = graph.neurons.get(other_id)
            rows.append({
                "source": syn.source,
                "target": syn.target,
                "other": other_id,
                "other_label": other.label if other else other_id,
                "other_kind": other.kind if other else "unknown",
                "other_surface": self._surface_for_id(other_id),
                "weight": round(syn.weight, 4),
                "updates": syn.updates,
                "last_updated": syn.last_updated,
            })
        rows.sort(key=lambda row: (-abs(float(row["weight"])), -int(row["last_updated"]), str(row["other"])))
        return rows

    def _recent_plasticity(
        self,
        *,
        last_trace: TickTrace | None,
        node_id: str | None = None,
        source: str | None = None,
        target: str | None = None,
    ) -> list[dict[str, object]]:
        if last_trace is None:
            return []
        rows: list[dict[str, object]] = []
        for event in last_trace.plasticity:
            touches_node = node_id is not None and (event.source == node_id or event.target == node_id)
            touches_edge = source is not None and target is not None and event.source == source and event.target == target
            if not touches_node and not touches_edge:
                continue
            rows.append({
                "source": event.source,
                "target": event.target,
                "before": round(event.before, 4),
                "after": round(event.after, 4),
                "delta": round(event.after - event.before, 4),
                "reason": event.reason,
            })
        rows.sort(key=lambda row: -abs(float(row["delta"])))
        return rows

    def _connected_nodes(
        self,
        *,
        graph: NeuralGrowthGraph,
        node_id: str,
        inbound: list[dict[str, object]],
        outbound: list[dict[str, object]],
    ) -> list[dict[str, object]]:
        refs: list[dict[str, object]] = []
        seen: set[str] = set()
        for row in inbound + outbound:
            other_id = str(row["other"])
            if other_id in seen:
                continue
            seen.add(other_id)
            node = graph.neurons.get(other_id)
            if node is not None:
                refs.append(self._node_ref(node))
        return refs

    def _node_ref(self, node: Neuron) -> dict[str, object]:
        return {
            "id": node.node_id,
            "label": node.label,
            "kind": node.kind,
            "surface": self._surface_for_node(node),
            "activation": round(node.activation, 4),
            "created_at": node.created_at,
            "last_active": node.last_active,
        }

    def _synapse_ref(self, synapse: Synapse) -> dict[str, object]:
        return {
            "source": synapse.source,
            "target": synapse.target,
            "source_surface": self._surface_for_id(synapse.source),
            "target_surface": self._surface_for_id(synapse.target),
            "weight": round(synapse.weight, 4),
            "updates": synapse.updates,
            "last_updated": synapse.last_updated,
        }

    def _node_summary(self, node: Neuron, *, tick: int, inbound: list[dict[str, object]], outbound: list[dict[str, object]]) -> str:
        surface = self._surface_for_node(node)
        age = max(0, tick - node.created_at)
        inactive = max(0, tick - node.last_active)
        return (
            f"{node.kind} node on {surface} surface; label={node.label}; "
            f"activation={node.activation:.3f}; age={age} ticks; inactive={inactive} ticks; "
            f"inbound={len(inbound)} outbound={len(outbound)}."
        )

    def _synapse_summary(self, *, synapse: Synapse, source_node: Neuron | None, target_node: Neuron | None, tick: int) -> str:
        inactive = max(0, tick - synapse.last_updated)
        source_label = source_node.label if source_node else synapse.source
        target_label = target_node.label if target_node else synapse.target
        polarity = "reinforcing" if synapse.weight >= 0 else "inhibitory"
        return (
            f"{polarity} synapse {source_label} -> {target_label}; "
            f"weight={synapse.weight:.3f}; updates={synapse.updates}; inactive={inactive} ticks."
        )

    def _surface_for_node(self, node: Neuron) -> str:
        if node.kind in {"concept", "symbol", "text", "tutor", "expression", "circuit", "binding"}:
            return node.kind
        return self._surface_for_id(node.node_id)

    def _surface_for_id(self, node_id: str) -> str:
        prefix = node_id.split(":", 1)[0]
        if prefix in {
            "vision", "screen", "image", "audio", "math", "text", "body", "action", "outcome", "need", "self",
            "place", "terrain", "symbol", "symbol_goal", "concept", "binding", "circuit", "intent", "plan",
            "predicted", "expression", "motor", "route", "comfort", "development", "priority", "tutor", "console", "sensor",
        }:
            return prefix
        return "unknown"
