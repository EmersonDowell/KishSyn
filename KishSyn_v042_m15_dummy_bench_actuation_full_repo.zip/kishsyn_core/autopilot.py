"""Autonomous bounded curriculum for the KishSyn Core organism.

The autopilot is not a mind and not a policy override. It is an environmental
teacher that periodically introduces weak lessons through the same tutor/text
surface a human would use. The organism remains the learner: only plastic graph
changes, symbol goals, priority arbitration, and later behavior determine
whether a lesson becomes useful.
"""

from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass

from .contracts import BodyState, PlasticityEvent
from .neural_graph import NeuralGrowthGraph
from .symbol_goal import ActiveSymbolGoalMemory
from .text_crib import TextCribMemory
from .tutor import TutorSurface


@dataclass(frozen=True)
class AutopilotLesson:
    tick: int
    message: str
    reason: str
    plasticity_count: int
    chosen_score: float


class AutonomousTutorCurriculum:
    """Small automatic tutor that reduces manual operator babysitting.

    It only teaches when the body is stable enough. It chooses lessons whose
    symbol/concept edges are still weak, so the system naturally cycles toward
    underdeveloped grounded symbols instead of repeating the strongest label.
    """

    BASE_LESSONS = (
        "teach red round A two",
        "teach blue square B three",
        "teach green triangle C one",
        "teach yellow star D four",
        "teach orange diamond E five",
        "teach purple circle F six",
        "teach white line G seven",
        "teach black cross H eight",
    )

    def __init__(self, *, enabled: bool = True, interval: int = 72, history_limit: int = 48) -> None:
        self.enabled = enabled
        self.interval = max(12, int(interval))
        self.history: deque[AutopilotLesson] = deque(maxlen=history_limit)
        self.lesson_count = 0
        self.plasticity_count = 0
        self.skipped_count = 0
        self.last_tick = -10_000
        self.last_reason = "autopilot has not taught yet"
        self.last_message = ""
        self.last_score = 0.0

    def maybe_teach(
        self,
        *,
        tick: int,
        body: BodyState,
        graph: NeuralGrowthGraph,
        tutor: TutorSurface,
        text_crib: TextCribMemory,
        symbol_goal: ActiveSymbolGoalMemory,
    ) -> tuple[PlasticityEvent, ...]:
        if not self.enabled:
            self.last_reason = "autopilot disabled"
            return ()
        if tick < 8:
            self.last_reason = "waiting for early sensory grounding"
            return ()
        if tick - self.last_tick < self.interval:
            return ()
        if not self._body_stable(body):
            self.skipped_count += 1
            self.last_reason = f"skipped: body pressure too high for safe lesson ({body.dominant_need()})"
            return ()

        message, score = self._select_lesson(graph)
        reason = f"autonomous weak-symbol lesson selected; weakness={score:.3f}"
        events = tutor.receive(
            tick=tick,
            message=message,
            text_crib=text_crib,
            graph=graph,
            symbol_goal=symbol_goal,
            source="autopilot",
            mode="local",
        )
        self.lesson_count += 1
        self.plasticity_count += len(events)
        self.last_tick = tick
        self.last_reason = reason
        self.last_message = message
        self.last_score = round(score, 4)
        self.history.append(AutopilotLesson(
            tick=tick,
            message=message,
            reason=reason,
            plasticity_count=len(events),
            chosen_score=round(score, 4),
        ))
        return tuple(events)

    def snapshot(self) -> dict[str, object]:
        return {
            "enabled": self.enabled,
            "interval": self.interval,
            "lesson_count": self.lesson_count,
            "plasticity_count": self.plasticity_count,
            "skipped_count": self.skipped_count,
            "last_tick": self.last_tick,
            "last_message": self.last_message,
            "last_reason": self.last_reason,
            "last_score": self.last_score,
            "history": [asdict(item) for item in list(self.history)[-8:]],
        }

    def state(self) -> dict[str, object]:
        return {
            "enabled": self.enabled,
            "interval": self.interval,
            "lesson_count": self.lesson_count,
            "plasticity_count": self.plasticity_count,
            "skipped_count": self.skipped_count,
            "last_tick": self.last_tick,
            "last_message": self.last_message,
            "last_reason": self.last_reason,
            "last_score": self.last_score,
            "history": [asdict(item) for item in self.history],
        }

    def restore(self, data: dict[str, object]) -> None:
        self.enabled = bool(data.get("enabled", self.enabled))
        self.interval = max(12, int(data.get("interval", self.interval)))
        self.lesson_count = int(data.get("lesson_count", 0))
        self.plasticity_count = int(data.get("plasticity_count", 0))
        self.skipped_count = int(data.get("skipped_count", 0))
        self.last_tick = int(data.get("last_tick", -10_000))
        self.last_message = str(data.get("last_message", ""))
        self.last_reason = str(data.get("last_reason", "restored autonomous curriculum"))
        self.last_score = float(data.get("last_score", 0.0))
        self.history.clear()
        for item in data.get("history", []):
            if isinstance(item, dict):
                self.history.append(AutopilotLesson(
                    tick=int(item.get("tick", 0)),
                    message=str(item.get("message", "")),
                    reason=str(item.get("reason", "restored")),
                    plasticity_count=int(item.get("plasticity_count", 0)),
                    chosen_score=float(item.get("chosen_score", 0.0)),
                ))

    def _body_stable(self, body: BodyState) -> bool:
        needs = body.needs()
        survival_pressure = max(needs["energy"], needs["hydration"], needs["integrity"], needs["fatigue"])
        return survival_pressure < 0.78 and body.integrity > 0.30

    def _select_lesson(self, graph: NeuralGrowthGraph) -> tuple[str, float]:
        scored = [(lesson, self._lesson_weakness(graph, lesson)) for lesson in self.BASE_LESSONS]
        # Highest weakness gets the next lesson. Tie-break by lesson count so the
        # curriculum slowly rotates even after all basics have some exposure.
        scored.sort(key=lambda item: (-item[1], item[0]))
        index = self.lesson_count % min(3, len(scored)) if scored else 0
        return scored[index]

    def _lesson_weakness(self, graph: NeuralGrowthGraph, lesson: str) -> float:
        words = [word.lower() for word in lesson.split() if word.lower() != "teach"]
        strengths: list[float] = []
        for word in words:
            token = f"symbol:token={word}"
            outgoing = [
                abs(synapse.weight)
                for (source, target), synapse in graph.synapses.items()
                if source == token and target.startswith("concept:")
            ]
            strengths.append(max(outgoing) if outgoing else 0.0)
        if not strengths:
            return 1.0
        return max(0.0, 1.0 - (sum(strengths) / len(strengths)))
