"""Grounded language cortex for KishSyn Core.

M12 treats language as a teaching and recall surface bound to lived organism
anchors. A word is not a mind, a persona, or a direct command. It becomes useful
only when repeated text exposure co-occurs with grounded concepts, object kinds,
object files, contextual affordances, outcomes, and retained memory summaries.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from .contextual_affordance import ActorProfile, ContextualAffordanceCortex, WorldContext, object_kind_from_features
from .contracts import PlasticityEvent, TickTrace
from .memory_economy import MemoryPressureGovernor
from .neural_graph import NeuralGrowthGraph
from .object_file import object_id_from_features


@dataclass
class GroundedLexemeRecord:
    """Reusable word-to-anchor evidence record.

    Pattern: Flyweight. Many text exposures update one record keyed by word,
    anchor, actor, and world context. This avoids tick-specific language nodes
    while letting language become a recall route into lived anatomy.
    """

    record_id: str
    word: str
    anchor_kind: str
    anchor_id: str
    actor_id: str
    context_id: str
    provenance: str
    evidence_count: int = 0
    first_tick: int = 0
    last_tick: int = 0
    total_strength: float = 0.0
    outcome_counts: dict[str, int] = field(default_factory=dict)

    def observe(self, *, tick: int, strength: float, outcome_kind: str) -> None:
        if self.evidence_count == 0:
            self.first_tick = int(tick)
        self.evidence_count += 1
        self.last_tick = int(tick)
        self.total_strength += max(0.0, min(1.0, float(strength)))
        self.outcome_counts[outcome_kind] = self.outcome_counts.get(outcome_kind, 0) + 1

    @property
    def confidence(self) -> float:
        evidence = min(1.0, self.evidence_count / 8.0)
        mean_strength = self.total_strength / max(1, self.evidence_count)
        return max(0.0, min(1.0, evidence * 0.55 + mean_strength * 0.45))

    def as_dict(self) -> dict[str, Any]:
        return {
            "record_id": self.record_id,
            "word": self.word,
            "anchor_kind": self.anchor_kind,
            "anchor_id": self.anchor_id,
            "actor_id": self.actor_id,
            "context_id": self.context_id,
            "provenance": self.provenance,
            "evidence_count": self.evidence_count,
            "first_tick": self.first_tick,
            "last_tick": self.last_tick,
            "confidence": round(float(self.confidence), 4),
            "mean_strength": round(float(self.total_strength / max(1, self.evidence_count)), 4),
            "outcome_counts": dict(sorted(self.outcome_counts.items())),
        }

    def state(self) -> dict[str, Any]:
        return {
            "record_id": self.record_id,
            "word": self.word,
            "anchor_kind": self.anchor_kind,
            "anchor_id": self.anchor_id,
            "actor_id": self.actor_id,
            "context_id": self.context_id,
            "provenance": self.provenance,
            "evidence_count": self.evidence_count,
            "first_tick": self.first_tick,
            "last_tick": self.last_tick,
            "total_strength": self.total_strength,
            "outcome_counts": dict(self.outcome_counts),
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "GroundedLexemeRecord":
        return cls(
            record_id=str(data.get("record_id", "unknown")),
            word=str(data.get("word", "unknown")),
            anchor_kind=str(data.get("anchor_kind", "unknown")),
            anchor_id=str(data.get("anchor_id", "unknown")),
            actor_id=str(data.get("actor_id", "kishsyn:self")),
            context_id=str(data.get("context_id", "mini_ecology")),
            provenance=str(data.get("provenance", "text_plus_lived_trace")),
            evidence_count=int(data.get("evidence_count", 0)),
            first_tick=int(data.get("first_tick", 0)),
            last_tick=int(data.get("last_tick", 0)),
            total_strength=float(data.get("total_strength", 0.0)),
            outcome_counts={str(k): int(v) for k, v in dict(data.get("outcome_counts", {})).items()},
        )


@dataclass(frozen=True)
class LanguageGroundingContract:
    """Inspectable word evidence exported to the rest of the organism.

    Pattern: Contract Object. Language may expose grounded recall candidates; it
    may not select actions, write goals, or claim understanding without anchors.
    """

    word: str
    grounded: bool
    anchor_count: int
    top_anchors: tuple[dict[str, Any], ...]
    confidence: float
    may_command_action: bool
    reason: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "word": self.word,
            "grounded": self.grounded,
            "anchor_count": self.anchor_count,
            "top_anchors": list(self.top_anchors),
            "confidence": round(float(self.confidence), 4),
            "may_command_action": self.may_command_action,
            "reason": self.reason,
        }


class GroundedLanguageCortex:
    """Repository for word-to-lived-anchor evidence.

    Pattern: Repository + Adapter. The adapter reads text tokens from existing
    sensory frames and binds them to already-existing organism anchors. It does
    not parse commands, choose actions, or fabricate semantic truth.
    """

    def __init__(self, *, capacity: int = 512, history_capacity: int = 128) -> None:
        self.capacity = max(32, int(capacity))
        self.history_capacity = max(32, int(history_capacity))
        self.records: dict[str, GroundedLexemeRecord] = {}
        self.history: list[dict[str, Any]] = []
        self.observed_count = 0
        self.record_updates = 0
        self.contract_count = 0
        self.last_contract: LanguageGroundingContract | None = None

    def observe(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph,
        trace: TickTrace,
        target_features: tuple[str, ...],
        actor: ActorProfile,
        context: WorldContext,
        contextual_affordance: ContextualAffordanceCortex | None = None,
        memory_economy: MemoryPressureGovernor | None = None,
    ) -> tuple[PlasticityEvent, ...]:
        words = _text_words(trace.frame.tokens())
        if not words:
            return ()
        anchors = self._anchors(
            graph=graph,
            trace=trace,
            target_features=target_features,
            contextual_affordance=contextual_affordance,
            memory_economy=memory_economy,
        )
        if not anchors:
            return ()
        events: list[PlasticityEvent] = []
        for word in words[:10]:
            word_node = f"language_word:{_safe(word)}"
            graph.ensure_neuron(word_node, kind="language_word", label=word, tick=tick)
            graph.activate(word_node, amount=0.58, tick=tick)
            for anchor_kind, anchor_id, strength in anchors[:16]:
                record_id = _record_id(word, anchor_kind, anchor_id, actor.actor_id, context.context_id)
                record = self.records.get(record_id)
                if record is None:
                    record = GroundedLexemeRecord(
                        record_id=record_id,
                        word=word,
                        anchor_kind=anchor_kind,
                        anchor_id=anchor_id,
                        actor_id=actor.actor_id,
                        context_id=context.context_id,
                        provenance="text_plus_lived_trace",
                    )
                    self.records[record_id] = record
                    self._trim_records()
                record.observe(tick=tick, strength=strength, outcome_kind=trace.outcome.kind)
                self.record_updates += 1
                anchor_node = self._anchor_node(anchor_kind, anchor_id)
                graph.ensure_neuron(anchor_node, kind=f"language_anchor_{anchor_kind}", label=anchor_id[:96], tick=tick)
                amount = max(0.004, min(0.040, 0.010 + strength * 0.030))
                events.append(graph.reinforce(word_node, anchor_node, amount=amount, tick=tick, reason="grounded language word recalls lived anchor"))
                events.append(graph.reinforce(anchor_node, word_node, amount=amount * 0.55, tick=tick, reason="lived anchor can recall grounded word"))
                if anchor_kind == "concept":
                    graph.symbol_binding_updates += 1
        self.observed_count += 1
        self.history.append({
            "tick": int(tick),
            "words": list(words[:10]),
            "anchor_count": len(anchors),
            "outcome": trace.outcome.kind,
            "context_id": context.context_id,
            "actor_id": actor.actor_id,
        })
        self.history = self.history[-self.history_capacity:]
        if words:
            self.last_contract = self.contract_for(words[0])
        return tuple(events)

    def contract_for(self, word: str) -> LanguageGroundingContract:
        normalized = _safe_word(word)
        matches = [record for record in self.records.values() if record.word == normalized]
        matches.sort(key=lambda record: (-record.confidence, -record.evidence_count, record.anchor_kind, record.anchor_id))
        top = tuple(record.as_dict() for record in matches[:16])
        confidence = max((record.confidence for record in matches), default=0.0)
        self.contract_count += 1
        contract = LanguageGroundingContract(
            word=normalized,
            grounded=bool(matches),
            anchor_count=len(matches),
            top_anchors=top,
            confidence=confidence,
            may_command_action=False,
            reason="language is grounded recall evidence only; it may not command action",
        )
        self.last_contract = contract
        return contract

    def snapshot(self) -> dict[str, Any]:
        records = sorted((record.as_dict() for record in self.records.values()), key=lambda item: (-int(item["evidence_count"]), str(item["record_id"])))
        words = sorted({record.word for record in self.records.values()})
        anchors = sorted({(record.anchor_kind, record.anchor_id) for record in self.records.values()})
        return {
            "record_count": len(self.records),
            "record_updates": self.record_updates,
            "observed_count": self.observed_count,
            "word_count": len(words),
            "anchor_count": len(anchors),
            "contract_count": self.contract_count,
            "last_contract": None if self.last_contract is None else self.last_contract.as_dict(),
            "top_records": records[:12],
            "last_history": self.history[-8:],
        }

    def state(self) -> dict[str, Any]:
        return {
            "capacity": self.capacity,
            "history_capacity": self.history_capacity,
            "observed_count": self.observed_count,
            "record_updates": self.record_updates,
            "contract_count": self.contract_count,
            "records": [record.state() for record in self.records.values()],
            "history": self.history[-self.history_capacity:],
            "last_contract": None if self.last_contract is None else self.last_contract.as_dict(),
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "GroundedLanguageCortex":
        cortex = cls(capacity=int(data.get("capacity", 512)), history_capacity=int(data.get("history_capacity", 128)))
        cortex.observed_count = int(data.get("observed_count", 0))
        cortex.record_updates = int(data.get("record_updates", 0))
        cortex.contract_count = int(data.get("contract_count", 0))
        for item in data.get("records", []):
            record = GroundedLexemeRecord.from_state(dict(item))
            cortex.records[record.record_id] = record
        cortex.history = [dict(item) for item in data.get("history", [])][-cortex.history_capacity:]
        last = data.get("last_contract")
        if isinstance(last, dict):
            cortex.last_contract = LanguageGroundingContract(
                word=str(last.get("word", "unknown")),
                grounded=bool(last.get("grounded", False)),
                anchor_count=int(last.get("anchor_count", 0)),
                top_anchors=tuple(dict(item) for item in last.get("top_anchors", [])),
                confidence=float(last.get("confidence", 0.0)),
                may_command_action=bool(last.get("may_command_action", False)),
                reason=str(last.get("reason", "restored")),
            )
        return cortex

    def _anchors(
        self,
        *,
        graph: NeuralGrowthGraph,
        trace: TickTrace,
        target_features: tuple[str, ...],
        contextual_affordance: ContextualAffordanceCortex | None,
        memory_economy: MemoryPressureGovernor | None,
    ) -> tuple[tuple[str, str, float], ...]:
        anchors: dict[tuple[str, str], float] = {}
        object_kind = object_kind_from_features(target_features)
        if object_kind.signature_id != "object=unknown":
            anchors[("object_kind", object_kind.signature_id)] = 0.72
        object_id = object_id_from_features(target_features)
        if object_id:
            anchors[("object_file", object_id)] = 0.66
        for feature in target_features:
            for concept in graph.concepts_for_feature(feature):
                anchors[("concept", concept)] = max(anchors.get(("concept", concept), 0.0), 0.58)
        anchors[("outcome", trace.outcome.kind)] = max(anchors.get(("outcome", trace.outcome.kind), 0.0), 0.40)
        if trace.action.kind:
            anchors[("action", trace.action.kind)] = max(anchors.get(("action", trace.action.kind), 0.0), 0.34)
        if contextual_affordance is not None:
            for record in contextual_affordance.records.values():
                if record.object_signature == object_kind.signature_id and record.action_kind == trace.action.kind:
                    anchors[("affordance", record.record_id)] = max(anchors.get(("affordance", record.record_id), 0.0), 0.42 * max(0.25, record.confidence))
        if memory_economy is not None and memory_economy.last_pressure is not None:
            pressure = memory_economy.last_pressure
            anchors[("memory_pressure", pressure.decision)] = max(anchors.get(("memory_pressure", pressure.decision), 0.0), 0.28 + pressure.score * 0.34)
            for summary in memory_economy.summaries.values():
                if summary.target_id == (trace.action.target_id or "none") and summary.action_kind == trace.action.kind:
                    anchors[("memory_summary", summary.summary_id)] = max(anchors.get(("memory_summary", summary.summary_id), 0.0), min(0.62, 0.22 + summary.mean_pressure * 0.40))
        ranked = sorted(((kind, anchor_id, strength) for (kind, anchor_id), strength in anchors.items()), key=lambda item: (-item[2], item[0], item[1]))
        return tuple(ranked[:20])

    def _anchor_node(self, anchor_kind: str, anchor_id: str) -> str:
        if anchor_kind == "concept" and anchor_id.startswith("concept:"):
            return anchor_id
        if anchor_kind == "object_kind":
            return f"object_kind:{anchor_id}"
        if anchor_kind == "object_file":
            return f"object_file:{_safe(anchor_id)}"
        if anchor_kind == "outcome":
            return f"outcome:{_safe(anchor_id)}"
        if anchor_kind == "action":
            return f"action:{_safe(anchor_id)}"
        if anchor_kind == "affordance":
            return f"affordance:{_safe(anchor_id)}"
        if anchor_kind == "memory_summary":
            return f"memory_summary:{_safe(anchor_id)}"
        if anchor_kind == "memory_pressure":
            return f"memory_pressure:{_safe(anchor_id)}"
        return f"language_anchor:{_safe(anchor_kind)}:{_safe(anchor_id)}"

    def _trim_records(self) -> None:
        if len(self.records) <= self.capacity:
            return
        ranked = sorted(self.records.values(), key=lambda record: (record.evidence_count, record.last_tick, record.record_id))
        for record in ranked[: max(0, len(self.records) - self.capacity)]:
            self.records.pop(record.record_id, None)


def _text_words(tokens: tuple[str, ...]) -> tuple[str, ...]:
    words: list[str] = []
    seen: set[str] = set()
    for token in tokens:
        if not token.startswith("text:word="):
            continue
        word = _safe_word(token.split("=", 1)[1])
        if not word or word in _STOP_WORDS or word in seen:
            continue
        words.append(word)
        seen.add(word)
    return tuple(words)


def _safe_word(word: object) -> str:
    cleaned = _safe(word)
    return cleaned[:48]


def _record_id(word: str, anchor_kind: str, anchor_id: str, actor_id: str, context_id: str) -> str:
    return ":".join(_safe(part) for part in (word, anchor_kind, anchor_id, actor_id, context_id))


def _safe(value: object) -> str:
    text = str(value).strip().lower().replace(" ", "_")
    allowed = []
    for char in text:
        if char.isalnum() or char in {"_", "-", "=", "|", ".", ":"}:
            allowed.append(char)
        else:
            allowed.append("_")
    compact = "".join(allowed)
    while "__" in compact:
        compact = compact.replace("__", "_")
    return compact.strip("_") or "unknown"


_STOP_WORDS = {
    "a", "an", "the", "is", "are", "this", "that", "these", "those", "to", "of", "and", "or", "for", "with", "teach",
    "learn", "means", "label", "name", "tutor", "observes", "text",
}
