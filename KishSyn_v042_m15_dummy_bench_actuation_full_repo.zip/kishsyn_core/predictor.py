"""Prediction facade over the neural graph."""

from __future__ import annotations

from .contracts import Prediction
from .neural_graph import NeuralGrowthGraph


class PredictiveModel:
    """Predicts expected outcome from learned target feature pathways."""

    def __init__(self, graph: NeuralGrowthGraph) -> None:
        self.graph = graph

    def predict(self, target_features: tuple[str, ...]) -> Prediction:
        outcome, confidence, evidence = self.graph.predicted_outcome(target_features)
        return Prediction(expected_outcome=outcome, confidence=confidence, evidence=evidence)
