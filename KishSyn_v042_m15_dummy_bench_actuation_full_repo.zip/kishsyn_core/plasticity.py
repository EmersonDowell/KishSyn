"""Plasticity engine for consequence learning."""

from __future__ import annotations

from .contracts import Action, BodyState, Outcome, PlasticityEvent, SensoryFrame
from .neural_graph import NeuralGrowthGraph


def _node_kind(token: str) -> str:
    if token.startswith("place:"):
        return "place"
    if token.startswith("terrain:"):
        return "terrain"
    if token.startswith("text:"):
        return "text"
    if token.startswith("screen:"):
        return "screen"
    if token.startswith("image:"):
        return "image"
    if token.startswith("audio:"):
        return "audio"
    if token.startswith("math:"):
        return "math"
    if token.startswith("console:"):
        return "console"
    if token.startswith("expression:"):
        return "expression"
    if token.startswith("action:"):
        return "action"
    if token.startswith("route:"):
        return "route"
    if token.startswith("target:"):
        return "target"
    if token.startswith("comfort:"):
        return "comfort"
    if token.startswith("motor:"):
        return "motor"
    if token.startswith("concept:"):
        return "concept"
    if token.startswith("symbol_goal:"):
        return "symbol_goal"
    if token.startswith("symbol:"):
        return "symbol"
    if token.startswith("outcome:"):
        return "outcome"
    if token.startswith("need:"):
        return "need"
    return "feature"


class PlasticityEngine:
    """Turns sensory-action-outcome traces into synapse updates."""

    def __init__(self, graph: NeuralGrowthGraph) -> None:
        self.graph = graph

    def integrate(
        self,
        *,
        tick: int,
        frame: SensoryFrame,
        body_before: BodyState,
        target_features: tuple[str, ...],
        outcome: Outcome,
        action: Action | None = None,
        self_causation: float = 0.0,
    ) -> tuple[PlasticityEvent, ...]:
        events: list[PlasticityEvent] = []
        dominant_need = body_before.dominant_need()
        need_node = f"need:{dominant_need}"
        outcome_node = f"outcome:{outcome.kind}"
        self.graph.ensure_neuron(need_node, kind="need", label=dominant_need, tick=tick)
        self.graph.ensure_neuron(outcome_node, kind="outcome", label=outcome.kind, tick=tick)
        self.graph.activate(need_node, amount=0.85, tick=tick)
        self.graph.activate(outcome_node, amount=0.95, tick=tick)
        if action is not None:
            action_node = f"action:{action.kind}"
            self.graph.ensure_neuron(action_node, kind="action", label=action.kind, tick=tick)
            self.graph.activate(action_node, amount=max(0.35, self_causation), tick=tick)
            if self_causation >= 0.5:
                events.append(self.graph.reinforce(action_node, outcome_node, amount=0.055, tick=tick, reason="efference outcome link"))

        if outcome.kind == "relief":
            amount = 0.16
        elif outcome.kind == "pain":
            amount = 0.22
        elif outcome.kind == "novelty":
            amount = 0.10
        else:
            amount = 0.035

        for token in frame.tokens():
            if token.startswith("vision:agent_"):
                continue
            self.graph.ensure_neuron(token, kind=_node_kind(token), label=token, tick=tick)
            self.graph.activate(token, amount=0.45, tick=tick)

        active_target_features: list[str] = []
        for feature in target_features:
            self.graph.ensure_neuron(feature, kind=_node_kind(feature), label=feature, tick=tick)
            self.graph.activate(feature, amount=0.80, tick=tick)
            active_target_features.append(feature)
            events.append(self.graph.reinforce(feature, outcome_node, amount=amount, tick=tick, reason="target consequence"))
            if outcome.kind == "pain":
                events.append(self.graph.reinforce(need_node, feature, amount=-0.10, tick=tick, reason="avoid harmful affordance"))
            elif outcome.kind in {"relief", "novelty"}:
                events.append(self.graph.reinforce(need_node, feature, amount=0.08, tick=tick, reason="need linked to useful affordance"))

        if outcome.kind in {"relief", "pain", "novelty"}:
            for i, source in enumerate(active_target_features[:6]):
                for target in active_target_features[i + 1 : 6]:
                    events.append(self.graph.reinforce(source, target, amount=0.012, tick=tick, reason="coactive sensory-place binding"))

        if active_target_features and outcome.kind in {"relief", "pain", "novelty", "depleted"}:
            events.extend(self.graph.abstract_from_features(
                tick=tick,
                features=tuple(active_target_features),
                outcome_node=outcome_node,
                need_node=need_node,
                reason="trace-grounded concept",
            ))
            events.extend(self.graph.bind_symbols_from_features(
                tick=tick,
                features=tuple(active_target_features),
                outcome_node=outcome_node,
                need_node=need_node,
                reason="embodied symbol teaching",
            ))

        self.graph.decay()
        return tuple(events)
