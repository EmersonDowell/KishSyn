"""Trace-grounded text crib for KishSyn Core.

Text is treated as a sensory-motor surface, not a chatbot mask. External text
enters the organism as replayable sensory features. Primitive typed output is
allowed only as a graph-derived response over learned text/symbol/concept
bindings.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import re

from .contracts import Outcome, PlasticityEvent, SensoryFeature, SensoryFrame
from .neural_graph import NeuralGrowthGraph
from .symbol_goal import ActiveSymbolGoalMemory

_WORD_RE = re.compile(r"[a-zA-Z0-9_]+")


@dataclass(frozen=True)
class TextUtterance:
    tick: int
    source: str
    text: str
    normalized: str
    words: tuple[str, ...]
    chars: tuple[str, ...]
    expires_tick: int
    consumed: bool = False


@dataclass(frozen=True)
class TextMotorOutput:
    tick: int
    text: str
    reason: str
    evidence: tuple[str, ...] = ()


class TextCribMemory:
    """Small persistent text surface.

    The crib does three lawful things:
    1. turns external text into sensory features for the main loop,
    2. binds text words/chars to already-grown symbol/concept pathways,
    3. emits primitive graph-derived text output for the observatory console.
    """

    def __init__(self, *, history_limit: int = 64, output_limit: int = 64) -> None:
        self.history: deque[TextUtterance] = deque(maxlen=history_limit)
        self.outputs: deque[TextMotorOutput] = deque(maxlen=output_limit)
        self.input_count = 0
        self.output_count = 0
        self.binding_updates = 0
        self.goal_activations = 0
        self.last_features: tuple[str, ...] = ()
        self.last_response = ""
        self.last_reason = "no text input yet"
        self.last_evidence: tuple[str, ...] = ()
        self._responded_inputs: set[tuple[int, str]] = set()

    def receive_text(self, *, tick: int, text: str, source: str = "user", ttl: int = 18) -> TextUtterance:
        normalized = self._normalize(text)
        words = tuple(_WORD_RE.findall(normalized))[:18]
        chars = tuple(ch for ch in normalized if not ch.isspace())[:64]
        utterance = TextUtterance(
            tick=tick,
            source=source[:32] or "user",
            text=text[:500],
            normalized=normalized[:500],
            words=words,
            chars=chars,
            expires_tick=tick + max(2, ttl),
        )
        self.history.append(utterance)
        self.input_count += 1
        self.last_reason = f"received {len(words)} text words"
        return utterance

    def inject_features(self, *, tick: int, frame: SensoryFrame) -> SensoryFrame:
        utterance = self.active_utterance(tick)
        if utterance is None:
            self.last_features = ()
            return frame
        additions: list[SensoryFeature] = [
            SensoryFeature("surface", "text_console", "text", 0.75),
            SensoryFeature("source", utterance.source, "text", 0.45),
            SensoryFeature("word_count", self._count_band(len(utterance.words)), "text", 0.36),
            SensoryFeature("char_count", self._count_band(len(utterance.chars)), "text", 0.32),
        ]
        if "?" in utterance.text:
            additions.append(SensoryFeature("punctuation", "question", "text", 0.42))
        for word in utterance.words[:8]:
            additions.append(SensoryFeature("word", word, "text", 0.64))
            if len(word) == 1:
                additions.append(SensoryFeature("glyph", word.upper(), "text", 0.50))
            if word.isdigit():
                additions.append(SensoryFeature("number", word, "text", 0.54))
        for char in utterance.chars[:12]:
            additions.append(SensoryFeature("char", char, "text", 0.30))
        features = tuple(frame.features) + tuple(additions)
        raw = dict(frame.raw)
        raw["text_crib"] = self.snapshot(tick=tick)
        self.last_features = tuple(feature.token for feature in additions)
        return SensoryFrame(tick=frame.tick, features=features, raw=raw)

    def activate_symbol_goals_from_text(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph,
        symbol_goal: ActiveSymbolGoalMemory,
    ) -> tuple[PlasticityEvent, ...]:
        utterance = self.active_utterance(tick)
        if utterance is None:
            return ()
        events: list[PlasticityEvent] = []
        best_word = ""
        best_strength = 0.0
        for word in utterance.words:
            token_node = f"symbol:token={word}"
            if token_node not in graph.neurons:
                continue
            strength = self._symbol_strength(graph, word)
            if strength > best_strength:
                best_word = word
                best_strength = strength
        if best_word and best_strength > 0.025:
            events.extend(symbol_goal.activate_token(
                tick=tick,
                graph=graph,
                token=best_word,
                source_target=None,
                reason=f"text crib cue word {best_word}",
                ttl=36,
            ))
            self.goal_activations += 1
        return tuple(events)

    def record_exposure(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph,
        frame: SensoryFrame,
        outcome: Outcome,
    ) -> tuple[PlasticityEvent, ...]:
        text_tokens = tuple(token for token in frame.tokens() if token.startswith("text:"))
        if not text_tokens:
            return ()
        events: list[PlasticityEvent] = []
        outcome_node = f"outcome:{outcome.kind}"
        graph.ensure_neuron(outcome_node, kind="outcome", label=outcome.kind, tick=tick)
        for token in text_tokens:
            graph.ensure_neuron(token, kind="text", label=token, tick=tick)
            graph.activate(token, amount=0.50, tick=tick)
        words = self._feature_values(text_tokens, "text:word")
        chars = self._feature_values(text_tokens, "text:char")
        for word in words:
            word_node = f"text:word={word}"
            events.append(graph.reinforce(word_node, outcome_node, amount=0.008, tick=tick, reason="text surface coactive outcome"))
            token_node = f"symbol:token={word}"
            if token_node in graph.neurons:
                events.append(graph.reinforce(word_node, token_node, amount=0.080, tick=tick, reason="text word recalled learned symbol"))
                events.append(graph.reinforce(token_node, word_node, amount=0.050, tick=tick, reason="symbol can be typed as text"))
                self.binding_updates += 2
                for (source, concept), synapse in list(graph.synapses.items()):
                    if source == token_node and concept.startswith("concept:") and synapse.weight > 0.01:
                        events.append(graph.reinforce(word_node, concept, amount=0.036, tick=tick, reason="text word grounded through symbol concept"))
                        events.append(graph.reinforce(concept, word_node, amount=0.018, tick=tick, reason="concept can recall text word"))
                        self.binding_updates += 2
        for word in words[:5]:
            word_node = f"text:word={word}"
            for char in chars[:16]:
                char_node = f"text:char={char}"
                events.append(graph.reinforce(word_node, char_node, amount=0.006, tick=tick, reason="text word/character coactivation"))
        self._maybe_generate_response(tick=tick, graph=graph, words=words)
        return tuple(events)

    def active_utterance(self, tick: int) -> TextUtterance | None:
        for utterance in reversed(self.history):
            if tick <= utterance.expires_tick:
                return utterance
        return None

    def snapshot(self, *, tick: int) -> dict[str, object]:
        active = self.active_utterance(tick)
        return {
            "input_count": self.input_count,
            "output_count": self.output_count,
            "binding_updates": self.binding_updates,
            "goal_activations": self.goal_activations,
            "active": None if active is None else {
                "source": active.source,
                "text": active.text,
                "words": list(active.words),
                "ttl": max(0, active.expires_tick - tick),
            },
            "last_features": list(self.last_features[:16]),
            "last_response": self.last_response,
            "last_reason": self.last_reason,
            "last_evidence": list(self.last_evidence),
            "history": [
                {"tick": item.tick, "source": item.source, "text": item.text, "words": list(item.words), "ttl": max(0, item.expires_tick - tick)}
                for item in list(self.history)[-8:]
            ],
            "outputs": [
                {"tick": item.tick, "text": item.text, "reason": item.reason, "evidence": list(item.evidence)}
                for item in list(self.outputs)[-8:]
            ],
        }

    def restore(self, data: dict[str, object]) -> None:
        self.history.clear()
        self.outputs.clear()
        for item in data.get("history", []):
            if isinstance(item, dict):
                self.history.append(TextUtterance(
                    tick=int(item.get("tick", 0)),
                    source=str(item.get("source", "user")),
                    text=str(item.get("text", "")),
                    normalized=str(item.get("normalized", self._normalize(str(item.get("text", ""))))),
                    words=tuple(str(v) for v in item.get("words", [])),
                    chars=tuple(str(v) for v in item.get("chars", [])),
                    expires_tick=int(item.get("expires_tick", item.get("tick", 0))),
                    consumed=bool(item.get("consumed", False)),
                ))
        for item in data.get("outputs", []):
            if isinstance(item, dict):
                self.outputs.append(TextMotorOutput(
                    tick=int(item.get("tick", 0)),
                    text=str(item.get("text", "")),
                    reason=str(item.get("reason", "restored")),
                    evidence=tuple(str(v) for v in item.get("evidence", [])),
                ))
        self.input_count = int(data.get("input_count", len(self.history)))
        self.output_count = int(data.get("output_count", len(self.outputs)))
        self.binding_updates = int(data.get("binding_updates", 0))
        self.goal_activations = int(data.get("goal_activations", 0))
        self.last_features = tuple(str(v) for v in data.get("last_features", []))
        self.last_response = str(data.get("last_response", ""))
        self.last_reason = str(data.get("last_reason", "restored text crib"))
        self.last_evidence = tuple(str(v) for v in data.get("last_evidence", []))

    def state(self) -> dict[str, object]:
        return {
            "input_count": self.input_count,
            "output_count": self.output_count,
            "binding_updates": self.binding_updates,
            "goal_activations": self.goal_activations,
            "last_features": list(self.last_features),
            "last_response": self.last_response,
            "last_reason": self.last_reason,
            "last_evidence": list(self.last_evidence),
            "history": [
                {
                    "tick": item.tick,
                    "source": item.source,
                    "text": item.text,
                    "normalized": item.normalized,
                    "words": list(item.words),
                    "chars": list(item.chars),
                    "expires_tick": item.expires_tick,
                    "consumed": item.consumed,
                }
                for item in self.history
            ],
            "outputs": [
                {"tick": item.tick, "text": item.text, "reason": item.reason, "evidence": list(item.evidence)}
                for item in self.outputs
            ],
        }

    def _maybe_generate_response(self, *, tick: int, graph: NeuralGrowthGraph, words: tuple[str, ...]) -> None:
        utterance = self.active_utterance(tick)
        if utterance is None:
            return
        key = (utterance.tick, utterance.normalized)
        if key in self._responded_inputs:
            return
        evidence: list[str] = []
        phrases: list[str] = []
        for word in words[:8]:
            token_node = f"symbol:token={word}"
            word_node = f"text:word={word}"
            if token_node in graph.neurons:
                linked = []
                for (source, target), synapse in graph.synapses.items():
                    if source == token_node and target.startswith("concept:") and synapse.weight > 0.01:
                        linked.append((target.replace("concept:", ""), synapse.weight))
                linked.sort(key=lambda item: -item[1])
                if linked:
                    best = linked[0]
                    phrases.append(f"{word}->{best[0]}")
                    evidence.append(f"{token_node}->{best[0]}:{best[1]:.3f}")
                    continue
            if word_node in graph.neurons:
                phrases.append(f"{word}->seen")
            else:
                phrases.append(f"{word}->unknown")
        if not phrases:
            response = "text sensed"
            reason = "no stable word features yet"
        else:
            response = " | ".join(phrases[:5])
            reason = "graph-derived text response"
        output = TextMotorOutput(tick=tick, text=response, reason=reason, evidence=tuple(evidence[:8]))
        self.outputs.append(output)
        self.output_count += 1
        self.last_response = response
        self.last_reason = reason
        self.last_evidence = tuple(evidence[:8])
        self._responded_inputs.add(key)

    def _symbol_strength(self, graph: NeuralGrowthGraph, word: str) -> float:
        token_node = f"symbol:token={word}"
        direct = 0.0
        for (source, target), synapse in graph.synapses.items():
            if source == token_node and target.startswith("concept:"):
                direct = max(direct, synapse.weight)
        return direct

    def _feature_values(self, features: tuple[str, ...], prefix: str) -> tuple[str, ...]:
        needle = prefix + "="
        return tuple(feature.split("=", 1)[1] for feature in features if feature.startswith(needle))

    def _normalize(self, text: str) -> str:
        return " ".join(text.strip().lower().split())

    def _count_band(self, count: int) -> str:
        if count <= 0:
            return "none"
        if count == 1:
            return "one"
        if count <= 3:
            return "few"
        if count <= 8:
            return "some"
        return "many"
