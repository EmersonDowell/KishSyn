"""The one living organism loop.

All future features must enter this loop through sensorium, action, prediction,
plasticity, memory, or workspace. No parallel mind stacks.
"""

from __future__ import annotations

from dataclasses import dataclass

from .action import ActionCandidate, ActionSelector
from .anatomy import AnatomyGrowthEngine
from .atlas import NeuralAtlasProjector
from .atlas_inspector import NeuralAtlasInspector
from .autopilot import AutonomousTutorCurriculum
from .body import BodyRegulator
from .binding import BindingEngine
from .body_map import ProtoBodyMap
from .development import DevelopmentalRegulator
from .dummy_bench import DummyBenchActuator
from .expression import ExpressionSurface
from .emotion import EmotionalRegulationField
from .desktop_observation import OSObservationSubstrate
from .external_interface import ExternalAdapterRegistry
from .comfort import ComfortAttractorMemory
from .contracts import Action, BodyState, EfferenceCopy, Outcome, Prediction, TickTrace
from .contextual_affordance import ActorProfile, ContextualAffordanceCortex, RealityProvenance, WorldContext
from .grounded_language import GroundedLanguageCortex
from .interface_affordance import InterfaceAffordanceCortex
from .focus import FocusGate
from .memory import TraceMemory
from .memory_economy import MemoryPressureGovernor
from .intent import IntentModel
from .moment import MomentFrame, MomentLedger
from .motor_experiment import MotorExperimenter
from .planning import CounterfactualReplayEngine
from .sensory import SensoryAdapterHub
from .priority import PriorityArbitrator
from .self_model import SelfBoundaryModel
from .route_memory import RouteMemory
from .symbol_choice import SymbolChoiceProbe
from .symbol_goal import ActiveSymbolGoalMemory
from .text_crib import TextCribMemory
from .tutor import TutorSurface
from .neural_graph import NeuralGrowthGraph
from .object_file import ObjectFileCortex
from .plasticity import PlasticityEngine
from .play import IntrinsicPlayDrive
from .predictor import PredictiveModel
from .runtime_shell import RuntimeShellPolicy
from .workspace import GlobalWorkspace
from .world import MiniEcologyWorld


@dataclass(frozen=True)
class OrganismSnapshot:
    tick: int
    body: dict[str, float]
    world: dict[str, object]
    graph: dict[str, object]
    memory: dict[str, object]
    workspace: dict[str, object]
    self_model: dict[str, object]
    route_memory: dict[str, object]
    comfort_memory: dict[str, object]
    body_map: dict[str, object]
    development: dict[str, object]
    motor_experiment: dict[str, object]
    symbol_choice: dict[str, object]
    symbol_goal: dict[str, object]
    priority: dict[str, object]
    text_crib: dict[str, object]
    tutor: dict[str, object]
    autopilot: dict[str, object]
    action_reasoning: dict[str, object]
    focus: dict[str, object]
    moments: dict[str, object]
    binding: dict[str, object]
    anatomy: dict[str, object]
    intent: dict[str, object]
    planning: dict[str, object]
    sensory: dict[str, object]
    expression: dict[str, object]
    atlas: dict[str, object]
    atlas_inspector: dict[str, object]
    emotion: dict[str, object]
    contextual_affordance: dict[str, object]
    object_file: dict[str, object]
    memory_economy: dict[str, object]
    play: dict[str, object]
    grounded_language: dict[str, object]
    os_observation: dict[str, object]
    interface_affordance: dict[str, object]
    dummy_bench: dict[str, object]
    external_interface: dict[str, object]
    runtime_shell: dict[str, object]
    last_trace: dict[str, object] | None
    score: dict[str, float]


class OrganismLoop:
    """Persistent reflex-first organism runtime."""

    def __init__(self, *, seed: int = 1, world: MiniEcologyWorld | None = None, graph: NeuralGrowthGraph | None = None) -> None:
        self.world = world if world is not None else MiniEcologyWorld(seed=seed)
        self.graph = graph if graph is not None else NeuralGrowthGraph()
        self.body = BodyState()
        self.regulator = BodyRegulator()
        self.selector = ActionSelector(self.graph)
        self.predictor = PredictiveModel(self.graph)
        self.plasticity = PlasticityEngine(self.graph)
        self.memory = TraceMemory()
        self.workspace = GlobalWorkspace()
        self.self_model = SelfBoundaryModel()
        self.route_memory = RouteMemory()
        self.comfort_memory = ComfortAttractorMemory()
        self.body_map = ProtoBodyMap()
        self.development = DevelopmentalRegulator()
        self.motor_experimenter = MotorExperimenter()
        self.symbol_choice_probe = SymbolChoiceProbe()
        self.symbol_goal = ActiveSymbolGoalMemory()
        self.priority = PriorityArbitrator()
        self.text_crib = TextCribMemory()
        self.tutor = TutorSurface()
        self.autopilot = AutonomousTutorCurriculum()
        self.focus_gate = FocusGate()
        self.moment_ledger = MomentLedger()
        self.binding_engine = BindingEngine()
        self.anatomy_growth = AnatomyGrowthEngine()
        self.intent_model = IntentModel()
        self.counterfactual_replay = CounterfactualReplayEngine()
        self.sensory_hub = SensoryAdapterHub()
        self.expression_surface = ExpressionSurface()
        self.neural_atlas = NeuralAtlasProjector()
        self.neural_atlas_inspector = NeuralAtlasInspector()
        self.emotional_regulation = EmotionalRegulationField()
        self.contextual_affordance = ContextualAffordanceCortex()
        self.object_file = ObjectFileCortex()
        self.memory_economy = MemoryPressureGovernor()
        self.play_drive = IntrinsicPlayDrive()
        self.grounded_language = GroundedLanguageCortex()
        self.os_observation = OSObservationSubstrate()
        self.interface_affordance = InterfaceAffordanceCortex()
        self.dummy_bench = DummyBenchActuator()
        self.external_registry = ExternalAdapterRegistry()
        self.runtime_shell_policy = RuntimeShellPolicy()
        self.actor_profile = ActorProfile()
        self.world_context = WorldContext()
        self.tick = 0
        self.last_trace: TickTrace | None = None
        self.replay_interval = 9
        self.current_goal_id: str | None = None
        self.goal_started_tick = 0

    def step(self) -> TickTrace:
        body_before = self.regulator.metabolic_drift(self.body)
        autopilot_plasticity = list(self.autopilot.maybe_teach(
            tick=self.tick,
            body=body_before,
            graph=self.graph,
            tutor=self.tutor,
            text_crib=self.text_crib,
            symbol_goal=self.symbol_goal,
        ))
        base_frame = self.world.observe(body_before)
        adapted_frame = self.sensory_hub.inject_features(tick=self.tick, frame=base_frame)
        raw_frame = self.text_crib.inject_features(tick=self.tick, frame=adapted_frame)
        frame = raw_frame
        text_goal_plasticity = list(self.text_crib.activate_symbol_goals_from_text(tick=self.tick, graph=self.graph, symbol_goal=self.symbol_goal))
        from_place = self.world.place_key(self.world.agent_x, self.world.agent_y)
        focus = self.development.sense(tick=self.tick, body=body_before, memory=self.memory, graph=self.graph)
        motor_intent = self.motor_experimenter.propose(
            tick=self.tick,
            body=body_before,
            focus=focus,
            body_map=self.body_map,
            world=self.world,
        )
        priority_decision, priority_plasticity = self.priority.decide(
            tick=self.tick,
            graph=self.graph,
            body=body_before,
            symbol_goal=self.symbol_goal,
            focus=focus,
        )
        play_intent = self.play_drive.propose(tick=self.tick, body=body_before, world=self.world)
        emotion_bias = self.emotional_regulation.bias_contract(tick=self.tick, body=body_before)
        focus_report = self.focus_gate.select(
            tick=self.tick,
            frame=raw_frame,
            body=body_before,
            graph=self.graph,
            active_symbol_tokens=priority_decision.active_symbol_tokens,
            learning_focus=focus,
            emotion_bias=emotion_bias,
        )
        frame = focus_report.to_frame(raw_frame)
        candidate = self.selector.choose(
            frame=frame,
            body=body_before,
            world=self.world,
            route_memory=self.route_memory,
            comfort_memory=self.comfort_memory,
            body_map=self.body_map,
            learning_focus=focus,
            motor_experiment=motor_intent,
            active_symbol_tokens=priority_decision.active_symbol_tokens,
            priority_focus=priority_decision,
            play_intent=play_intent,
        )
        candidate = self.counterfactual_replay.plan(
            tick=self.tick,
            candidate=candidate,
            decision_snapshot=self.selector.decision_snapshot(),
            body=body_before,
            world=self.world,
            graph=self.graph,
            predictor=self.predictor,
        )
        candidate = self.intent_model.stabilize(
            tick=self.tick,
            candidate=candidate,
            world=self.world,
            body=body_before,
            active_symbol_tokens=priority_decision.active_symbol_tokens,
        )
        self.selector.note_final_choice(candidate, world=self.world)
        target_features = self.world.target_features(candidate.action.target_id)
        prediction = self.predictor.predict(target_features)
        efference = EfferenceCopy(tick=self.tick, action=candidate.action, prediction=prediction)
        outcome = self.world.step(candidate.action)
        world_events = tuple(self.world.last_events)
        boundary = self.self_model.evaluate(efference=efference, outcome=outcome, world_events=world_events)
        to_place = self.world.place_key(self.world.agent_x, self.world.agent_y)
        body_after = self.regulator.apply_outcome(body_before, outcome)
        prediction_error = self._prediction_error(prediction, outcome)
        moment = MomentFrame.capture(
            tick=self.tick,
            raw_frame=raw_frame,
            focused_frame=frame,
            focus=focus_report,
            body_before=body_before,
            action=candidate.action,
            prediction=prediction,
            outcome=outcome,
            prediction_error=prediction_error,
            target_tokens=target_features,
            self_causation=boundary.self_causation,
            world_causation=boundary.world_causation,
            causation_label=boundary.label,
        )
        plasticity = list(autopilot_plasticity)
        plasticity.extend(text_goal_plasticity)
        plasticity.extend(priority_plasticity)
        plasticity.extend(self.plasticity.integrate(
            tick=self.tick,
            frame=frame,
            body_before=body_before,
            target_features=target_features,
            outcome=outcome,
            action=candidate.action,
            self_causation=boundary.self_causation,
        ))
        plasticity.extend(self.route_memory.record(
            tick=self.tick,
            graph=self.graph,
            from_place=from_place,
            to_place=to_place,
            action=candidate.action,
            outcome=outcome,
            dominant_need=body_before.dominant_need(),
        ))
        plasticity.extend(self.comfort_memory.record(
            tick=self.tick,
            graph=self.graph,
            place_key=to_place,
            terrain=self.world.terrain_at(self.world.agent_x, self.world.agent_y),
            body_before=body_before,
            body_after=body_after,
            outcome=outcome,
            prediction_error=prediction_error,
            world_events=world_events,
        ))
        plasticity.extend(self.body_map.record(
            tick=self.tick,
            graph=self.graph,
            action=candidate.action,
            body_before=body_before,
            body_after=body_after,
            from_place=from_place,
            to_place=to_place,
            outcome=outcome,
            prediction_error=prediction_error,
            self_causation=boundary.self_causation,
        ))
        plasticity.extend(self.motor_experimenter.record(
            tick=self.tick,
            graph=self.graph,
            intent=motor_intent,
            action=candidate.action,
            outcome=outcome,
            prediction_error=prediction_error,
            self_causation=boundary.self_causation,
            body_before=body_before,
            body_after=body_after,
        ))
        plasticity.extend(self.intent_model.record_outcome(
            tick=self.tick,
            graph=self.graph,
            action=candidate.action,
            outcome=outcome,
            prediction_error=prediction_error,
        ))
        plasticity.extend(self.counterfactual_replay.record_outcome(
            tick=self.tick,
            graph=self.graph,
            action=candidate.action,
            outcome_kind=outcome.kind,
            prediction=prediction,
            prediction_error=prediction_error,
        ))
        plasticity.extend(self.contextual_affordance.record(
            tick=self.tick,
            graph=self.graph,
            actor=self.actor_profile,
            context=self.world_context,
            target_features=target_features,
            action=candidate.action,
            outcome=outcome,
            prediction_error=prediction_error,
            provenance=RealityProvenance(source="self_action", confidence=1.0, note="completed organism loop tick"),
        ))
        plasticity.extend(self.object_file.record(
            tick=self.tick,
            graph=self.graph,
            target_features=target_features,
            action=candidate.action,
            outcome=outcome,
            prediction_error=prediction_error,
        ))
        plasticity.extend(self.play_drive.record(
            tick=self.tick,
            graph=self.graph,
            intent=play_intent,
            action=candidate.action,
            target_features=target_features,
            prediction=prediction,
            outcome=outcome,
            prediction_error=prediction_error,
        ))
        plasticity.extend(self.expression_surface.maybe_express(
            tick=self.tick,
            graph=self.graph,
            body=body_before,
            action=candidate.action,
            prediction=prediction,
            outcome=outcome,
            prediction_error=prediction_error,
            focus_report=focus_report,
            emotion_bias=emotion_bias,
        ))
        plasticity.extend(self.emotional_regulation.observe(
            tick=self.tick,
            graph=self.graph,
            body_before=body_before,
            body_after=body_after,
            action=candidate.action,
            prediction=prediction,
            outcome=outcome,
            prediction_error=prediction_error,
            self_causation=boundary.self_causation,
            world_causation=boundary.world_causation,
            focus_report=focus_report,
            intent_snapshot=self.intent_model.snapshot(),
            planning_snapshot=self.counterfactual_replay.snapshot(),
        ))
        plasticity.extend(self.symbol_goal.record_guided_choice(
            tick=self.tick,
            graph=self.graph,
            action=candidate.action,
            target_features=target_features,
            outcome=outcome,
        ))
        plasticity.extend(self.symbol_goal.record_cue_experience(
            tick=self.tick,
            graph=self.graph,
            target_features=target_features,
            outcome=outcome,
        ))
        plasticity.extend(self.text_crib.record_exposure(
            tick=self.tick,
            graph=self.graph,
            frame=frame,
            outcome=outcome,
        ))
        plasticity.extend(self.binding_engine.observe(
            tick=self.tick,
            graph=self.graph,
            moment=moment,
        ))
        plasticity.extend(self.anatomy_growth.observe(
            tick=self.tick,
            graph=self.graph,
            moment=moment,
            binding=self.binding_engine.last_binding,
        ))
        self.moment_ledger.append(moment)
        # Developmental regulation is made plastic only after the actual outcome.
        # It may bias future actions, but it cannot rewrite this tick.
        provisional_trace = TickTrace(
            tick=self.tick,
            frame=frame,
            body_before=body_before,
            action=candidate.action,
            prediction=prediction,
            outcome=outcome,
            body_after=body_after,
            prediction_error=prediction_error,
            plasticity=tuple(plasticity),
            workspace=(),
            efference=efference,
            self_causation=boundary.self_causation,
            world_causation=boundary.world_causation,
            causation_label=boundary.label,
            world_events=world_events,
        )
        plasticity.extend(self.development.record(tick=self.tick, graph=self.graph, trace=provisional_trace, focus=focus))
        trace = TickTrace(
            tick=self.tick,
            frame=frame,
            body_before=body_before,
            action=candidate.action,
            prediction=prediction,
            outcome=outcome,
            body_after=body_after,
            prediction_error=prediction_error,
            plasticity=tuple(plasticity),
            workspace=(),
            efference=efference,
            self_causation=boundary.self_causation,
            world_causation=boundary.world_causation,
            causation_label=boundary.label,
            world_events=world_events,
        )
        broadcasts = self.workspace.evaluate(trace)
        trace = TickTrace(
            tick=trace.tick,
            frame=trace.frame,
            body_before=trace.body_before,
            action=trace.action,
            prediction=trace.prediction,
            outcome=trace.outcome,
            body_after=trace.body_after,
            prediction_error=trace.prediction_error,
            plasticity=trace.plasticity,
            workspace=broadcasts,
            efference=trace.efference,
            self_causation=trace.self_causation,
            world_causation=trace.world_causation,
            causation_label=trace.causation_label,
            world_events=trace.world_events,
        )
        memory_events = self.memory_economy.observe(tick=self.tick, graph=self.graph, trace=trace)
        if memory_events:
            trace = TickTrace(
                tick=trace.tick,
                frame=trace.frame,
                body_before=trace.body_before,
                action=trace.action,
                prediction=trace.prediction,
                outcome=trace.outcome,
                body_after=trace.body_after,
                prediction_error=trace.prediction_error,
                plasticity=trace.plasticity + tuple(memory_events),
                workspace=trace.workspace,
                efference=trace.efference,
                self_causation=trace.self_causation,
                world_causation=trace.world_causation,
                causation_label=trace.causation_label,
                world_events=trace.world_events,
            )
        language_events = self.grounded_language.observe(
            tick=self.tick,
            graph=self.graph,
            trace=trace,
            target_features=target_features,
            actor=self.actor_profile,
            context=self.world_context,
            contextual_affordance=self.contextual_affordance,
            memory_economy=self.memory_economy,
        )
        if language_events:
            trace = TickTrace(
                tick=trace.tick,
                frame=trace.frame,
                body_before=trace.body_before,
                action=trace.action,
                prediction=trace.prediction,
                outcome=trace.outcome,
                body_after=trace.body_after,
                prediction_error=trace.prediction_error,
                plasticity=trace.plasticity + tuple(language_events),
                workspace=trace.workspace,
                efference=trace.efference,
                self_causation=trace.self_causation,
                world_causation=trace.world_causation,
                causation_label=trace.causation_label,
                world_events=trace.world_events,
            )
        self.memory.append(trace)
        self.body = body_after
        self.last_trace = trace
        self.tick += 1
        if self.development.should_replay_now(tick=self.tick, focus=self.development.last_focus) or self.tick % self.replay_interval == 0:
            replay = self.memory.replay(tick=self.tick, graph=self.graph)
            if replay is not None:
                self.workspace.events.append(f"t{self.tick}: replayed t{replay.source_tick} ({replay.strengthened_edges} edges)")
        return trace


    def _stabilize_goal(self, candidate: ActionCandidate) -> ActionCandidate:
        """Keep a foraging/motor target long enough to reach it.

        This is not a hardcoded home or task policy. It is motor continuity:
        without a short-lived goal trace, the selector can oscillate between
        nearby high-value targets and never complete contact. The trace decays
        quickly, drops on depleted/painful/missing targets, and only biases
        movement toward currently available non-hazard objects.
        """

        target_id = candidate.action.target_id
        if self.current_goal_id in self.world.objects:
            goal = self.world.objects[self.current_goal_id]
            age = self.tick - self.goal_started_tick
            if goal.quantity > 0 and goal.affordance != "hazard" and age <= 22:
                distance = self.world.distance_to(goal.object_id)
                if distance > 0:
                    reason = f"persistent foraging goal toward {goal.color}/{goal.shape}; {candidate.action.reason}"
                    return ActionCandidate(Action("move", goal.object_id, reason), candidate.score + 0.12, reason)
                reason = f"reached persistent foraging goal {goal.color}/{goal.shape}; {candidate.action.reason}"
                return ActionCandidate(Action("touch", goal.object_id, reason), candidate.score + 0.18, reason)
            self.current_goal_id = None

        if target_id in self.world.objects:
            target = self.world.objects[target_id]
            if target.quantity > 0 and target.affordance != "hazard" and candidate.action.kind in {"move", "inspect", "touch", "eat", "drink", "rest"}:
                self.current_goal_id = target_id
                self.goal_started_tick = self.tick
        return candidate

    def run(self, *, steps: int) -> list[TickTrace]:
        return [self.step() for _ in range(steps)]

    def ablated_memory_score(self, *, steps: int = 36, seed: int = 1) -> float:
        ablated = OrganismLoop(seed=seed, graph=self.graph.ablated_copy(keep_neurons=True))
        ablated.run(steps=steps)
        return ablated.survival_score()

    def survival_score(self) -> float:
        return round((self.body.energy + self.body.hydration + self.body.integrity + (1.0 - self.body.fatigue)) / 4.0, 4)

    def growth_score(self) -> float:
        node_count = len(self.graph.neurons)
        edge_count = len([s for s in self.graph.synapses.values() if abs(s.weight) > 0.01])
        return round(min(1.0, (node_count / 32.0) * 0.35 + (edge_count / 48.0) * 0.65), 4)

    def snapshot(self) -> OrganismSnapshot:
        return OrganismSnapshot(
            tick=self.tick,
            body={
                "energy": round(self.body.energy, 4),
                "hydration": round(self.body.hydration, 4),
                "integrity": round(self.body.integrity, 4),
                "fatigue": round(self.body.fatigue, 4),
                "curiosity": round(self.body.curiosity, 4),
                "uncertainty": round(self.body.uncertainty, 4),
                "dominant_need": self.body.dominant_need(),
            },
            world={
                "agent": {"x": self.world.agent_x, "y": self.world.agent_y},
                "width": self.world.width,
                "height": self.world.height,
                "objects": [self.world.object_view(obj) for obj in self.world.living_objects()],
                "terrain_map": self.world.terrain_view(),
                "comfort_map": self._comfort_view(),
                "foraging": self.world.foraging_snapshot(),
            },
            graph=self.graph.snapshot(),
            memory=self.memory.snapshot(),
            workspace=self.workspace.snapshot(),
            self_model=self.self_model.snapshot(),
            route_memory=self.route_memory.snapshot(),
            comfort_memory=self.comfort_memory.snapshot(),
            body_map=self.body_map.snapshot(),
            development=self.development.snapshot(),
            motor_experiment=self.motor_experimenter.snapshot(),
            symbol_choice=self.symbol_choice_probe.evaluate(self.graph).as_dict(),
            symbol_goal=self.symbol_goal.snapshot(tick=self.tick),
            priority=self.priority.snapshot(),
            text_crib=self.text_crib.snapshot(tick=self.tick),
            tutor=self.tutor.snapshot(),
            autopilot=self.autopilot.snapshot(),
            action_reasoning=self.selector.decision_snapshot(),
            focus=self.focus_gate.snapshot(),
            moments=self.moment_ledger.snapshot(),
            binding=self.binding_engine.snapshot(),
            anatomy=self.anatomy_growth.snapshot(),
            intent=self.intent_model.snapshot(),
            planning=self.counterfactual_replay.snapshot(),
            sensory=self.sensory_hub.snapshot(),
            expression=self.expression_surface.snapshot(),
            atlas=self.neural_atlas.project(tick=self.tick, graph=self.graph, last_trace=self.last_trace).as_dict(),
            atlas_inspector=self.neural_atlas_inspector.atlas_index(graph=self.graph, tick=self.tick, limit=80),
            emotion=self.emotional_regulation.snapshot(),
            contextual_affordance=self.contextual_affordance.snapshot(),
            object_file=self.object_file.snapshot(),
            memory_economy=self.memory_economy.snapshot(),
            play=self.play_drive.snapshot(),
            grounded_language=self.grounded_language.snapshot(),
            os_observation=self.os_observation.snapshot(),
            interface_affordance=self.interface_affordance.snapshot(),
            dummy_bench=self.dummy_bench.snapshot(),
            external_interface=self.external_registry.snapshot(),
            runtime_shell=self.runtime_shell_policy.snapshot(),
            last_trace=self._trace_view(self.last_trace),
            score={
                "survival": self.survival_score(),
                "growth": self.growth_score(),
                "focus_selectivity": float(self.focus_gate.snapshot()["mean_selectivity"]),
                "moment_count": float(self.moment_ledger.snapshot()["count"]),
                "binding_candidates": float(self.binding_engine.snapshot()["candidate_count"]),
                "stable_bindings": float(self.binding_engine.snapshot()["stable_count"]),
                "circuit_count": float(self.anatomy_growth.snapshot()["circuit_count"]),
                "circuit_promotions": float(self.anatomy_growth.snapshot()["promotion_count"]),
                "cross_modal_bindings": float(self.binding_engine.snapshot().get("stable_cross_modal_count", 0.0)),
                "intent_continuity": float(self.intent_model.snapshot().get("continuity_ratio", 0.0)),
                "intent_completed": float(self.intent_model.snapshot().get("completed_count", 0.0)),
                "planning_alignment": float(self.counterfactual_replay.snapshot().get("alignment_ratio", 0.0)),
                "planning_options": float(self.counterfactual_replay.snapshot().get("mean_options", 0.0)),
                "planning_switches": float(self.counterfactual_replay.snapshot().get("plan_switches", 0.0)),
                "planning_templates": float(self.counterfactual_replay.snapshot().get("plan_template_count", 0.0)),
                "planning_template_updates": float(self.counterfactual_replay.snapshot().get("plan_template_updates", 0.0)),
                "sensory_packets": float(self.sensory_hub.snapshot().get("packet_count", 0.0)),
                "sensory_features": float(self.sensory_hub.snapshot().get("feature_count", 0.0)),
                "expression_outputs": float(self.expression_surface.snapshot().get("output_count", 0.0)),
                "atlas_inspectable_nodes": float(self.neural_atlas_inspector.atlas_index(graph=self.graph, tick=self.tick, limit=80).get("node_count", 0.0)),
                "atlas_inspectable_synapses": float(self.neural_atlas_inspector.atlas_index(graph=self.graph, tick=self.tick, limit=80).get("edge_count", 0.0)),
                "emotion_samples": float(self.emotional_regulation.snapshot().get("sample_count", 0.0)),
                "emotion_traits": float(self.emotional_regulation.snapshot().get("trait_count", 0.0)),
                "emotion_trait_mass": float(self.emotional_regulation.snapshot().get("trait_mass", 0.0)),
                "emotion_modes": float(self.emotional_regulation.snapshot().get("distinct_modes", 0.0)),
                "emotion_graph_events": float(self.emotional_regulation.snapshot().get("graph_event_count", 0.0)),
                "contextual_affordance_records": float(self.contextual_affordance.snapshot().get("record_count", 0.0)),
                "contextual_affordance_updates": float(self.contextual_affordance.snapshot().get("record_updates", 0.0)),
                "object_files": float(self.object_file.snapshot().get("file_count", 0.0)),
                "object_file_kinds": float(self.object_file.snapshot().get("kind_count", 0.0)),
                "memory_summaries": float(self.memory_economy.snapshot().get("summary_count", 0.0)),
                "memory_summary_updates": float(self.memory_economy.snapshot().get("summary_updates", 0.0)),
                "memory_consolidated": float(self.memory_economy.snapshot().get("consolidated_count", 0.0)),
                "play_proposals": float(self.play_drive.snapshot().get("proposal_count", 0.0)),
                "play_records": float(self.play_drive.snapshot().get("record_count", 0.0)),
                "play_patterns": float(self.play_drive.snapshot().get("pattern_count", 0.0)),
                "play_safe_count": float(self.play_drive.snapshot().get("safe_count", 0.0)),
                "grounded_language_records": float(self.grounded_language.snapshot().get("record_count", 0.0)),
                "grounded_language_words": float(self.grounded_language.snapshot().get("word_count", 0.0)),
                "grounded_language_updates": float(self.grounded_language.snapshot().get("record_updates", 0.0)),
                "os_observations": float(self.os_observation.snapshot().get("observation_count", 0.0)),
                "os_observation_surfaces": float(self.os_observation.snapshot().get("surface_count", 0.0)),
                "interface_affordance_records": float(self.interface_affordance.snapshot().get("record_count", 0.0)),
                "interface_affordance_signatures": float(self.interface_affordance.snapshot().get("signature_count", 0.0)),
                "interface_affordance_blocked_write_like": float(self.interface_affordance.snapshot().get("write_like_blocked_count", 0.0)),
                "interface_affordance_actuation_grants": float(self.interface_affordance.snapshot().get("actuation_grant_count", 0.0)),
                "dummy_bench_executions": float(self.dummy_bench.snapshot().get("executed_count", 0.0)),
                "dummy_bench_real_os_touches": float(self.dummy_bench.snapshot().get("real_os_touch_count", 0.0)),
                "external_allowed_affordances": float(self.external_registry.snapshot().get("allowed_count", 0.0)),
                "external_blocked_write_like": float(self.external_registry.snapshot().get("blocked_write_like_count", 0.0)),
                "runtime_desktop_exe_support": 1.0 if self.runtime_shell_policy.snapshot().get("supports_desktop_exe") else 0.0,
                "route_steps": float(self.route_memory.snapshot()["step_count"]),
                "comfort_basins": float(self.comfort_memory.snapshot()["basin_count"]),
                "body_channels": float(self.body_map.snapshot()["channel_count"]),
                "motor_probes": float(self.motor_experimenter.snapshot()["probe_count"]),
                "learning_progress": float(self.development.snapshot()["learning_progress"]),
                "visited_cells": float(self.world.foraging_snapshot()["visited_cells"]),
                "depleted_resources": float(self.world.foraging_snapshot()["depleted_resources"]),
                "resource_migrations": float(self.world.foraging_snapshot()["migration_count"]),
                "concept_count": float(self.graph.concept_snapshot()["concept_count"]),
                "concept_updates": float(self.graph.concept_snapshot()["concept_updates"]),
                "symbol_count": float(self.graph.symbol_snapshot()["symbol_count"]),
                "symbol_binding_updates": float(self.graph.symbol_snapshot()["symbol_binding_updates"]),
                "symbol_choice_accuracy": float(self.symbol_choice_probe.evaluate(self.graph).accuracy),
                "symbol_choice_ablation_delta": float(self.symbol_choice_probe.evaluate(self.graph).ablation_delta),
                "symbol_goal_activations": float(self.symbol_goal.snapshot(tick=self.tick)["activation_count"]),
                "symbol_goal_guided_attempts": float(self.symbol_goal.snapshot(tick=self.tick)["guided_attempts"]),
                "priority_honors": float(self.priority.snapshot()["honor_count"]),
                "priority_deferrals": float(self.priority.snapshot()["defer_count"]),
                "priority_survival_overrides": float(self.priority.snapshot()["survival_override_count"]),
                "text_inputs": float(self.text_crib.snapshot(tick=self.tick)["input_count"]),
                "text_outputs": float(self.text_crib.snapshot(tick=self.tick)["output_count"]),
                "text_binding_updates": float(self.text_crib.snapshot(tick=self.tick)["binding_updates"]),
                "tutor_lessons": float(self.tutor.snapshot()["lesson_count"]),
                "tutor_plasticity": float(self.tutor.snapshot()["plasticity_count"]),
                "autopilot_lessons": float(self.autopilot.snapshot()["lesson_count"]),
                "autopilot_plasticity": float(self.autopilot.snapshot()["plasticity_count"]),
            },
        )


    def _comfort_view(self) -> list[dict[str, object]]:
        cells: list[dict[str, object]] = []
        for y in range(self.world.height):
            for x in range(self.world.width):
                place = self.world.place_key(x, y)
                score = self.comfort_memory.heat_for(place)
                if abs(score) > 0.001:
                    cells.append({"x": x, "y": y, "place": place, "score": score})
        return cells

    def _prediction_error(self, prediction: Prediction, outcome: Outcome) -> float:
        if prediction.expected_outcome == outcome.kind:
            return round(max(0.0, 0.25 - prediction.confidence * 0.2), 4)
        if prediction.confidence < 0.15 and outcome.kind in {"relief", "pain", "novelty"}:
            return 0.85
        return round(0.55 + prediction.confidence * 0.35, 4)

    def _trace_view(self, trace: TickTrace | None) -> dict[str, object] | None:
        if trace is None:
            return None
        return {
            "tick": trace.tick,
            "action": trace.action.kind,
            "target": trace.action.target_id,
            "reason": trace.action.reason,
            "prediction": trace.prediction.expected_outcome,
            "prediction_confidence": round(trace.prediction.confidence, 4),
            "prediction_evidence": list(trace.prediction.evidence),
            "outcome": trace.outcome.kind,
            "message": trace.outcome.message,
            "prediction_error": trace.prediction_error,
            "plasticity_count": len(trace.plasticity),
            "workspace": list(trace.workspace),
            "efference_action": None if trace.efference is None else trace.efference.action.kind,
            "self_causation": round(trace.self_causation, 4),
            "world_causation": round(trace.world_causation, 4),
            "causation_label": trace.causation_label,
            "world_events": list(trace.world_events),
        }
