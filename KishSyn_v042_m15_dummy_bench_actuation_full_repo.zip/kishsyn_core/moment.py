"""Focused moment frames for KishSyn Milestone M1.

A TickTrace says what happened. A MomentFrame says what the organism selected
as the active experiential slice that made the tick learnable.
"""

from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass
from typing import Any

from .contracts import Action, BodyState, Outcome, Prediction, SensoryFrame
from .focus import FocusReport


@dataclass(frozen=True)
class MomentFrame:
    """One focused organism moment after action consequence is known.

    Pattern: Memento. The frame is immutable and replayable so future stores,
    tests, and anatomy growth can rely on a stable milestone contract.
    """

    tick: int
    raw_tokens: tuple[str, ...]
    focused_tokens: tuple[str, ...]
    target_tokens: tuple[str, ...]
    dominant_need: str
    body_pressure: float
    focus_selectivity: float
    action: str
    target_id: str | None
    prediction: str
    prediction_confidence: float
    outcome: str
    prediction_error: float
    self_causation: float
    world_causation: float
    causation_label: str
    workspace: tuple[str, ...] = ()

    @property
    def signature(self) -> str:
        head = ":".join(self.focused_tokens[:4]) or "empty"
        return f"{self.dominant_need}|{self.action}|{self.outcome}|{head}"

    def as_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["signature"] = self.signature
        payload["raw_count"] = len(self.raw_tokens)
        payload["focused_count"] = len(self.focused_tokens)
        payload["target_count"] = len(self.target_tokens)
        return payload

    @classmethod
    def capture(
        cls,
        *,
        tick: int,
        raw_frame: SensoryFrame,
        focused_frame: SensoryFrame,
        focus: FocusReport,
        body_before: BodyState,
        action: Action,
        prediction: Prediction,
        outcome: Outcome,
        prediction_error: float,
        target_tokens: tuple[str, ...],
        self_causation: float,
        world_causation: float,
        causation_label: str,
        workspace: tuple[str, ...] = (),
    ) -> "MomentFrame":
        pressures = body_before.needs()
        return cls(
            tick=tick,
            raw_tokens=raw_frame.tokens(),
            focused_tokens=focused_frame.tokens(),
            target_tokens=target_tokens,
            dominant_need=body_before.dominant_need(),
            body_pressure=round(max(pressures.values()) if pressures else 0.0, 4),
            focus_selectivity=focus.selectivity,
            action=action.kind,
            target_id=action.target_id,
            prediction=prediction.expected_outcome,
            prediction_confidence=round(prediction.confidence, 4),
            outcome=outcome.kind,
            prediction_error=round(prediction_error, 4),
            self_causation=round(self_causation, 4),
            world_causation=round(world_causation, 4),
            causation_label=causation_label,
            workspace=workspace,
        )


class MomentLedger:
    """Bounded recent focused-moment memory for inspection and persistence."""

    def __init__(self, *, capacity: int = 96) -> None:
        self.moments: deque[MomentFrame] = deque(maxlen=max(8, int(capacity)))

    def append(self, moment: MomentFrame) -> None:
        self.moments.append(moment)

    def snapshot(self) -> dict[str, Any]:
        moments = list(self.moments)
        return {
            "capacity": self.moments.maxlen or 96,
            "count": len(moments),
            "last": moments[-1].as_dict() if moments else None,
            "recent": [moment.as_dict() for moment in moments[-8:]],
        }

    def state(self) -> dict[str, Any]:
        return {
            "capacity": self.moments.maxlen or 96,
            "moments": [moment.as_dict() for moment in self.moments],
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "MomentLedger":
        ledger = cls(capacity=int(data.get("capacity", 96)))
        for item in data.get("moments", [])[-ledger.moments.maxlen :]:
            ledger.moments.append(moment_from_dict(item))
        return ledger


def moment_from_dict(data: dict[str, Any]) -> MomentFrame:
    return MomentFrame(
        tick=int(data.get("tick", 0)),
        raw_tokens=tuple(str(item) for item in data.get("raw_tokens", [])),
        focused_tokens=tuple(str(item) for item in data.get("focused_tokens", [])),
        target_tokens=tuple(str(item) for item in data.get("target_tokens", [])),
        dominant_need=str(data.get("dominant_need", "unknown")),
        body_pressure=float(data.get("body_pressure", 0.0)),
        focus_selectivity=float(data.get("focus_selectivity", 0.0)),
        action=str(data.get("action", "wait")),
        target_id=data.get("target_id"),
        prediction=str(data.get("prediction", "neutral")),
        prediction_confidence=float(data.get("prediction_confidence", 0.0)),
        outcome=str(data.get("outcome", "neutral")),
        prediction_error=float(data.get("prediction_error", 0.0)),
        self_causation=float(data.get("self_causation", 0.0)),
        world_causation=float(data.get("world_causation", 0.0)),
        causation_label=str(data.get("causation_label", "unknown")),
        workspace=tuple(str(item) for item in data.get("workspace", [])),
    )
