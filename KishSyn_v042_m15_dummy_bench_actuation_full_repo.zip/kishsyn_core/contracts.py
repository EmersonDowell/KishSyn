"""Locked core contracts for KishSyn Core.

These dataclasses are the living spine. Add fields only with safe defaults and
update tests/docs when contracts change.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

FeatureKind = Literal["vision", "body", "action", "outcome", "need", "self", "place", "terrain", "text", "screen", "image", "audio", "math", "console", "sensor", "expression", "emotion", "unknown"]
ActionKind = Literal["wait", "move", "inspect", "touch", "eat", "drink", "rest", "avoid", "type"]
OutcomeKind = Literal["neutral", "relief", "pain", "novelty", "blocked", "depleted", "communication"]


@dataclass(frozen=True)
class SensoryFeature:
    """A small interpreted feature from raw world/body input."""

    key: str
    value: str
    kind: FeatureKind = "unknown"
    intensity: float = 1.0

    @property
    def token(self) -> str:
        return f"{self.kind}:{self.key}={self.value}"


@dataclass(frozen=True)
class SensoryFrame:
    """One sensory collapse moment.

    A frame must be replayable and contain no live object references.
    """

    tick: int
    features: tuple[SensoryFeature, ...]
    raw: dict[str, Any] = field(default_factory=dict)

    def tokens(self) -> tuple[str, ...]:
        return tuple(feature.token for feature in self.features)


@dataclass(frozen=True)
class BodyState:
    """Body pressure surface.

    Values are normalized 0..1 where higher is more of that condition.
    """

    energy: float = 0.65
    hydration: float = 0.65
    integrity: float = 0.85
    fatigue: float = 0.10
    curiosity: float = 0.35
    uncertainty: float = 0.50

    def clipped(self) -> "BodyState":
        return BodyState(
            energy=_clip01(self.energy),
            hydration=_clip01(self.hydration),
            integrity=_clip01(self.integrity),
            fatigue=_clip01(self.fatigue),
            curiosity=_clip01(self.curiosity),
            uncertainty=_clip01(self.uncertainty),
        )

    def needs(self) -> dict[str, float]:
        return {
            "energy": 1.0 - self.energy,
            "hydration": 1.0 - self.hydration,
            "integrity": 1.0 - self.integrity,
            "fatigue": self.fatigue,
            "curiosity": self.curiosity,
            "uncertainty": self.uncertainty,
        }

    def dominant_need(self) -> str:
        return max(self.needs().items(), key=lambda item: item[1])[0]


@dataclass(frozen=True)
class Action:
    """A motor proposal selected by the reflex/action layer."""

    kind: ActionKind
    target_id: str | None = None
    reason: str = ""


@dataclass(frozen=True)
class Prediction:
    """Expected consequence before action."""

    expected_outcome: OutcomeKind = "neutral"
    confidence: float = 0.0
    evidence: tuple[str, ...] = ()


@dataclass(frozen=True)
class EfferenceCopy:
    """Self-caused action trace."""

    tick: int
    action: Action
    prediction: Prediction


@dataclass(frozen=True)
class Outcome:
    """Actual result after action."""

    kind: OutcomeKind
    delta_body: dict[str, float] = field(default_factory=dict)
    target_id: str | None = None
    message: str = ""


@dataclass(frozen=True)
class PlasticityEvent:
    """A connection update caused by experience."""

    source: str
    target: str
    before: float
    after: float
    reason: str


@dataclass(frozen=True)
class TickTrace:
    """One complete reflex loop trace."""

    tick: int
    frame: SensoryFrame
    body_before: BodyState
    action: Action
    prediction: Prediction
    outcome: Outcome
    body_after: BodyState
    prediction_error: float
    plasticity: tuple[PlasticityEvent, ...] = ()
    workspace: tuple[str, ...] = ()
    efference: EfferenceCopy | None = None
    self_causation: float = 0.0
    world_causation: float = 0.0
    causation_label: str = "unknown"
    world_events: tuple[str, ...] = ()


def _clip01(value: float) -> float:
    return max(0.0, min(1.0, float(value)))
