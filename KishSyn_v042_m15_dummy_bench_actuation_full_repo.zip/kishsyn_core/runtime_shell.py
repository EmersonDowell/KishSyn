"""Runtime shell portability contracts for KishSyn Core.

The organism/runtime must not be owned by HTML, a web page, a desktop window,
or any single presentation layer. Web observatory, future packaged .exe, CLI,
and service shells are adapters around the same brain-state and organism loop.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal

ShellKind = Literal["web_observatory", "desktop_exe", "cli", "service", "test_harness"]
TransportKind = Literal["http_json", "in_process", "stdio_json", "websocket_json", "file_json"]


@dataclass(frozen=True)
class RuntimeShellContract:
    """Declares how a UI/runtime shell attaches to the organism.

    Pattern: Contract Object. A shell may render, inspect, transport messages,
    and host process lifecycle. It may not own cognition or become a separate
    mind stack. This is the guardrail that keeps future .exe work portable.
    """

    shell_id: str
    kind: ShellKind
    transport: TransportKind
    persistence_root: str = "stores"
    owns_cognition: bool = False
    owns_brain_state: bool = False
    html_required: bool = False
    packaged_exe_ready: bool = False
    notes: tuple[str, ...] = ()

    def validate(self) -> tuple[str, ...]:
        violations: list[str] = []
        if self.owns_cognition:
            violations.append("shell may not own cognition")
        if self.owns_brain_state:
            violations.append("shell may not own brain state")
        if self.persistence_root != "stores":
            violations.append("durable brain-state path must remain under stores/")
        if self.kind == "desktop_exe" and self.html_required:
            violations.append("desktop executable shell may not require HTML as its core runtime")
        return tuple(violations)

    @property
    def valid(self) -> bool:
        return not self.validate()

    def as_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["valid"] = self.valid
        payload["violations"] = list(self.validate())
        payload["notes"] = list(self.notes)
        return payload


class RuntimeShellPolicy:
    """Registry of accepted runtime shells.

    Pattern: Registry + Policy. The web observatory and future desktop .exe are
    sibling shells over the same organism loop, not forks of the organism.
    """

    def __init__(self, contracts: tuple[RuntimeShellContract, ...] | None = None) -> None:
        self.contracts: dict[str, RuntimeShellContract] = {}
        for contract in contracts or self.default_contracts():
            self.register(contract)

    @staticmethod
    def default_contracts() -> tuple[RuntimeShellContract, ...]:
        return (
            RuntimeShellContract(
                shell_id="observatory_web",
                kind="web_observatory",
                transport="http_json",
                html_required=True,
                notes=("current browser-based observatory", "read/write only through governed API endpoints"),
            ),
            RuntimeShellContract(
                shell_id="kishsyn_desktop_exe_future",
                kind="desktop_exe",
                transport="in_process",
                packaged_exe_ready=True,
                notes=("future official Windows executable shell", "must reuse stores/ brain-state and organism loop"),
            ),
            RuntimeShellContract(
                shell_id="headless_cli",
                kind="cli",
                transport="stdio_json",
                notes=("headless development and gate runner shell",),
            ),
        )

    def register(self, contract: RuntimeShellContract) -> None:
        violations = contract.validate()
        if violations:
            raise ValueError(f"invalid runtime shell contract {contract.shell_id!r}: {', '.join(violations)}")
        self.contracts[contract.shell_id] = contract

    def supports_desktop_exe(self) -> bool:
        return any(contract.kind == "desktop_exe" and contract.packaged_exe_ready for contract in self.contracts.values())

    def snapshot(self) -> dict[str, Any]:
        return {
            "contract_count": len(self.contracts),
            "supports_desktop_exe": self.supports_desktop_exe(),
            "html_locked": any(contract.html_required and contract.owns_cognition for contract in self.contracts.values()),
            "contracts": [contract.as_dict() for contract in sorted(self.contracts.values(), key=lambda item: item.shell_id)],
            "law": "UI shells may render or transport; the organism loop and stores/ brain state remain shell-independent.",
        }

    def state(self) -> dict[str, Any]:
        return {"contracts": [contract.as_dict() for contract in sorted(self.contracts.values(), key=lambda item: item.shell_id)]}

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "RuntimeShellPolicy":
        contracts: list[RuntimeShellContract] = []
        for item in data.get("contracts", []):
            if isinstance(item, dict):
                raw = dict(item)
                raw.pop("valid", None)
                raw.pop("violations", None)
                if isinstance(raw.get("notes"), list):
                    raw["notes"] = tuple(str(note) for note in raw["notes"])
                contracts.append(RuntimeShellContract(**raw))
        return cls(tuple(contracts) if contracts else None)
