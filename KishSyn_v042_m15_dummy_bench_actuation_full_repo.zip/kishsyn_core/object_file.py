"""Object-file cortex for KishSyn Core.

M9 separates object identity from object kind. Apple A and Apple B may share an
apple-like category signature while keeping distinct histories, locations,
properties, and transformation traces. This layer observes completed experience;
it does not command action.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass, field
from typing import Any

from .contextual_affordance import ObjectKindSignature, object_kind_from_features
from .contracts import Action, Outcome, PlasticityEvent
from .neural_graph import NeuralGrowthGraph


@dataclass
class ObjectFile:
    """A persistent file for one perceived object identity.

    Pattern: Entity + Memento. The file has identity continuity across ticks,
    while its short transformation history preserves meaningful state changes
    without making each observation into a durable graph node.
    """

    object_id: str
    object_signature: str
    first_tick: int
    last_tick: int
    observation_count: int = 0
    feature_counts: dict[str, dict[str, int]] = field(default_factory=dict)
    last_features: dict[str, str] = field(default_factory=dict)
    location_counts: dict[str, int] = field(default_factory=dict)
    action_counts: dict[str, int] = field(default_factory=dict)
    outcome_counts: dict[str, int] = field(default_factory=dict)
    transformation_history: list[dict[str, Any]] = field(default_factory=list)
    mean_prediction_error: float = 0.0

    def observe(
        self,
        *,
        tick: int,
        features: tuple[str, ...],
        object_kind: ObjectKindSignature,
        action: Action,
        outcome: Outcome,
        prediction_error: float,
    ) -> None:
        parsed = _feature_map(features)
        transforms: list[dict[str, Any]] = []
        for key, value in parsed.items():
            previous = self.last_features.get(key)
            if previous is not None and previous != value and _tracks_transform(key):
                transforms.append({"tick": int(tick), "field": key, "before": previous, "after": value})
            self.feature_counts.setdefault(key, {})[value] = self.feature_counts.setdefault(key, {}).get(value, 0) + 1
        place = parsed.get("place:cell") or parsed.get("place:zone")
        if place:
            self.location_counts[place] = self.location_counts.get(place, 0) + 1
        if action.kind:
            self.action_counts[action.kind] = self.action_counts.get(action.kind, 0) + 1
        if outcome.kind:
            self.outcome_counts[outcome.kind] = self.outcome_counts.get(outcome.kind, 0) + 1
        total_before = self.observation_count
        self.observation_count += 1
        self.last_tick = int(tick)
        self.object_signature = object_kind.signature_id
        self.mean_prediction_error = ((self.mean_prediction_error * total_before) + float(prediction_error)) / max(1, self.observation_count)
        self.last_features = parsed
        if transforms:
            self.transformation_history.extend(transforms)
            self.transformation_history = self.transformation_history[-32:]

    def dominant_value(self, key: str) -> str | None:
        values = self.feature_counts.get(key, {})
        if not values:
            return None
        return sorted(values.items(), key=lambda item: (-item[1], item[0]))[0][0]

    def stable_feature_summary(self) -> dict[str, str]:
        keys = sorted(k for k in self.feature_counts if k.startswith("vision:") and k not in {"vision:object", "vision:distance"})
        return {key: self.dominant_value(key) or "unknown" for key in keys[:12]}

    def as_dict(self) -> dict[str, Any]:
        return {
            "object_id": self.object_id,
            "object_signature": self.object_signature,
            "first_tick": self.first_tick,
            "last_tick": self.last_tick,
            "observation_count": self.observation_count,
            "stable_features": self.stable_feature_summary(),
            "last_features": dict(self.last_features),
            "location_counts": dict(sorted(self.location_counts.items())),
            "action_counts": dict(sorted(self.action_counts.items())),
            "outcome_counts": dict(sorted(self.outcome_counts.items())),
            "transformation_history": list(self.transformation_history[-12:]),
            "mean_prediction_error": round(float(self.mean_prediction_error), 4),
        }

    def state(self) -> dict[str, Any]:
        return {
            "object_id": self.object_id,
            "object_signature": self.object_signature,
            "first_tick": self.first_tick,
            "last_tick": self.last_tick,
            "observation_count": self.observation_count,
            "feature_counts": self.feature_counts,
            "last_features": self.last_features,
            "location_counts": self.location_counts,
            "action_counts": self.action_counts,
            "outcome_counts": self.outcome_counts,
            "transformation_history": self.transformation_history[-32:],
            "mean_prediction_error": self.mean_prediction_error,
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "ObjectFile":
        return cls(
            object_id=str(data.get("object_id", "unknown")),
            object_signature=str(data.get("object_signature", "object=unknown")),
            first_tick=int(data.get("first_tick", 0)),
            last_tick=int(data.get("last_tick", 0)),
            observation_count=int(data.get("observation_count", 0)),
            feature_counts={str(k): {str(vk): int(vv) for vk, vv in dict(v).items()} for k, v in dict(data.get("feature_counts", {})).items()},
            last_features={str(k): str(v) for k, v in dict(data.get("last_features", {})).items()},
            location_counts={str(k): int(v) for k, v in dict(data.get("location_counts", {})).items()},
            action_counts={str(k): int(v) for k, v in dict(data.get("action_counts", {})).items()},
            outcome_counts={str(k): int(v) for k, v in dict(data.get("outcome_counts", {})).items()},
            transformation_history=[dict(item) for item in list(data.get("transformation_history", []))][-32:],
            mean_prediction_error=float(data.get("mean_prediction_error", 0.0)),
        )


@dataclass(frozen=True)
class ObjectFileObservation:
    """Compact observable event emitted by the object-file cortex."""

    tick: int
    object_id: str
    object_signature: str
    action_kind: str
    outcome_kind: str
    observation_count: int

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class ObjectFileCortex:
    """Repository for individual object identity files.

    Pattern: Repository + Flyweight. Object files are keyed by persistent object
    id, while category signatures are shared. This prevents the system from
    collapsing Apple A and Apple B into one object, and also prevents every
    sighting from becoming a new durable identity node.
    """

    def __init__(self, *, capacity: int = 256) -> None:
        self.capacity = max(16, int(capacity))
        self.files: dict[str, ObjectFile] = {}
        self.observations: list[ObjectFileObservation] = []
        self.record_updates = 0
        self.kind_index: dict[str, set[str]] = {}

    def record(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph,
        target_features: tuple[str, ...],
        action: Action,
        outcome: Outcome,
        prediction_error: float,
    ) -> tuple[PlasticityEvent, ...]:
        object_id = object_id_from_features(target_features)
        if not object_id:
            return ()
        object_kind = object_kind_from_features(target_features)
        file = self.files.get(object_id)
        if file is None:
            file = ObjectFile(object_id=object_id, object_signature=object_kind.signature_id, first_tick=int(tick), last_tick=int(tick))
            self.files[object_id] = file
            self._trim_files()
        file.observe(tick=tick, features=target_features, object_kind=object_kind, action=action, outcome=outcome, prediction_error=prediction_error)
        self.kind_index.setdefault(object_kind.signature_id, set()).add(object_id)
        self.record_updates += 1
        observation = ObjectFileObservation(
            tick=int(tick),
            object_id=object_id,
            object_signature=object_kind.signature_id,
            action_kind=action.kind,
            outcome_kind=outcome.kind,
            observation_count=file.observation_count,
        )
        self.observations.append(observation)
        self.observations = self.observations[-64:]
        return self._write_graph(graph=graph, tick=tick, file=file, object_kind=object_kind, action=action, outcome=outcome)

    def files_for_kind(self, object_signature: str) -> tuple[ObjectFile, ...]:
        ids = sorted(self.kind_index.get(object_signature, set()))
        return tuple(self.files[item] for item in ids if item in self.files)

    def compare_same_kind(self, left_id: str, right_id: str) -> dict[str, Any]:
        """Return shared-kind and difference evidence for two object files."""

        left = self.files[left_id]
        right = self.files[right_id]
        left_features = left.stable_feature_summary()
        right_features = right.stable_feature_summary()
        keys = sorted(set(left_features) | set(right_features))
        same = {key: left_features[key] for key in keys if key in left_features and left_features.get(key) == right_features.get(key)}
        different = {key: {"left": left_features.get(key), "right": right_features.get(key)} for key in keys if left_features.get(key) != right_features.get(key)}
        return {
            "left_id": left_id,
            "right_id": right_id,
            "same_kind": left.object_signature == right.object_signature,
            "shared_signature": left.object_signature if left.object_signature == right.object_signature else "",
            "same_features": same,
            "different_features": different,
        }

    def snapshot(self) -> dict[str, Any]:
        self._refresh_kind_index()
        files = sorted((file.as_dict() for file in self.files.values()), key=lambda item: (-int(item["observation_count"]), str(item["object_id"])))
        transformation_count = sum(len(file.transformation_history) for file in self.files.values())
        return {
            "file_count": len(self.files),
            "kind_count": len(self.kind_index),
            "record_updates": self.record_updates,
            "transformation_count": transformation_count,
            "top_files": files[:12],
            "last_observations": [item.as_dict() for item in self.observations[-8:]],
        }

    def state(self) -> dict[str, Any]:
        self._refresh_kind_index()
        return {
            "capacity": self.capacity,
            "record_updates": self.record_updates,
            "files": [file.state() for file in self.files.values()],
            "observations": [item.as_dict() for item in self.observations[-64:]],
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "ObjectFileCortex":
        cortex = cls(capacity=int(data.get("capacity", 256)))
        cortex.record_updates = int(data.get("record_updates", 0))
        for item in data.get("files", []):
            file = ObjectFile.from_state(dict(item))
            cortex.files[file.object_id] = file
        cortex.observations = [
            ObjectFileObservation(
                tick=int(item.get("tick", 0)),
                object_id=str(item.get("object_id", "unknown")),
                object_signature=str(item.get("object_signature", "object=unknown")),
                action_kind=str(item.get("action_kind", "wait")),
                outcome_kind=str(item.get("outcome_kind", "neutral")),
                observation_count=int(item.get("observation_count", 0)),
            )
            for item in data.get("observations", [])
        ][-64:]
        cortex._refresh_kind_index()
        return cortex

    def _write_graph(
        self,
        *,
        graph: NeuralGrowthGraph,
        tick: int,
        file: ObjectFile,
        object_kind: ObjectKindSignature,
        action: Action,
        outcome: Outcome,
    ) -> tuple[PlasticityEvent, ...]:
        object_node = f"object_file:{_safe(file.object_id)}"
        kind_node = object_kind.node_id()
        action_node = f"action:{_safe(action.kind)}"
        outcome_node = f"outcome:{_safe(outcome.kind)}"
        graph.ensure_neuron(object_node, kind="object_file", label=file.object_id, tick=tick)
        graph.ensure_neuron(kind_node, kind="object_kind", label=object_kind.signature_id, tick=tick)
        graph.ensure_neuron(action_node, kind="action", label=action.kind, tick=tick)
        graph.ensure_neuron(outcome_node, kind="outcome", label=outcome.kind, tick=tick)
        graph.activate(object_node, amount=min(1.0, 0.25 + file.observation_count * 0.05), tick=tick)
        events: list[PlasticityEvent] = [
            graph.reinforce(object_node, kind_node, amount=0.018, tick=tick, reason="object file shares reusable object-kind anatomy"),
            graph.reinforce(object_node, action_node, amount=0.006, tick=tick, reason="object file action history"),
            graph.reinforce(object_node, outcome_node, amount=0.008, tick=tick, reason="object file outcome history"),
        ]
        for key, value in sorted(file.stable_feature_summary().items())[:8]:
            feature_node = f"object_feature:{_safe(key)}={_safe(value)}"
            graph.ensure_neuron(feature_node, kind="object_feature", label=f"{key}={value}", tick=tick)
            events.append(graph.reinforce(object_node, feature_node, amount=0.010, tick=tick, reason="object file preserves individual feature evidence"))
        return tuple(events)

    def _trim_files(self) -> None:
        if len(self.files) <= self.capacity:
            return
        ranked = sorted(self.files.values(), key=lambda file: (file.observation_count, file.last_tick, file.object_id))
        for file in ranked[: max(0, len(self.files) - self.capacity)]:
            self.files.pop(file.object_id, None)
        self._refresh_kind_index()

    def _refresh_kind_index(self) -> None:
        self.kind_index = {}
        for object_id, file in self.files.items():
            self.kind_index.setdefault(file.object_signature, set()).add(object_id)


def object_id_from_features(features: tuple[str, ...]) -> str | None:
    for feature in features:
        if feature.startswith("vision:object="):
            value = feature.split("=", 1)[1].strip()
            return value or None
    return None


def _feature_map(features: tuple[str, ...]) -> dict[str, str]:
    parsed: dict[str, str] = {}
    for feature in features:
        if "=" not in feature or ":" not in feature.split("=", 1)[0]:
            continue
        key, value = feature.split("=", 1)
        parsed[key] = value
    return parsed


def _tracks_transform(key: str) -> bool:
    return key in {"vision:quantity", "place:cell", "place:zone", "terrain:terrain", "terrain:charge", "place:visit"}


def _safe(value: object) -> str:
    text = str(value).strip().lower().replace(" ", "_")
    allowed = []
    for char in text:
        if char.isalnum() or char in {"_", "-", "=", "|", "."}:
            allowed.append(char)
        else:
            allowed.append("_")
    compact = "".join(allowed)
    while "__" in compact:
        compact = compact.replace("__", "_")
    return compact.strip("_") or "unknown"
