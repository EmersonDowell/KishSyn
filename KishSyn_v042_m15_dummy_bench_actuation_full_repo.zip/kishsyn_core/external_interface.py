"""Graduated external-program embodiment contracts.

This module does not move the mouse, press keys, browse the web, or call APIs.
It defines the governed adapter surface that future OS/program interaction must
pass through so KishSyn can learn organic affordances without receiving hidden,
hardcoded app-specific control.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal

EmbodimentStage = Literal[
    "simulation",
    "dummy_safe_bench",
    "supervised_dummy_field",
    "read_only_telemetry",
    "adapter_quarantine",
    "static_inspection",
    "certified_actuation",
    "approved_physical_actuation",
]
SurfaceKind = Literal["screen", "window", "console", "web_page", "game", "filesystem", "api", "robot_body", "unknown"]
AffordanceKind = Literal["observe", "inspect", "move_pointer", "click", "type_text", "press_key", "scroll", "read_file", "write_file", "api_call", "unknown"]
PermissionLevel = Literal["observe_only", "propose_only", "supervised_write", "approved_write", "forbidden"]

_WRITE_AFFORDANCES = {"move_pointer", "click", "type_text", "press_key", "scroll", "write_file", "api_call"}


@dataclass(frozen=True)
class ExternalSurface:
    """A program/OS surface visible to an adapter.

    Pattern: Value Object. This is not an app-specific automation command; it is
    a typed surface that can later emit sensory features and affordance probes.
    """

    surface_id: str
    kind: SurfaceKind
    title: str = ""
    adapter_id: str = "unknown_adapter"
    read_only: bool = True
    metadata: dict[str, str] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ExternalAffordance:
    """A possible interaction exposed by an adapter, not a chosen action."""

    affordance_id: str
    surface_id: str
    kind: AffordanceKind
    description: str
    confidence: float = 0.0
    risk: float = 1.0
    evidence: tuple[str, ...] = ()

    @property
    def is_write_like(self) -> bool:
        return self.kind in _WRITE_AFFORDANCES

    def as_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["confidence"] = round(float(self.confidence), 4)
        payload["risk"] = round(float(self.risk), 4)
        payload["evidence"] = list(self.evidence)
        payload["write_like"] = self.is_write_like
        return payload


@dataclass(frozen=True)
class AdapterSafetyContract:
    """Governed safety envelope for an external adapter.

    Pattern: Contract Object. Future adapters must declare stage and permission
    before they can expose write-like affordances. Until certification, the
    organism can observe and propose but cannot actuate.
    """

    adapter_id: str
    stage: EmbodimentStage = "simulation"
    permission: PermissionLevel = "observe_only"
    human_supervised: bool = False
    explicit_session_grant: bool = False
    max_risk: float = 0.15

    def allows(self, affordance: ExternalAffordance) -> bool:
        if self.permission == "forbidden":
            return False
        if affordance.risk > self.max_risk:
            return False
        if not affordance.is_write_like:
            return self.permission in {"observe_only", "propose_only", "supervised_write", "approved_write"}
        if self.stage not in {"certified_actuation", "approved_physical_actuation"}:
            return False
        if self.permission == "approved_write":
            return self.explicit_session_grant
        if self.permission == "supervised_write":
            return self.human_supervised and self.explicit_session_grant
        return False

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class ExternalAdapterRegistry:
    """Read-only registry for future external surface adapters.

    Pattern: Registry + Facade. The organism can inspect surfaces and affordance
    proposals through one stable facade; actual actuation must remain adapter-
    specific and gated outside this pure contract layer.
    """

    def __init__(self) -> None:
        self.surfaces: dict[str, ExternalSurface] = {}
        self.affordances: dict[str, ExternalAffordance] = {}
        self.contracts: dict[str, AdapterSafetyContract] = {}

    def register_surface(self, surface: ExternalSurface, contract: AdapterSafetyContract) -> None:
        self.surfaces[surface.surface_id] = surface
        self.contracts[contract.adapter_id] = contract

    def propose_affordance(self, affordance: ExternalAffordance) -> None:
        if affordance.surface_id not in self.surfaces:
            raise ValueError(f"unknown external surface: {affordance.surface_id}")
        self.affordances[affordance.affordance_id] = affordance

    def allowed_affordances(self) -> tuple[ExternalAffordance, ...]:
        allowed: list[ExternalAffordance] = []
        for affordance in self.affordances.values():
            surface = self.surfaces.get(affordance.surface_id)
            if surface is None:
                continue
            contract = self.contracts.get(surface.adapter_id, AdapterSafetyContract(adapter_id=surface.adapter_id))
            if contract.allows(affordance):
                allowed.append(affordance)
        return tuple(sorted(allowed, key=lambda item: item.affordance_id))

    def snapshot(self) -> dict[str, Any]:
        allowed = self.allowed_affordances()
        allowed_write_like = [affordance for affordance in allowed if affordance.is_write_like]
        return {
            "surface_count": len(self.surfaces),
            "affordance_count": len(self.affordances),
            "allowed_count": len(allowed),
            "allowed_write_like_count": len(allowed_write_like),
            "blocked_write_like_count": max(0, sum(1 for item in self.affordances.values() if item.is_write_like) - len(allowed_write_like)),
            "surfaces": [surface.as_dict() for surface in sorted(self.surfaces.values(), key=lambda item: item.surface_id)],
            "affordances": [affordance.as_dict() for affordance in sorted(self.affordances.values(), key=lambda item: item.affordance_id)],
            "allowed_affordances": [affordance.as_dict() for affordance in allowed],
            "contracts": [contract.as_dict() for contract in sorted(self.contracts.values(), key=lambda item: item.adapter_id)],
        }

    def state(self) -> dict[str, Any]:
        return {
            "surfaces": [surface.as_dict() for surface in sorted(self.surfaces.values(), key=lambda item: item.surface_id)],
            "affordances": [affordance.as_dict() for affordance in sorted(self.affordances.values(), key=lambda item: item.affordance_id)],
            "contracts": [contract.as_dict() for contract in sorted(self.contracts.values(), key=lambda item: item.adapter_id)],
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "ExternalAdapterRegistry":
        registry = cls()
        for item in data.get("contracts", []):
            if isinstance(item, dict):
                registry.contracts[str(item.get("adapter_id", "unknown_adapter"))] = AdapterSafetyContract(
                    adapter_id=str(item.get("adapter_id", "unknown_adapter")),
                    stage=item.get("stage", "simulation"),
                    permission=item.get("permission", "observe_only"),
                    human_supervised=bool(item.get("human_supervised", False)),
                    explicit_session_grant=bool(item.get("explicit_session_grant", False)),
                    max_risk=float(item.get("max_risk", 0.15)),
                )
        for item in data.get("surfaces", []):
            if isinstance(item, dict):
                surface = ExternalSurface(
                    surface_id=str(item.get("surface_id", "unknown_surface")),
                    kind=item.get("kind", "unknown"),
                    title=str(item.get("title", "")),
                    adapter_id=str(item.get("adapter_id", "unknown_adapter")),
                    read_only=bool(item.get("read_only", True)),
                    metadata={str(k): str(v) for k, v in dict(item.get("metadata", {})).items()},
                )
                registry.surfaces[surface.surface_id] = surface
        for item in data.get("affordances", []):
            if isinstance(item, dict):
                affordance = ExternalAffordance(
                    affordance_id=str(item.get("affordance_id", "unknown_affordance")),
                    surface_id=str(item.get("surface_id", "unknown_surface")),
                    kind=item.get("kind", "unknown"),
                    description=str(item.get("description", "")),
                    confidence=float(item.get("confidence", 0.0)),
                    risk=float(item.get("risk", 1.0)),
                    evidence=tuple(str(ev) for ev in item.get("evidence", ())),
                )
                registry.affordances[affordance.affordance_id] = affordance
        return registry
