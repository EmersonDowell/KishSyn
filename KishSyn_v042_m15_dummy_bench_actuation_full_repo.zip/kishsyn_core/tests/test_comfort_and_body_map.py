from kishsyn_core.body import BodyRegulator
from kishsyn_core.body_map import ProtoBodyMap
from kishsyn_core.comfort import ComfortAttractorMemory
from kishsyn_core.contracts import Action, BodyState, Outcome
from kishsyn_core.loop import OrganismLoop
from kishsyn_core.neural_graph import NeuralGrowthGraph


def test_comfort_basin_emerges_from_relief_without_home_label():
    graph = NeuralGrowthGraph()
    memory = ComfortAttractorMemory()
    before = BodyState(energy=0.30, hydration=0.70, integrity=0.80, fatigue=0.30, curiosity=0.40, uncertainty=0.40)
    after = BodyRegulator().apply_outcome(before, Outcome("relief", {"energy": 0.24}, message="energy restored"))
    for tick in range(10):
        events = memory.record(
            tick=tick,
            graph=graph,
            place_key="north_west:1,1",
            terrain="grove",
            body_before=before,
            body_after=after,
            outcome=Outcome("relief", {"energy": 0.24}, message="energy restored"),
            prediction_error=0.10,
        )
    snapshot = memory.snapshot()
    assert snapshot["basin_count"] == 1
    assert snapshot["top_basins"][0]["score"] > 0
    assert graph.weight("comfort:place=north_west:1,1", "comfort:basin") > 0
    assert events


def test_comfort_basin_can_become_negative_after_pain():
    graph = NeuralGrowthGraph()
    memory = ComfortAttractorMemory()
    before = BodyState(integrity=0.80, fatigue=0.20)
    after = BodyRegulator().apply_outcome(before, Outcome("pain", {"integrity": -0.20}, message="damage"))
    for tick in range(12):
        memory.record(
            tick=tick,
            graph=graph,
            place_key="south_west:0,4",
            terrain="rough",
            body_before=before,
            body_after=after,
            outcome=Outcome("pain", {"integrity": -0.20}, message="damage"),
            prediction_error=0.75,
        )
    assert memory.snapshot()["top_basins"][0]["score"] < 0


def test_proto_body_map_learns_self_caused_motor_channel():
    graph = NeuralGrowthGraph()
    body_map = ProtoBodyMap()
    before = BodyState()
    after = BodyRegulator().apply_outcome(before, Outcome("relief", {"hydration": 0.1}, target_id="tall_blue_0"))
    for tick in range(8):
        body_map.record(
            tick=tick,
            graph=graph,
            action=Action("move", "tall_blue_0"),
            body_before=before,
            body_after=after,
            from_place="middle_center:3,2",
            to_place="middle_east:4,2",
            outcome=Outcome("relief", {"hydration": 0.1}, target_id="tall_blue_0"),
            prediction_error=0.12,
            self_causation=0.86,
        )
    snap = body_map.snapshot()
    assert snap["channel_count"] == 1
    assert snap["bindings"][0]["strength"] > 0.25
    assert graph.weight("motor:move", "self:caused") > 0


def test_core_snapshot_exposes_comfort_and_body_binding_surfaces():
    loop = OrganismLoop(seed=337)
    loop.run(steps=48)
    snap = loop.snapshot().__dict__
    assert "comfort_memory" in snap
    assert "body_map" in snap
    assert snap["score"]["comfort_basins"] > 0
    assert snap["score"]["body_channels"] > 0
    assert isinstance(snap["world"]["comfort_map"], list)
