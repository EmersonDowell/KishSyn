from kishsyn_core.loop import OrganismLoop
from kishsyn_core.route_memory import RouteMemory
from kishsyn_core.contracts import Action, Outcome
from kishsyn_core.neural_graph import NeuralGrowthGraph


def test_route_memory_records_and_scores_relief_place():
    graph = NeuralGrowthGraph()
    routes = RouteMemory()
    events = routes.record(
        tick=1,
        graph=graph,
        from_place="north_west:0,0",
        to_place="east_spring:6,1",
        action=Action("touch", "tall_blue_0"),
        outcome=Outcome("relief", target_id="tall_blue_0"),
        dominant_need="hydration",
    )
    assert events
    assert routes.snapshot()["step_count"] == 1
    assert routes.score_place(place_key="east_spring:6,1", need="hydration", graph=graph) > 0


def test_living_loop_grows_route_neurons():
    loop = OrganismLoop(seed=337)
    loop.run(steps=80)
    kinds = {node.kind for node in loop.graph.neurons.values()}
    assert "route" in kinds
    assert loop.route_memory.snapshot()["step_count"] >= 40
    assert loop.snapshot().world["width"] >= 23
