from pathlib import Path

from kishsyn_core.loop import OrganismLoop
from kishsyn_core.state import load_loop, save_loop


def test_text_input_becomes_sensory_features_and_typed_output():
    loop = OrganismLoop(seed=337)
    loop.text_crib.receive_text(tick=loop.tick, text="red A", source="tester")
    trace = loop.step()
    tokens = trace.frame.tokens()
    assert "text:surface=text_console" in tokens
    assert "text:word=red" in tokens
    assert "text:word=a" in tokens
    snapshot = loop.snapshot().__dict__["text_crib"]
    assert snapshot["input_count"] == 1
    assert snapshot["output_count"] >= 1
    assert any(node_id.startswith("text:word=red") for node_id in loop.graph.neurons)


def test_text_word_can_activate_learned_symbol_goal():
    loop = OrganismLoop(seed=337)
    tick = loop.tick
    graph = loop.graph
    graph.ensure_neuron("symbol:token=red", kind="symbol", label="token=red", tick=tick)
    graph.ensure_neuron("concept:color=red", kind="concept", label="color=red", tick=tick)
    graph.reinforce("symbol:token=red", "concept:color=red", amount=0.22, tick=tick, reason="test learned symbol")
    loop.text_crib.receive_text(tick=loop.tick, text="red", source="tester")
    loop.step()
    snap = loop.snapshot().__dict__
    assert snap["text_crib"]["goal_activations"] >= 1
    assert snap["symbol_goal"]["activation_count"] >= 1


def test_text_crib_persists_with_brain_state(tmp_path: Path):
    loop = OrganismLoop(seed=337)
    loop.text_crib.receive_text(tick=loop.tick, text="round", source="tester")
    loop.step()
    state_path = tmp_path / "brain.json"
    save_loop(loop, state_path, seed=337, note="text crib test")
    loaded, _ = load_loop(state_path)
    snap = loaded.snapshot().__dict__["text_crib"]
    assert snap["input_count"] == 1
    assert snap["history"][-1]["text"] == "round"
