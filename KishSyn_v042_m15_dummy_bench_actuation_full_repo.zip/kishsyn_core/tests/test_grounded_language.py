from pathlib import Path

from kishsyn_core.contextual_affordance import ActorProfile, ContextualAffordanceCortex, RealityProvenance, WorldContext
from kishsyn_core.contracts import Action, BodyState, Outcome, Prediction, SensoryFeature, SensoryFrame, TickTrace
from kishsyn_core.grounded_language import GroundedLanguageCortex
from kishsyn_core.loop import OrganismLoop
from kishsyn_core.neural_graph import NeuralGrowthGraph
from kishsyn_core.state import load_loop, save_loop


def _trace(*, tick: int = 1) -> TickTrace:
    frame = SensoryFrame(
        tick=tick,
        features=(
            SensoryFeature("word", "apple", "text", 0.8),
            SensoryFeature("word", "red", "text", 0.8),
        ),
    )
    body = BodyState()
    return TickTrace(
        tick=tick,
        frame=frame,
        body_before=body,
        action=Action("inspect", "apple_A", "ground language test"),
        prediction=Prediction("novelty", 0.2),
        outcome=Outcome("novelty", target_id="apple_A", message="apple-like object inspected"),
        body_after=body,
        prediction_error=0.35,
        self_causation=0.8,
        causation_label="self",
    )


def test_grounded_language_binds_words_to_lived_anchors_not_commands() -> None:
    graph = NeuralGrowthGraph()
    cortex = GroundedLanguageCortex()
    target = (
        "vision:object=apple_A",
        "vision:color=red",
        "vision:shape=round",
        "vision:quantity=available",
    )
    events = cortex.observe(
        tick=1,
        graph=graph,
        trace=_trace(),
        target_features=target,
        actor=ActorProfile(),
        context=WorldContext(),
    )
    assert events
    snap = cortex.snapshot()
    assert snap["word_count"] == 2
    assert snap["record_count"] >= 4
    contract = cortex.contract_for("apple")
    assert contract.grounded is True
    assert contract.may_command_action is False
    assert any(item["anchor_kind"] == "object_kind" for item in contract.top_anchors)
    assert any(item["anchor_kind"] == "object_file" for item in contract.top_anchors)
    assert any(node_id.startswith("language_word:apple") for node_id in graph.neurons)
    assert not any(node_id.startswith("language:t") for node_id in graph.neurons)


def test_grounded_language_can_attach_to_contextual_affordance_evidence() -> None:
    graph = NeuralGrowthGraph()
    language = GroundedLanguageCortex()
    affordances = ContextualAffordanceCortex()
    actor = ActorProfile(actor_id="player", kind="game_avatar", body_schema="hp_body", can_receive_game_hp=True)
    context = WorldContext(context_id="game_a", kind="game", rule_surface="apple_heals_hp")
    target = ("vision:object=apple_A", "vision:color=red", "vision:shape=round")
    for tick in range(3):
        affordances.record(
            tick=tick,
            graph=graph,
            actor=actor,
            context=context,
            target_features=target,
            action=Action("eat", "apple_A", "game use"),
            outcome=Outcome("relief", target_id="apple_A", message="hp +5"),
            prediction_error=0.08,
            provenance=RealityProvenance(source="self_action"),
        )
    trace = TickTrace(
        tick=4,
        frame=SensoryFrame(tick=4, features=(SensoryFeature("word", "apple", "text", 0.8),)),
        body_before=BodyState(),
        action=Action("eat", "apple_A", "test eat"),
        prediction=Prediction("relief", 0.6),
        outcome=Outcome("relief", target_id="apple_A", message="hp +5"),
        body_after=BodyState(),
        prediction_error=0.1,
    )
    language.observe(
        tick=4,
        graph=graph,
        trace=trace,
        target_features=target,
        actor=actor,
        context=context,
        contextual_affordance=affordances,
    )
    contract = language.contract_for("apple")
    assert any(item["anchor_kind"] == "affordance" for item in contract.top_anchors)
    assert contract.may_command_action is False


def test_loop_records_grounded_language_and_persists(tmp_path: Path) -> None:
    loop = OrganismLoop(seed=337)
    loop.text_crib.receive_text(tick=loop.tick, text="apple red round remember", source="tester", ttl=48)
    loop.run(steps=24)
    snap = loop.snapshot().__dict__
    assert snap["grounded_language"]["record_count"] >= 1
    assert snap["score"]["grounded_language_records"] >= 1
    assert snap["grounded_language"]["last_contract"]["may_command_action"] is False
    path = tmp_path / "brain.json"
    save_loop(loop, path, seed=337, note="grounded language test")
    restored, meta = load_loop(path)
    assert meta["loaded"] is True
    after = restored.snapshot().__dict__["grounded_language"]
    assert after["record_count"] == snap["grounded_language"]["record_count"]
