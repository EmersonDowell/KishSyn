from pathlib import Path

from kishsyn_core.desktop_observation import DesktopElement, DesktopObservationFrame
from kishsyn_core.interface_affordance import InterfaceAffordanceCortex
from kishsyn_core.loop import OrganismLoop
from kishsyn_core.state import load_loop, save_loop


def _frame(tick: int = 0) -> DesktopObservationFrame:
    return DesktopObservationFrame(
        tick=tick,
        surface_id="desktop:screen0:editor",
        title="KishSyn Notes - Editor",
        active_application="editor.exe",
        elements=(
            DesktopElement("main_window", "window", "KishSyn Notes", (0, 0, 1200, 820), False, 0.96),
            DesktopElement("body_text", "text_field", "note body", (20, 90, 980, 650), True, 0.88),
            DesktopElement("save_button", "button", "Save", (1020, 90, 110, 42), True, 0.84),
            DesktopElement("file_menu", "menu", "File", (4, 26, 48, 22), True, 0.78),
            DesktopElement("status_console", "console", "status output", (0, 780, 1200, 40), False, 0.75),
        ),
        text_fragments=("apple note", "Save", "Ready"),
        source="desktop_read_only_adapter",
        screenshot_digest="demo:m14",
    )


def test_interface_affordance_discovers_roles_without_actuation() -> None:
    loop = OrganismLoop(seed=337)
    loop.os_observation.observe(
        _frame(),
        sensory_hub=loop.sensory_hub,
        registry=loop.external_registry,
        graph=loop.graph,
        interface_affordance=loop.interface_affordance,
    )
    snap = loop.snapshot().__dict__
    iface = snap["interface_affordance"]
    assert iface["signature_count"] >= 5
    assert iface["record_count"] >= 8
    assert iface["write_like_blocked_count"] >= 3
    assert iface["actuation_grant_count"] == 0
    assert all((rec["contract"] or {}).get("may_actuate") is False for rec in iface["top_records"])
    assert any(node["id"].startswith("ui_element_kind:") for node in snap["graph"]["nodes"])
    assert any(node["id"] == "interface_contract:proposal_only" for node in snap["graph"]["nodes"])
    assert not any(node["id"].startswith("ui:t") for node in snap["graph"]["nodes"])


def test_interface_affordance_strengthens_reusable_records_across_repeated_frames() -> None:
    cortex = InterfaceAffordanceCortex()
    loop = OrganismLoop(seed=171)
    frame = _frame()
    cortex.observe_frame(tick=0, frame=frame, registry=loop.external_registry, graph=loop.graph)
    # Direct observation before the OS substrate registers surfaces should still
    # build safe inspect/read records from the frame shape alone.
    assert cortex.snapshot()["record_count"] >= 5

    loop.os_observation.observe(frame, sensory_hub=loop.sensory_hub, registry=loop.external_registry, graph=loop.graph, interface_affordance=loop.interface_affordance)
    loop.os_observation.observe(_frame(tick=1), sensory_hub=loop.sensory_hub, registry=loop.external_registry, graph=loop.graph, interface_affordance=loop.interface_affordance)
    snap = loop.snapshot().__dict__["interface_affordance"]
    assert snap["record_updates"] > snap["record_count"]
    assert snap["actuation_grant_count"] == 0


def test_interface_affordance_persists_with_brain_state(tmp_path: Path) -> None:
    loop = OrganismLoop(seed=337)
    loop.os_observation.observe(_frame(), sensory_hub=loop.sensory_hub, registry=loop.external_registry, graph=loop.graph, interface_affordance=loop.interface_affordance)
    loop.run(steps=10)
    path = tmp_path / "brain.json"
    save_loop(loop, path, seed=337, note="M14 persistence")
    restored, meta = load_loop(path)
    snap = restored.snapshot().__dict__
    assert meta["loaded"] is True
    assert snap["interface_affordance"]["record_count"] >= 8
    assert snap["interface_affordance"]["actuation_grant_count"] == 0
    assert snap["runtime_shell"]["supports_desktop_exe"] is True
