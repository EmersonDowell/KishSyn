from kishsyn_core.loop import OrganismLoop


def test_loop_ticks_and_preserves_single_runtime_state():
    loop = OrganismLoop(seed=11)
    first = loop.step()
    loop.run(steps=12)
    snapshot = loop.snapshot()
    assert first.tick == 0
    assert snapshot.tick == 13
    assert 0.0 <= snapshot.score["survival"] <= 1.0
    assert snapshot.memory["trace_count"] == 13
    assert snapshot.last_trace is not None


def test_core_loop_records_efference_and_self_boundary():
    from kishsyn_core.loop import OrganismLoop

    loop = OrganismLoop(seed=51)
    trace = loop.step()
    assert trace.efference is not None
    assert 0.0 <= trace.self_causation <= 1.0
    assert trace.causation_label in {"self_caused", "world_caused", "mixed", "uncertain"}
    snap = loop.snapshot().__dict__
    assert snap["self_model"]["sample_count"] == 1


def test_body_metabolism_is_gentle_enough_for_exploration():
    from kishsyn_core.body import BodyRegulator
    from kishsyn_core.contracts import BodyState

    regulator = BodyRegulator()
    body = BodyState()
    for _ in range(80):
        body = regulator.metabolic_drift(body)
    assert body.energy > 0.58
    assert body.hydration > 0.58
    assert body.fatigue < 0.14


def test_core_snapshot_exposes_action_reasoning_candidates():
    loop = OrganismLoop(seed=337)
    loop.run(steps=8)
    snap = loop.snapshot().__dict__
    reasoning = snap["action_reasoning"]
    assert reasoning["candidate_count"] >= 1
    assert reasoning["final"] is not None
    assert reasoning["top_candidates"]
    assert "dominant_need" in reasoning
