from pathlib import Path

from kishsyn_core.loop import OrganismLoop
from kishsyn_core.state import load_loop, save_loop


def test_autonomous_tutor_injects_lessons_without_manual_input():
    loop = OrganismLoop(seed=171)
    loop.run(steps=96)
    snap = loop.snapshot()
    assert snap.autopilot["enabled"] is True
    assert snap.autopilot["lesson_count"] >= 1
    assert snap.tutor["lesson_count"] >= snap.autopilot["lesson_count"]
    assert snap.text_crib["input_count"] >= 2
    assert snap.score["autopilot_lessons"] >= 1


def test_autonomous_tutor_state_persists(tmp_path: Path):
    path = tmp_path / "brain.json"
    loop = OrganismLoop(seed=172)
    loop.run(steps=96)
    before = loop.snapshot()
    save_loop(loop, path, seed=172, note="autopilot persistence")
    restored, meta = load_loop(path)
    after = restored.snapshot()
    assert meta["loaded"] is True
    assert after.autopilot["lesson_count"] == before.autopilot["lesson_count"]
    assert after.autopilot["last_message"] == before.autopilot["last_message"]


def test_autonomous_tutor_can_be_disabled():
    loop = OrganismLoop(seed=173)
    loop.autopilot.enabled = False
    loop.run(steps=120)
    snap = loop.snapshot()
    assert snap.autopilot["lesson_count"] == 0
    assert snap.tutor["lesson_count"] == 0
