from pathlib import Path

from kishsyn_core.loop import OrganismLoop
from kishsyn_core.state import load_loop, save_loop


def test_brain_state_round_trips_learned_graph_and_memory(tmp_path: Path):
    path = tmp_path / "brain_state.json"
    loop = OrganismLoop(seed=121)
    loop.run(steps=64)
    before = loop.snapshot().__dict__
    save_meta = save_loop(loop, path, seed=121, note="test persistence")
    loaded, load_meta = load_loop(path)
    after = loaded.snapshot().__dict__

    assert save_meta["saved"] is True
    assert load_meta["loaded"] is True
    assert after["tick"] == before["tick"]
    assert after["graph"]["node_count"] == before["graph"]["node_count"]
    assert after["graph"]["edge_count"] == before["graph"]["edge_count"]
    assert after["memory"]["trace_count"] == before["memory"]["trace_count"]
    assert after["score"]["comfort_basins"] == before["score"]["comfort_basins"]
    assert after["score"]["body_channels"] == before["score"]["body_channels"]


def test_loaded_brain_continues_growth_from_previous_tick(tmp_path: Path):
    path = tmp_path / "brain_state.json"
    loop = OrganismLoop(seed=122)
    loop.run(steps=40)
    save_loop(loop, path, seed=122, note="before continuation")

    loaded, _ = load_loop(path)
    start_tick = loaded.tick
    start_nodes = loaded.snapshot().__dict__["graph"]["node_count"]
    loaded.run(steps=20)
    save_loop(loaded, path, seed=122, note="after continuation")
    continued, _ = load_loop(path)

    assert continued.tick == start_tick + 20
    assert continued.snapshot().__dict__["graph"]["node_count"] >= start_nodes
    assert continued.snapshot().__dict__["memory"]["trace_count"] >= 60
