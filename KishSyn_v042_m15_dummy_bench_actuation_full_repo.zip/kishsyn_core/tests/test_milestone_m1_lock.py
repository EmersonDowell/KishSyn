from kishsyn_core.milestone import MilestoneM1LockEvaluator


def test_milestone_m1_lock_surface_is_declared():
    assert MilestoneM1LockEvaluator.milestone_id == "M1"
    assert MilestoneM1LockEvaluator.name == "Focused Moment Substrate"
