from pathlib import Path

from kishsyn_core.contracts import Action, BodyState, Outcome, Prediction
from kishsyn_core.loop import OrganismLoop
from kishsyn_core.neural_graph import NeuralGrowthGraph
from kishsyn_core.play import IntrinsicPlayDrive
from kishsyn_core.state import load_loop, save_loop
from kishsyn_core.world import MiniEcologyWorld


def test_play_inhibits_when_body_pressure_is_unsafe() -> None:
    drive = IntrinsicPlayDrive()
    world = MiniEcologyWorld(seed=337)

    intent = drive.propose(tick=1, body=BodyState(energy=0.12, hydration=0.65, integrity=0.85, fatigue=0.10, curiosity=0.90, uncertainty=0.90), world=world)

    assert intent.active is False
    assert "survival" in intent.reason or "body pressure" in intent.reason
    assert drive.snapshot()["inhibited_count"] == 1


def test_play_records_reusable_patterns_without_tick_nodes() -> None:
    drive = IntrinsicPlayDrive()
    world = MiniEcologyWorld(seed=337)
    graph = NeuralGrowthGraph()
    body = BodyState(energy=0.75, hydration=0.72, integrity=0.90, fatigue=0.12, curiosity=0.72, uncertainty=0.70)

    intent = drive.propose(tick=1, body=body, world=world)
    assert intent.active is True
    features = world.target_features(intent.target_id)
    action = Action(intent.action_kind, intent.target_id, "unit play")
    events = drive.record(
        tick=1,
        graph=graph,
        intent=intent,
        action=action,
        target_features=features,
        prediction=Prediction("neutral", confidence=0.0),
        outcome=Outcome("novelty", target_id=intent.target_id),
        prediction_error=0.85,
    )
    snap = drive.snapshot()

    assert events
    assert snap["record_count"] == 1
    assert snap["safe_count"] == 1
    assert snap["pattern_count"] == 1
    assert any(node_id.startswith("play_pattern:") for node_id in graph.neurons)
    assert not any(node_id.startswith("play:t") for node_id in graph.neurons)


def test_loop_integrates_and_persists_intrinsic_play(tmp_path: Path) -> None:
    loop = OrganismLoop(seed=337)
    loop.run(steps=96)
    snap = loop.snapshot().__dict__

    assert snap["play"]["proposal_count"] >= 1
    assert snap["play"]["record_count"] >= 1
    assert snap["score"]["play_patterns"] >= 1
    assert not any(str(node.get("id", "")).startswith("play:t") for node in snap["graph"]["nodes"])

    path = tmp_path / "brain.json"
    save_loop(loop, path, seed=337, note="play persistence")
    restored, meta = load_loop(path)
    restored_snap = restored.snapshot().__dict__

    assert meta["loaded"] is True
    assert restored_snap["play"]["pattern_count"] == snap["play"]["pattern_count"]
    assert restored_snap["play"]["record_count"] == snap["play"]["record_count"]
