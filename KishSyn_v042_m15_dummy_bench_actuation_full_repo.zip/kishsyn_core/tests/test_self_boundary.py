from kishsyn_core.contracts import Action, EfferenceCopy, Outcome, Prediction
from kishsyn_core.self_model import SelfBoundaryModel


def test_self_boundary_detects_self_caused_action():
    model = SelfBoundaryModel()
    efference = EfferenceCopy(0, Action("move", "round_red_0"), Prediction("neutral", 0.2))
    assessment = model.evaluate(efference=efference, outcome=Outcome("neutral", target_id="round_red_0", message="moved"))
    assert assessment.label == "self_caused"
    assert assessment.self_causation > assessment.world_causation


def test_self_boundary_detects_world_change():
    model = SelfBoundaryModel()
    efference = EfferenceCopy(0, Action("wait"), Prediction("neutral", 0.2))
    assessment = model.evaluate(efference=efference, outcome=Outcome("neutral", message="waited"), world_events=("spawn:new",))
    assert assessment.label == "world_caused"
    assert assessment.world_causation > assessment.self_causation
