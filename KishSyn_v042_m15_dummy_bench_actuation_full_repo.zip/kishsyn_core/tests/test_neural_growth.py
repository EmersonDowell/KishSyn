from kishsyn_core.loop import OrganismLoop


def test_neural_graph_grows_from_experience():
    loop = OrganismLoop(seed=21)
    before = loop.snapshot().graph
    loop.run(steps=72)
    after = loop.snapshot().graph
    assert before["node_count"] == 0
    assert after["node_count"] >= 10
    assert after["edge_count"] >= 8
    assert loop.growth_score() > 0.1


def test_synapses_include_consequence_paths_after_run():
    loop = OrganismLoop(seed=22)
    loop.run(steps=72)
    edges = loop.snapshot().graph["edges"]
    assert any(edge["target"] == "outcome:relief" for edge in edges)
    assert any(edge["target"] in {"outcome:pain", "outcome:novelty", "outcome:depleted", "outcome:neutral"} for edge in edges)



def test_concept_nodes_form_from_colors_shapes_glyphs_and_counts():
    loop = OrganismLoop(seed=337)
    loop.run(steps=100)
    graph = loop.snapshot().graph
    concepts = graph["concepts"]
    assert concepts["concept_count"] >= 6
    assert concepts["concept_updates"] > 0
    families = concepts["families"]
    assert families.get("dimension", 0) >= 3
    assert any(node["kind"] == "concept" and "glyph" in node["id"] for node in graph["nodes"])
    assert any(node["kind"] == "concept" and "count" in node["id"] for node in graph["nodes"])


def test_symbol_tokens_bind_to_grounded_concept_hubs_after_experience():
    loop = OrganismLoop(seed=337)
    loop.run(steps=100)
    graph = loop.snapshot().graph
    symbols = graph["symbols"]
    assert symbols["symbol_count"] >= 1
    assert symbols["symbol_binding_updates"] > 0
    assert symbols["bindings"]
    assert any(link["concept"].startswith("concept:color=") or link["concept"].startswith("concept:shape=") or link["concept"].startswith("concept:glyph=") or link["concept"].startswith("concept:count=") for binding in symbols["bindings"] for link in binding["links"])
