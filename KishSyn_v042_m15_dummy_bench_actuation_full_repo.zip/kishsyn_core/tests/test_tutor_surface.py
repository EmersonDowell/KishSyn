from kishsyn_core.loop import OrganismLoop
from kishsyn_core.state import load_loop, save_loop
from kishsyn_core.tutor import TutorSurface


def test_tutor_surface_injects_weak_symbol_lessons_through_text():
    loop = OrganismLoop(seed=17)
    events = loop.tutor.receive(
        tick=loop.tick,
        message="teach red round A two",
        text_crib=loop.text_crib,
        graph=loop.graph,
        symbol_goal=loop.symbol_goal,
    )
    assert events
    assert loop.tutor.snapshot()["lesson_count"] == 1
    assert "symbol:token=red" in loop.graph.neurons
    assert "concept:color=red" in loop.graph.neurons
    assert loop.graph.weight("symbol:token=red", "concept:color=red") > 0
    assert loop.text_crib.snapshot(tick=loop.tick)["input_count"] >= 2


def test_tutor_endpoint_pathway_updates_organism_loop_without_becoming_persona():
    loop = OrganismLoop(seed=19)
    loop.tutor.receive(
        tick=loop.tick,
        message="teach blue square B three",
        text_crib=loop.text_crib,
        graph=loop.graph,
        symbol_goal=loop.symbol_goal,
    )
    loop.run(steps=4)
    snap = loop.snapshot()
    assert snap.tutor["lesson_count"] == 1
    assert snap.text_crib["output_count"] >= 1
    assert snap.tutor["last_note"].startswith("local bounded tutor")
    assert snap.tutor["external_api_enabled"] is False


def test_tutor_state_persists_with_brain_state(tmp_path):
    loop = OrganismLoop(seed=23)
    loop.tutor.receive(
        tick=loop.tick,
        message="teach yellow triangle C one",
        text_crib=loop.text_crib,
        graph=loop.graph,
        symbol_goal=loop.symbol_goal,
    )
    path = tmp_path / "brain.json"
    save_loop(loop, path, seed=23, note="tutor persistence test")
    restored, meta = load_loop(path)
    assert meta["loaded"] is True
    assert restored.tutor.snapshot()["lesson_count"] == 1
    assert restored.graph.weight("symbol:token=yellow", "concept:color=yellow") > 0
