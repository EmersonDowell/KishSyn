from kishsyn_core.external_interface import AdapterSafetyContract, ExternalAdapterRegistry, ExternalAffordance, ExternalSurface


def test_external_adapter_blocks_write_like_actions_until_certified_and_granted() -> None:
    registry = ExternalAdapterRegistry()
    surface = ExternalSurface(surface_id="desktop:screen0", kind="screen", title="Desktop", adapter_id="desktop_adapter", read_only=True)
    registry.register_surface(surface, AdapterSafetyContract(adapter_id="desktop_adapter", stage="read_only_telemetry", permission="observe_only"))
    registry.propose_affordance(ExternalAffordance("a1", "desktop:screen0", "inspect", "inspect visible window", confidence=0.8, risk=0.02))
    registry.propose_affordance(ExternalAffordance("a2", "desktop:screen0", "click", "click visible button", confidence=0.7, risk=0.03))

    allowed = registry.allowed_affordances()
    assert [item.affordance_id for item in allowed] == ["a1"]


def test_external_adapter_allows_low_risk_write_only_after_certified_session_grant() -> None:
    registry = ExternalAdapterRegistry()
    surface = ExternalSurface(surface_id="dummy:bench", kind="window", title="Dummy Bench", adapter_id="dummy_adapter", read_only=False)
    contract = AdapterSafetyContract(
        adapter_id="dummy_adapter",
        stage="certified_actuation",
        permission="approved_write",
        explicit_session_grant=True,
        max_risk=0.10,
    )
    registry.register_surface(surface, contract)
    registry.propose_affordance(ExternalAffordance("type_ok", "dummy:bench", "type_text", "type into dummy box", confidence=0.9, risk=0.04))
    registry.propose_affordance(ExternalAffordance("risky", "dummy:bench", "write_file", "write outside sandbox", confidence=0.9, risk=0.80))

    allowed = registry.allowed_affordances()
    assert [item.affordance_id for item in allowed] == ["type_ok"]
    assert registry.snapshot()["allowed_count"] == 1
