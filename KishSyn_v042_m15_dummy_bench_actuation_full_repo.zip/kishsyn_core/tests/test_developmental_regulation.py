from kishsyn_core.development import DevelopmentalRegulator, LearningFocus
from kishsyn_core.loop import OrganismLoop
from kishsyn_core.action import ActionSelector
from kishsyn_core.contracts import BodyState, Outcome, TickTrace, Action, Prediction, SensoryFrame
from kishsyn_core.memory import TraceMemory
from kishsyn_core.neural_graph import NeuralGrowthGraph
from kishsyn_core.world import MiniEcologyWorld


def test_developmental_regulator_stabilizes_under_body_pressure():
    regulator = DevelopmentalRegulator()
    focus = regulator.sense(
        tick=1,
        body=BodyState(energy=0.18, hydration=0.45, integrity=0.80, fatigue=0.25),
        memory=TraceMemory(),
        graph=NeuralGrowthGraph(),
    )
    assert focus.mode == "stabilize"
    assert focus.safety_bias > 0
    assert focus.novelty_bias < 0


def test_developmental_regulator_records_plastic_focus_paths():
    graph = NeuralGrowthGraph()
    regulator = DevelopmentalRegulator()
    focus = regulator.last_focus
    frame = SensoryFrame(tick=0, features=())
    trace = TickTrace(
        tick=0,
        frame=frame,
        body_before=BodyState(),
        action=Action("inspect", "glow_gold_0"),
        prediction=Prediction("neutral", 0.0),
        outcome=Outcome("novelty", target_id="glow_gold_0"),
        body_after=BodyState(curiosity=0.20, uncertainty=0.30),
        prediction_error=0.72,
    )
    events = regulator.record(tick=0, graph=graph, trace=trace, focus=focus)
    assert events
    assert graph.weight("development:mode=explore", "action:inspect") > 0
    assert graph.weight("development:mode=explore", "outcome:novelty") > 0


def test_action_selector_uses_developmental_focus_without_commanding_action():
    graph = NeuralGrowthGraph()
    world = MiniEcologyWorld(seed=337)
    selector = ActionSelector(graph)
    body = BodyState(curiosity=0.55, uncertainty=0.40)
    frame = world.observe(body)
    explore = LearningFocus("explore", 0.1, 0.1, 0.0, 0.0, 0.32, 0.0, 0.0, 0.0, "test")
    stabilize = LearningFocus("stabilize", 0.8, 0.2, 0.0, 0.4, -0.20, 0.2, 0.2, 0.1, "test")
    explore_pick = selector.choose(frame=frame, body=body, world=world, learning_focus=explore)
    stabilize_pick = selector.choose(frame=frame, body=body, world=world, learning_focus=stabilize)
    assert explore_pick.score != stabilize_pick.score or explore_pick.action.reason != stabilize_pick.action.reason


def test_loop_exposes_developmental_surface_and_grows_development_nodes():
    loop = OrganismLoop(seed=337)
    loop.run(steps=72)
    snap = loop.snapshot().__dict__
    assert "development" in snap
    assert snap["development"]["mode"] in {"stabilize", "explore", "verify", "consolidate"}
    assert "learning_progress" in snap["score"]
    assert any(node.kind == "development" for node in loop.graph.neurons.values())

from kishsyn_core.motor_experiment import MotorExperimenter
from kishsyn_core.body_map import ProtoBodyMap
from kishsyn_core.self_model import SelfBoundaryModel


def test_motor_experimenter_proposes_safe_probe_under_low_pressure():
    world = MiniEcologyWorld(seed=337)
    focus = LearningFocus("explore", 0.2, 0.1, 0.0, 0.0, 0.25, 0.0, 0.0, 0.0, "test")
    intent = MotorExperimenter().propose(
        tick=3,
        body=BodyState(energy=0.70, hydration=0.70, integrity=0.85, fatigue=0.15),
        focus=focus,
        body_map=ProtoBodyMap(),
        world=world,
    )
    assert intent.active
    assert intent.action_kind in {"move", "inspect", "touch", "wait"}
    if intent.action_kind != "wait":
        assert intent.target_id is not None


def test_motor_experimenter_records_controllability_without_body_ownership_flag():
    graph = NeuralGrowthGraph()
    experimenter = MotorExperimenter()
    focus = LearningFocus("explore", 0.2, 0.1, 0.0, 0.0, 0.25, 0.0, 0.0, 0.0, "test")
    world = MiniEcologyWorld(seed=337)
    intent = experimenter.propose(tick=3, body=BodyState(), focus=focus, body_map=ProtoBodyMap(), world=world)
    action = Action(intent.action_kind, intent.target_id, "probe")
    before = BodyState()
    after = BodyState(energy=0.68, hydration=0.66, integrity=0.85, fatigue=0.09, curiosity=0.30, uncertainty=0.42)
    events = experimenter.record(
        tick=3,
        graph=graph,
        intent=intent,
        action=action,
        outcome=Outcome("novelty", {"uncertainty": -0.08}, target_id=intent.target_id),
        prediction_error=0.22,
        self_causation=0.74,
        body_before=before,
        body_after=after,
    )
    snap = experimenter.snapshot()
    assert events
    assert snap["probe_count"] == 1
    assert snap["channels"][0]["controllability"] > 0
    assert any(node.kind == "experiment" for node in graph.neurons.values())


def test_loop_exposes_motor_experiment_surface_and_experiment_nodes():
    loop = OrganismLoop(seed=337)
    loop.run(steps=72)
    snap = loop.snapshot().__dict__
    assert "motor_experiment" in snap
    assert snap["score"]["motor_probes"] > 0
    assert snap["motor_experiment"]["probe_count"] > 0
    assert any(node.kind == "experiment" for node in loop.graph.neurons.values())
