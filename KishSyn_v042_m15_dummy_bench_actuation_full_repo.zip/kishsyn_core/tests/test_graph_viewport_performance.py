from __future__ import annotations

from kishsyn_core.graph_viewport import GraphViewportBudget, GraphViewportProjector
from kishsyn_core.neural_graph import NeuralGrowthGraph
from kishsyn_core.observatory.server import ObservatorySession


def _large_graph() -> NeuralGrowthGraph:
    graph = NeuralGrowthGraph()
    for idx in range(900):
        node = graph.ensure_neuron(
            f"stress:{idx}",
            kind="concept" if idx % 17 == 0 else "feature",
            label=f"stress node {idx}",
            tick=idx,
        )
        node.activation = (idx % 23) / 23.0
        node.last_active = idx % 120
    for idx in range(1800):
        source = f"stress:{idx % 900}"
        target = f"stress:{(idx * 37 + 11) % 900}"
        graph.reinforce(source, target, amount=0.02 + ((idx % 19) / 100.0), tick=idx % 180, reason="viewport stress")
    return graph


def test_graph_viewport_projects_budget_without_mutating_full_graph() -> None:
    graph = _large_graph()
    full_nodes = len(graph.neurons)
    full_edges = len([syn for syn in graph.synapses.values() if abs(syn.weight) > 0.01])
    projected = GraphViewportProjector().project(
        graph=graph,
        tick=240,
        budget=GraphViewportBudget(node_limit=180, edge_limit=260, recent_window=48),
    )
    assert projected["node_count"] == full_nodes
    assert projected["edge_count"] == full_edges
    assert len(projected["nodes"]) <= 180
    assert len(projected["edges"]) <= 260
    assert projected["viewport"]["limited"] is True
    assert projected["viewport"]["omitted_node_count"] > 0
    assert len(graph.neurons) == full_nodes
    assert len([syn for syn in graph.synapses.values() if abs(syn.weight) > 0.01]) == full_edges


def test_observatory_snapshot_can_return_budgeted_viewport_graph() -> None:
    session = ObservatorySession(seed=337, autosave_every=0)
    try:
        session.loop.graph = _large_graph()
        viewport = session.snapshot(graph_view="viewport", node_limit=128, edge_limit=160)
        full = session.snapshot(graph_view="full")
        assert viewport["graph"]["node_count"] == full["graph"]["node_count"]
        assert viewport["graph"]["edge_count"] == full["graph"]["edge_count"]
        assert len(viewport["graph"]["nodes"]) <= 128
        assert len(viewport["graph"]["edges"]) <= 160
        assert len(full["graph"]["nodes"]) > len(viewport["graph"]["nodes"])
        assert viewport["graph"]["viewport"]["mode"] == "budgeted"
    finally:
        session.stop()
