from pathlib import Path

import pytest

from kishsyn_core.desktop_observation import DesktopElement, DesktopObservationFrame
from kishsyn_core.loop import OrganismLoop
from kishsyn_core.runtime_shell import RuntimeShellContract, RuntimeShellPolicy
from kishsyn_core.state import load_loop, save_loop


def _sample_frame(tick: int = 0) -> DesktopObservationFrame:
    return DesktopObservationFrame(
        tick=tick,
        surface_id="desktop:screen0:notepad",
        title="Untitled - Notepad",
        active_application="notepad.exe",
        elements=(
            DesktopElement("window_main", "window", "Untitled - Notepad", (0, 0, 900, 700), interactable=False, confidence=0.95),
            DesktopElement("edit_box", "text_field", "main text area", (12, 88, 870, 570), interactable=True, confidence=0.88),
            DesktopElement("file_menu", "menu", "File", (4, 24, 38, 22), interactable=True, confidence=0.75),
            DesktopElement("status_console", "console", "status line", (0, 670, 900, 30), interactable=False, confidence=0.72),
        ),
        text_fragments=("hello apple", "File Edit View", "Ln 1, Col 1"),
        source="desktop_read_only_adapter",
        screenshot_digest="sha256:demo",
    )


def test_desktop_observation_enters_sensory_hub_and_registry_without_actuation() -> None:
    loop = OrganismLoop(seed=337)
    report = loop.os_observation.observe(_sample_frame(), sensory_hub=loop.sensory_hub, registry=loop.external_registry, graph=loop.graph)

    assert report.sensory_packet_created is True
    assert report.inspect_affordances == 4
    assert report.blocked_write_like_affordances >= 2
    assert report.graph_events >= 4

    registry = loop.external_registry.snapshot()
    assert registry["surface_count"] == 1
    assert registry["allowed_count"] == 4
    assert registry["allowed_write_like_count"] == 0
    assert registry["blocked_write_like_count"] >= 2

    loop.run(steps=32)
    snap = loop.snapshot().__dict__
    assert snap["os_observation"]["observation_count"] == 1
    assert snap["sensory"]["modality_counts"].get("screen", 0) >= 2
    assert snap["score"]["os_observations"] == 1.0
    assert any(str(node.get("id", "")).startswith("external_surface:") for node in snap["graph"]["nodes"])
    assert not any(str(node.get("id", "")).startswith("os:t") for node in snap["graph"]["nodes"])


def test_desktop_observation_and_shell_policy_persist(tmp_path: Path) -> None:
    loop = OrganismLoop(seed=337)
    loop.os_observation.observe(_sample_frame(), sensory_hub=loop.sensory_hub, registry=loop.external_registry, graph=loop.graph)
    loop.run(steps=12)
    path = tmp_path / "brain.json"
    save_loop(loop, path, seed=337, note="M13 persistence")

    restored, meta = load_loop(path)
    restored_snap = restored.snapshot().__dict__
    assert meta["loaded"] is True
    assert restored_snap["os_observation"]["observation_count"] == 1
    assert restored_snap["external_interface"]["surface_count"] == 1
    assert restored_snap["runtime_shell"]["supports_desktop_exe"] is True
    assert restored_snap["runtime_shell"]["html_locked"] is False


def test_runtime_shell_policy_keeps_desktop_exe_from_html_lock_in() -> None:
    policy = RuntimeShellPolicy()
    snap = policy.snapshot()
    assert snap["supports_desktop_exe"] is True
    assert snap["html_locked"] is False
    assert all(item["valid"] for item in snap["contracts"])

    with pytest.raises(ValueError):
        policy.register(
            RuntimeShellContract(
                shell_id="bad_desktop_shell",
                kind="desktop_exe",
                transport="in_process",
                html_required=True,
                owns_cognition=True,
                owns_brain_state=True,
            )
        )
