from kishsyn_core.evidence import IntelligenceEvidenceEvaluator


def test_intelligence_evidence_report_is_bounded_and_conservative():
    report = IntelligenceEvidenceEvaluator().evaluate(seed=337, steps=180, ablation_steps=36)
    payload = report.as_dict()
    assert payload["consciousness_claimed"] is False
    assert payload["summary_score"] >= 0.55
    assert len(payload["criteria"]) >= 8
    assert any(item["name"] == "symbol ablation" for item in payload["criteria"])
    assert payload["metrics"]["trace_count"] == 180.0


def test_evidence_report_has_no_parallel_mind_stack():
    report = IntelligenceEvidenceEvaluator().evaluate(seed=171, steps=96, ablation_steps=24)
    criterion_names = {criterion.name for criterion in report.criteria}
    assert "bounded teaching surface" in criterion_names
    assert report.consciousness_claimed is False
    assert report.metrics["autopilot_lessons"] >= 1.0
