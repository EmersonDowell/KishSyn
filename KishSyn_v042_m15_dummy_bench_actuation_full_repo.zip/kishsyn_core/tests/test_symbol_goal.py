from kishsyn_core.action import ActionSelector
from kishsyn_core.contracts import BodyState, Outcome, SensoryFrame
from kishsyn_core.loop import OrganismLoop
from kishsyn_core.neural_graph import NeuralGrowthGraph
from kishsyn_core.symbol_goal import ActiveSymbolGoalMemory
from kishsyn_core.world import MiniEcologyWorld, WorldObject


def _seed_red_symbol_graph() -> NeuralGrowthGraph:
    graph = NeuralGrowthGraph()
    graph.ensure_neuron("symbol:token=red", kind="symbol", label="token=red", tick=0)
    graph.ensure_neuron("concept:color=red", kind="concept", label="color=red", tick=0)
    graph.ensure_neuron("concept:color=blue", kind="concept", label="color=blue", tick=0)
    graph.ensure_neuron("vision:color=red", kind="feature", label="vision:color=red", tick=0)
    graph.ensure_neuron("vision:color=blue", kind="feature", label="vision:color=blue", tick=0)
    graph.reinforce("symbol:token=red", "concept:color=red", amount=0.8, tick=0, reason="test symbol grounding")
    graph.reinforce("vision:color=red", "concept:color=red", amount=0.5, tick=0, reason="test sensory abstraction")
    graph.reinforce("vision:color=blue", "concept:color=blue", amount=0.5, tick=0, reason="test sensory abstraction")
    return graph


def test_symbol_goal_activates_only_from_experienced_cue_surface():
    graph = _seed_red_symbol_graph()
    memory = ActiveSymbolGoalMemory()
    noncue = ("vision:symbol_token=red", "vision:teaches=color", "vision:paired_color=red")
    assert memory.record_cue_experience(tick=1, graph=graph, target_features=noncue, outcome=Outcome("novelty", message="mapped symbol token red via color")) == ()
    cue = ("vision:symbol_token=red", "vision:teaches=cue")
    events = memory.record_cue_experience(tick=2, graph=graph, target_features=cue, outcome=Outcome("novelty", target_id="cue", message="mapped symbol token red via cue"))
    assert events
    assert memory.active_tokens(3) == ("red",)
    assert memory.snapshot(tick=3)["active"]["token"] == "red"


def test_active_symbol_goal_biases_selector_without_lookup_table():
    graph = _seed_red_symbol_graph()
    world = MiniEcologyWorld(seed=7, width=9, height=7)
    world.objects.clear()
    world.agent_x = 4
    world.agent_y = 3
    world.objects["blue_candidate"] = WorldObject("blue_candidate", 3, 3, "blue", "round", "food", 1)
    world.objects["red_candidate"] = WorldObject("red_candidate", 5, 3, "red", "round", "food", 1)
    selector = ActionSelector(graph)
    frame = SensoryFrame(tick=0, features=())
    body = BodyState(energy=0.15, hydration=0.8, integrity=0.9, fatigue=0.1, curiosity=0.1, uncertainty=0.2)
    choice = selector.choose(frame=frame, body=body, world=world, active_symbol_tokens=("red",))
    assert choice.action.target_id == "red_candidate"
    assert "active goal" in choice.action.reason


def test_living_loop_exposes_persistent_symbol_goal_surface():
    loop = OrganismLoop(seed=337)
    loop.run(steps=120)
    snapshot = loop.snapshot()
    assert snapshot.symbol_goal["activation_count"] >= 1
    assert snapshot.score["symbol_goal_activations"] >= 1.0
    assert "symbol_goal" in {node["kind"] for node in snapshot.graph["nodes"]}
