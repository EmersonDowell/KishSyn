from kishsyn_core.benchmark import BenchmarkPlaygroundSuite
from kishsyn_core.loop import OrganismLoop
from kishsyn_core.milestone import MilestoneM3LockEvaluator
from kishsyn_core.state import load_loop, save_loop


def test_counterfactual_replay_surface_runs_inside_loop():
    loop = OrganismLoop(seed=337)
    loop.run(steps=96)
    snap = loop.snapshot().__dict__
    planning = snap["planning"]
    assert planning["report_count"] >= 90
    assert planning["mean_options"] >= 3.0
    assert planning["predicted_risk_count"] >= 1
    assert snap["score"]["planning_alignment"] >= 0.08


def test_counterfactual_replay_persists_in_brain_state(tmp_path):
    loop = OrganismLoop(seed=337)
    loop.run(steps=72)
    path = tmp_path / "brain.json"
    save_loop(loop, path, seed=337, note="m3 planning persistence test")
    restored, _ = load_loop(path)
    planning = restored.snapshot().__dict__["planning"]
    assert planning["report_count"] >= 64
    assert planning["last_report"] is not None
    assert planning["mean_options"] >= 3.0


def test_benchmark_suite_contains_m3_task():
    report = BenchmarkPlaygroundSuite().evaluate(seeds=(337,), steps=160).as_dict()
    names = {task["name"] for task in report["tasks"]}
    assert "counterfactual replay proto-planning" in names
    assert report["summary_score"] >= 0.80


def test_milestone_m3_lock_surface_is_declared():
    assert MilestoneM3LockEvaluator.milestone_id == "M3"
    assert MilestoneM3LockEvaluator.name == "Counterfactual Replay and Proto-Planning"
