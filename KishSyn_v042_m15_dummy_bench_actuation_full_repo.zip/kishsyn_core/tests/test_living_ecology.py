from kishsyn_core.loop import OrganismLoop
from kishsyn_core.world import MiniEcologyWorld


def test_world_is_larger_and_has_living_dynamics():
    world = MiniEcologyWorld(seed=91)
    assert world.width >= 15
    assert world.height >= 11
    mobile_ids = {obj.object_id for obj in world.living_objects() if obj.mobility != (0, 0)}
    assert mobile_ids
    positions_before = {obj.object_id: (obj.x, obj.y) for obj in world.living_objects()}
    for _ in range(6):
        world.step(action=__import__("kishsyn_core.contracts", fromlist=["Action"]).Action("wait"))
    positions_after = {obj.object_id: (obj.x, obj.y) for obj in world.living_objects()}
    assert any(positions_before[item] != positions_after[item] for item in mobile_ids)


def test_place_and_terrain_neurons_grow_from_loop():
    loop = OrganismLoop(seed=92)
    loop.run(steps=96)
    nodes = loop.snapshot().graph["nodes"]
    kinds = {node["kind"] for node in nodes}
    assert "place" in kinds
    assert "terrain" in kinds
    assert any(edge["source"].startswith("place:") or edge["source"].startswith("terrain:") for edge in loop.snapshot().graph["edges"])


def test_resources_are_finite_and_migrate_after_depletion():
    from kishsyn_core.contracts import Action

    world = MiniEcologyWorld(seed=101)
    target = next(obj for obj in world.living_objects() if obj.affordance == "food")
    world.agent_x, world.agent_y = target.x, target.y
    original_position = (target.x, target.y)
    while target.quantity > 0:
        world.step(Action("touch", target.object_id))
    assert target.quantity == 0
    assert target.depleted_at is not None
    for _ in range(target.regrow_interval + 2):
        world.step(Action("wait"))
    assert target.quantity > 0
    assert (target.x, target.y) != original_position
    assert world.foraging_snapshot()["migration_count"] >= 1


def test_loop_forages_across_many_cells_instead_of_camping():
    loop = OrganismLoop(seed=337)
    loop.run(steps=120)
    foraging = loop.snapshot().world["foraging"]
    assert foraging["visited_cells"] >= 40
    assert foraging["depletion_count"] >= 1



def test_world_exposes_symbol_glyphs_without_affordance_labels_in_features():
    world = MiniEcologyWorld(seed=202)
    symbol = next(obj for obj in world.living_objects() if obj.affordance == "symbol")
    features = {feature.token for feature in symbol.visible_features(world.distance_to(symbol.object_id), zone=world.zone_for(symbol.x, symbol.y))}
    assert f"vision:glyph={symbol.glyph}" in features
    assert f"vision:count={symbol.count}" in features
    assert all("affordance" not in token for token in features)


def test_world_exposes_teacher_symbols_as_sensory_features_not_lookup_table():
    world = MiniEcologyWorld(seed=337)
    teacher = next(obj for obj in world.living_objects() if obj.affordance == "symbol" and obj.symbol_token)
    features = {feature.token for feature in teacher.visible_features(world.distance_to(teacher.object_id), zone=world.zone_for(teacher.x, teacher.y))}
    assert f"vision:symbol_token={teacher.symbol_token}" in features
    assert any(token.startswith("vision:paired_") for token in features)
    assert all("affordance" not in token for token in features)
