from __future__ import annotations

from pathlib import Path

from kishsyn_core.scope import ProjectScopePolicy

ROOT = Path(__file__).resolve().parents[2]


def test_markdown_inventory_ignores_archives_and_generated_stores() -> None:
    files = ProjectScopePolicy(ROOT).inventory().markdown_files
    rendered = {str(path).replace('\\', '/') for path in files}
    assert any(path.endswith('README.md') for path in rendered)
    assert not any('/stores/' in path for path in rendered)
    assert not any('Patches & Other Files' in path for path in rendered)
