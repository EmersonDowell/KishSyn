from __future__ import annotations

from pathlib import Path

from kishsyn_core.dummy_bench import DummyActionProposal, DummyActuationContract, DummyBenchActuator
from kishsyn_core.loop import OrganismLoop
from kishsyn_core.state import load_loop, save_loop


def _prime_loop() -> OrganismLoop:
    loop = OrganismLoop(seed=337)
    frame = loop.dummy_bench.observe_frame(tick=loop.tick)
    loop.os_observation.observe(
        frame,
        sensory_hub=loop.sensory_hub,
        registry=loop.external_registry,
        graph=loop.graph,
        interface_affordance=loop.interface_affordance,
    )
    return loop


def test_dummy_bench_executes_only_inside_sealed_sandbox() -> None:
    loop = _prime_loop()
    before_external = loop.external_registry.snapshot()
    outcomes = loop.dummy_bench.execute_script(tick=loop.tick, graph=loop.graph, sensory_hub=loop.sensory_hub)
    snap = loop.snapshot().__dict__

    assert len(outcomes) == 4
    assert all(outcome.executed for outcome in outcomes)
    assert any(outcome.changed for outcome in outcomes)
    assert snap["dummy_bench"]["executed_count"] == 4
    assert snap["dummy_bench"]["changed_count"] >= 2
    assert snap["dummy_bench"]["real_os_touch_count"] == 0
    assert snap["external_interface"]["allowed_write_like_count"] == before_external["allowed_write_like_count"] == 0
    assert snap["sensory"]["packet_count"] >= 4
    assert any(node["id"].startswith("dummy_action_template:") for node in snap["graph"]["nodes"])
    assert any(node["id"].startswith("dummy_outcome:") for node in snap["graph"]["nodes"])
    assert not any(node["id"].startswith("dummy:t") for node in snap["graph"]["nodes"])


def test_interface_affordance_records_can_feed_dummy_proposals_without_real_actuation() -> None:
    loop = _prime_loop()
    proposals = []
    for record in loop.interface_affordance.records.values():
        proposal = loop.dummy_bench.propose_from_interface_record(tick=loop.tick, record=record, payload="hello")
        if proposal is not None:
            proposals.append(proposal)
    assert proposals
    assert all((proposal.contract and proposal.contract.dummy_only and proposal.contract.real_os_allowed is False) for proposal in proposals)
    for proposal in proposals[:4]:
        loop.dummy_bench.execute(proposal, tick=loop.tick, graph=loop.graph, sensory_hub=loop.sensory_hub)
    snap = loop.snapshot().__dict__
    assert snap["dummy_bench"]["executed_count"] >= 1
    assert snap["dummy_bench"]["real_os_touch_count"] == 0
    assert snap["interface_affordance"]["actuation_grant_count"] == 0
    assert snap["external_interface"]["allowed_write_like_count"] == 0


def test_dummy_bench_blocks_non_dummy_surface_and_unknown_element() -> None:
    actuator = DummyBenchActuator()
    bad_contract = DummyActuationContract(
        bench_id="m15_dummy_bench",
        surface_id="desktop:real:editor",
        action_kind="click",
        dummy_only=True,
        may_execute_dummy=True,
    )
    bad = DummyActionProposal(
        proposal_id="bad-real-surface",
        surface_id="desktop:real:editor",
        element_id="send_button",
        action_kind="click",
        contract=bad_contract,
    )
    outcome = actuator.execute(bad, tick=0)
    assert outcome.blocked
    assert not outcome.executed
    assert "not the sealed dummy surface" in outcome.message

    unknown = actuator.propose(tick=1, element_id="missing_button", action_kind="click")
    outcome2 = actuator.execute(unknown, tick=1)
    assert outcome2.blocked
    assert "unknown dummy element" in outcome2.message
    assert actuator.snapshot()["real_os_touch_count"] == 0


def test_dummy_bench_persists_with_brain_state(tmp_path: Path) -> None:
    loop = _prime_loop()
    loop.dummy_bench.execute_script(tick=loop.tick, graph=loop.graph, sensory_hub=loop.sensory_hub)
    path = tmp_path / "brain.json"
    save_loop(loop, path, seed=337, note="M15 dummy bench persistence")
    restored, meta = load_loop(path)
    snap = restored.snapshot().__dict__
    assert meta["loaded"] is True
    assert snap["dummy_bench"]["executed_count"] == 4
    assert snap["dummy_bench"]["real_os_touch_count"] == 0
    assert "apple note" in snap["dummy_bench"]["surface"]["elements"][3]["text"] or snap["dummy_bench"]["changed_count"] >= 2
