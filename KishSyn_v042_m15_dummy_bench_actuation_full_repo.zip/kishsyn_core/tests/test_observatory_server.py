from kishsyn_core.observatory.server import ObservatorySession


def test_observatory_session_ticks_same_organism():
    session = ObservatorySession(seed=44)
    a = session.snapshot()
    b = session.tick(steps=5)
    c = session.tick(steps=5)
    assert a["tick"] == 0
    assert b["tick"] == 5
    assert c["tick"] == 10
    assert c["memory"]["trace_count"] == 10
    assert c["action_reasoning"]["top_candidates"]


def test_observatory_reset_starts_fresh_runtime():
    session = ObservatorySession(seed=44)
    session.tick(steps=7)
    reset = session.reset(seed=45)
    assert reset["tick"] == 0
    assert reset["memory"]["trace_count"] == 0


def test_observatory_autonomous_run_advances_without_manual_tick():
    import time

    session = ObservatorySession(seed=46, hz=20.0, autostart=True)
    try:
        time.sleep(0.14)
        first = session.snapshot()["tick"]
        time.sleep(0.12)
        second = session.snapshot()["tick"]
        assert first > 0
        assert second > first
        assert session.status()["running"] is True
    finally:
        session.stop()


def test_observatory_pause_stops_autonomous_run():
    import time

    session = ObservatorySession(seed=47, hz=20.0, autostart=True)
    try:
        time.sleep(0.10)
        session.stop()
        stopped = session.snapshot()["tick"]
        time.sleep(0.10)
        assert session.snapshot()["tick"] == stopped
        assert session.status()["running"] is False
    finally:
        session.stop()


def test_observatory_save_and_load_persistent_brain_state(tmp_path):
    state_path = tmp_path / "brain_state.json"
    session = ObservatorySession(seed=61, state_path=state_path, autosave_every=0)
    try:
        session.tick(steps=32)
        saved = session.save_state(note="unit test save")
        saved_tick = saved["tick"]
        session.reset(seed=62, autostart=False)
        assert session.snapshot()["tick"] == 0
        loaded = session.load_state(autostart=False)
        assert loaded["tick"] == saved_tick
        assert loaded["graph"]["node_count"] == saved["graph"]["node_count"]
        assert loaded["persistence"]["last_event"]["loaded"] is True
    finally:
        session.stop()


def test_observatory_tutor_surface_teaches_through_session():
    session = ObservatorySession(seed=63, autosave_every=0)
    try:
        snap = session.receive_tutor(text="teach red round A two", steps=3)
        assert snap["tutor"]["lesson_count"] == 1
        assert snap["tutor"]["plasticity_count"] > 0
        assert snap["text_crib"]["input_count"] >= 2
        assert any(node["kind"] == "tutor" for node in snap["graph"]["nodes"])
    finally:
        session.stop()


def test_observatory_autopilot_configuration_controls_automatic_tutor():
    session = ObservatorySession(seed=64, autosave_every=0)
    try:
        disabled = session.configure_autopilot(enabled=False, interval=24)
        assert disabled["autopilot"]["enabled"] is False
        assert disabled["autopilot"]["interval"] == 24
        session.tick(steps=72)
        assert session.snapshot()["autopilot"]["lesson_count"] == 0
        enabled = session.configure_autopilot(enabled=True, interval=24)
        assert enabled["autopilot"]["enabled"] is True
        session.tick(steps=48)
        assert session.snapshot()["autopilot"]["lesson_count"] >= 1
    finally:
        session.stop()


def test_observatory_report_surface_runs_benchmark_and_evidence(tmp_path):
    session = ObservatorySession(seed=65, autosave_every=0, report_history_path=tmp_path / "history.jsonl")
    try:
        benchmark_path = tmp_path / "benchmark_report.json"
        evidence_path = tmp_path / "evidence_report.json"
        benchmark = session.run_benchmark_report(seeds=(337,), steps=120, out=benchmark_path)
        assert benchmark_path.exists()
        assert benchmark["benchmark"]["tasks"]
        assert benchmark["benchmark"]["summary_score"] >= 0.5
        assert benchmark["history"]["summary"]["benchmark_runs"] == 1
        evidence = session.run_evidence_report(seed=337, steps=120, ablation_steps=24, benchmark_seeds=(337,), out=evidence_path)
        assert evidence_path.exists()
        assert evidence["evidence"]["criteria"]
        assert evidence["evidence"]["summary_score"] >= 0.5
        assert evidence["benchmark"]["tasks"]
        assert evidence["history"]["summary"]["count"] == 2
        assert evidence["history"]["records"][-1]["kind"] == "evidence"
        latest = session.reports_snapshot()
        assert latest["benchmark"] is not None
        assert latest["evidence"] is not None
        assert latest["history"]["summary"]["evidence_runs"] == 1
    finally:
        session.stop()


def test_observatory_report_history_persists_compact_records(tmp_path):
    history_path = tmp_path / "report_history.jsonl"
    first = ObservatorySession(seed=66, autosave_every=0, report_history_path=history_path)
    try:
        first.run_benchmark_report(seeds=(337,), steps=120, out=tmp_path / "b1.json")
        first.run_benchmark_report(seeds=(171,), steps=120, out=tmp_path / "b2.json")
        first_history = first.reports_snapshot()["history"]
        assert first_history["summary"]["benchmark_runs"] == 2
        assert "delayed symbol-object matching" in first_history["records"][-1]["observed"]
    finally:
        first.stop()

    restored = ObservatorySession(seed=67, autosave_every=0, report_history_path=history_path)
    try:
        restored_history = restored.reports_snapshot()["history"]
        assert restored_history["summary"]["count"] == 2
        assert restored_history["records"][-1]["kind"] == "benchmark"
    finally:
        restored.stop()


def test_observatory_sensory_adapter_endpoint_surface():
    session = ObservatorySession(seed=68, autosave_every=0)
    try:
        snap = session.receive_sensory(modality="math", payload="2+2=4", source="unit", steps=4)
        assert snap["sensory"]["packet_count"] >= 1
        assert snap["sensory"]["feature_count"] >= 5
        assert snap["atlas"]["surface_counts"].get("math", 0) >= 1
        snap = session.receive_sensory(modality="screen", payload="screen red circle near cursor", source="unit", steps=4)
        assert snap["sensory"]["modality_counts"]["screen"] >= 1
    finally:
        session.stop()
