from pathlib import Path

from kishsyn_core.contracts import Action, Outcome
from kishsyn_core.loop import OrganismLoop
from kishsyn_core.neural_graph import NeuralGrowthGraph
from kishsyn_core.object_file import ObjectFileCortex, object_id_from_features
from kishsyn_core.state import load_loop, save_loop


def test_object_file_separates_same_kind_from_same_individual() -> None:
    graph = NeuralGrowthGraph()
    cortex = ObjectFileCortex()
    apple_a = (
        "vision:object=apple_A",
        "vision:color=red",
        "vision:shape=round",
        "vision:size=small",
        "vision:blemish=none",
        "vision:quantity=available",
        "place:cell=1,2",
    )
    apple_b = (
        "vision:object=apple_B",
        "vision:color=red",
        "vision:shape=round",
        "vision:size=large",
        "vision:blemish=present",
        "vision:quantity=available",
        "place:cell=8,4",
    )

    cortex.record(tick=0, graph=graph, target_features=apple_a, action=Action("inspect", "apple_A"), outcome=Outcome("novelty", target_id="apple_A"), prediction_error=0.2)
    cortex.record(tick=1, graph=graph, target_features=apple_b, action=Action("inspect", "apple_B"), outcome=Outcome("novelty", target_id="apple_B"), prediction_error=0.2)

    snap = cortex.snapshot()
    comparison = cortex.compare_same_kind("apple_A", "apple_B")
    assert snap["file_count"] == 2
    assert snap["kind_count"] == 1
    assert comparison["same_kind"] is True
    assert comparison["different_features"]["vision:size"] == {"left": "small", "right": "large"}
    assert comparison["different_features"]["vision:blemish"] == {"left": "none", "right": "present"}
    assert object_id_from_features(apple_a) == "apple_A"
    assert any(node_id.startswith("object_file:") for node_id in graph.neurons)


def test_object_file_tracks_transformations_without_new_identity() -> None:
    graph = NeuralGrowthGraph()
    cortex = ObjectFileCortex()
    available = (
        "vision:object=apple_A",
        "vision:color=red",
        "vision:shape=round",
        "vision:quantity=available",
        "place:cell=1,2",
    )
    depleted = (
        "vision:object=apple_A",
        "vision:color=red",
        "vision:shape=round",
        "vision:quantity=depleted",
        "place:cell=1,2",
    )

    cortex.record(tick=0, graph=graph, target_features=available, action=Action("inspect", "apple_A"), outcome=Outcome("novelty", target_id="apple_A"), prediction_error=0.2)
    cortex.record(tick=1, graph=graph, target_features=depleted, action=Action("eat", "apple_A"), outcome=Outcome("relief", target_id="apple_A"), prediction_error=0.08)

    snap = cortex.snapshot()
    file = cortex.files["apple_A"]
    assert snap["file_count"] == 1
    assert file.observation_count == 2
    assert file.outcome_counts["relief"] == 1
    assert any(item["field"] == "vision:quantity" and item["before"] == "available" and item["after"] == "depleted" for item in file.transformation_history)


def test_loop_records_object_files_and_persists(tmp_path: Path) -> None:
    loop = OrganismLoop(seed=337)
    loop.run(steps=96)
    snap = loop.snapshot().__dict__
    assert snap["object_file"]["file_count"] >= 1
    assert snap["object_file"]["record_updates"] >= 1
    assert snap["score"]["object_files"] >= 1

    path = tmp_path / "brain.json"
    save_loop(loop, path, seed=337, note="object file persistence")
    restored, meta = load_loop(path)
    restored_snap = restored.snapshot().__dict__
    assert meta["loaded"] is True
    assert restored_snap["object_file"]["file_count"] == snap["object_file"]["file_count"]
    assert restored_snap["object_file"]["kind_count"] == snap["object_file"]["kind_count"]
