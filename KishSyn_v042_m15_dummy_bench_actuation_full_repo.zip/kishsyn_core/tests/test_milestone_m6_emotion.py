from __future__ import annotations

from kishsyn_core.milestone import MilestoneM6LockEvaluator


def test_milestone_m6_lock_evaluator_locks_emotional_regulation_field():
    report = MilestoneM6LockEvaluator().evaluate(seed=337, seeds=(337,), steps=120, ablation_steps=24)
    assert report.milestone_id == "M6"
    assert report.locked is True
    assert report.summary_score == 1.0
    assert report.metrics["emotion_samples"] >= 90
    assert report.metrics["trait_count"] >= 3
    assert all(item.status == "pass" for item in report.criteria)
