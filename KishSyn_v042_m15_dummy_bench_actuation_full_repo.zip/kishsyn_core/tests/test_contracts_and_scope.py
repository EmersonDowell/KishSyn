from pathlib import Path

from kishsyn_core.contracts import Action, BodyState, Outcome, SensoryFeature, SensoryFrame
from kishsyn_core.scope import ProjectScopePolicy

ROOT = Path(__file__).resolve().parents[2]


def test_locked_contracts_construct_with_safe_defaults():
    feature = SensoryFeature("color", "red", "vision")
    frame = SensoryFrame(tick=0, features=(feature,))
    body = BodyState()
    action = Action("wait")
    outcome = Outcome("neutral")
    assert feature.token == "vision:color=red"
    assert frame.tokens() == ("vision:color=red",)
    assert body.dominant_need() in body.needs()
    assert action.kind == "wait"
    assert outcome.kind == "neutral"


def test_scope_budget_is_enforced_by_repo_shape():
    inventory = ProjectScopePolicy(ROOT).validate()
    assert len(inventory.python_files) <= 82
    assert len(inventory.markdown_files) <= 17


def test_scope_budget_never_walks_archives_or_generated_stores(tmp_path):
    root = tmp_path / "repo"
    (root / "kishsyn_core").mkdir(parents=True)
    (root / "docs").mkdir()
    (root / "Patches & Other Files (Like Images)" / "old_repo").mkdir(parents=True)
    (root / "stores" / "_demo" / "old_repo").mkdir(parents=True)

    (root / "README.md").write_text("living doc", encoding="utf-8")
    (root / "docs" / "ARCHITECTURE.md").write_text("living architecture", encoding="utf-8")
    (root / "Patches & Other Files (Like Images)" / "old_repo" / "ARCHIVE.md").write_text("ignored", encoding="utf-8")
    (root / "stores" / "_demo" / "old_repo" / "TRACE.md").write_text("ignored", encoding="utf-8")
    (root / "kishsyn_core" / "loop.py").write_text("# active source", encoding="utf-8")

    inventory = ProjectScopePolicy(root).validate()
    assert {path.name for path in inventory.markdown_files} == {"README.md", "ARCHITECTURE.md"}
