from pathlib import Path

from kishsyn_core.contracts import Action, BodyState, Outcome, Prediction, SensoryFeature, SensoryFrame, TickTrace
from kishsyn_core.loop import OrganismLoop
from kishsyn_core.memory_economy import MemoryPressureGovernor
from kishsyn_core.neural_graph import NeuralGrowthGraph
from kishsyn_core.state import load_loop, save_loop


def _trace(*, tick: int, outcome: str, error: float, text: str = "") -> TickTrace:
    features = []
    if text:
        for word in text.split():
            features.append(SensoryFeature(key="word", value=word.lower(), kind="text", intensity=1.0))
    return TickTrace(
        tick=tick,
        frame=SensoryFrame(tick=tick, features=tuple(features), raw={}),
        body_before=BodyState(energy=0.18, hydration=0.72, integrity=0.88, fatigue=0.12, curiosity=0.46, uncertainty=0.60),
        action=Action("inspect", "apple_A", "unit trace"),
        prediction=Prediction("neutral", confidence=0.1),
        outcome=Outcome(outcome, target_id="apple_A", message="unit outcome"),
        body_after=BodyState(energy=0.20, hydration=0.72, integrity=0.88, fatigue=0.12, curiosity=0.40, uncertainty=0.50),
        prediction_error=error,
        self_causation=0.9,
        world_causation=0.1,
        causation_label="self_caused",
        world_events=("apple changed",),
    )


def test_retention_pressure_preserves_instruction_and_surprise_without_tick_nodes() -> None:
    graph = NeuralGrowthGraph()
    governor = MemoryPressureGovernor()
    trace = _trace(tick=1, outcome="novelty", error=0.92, text="remember this page")

    events = governor.observe(tick=1, graph=graph, trace=trace)
    snap = governor.snapshot()

    assert events
    assert snap["observed_count"] == 1
    assert snap["summary_count"] == 1
    assert snap["last_pressure"]["decision"] in {"preserve", "consolidate"}
    assert snap["last_pressure"]["instruction_pressure"] > 0.2
    assert any(node_id.startswith("memory_summary:") for node_id in graph.neurons)
    assert not any(node_id.startswith("memory:t") for node_id in graph.neurons)


def test_repeated_experience_reuses_one_summary_bucket() -> None:
    graph = NeuralGrowthGraph()
    governor = MemoryPressureGovernor()
    for tick in range(18):
        governor.observe(tick=tick, graph=graph, trace=_trace(tick=tick, outcome="relief", error=0.40))

    snap = governor.snapshot()
    assert snap["observed_count"] == 18
    assert snap["summary_count"] == 1
    assert snap["summary_updates"] == 18
    assert snap["top_summaries"][0]["evidence_count"] == 18
    assert snap["top_summaries"][0]["consolidated"] is True


def test_loop_records_memory_economy_and_persists(tmp_path: Path) -> None:
    loop = OrganismLoop(seed=337)
    loop.sensory_hub.receive_console(tick=loop.tick, text="remember red round page", source="memory_economy_test", ttl=120)
    loop.run(steps=96)
    snap = loop.snapshot().__dict__

    assert snap["memory_economy"]["observed_count"] >= 90
    assert snap["memory_economy"]["summary_count"] >= 1
    assert snap["score"]["memory_summary_updates"] >= 1

    path = tmp_path / "brain.json"
    save_loop(loop, path, seed=337, note="memory economy persistence")
    restored, meta = load_loop(path)
    restored_snap = restored.snapshot().__dict__

    assert meta["loaded"] is True
    assert restored_snap["memory_economy"]["summary_count"] == snap["memory_economy"]["summary_count"]
    assert restored_snap["memory_economy"]["summary_updates"] == snap["memory_economy"]["summary_updates"]
