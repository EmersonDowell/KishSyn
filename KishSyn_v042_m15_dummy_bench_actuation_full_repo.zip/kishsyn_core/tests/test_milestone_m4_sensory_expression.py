from kishsyn_core.benchmark import BenchmarkPlaygroundSuite
from kishsyn_core.loop import OrganismLoop
from kishsyn_core.milestone import MilestoneM4LockEvaluator
from kishsyn_core.state import load_loop, save_loop


def test_sensory_adapters_enter_focused_moment_and_atlas():
    loop = OrganismLoop(seed=337)
    loop.autopilot.enabled = False
    loop.sensory_hub.receive_console(tick=loop.tick, text="red round ?", source="unit_console")
    loop.sensory_hub.receive_math(tick=loop.tick, expression="2+2=4", source="unit_math")
    loop.sensory_hub.receive_screen_probe(tick=loop.tick, description="screen red circle near cursor", source="unit_screen")
    loop.sensory_hub.receive_image_probe(tick=loop.tick, description="image blue tall glyph A", source="unit_image")
    loop.sensory_hub.receive_audio_probe(tick=loop.tick, description="audio soft tone red", source="unit_audio")
    loop.run(steps=42)
    snap = loop.snapshot().__dict__
    assert snap["sensory"]["packet_count"] >= 5
    assert snap["sensory"]["feature_count"] >= 36
    assert snap["expression"]["output_count"] >= 2
    surface_counts = snap["atlas"]["surface_counts"]
    assert surface_counts["math"] > 0
    assert surface_counts["screen"] > 0
    assert surface_counts["image"] > 0
    assert surface_counts["audio"] > 0
    assert surface_counts["expression"] > 0


def test_sensory_and_expression_persist_in_brain_state(tmp_path):
    loop = OrganismLoop(seed=337)
    loop.sensory_hub.receive_math(tick=loop.tick, expression="2+2=4", source="persist_math")
    loop.sensory_hub.receive_console(tick=loop.tick, text="red round ?", source="persist_console")
    loop.run(steps=28)
    path = tmp_path / "brain.json"
    save_loop(loop, path, seed=337, note="m4 sensory expression persistence")
    restored, _ = load_loop(path)
    snap = restored.snapshot().__dict__
    assert snap["sensory"]["packet_count"] >= 2
    assert snap["expression"]["output_count"] >= 1
    assert snap["atlas"]["surface_counts"].get("expression", 0) >= 1


def test_benchmark_suite_contains_m4_task():
    report = BenchmarkPlaygroundSuite().evaluate(seeds=(337,), steps=180).as_dict()
    names = {task["name"] for task in report["tasks"]}
    assert "sensory adapter and expression surface" in names
    task = next(task for task in report["tasks"] if task["name"] == "sensory adapter and expression surface")
    assert task["status"] == "pass"
    assert report["summary_score"] >= 0.80


def test_milestone_m4_lock_surface_is_declared():
    assert MilestoneM4LockEvaluator.milestone_id == "M4"
    assert MilestoneM4LockEvaluator.name == "Sensory Adapter and Expression Surface"
