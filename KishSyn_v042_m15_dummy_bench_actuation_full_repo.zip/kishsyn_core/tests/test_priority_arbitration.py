from kishsyn_core.contracts import BodyState
from kishsyn_core.neural_graph import NeuralGrowthGraph
from kishsyn_core.priority import PriorityArbitrator
from kishsyn_core.symbol_goal import ActiveSymbolGoalMemory
from kishsyn_core.loop import OrganismLoop


def _active_goal(tick: int = 0):
    graph = NeuralGrowthGraph()
    goal = ActiveSymbolGoalMemory()
    goal.activate_token(tick=tick, graph=graph, token="red", source_target="cue", reason="test cue", ttl=8)
    return graph, goal


def test_priority_honors_symbol_goal_when_body_is_stable():
    graph, goal = _active_goal()
    arbiter = PriorityArbitrator()
    decision, events = arbiter.decide(
        tick=1,
        graph=graph,
        body=BodyState(energy=0.72, hydration=0.72, integrity=0.9, fatigue=0.2, curiosity=0.4, uncertainty=0.35),
        symbol_goal=goal,
    )
    assert decision.mode == "honor_symbol"
    assert decision.active_symbol_tokens == ("red",)
    assert decision.symbol_bias > 0
    assert events


def test_priority_defers_symbol_goal_under_survival_pressure_without_erasing_it():
    graph, goal = _active_goal()
    arbiter = PriorityArbitrator()
    decision, events = arbiter.decide(
        tick=7,
        graph=graph,
        body=BodyState(energy=0.08, hydration=0.7, integrity=0.9, fatigue=0.2, curiosity=0.4, uncertainty=0.35),
        symbol_goal=goal,
    )
    assert decision.mode == "survival_override"
    assert decision.active_symbol_tokens == ()
    assert decision.deferred is True
    assert goal.active_state(9) is not None
    assert events


def test_metabolism_no_longer_crushes_energy_or_caps_fatigue_during_short_living_run():
    loop = OrganismLoop(seed=337)
    loop.run(steps=180)
    snapshot = loop.snapshot()
    assert snapshot.body["energy"] > 0.05
    assert snapshot.body["fatigue"] < 0.98
    assert snapshot.priority["mode"] in {"body_guided", "honor_symbol", "defer_symbol", "survival_override"}
