from kishsyn_core.atlas_inspector import NeuralAtlasInspector
from kishsyn_core.benchmark import BenchmarkPlaygroundSuite
from kishsyn_core.loop import OrganismLoop
from kishsyn_core.milestone import MilestoneM5LockEvaluator
from kishsyn_core.observatory.server import ObservatorySession


def _primed_loop() -> OrganismLoop:
    loop = OrganismLoop(seed=337)
    loop.sensory_hub.receive_console(tick=loop.tick, text="red round ?", source="unit_console")
    loop.sensory_hub.receive_math(tick=loop.tick, expression="2+2=4", source="unit_math")
    loop.sensory_hub.receive_screen_probe(tick=loop.tick, description="screen red circle near cursor", source="unit_screen")
    loop.run(steps=54)
    return loop


def test_atlas_inspector_explains_node_and_synapse():
    loop = _primed_loop()
    edges = [edge for edge in loop.graph.snapshot()["edges"] if abs(float(edge["weight"])) > 0.01]
    assert edges
    edge = sorted(edges, key=lambda item: (-int(item["last_updated"]), -abs(float(item["weight"]))))[0]
    inspector = NeuralAtlasInspector()
    node_info = inspector.inspect_node(graph=loop.graph, node_id=edge["source"], tick=loop.tick, last_trace=loop.last_trace).as_dict()
    syn_info = inspector.inspect_synapse(graph=loop.graph, source=edge["source"], target=edge["target"], tick=loop.tick, last_trace=loop.last_trace).as_dict()
    assert node_info["found"] is True
    assert node_info["item_type"] == "node"
    assert node_info["surface"] != "unknown"
    assert node_info["top_outbound"] or node_info["top_inbound"]
    assert syn_info["found"] is True
    assert syn_info["item_type"] == "synapse"
    assert len(syn_info["connected_nodes"]) == 2
    assert "weight=" in syn_info["summary"]


def test_observatory_exposes_atlas_inspection_api_surface():
    session = ObservatorySession(seed=337, autosave_every=0)
    try:
        session.loop.sensory_hub.receive_console(tick=session.loop.tick, text="red round ?", source="unit_console")
        session.tick(steps=54)
        index = session.atlas_index(limit=12)
        assert index["node_count"] >= 32
        assert index["edge_count"] >= 24
        node_id = index["nodes"][0]["id"]
        node_info = session.inspect_atlas_node(node_id=node_id)
        assert node_info["found"] is True
        syn = index["synapses"][0]
        syn_info = session.inspect_atlas_synapse(source=syn["source"], target=syn["target"])
        assert syn_info["found"] is True
    finally:
        session.stop()


def test_benchmark_suite_contains_m5_task():
    report = BenchmarkPlaygroundSuite().evaluate(seeds=(337,), steps=180).as_dict()
    names = {task["name"] for task in report["tasks"]}
    assert "neural atlas inspection" in names
    task = next(task for task in report["tasks"] if task["name"] == "neural atlas inspection")
    assert task["status"] == "pass"


def test_milestone_m5_lock_surface_is_declared():
    assert MilestoneM5LockEvaluator.milestone_id == "M5"
    assert MilestoneM5LockEvaluator.name == "Neural Atlas Inspector and Synapse Introspection"
