from __future__ import annotations

from kishsyn_core.loop import OrganismLoop
from kishsyn_core.milestone import MilestoneM7LockEvaluator
from kishsyn_core.state import load_loop, save_loop


def test_emotion_bias_contract_reaches_focus_and_expression():
    loop = OrganismLoop(seed=337)
    loop.sensory_hub.receive_console(tick=loop.tick, text="red round ?", source="test_m7", ttl=140)
    loop.run(steps=120)
    snap = loop.snapshot().__dict__
    emotion = snap["emotion"]
    assert emotion["bias_count"] >= 100
    assert emotion["last_bias"] is not None
    assert emotion["last_bias"]["focus_bias"] <= 0.28
    assert emotion["last_bias"]["expression_bias"] <= 0.30
    emotion_hits = 0
    for report in snap["focus"]["recent"]:
        for signal in report.get("selected", []) + report.get("rejected", []):
            emotion_hits += 1 if signal.get("components", {}).get("emotion", 0.0) > 0.0 else 0
    assert emotion_hits > 0
    outputs = snap["expression"]["outputs"]
    assert any(any(str(ev).startswith("emotion_bias:") for ev in out.get("evidence", [])) for out in outputs)


def test_plan_instances_compress_into_reusable_templates():
    loop = OrganismLoop(seed=337)
    loop.run(steps=180)
    snap = loop.snapshot().__dict__
    planning = snap["planning"]
    assert planning["plan_template_count"] >= 3
    assert planning["plan_template_updates"] >= 160
    assert planning["plan_template_count"] < planning["report_count"]
    assert not any(str(node.get("id", "")).startswith("plan:t") for node in snap["graph"]["nodes"])
    assert any(node.get("kind") == "plan_template" for node in snap["graph"]["nodes"])


def test_plan_templates_and_emotion_bias_persist(tmp_path):
    loop = OrganismLoop(seed=171)
    loop.run(steps=96)
    path = tmp_path / "brain.json"
    save_loop(loop, path, seed=171, note="m7 persistence test")
    restored, _ = load_loop(path)
    before = loop.snapshot().__dict__
    after = restored.snapshot().__dict__
    assert after["planning"]["plan_template_count"] == before["planning"]["plan_template_count"]
    assert after["planning"]["plan_template_updates"] == before["planning"]["plan_template_updates"]
    assert after["emotion"]["bias_count"] == before["emotion"]["bias_count"]
    assert after["emotion"]["last_bias"] is not None


def test_milestone_m7_lock_evaluator_surface_is_declared():
    assert MilestoneM7LockEvaluator.milestone_id == "M7"
    assert MilestoneM7LockEvaluator.name == "Emotion-Biased Attention and Expression"
