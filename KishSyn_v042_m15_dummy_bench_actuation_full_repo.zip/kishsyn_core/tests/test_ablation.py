from kishsyn_core.loop import OrganismLoop


def test_memory_graph_ablation_changes_survival_or_growth():
    trained = OrganismLoop(seed=33)
    trained.run(steps=120)
    trained_survival = trained.survival_score()
    ablated_survival = trained.ablated_memory_score(steps=72, seed=33)
    # The exact direction can vary with seed because exploration can luck into resources,
    # but ablated and trained runs must not be treated as equivalent proof.
    assert abs(trained_survival - ablated_survival) >= 0.01 or trained.growth_score() > 0.4
