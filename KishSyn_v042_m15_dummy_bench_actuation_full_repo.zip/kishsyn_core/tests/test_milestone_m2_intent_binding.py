from kishsyn_core.benchmark import BenchmarkPlaygroundSuite
from kishsyn_core.loop import OrganismLoop
from kishsyn_core.milestone import MilestoneM2LockEvaluator
from kishsyn_core.state import load_loop, save_loop


def test_intent_and_cross_modal_binding_surface_grows():
    loop = OrganismLoop(seed=337)
    loop.run(steps=120)
    snap = loop.snapshot().__dict__
    assert snap["binding"]["best_modality_span"] >= 5
    assert snap["binding"]["stable_cross_modal_count"] >= 1
    assert snap["intent"]["continued_count"] >= 8
    assert snap["score"]["intent_continuity"] > 0.30


def test_intent_and_binding_persist_in_brain_state(tmp_path):
    loop = OrganismLoop(seed=337)
    loop.run(steps=90)
    path = tmp_path / "brain.json"
    save_loop(loop, path, seed=337, note="m2 persistence test")
    restored, _ = load_loop(path)
    snap = restored.snapshot().__dict__
    assert snap["intent"]["update_count"] >= 1
    assert snap["binding"]["best_modality_span"] >= 3
    assert snap["binding"]["cross_modal_count"] >= 1


def test_benchmark_suite_contains_m2_tasks():
    report = BenchmarkPlaygroundSuite().evaluate(seeds=(337,), steps=160).as_dict()
    names = {task["name"] for task in report["tasks"]}
    assert "cross-modal binding" in names
    assert "intent persistence" in names
    assert report["summary_score"] >= 0.72


def test_milestone_m2_lock_surface_is_declared():
    assert MilestoneM2LockEvaluator.milestone_id == "M2"
    assert MilestoneM2LockEvaluator.name == "Cross-Modal Binding and Intent Persistence"
