from __future__ import annotations

from kishsyn_core.emotion import EmotionalRegulationField
from kishsyn_core.loop import OrganismLoop
from kishsyn_core.state import load_loop, save_loop


def test_emotional_regulation_field_records_graph_visible_weather():
    loop = OrganismLoop(seed=337)
    loop.run(steps=128)
    snap = loop.snapshot().__dict__
    emotion = snap["emotion"]
    assert emotion["sample_count"] >= 64
    assert emotion["trait_count"] >= 3
    assert emotion["trait_mass"] > 0.20
    assert emotion["distinct_modes"] >= 2
    assert emotion["graph_event_count"] >= 400
    assert any(node["kind"] == "emotion" for node in snap["graph"]["nodes"])
    assert "emotion" in snap["atlas"]["surface_counts"]


def test_emotional_regulation_field_persists_through_brain_state(tmp_path):
    loop = OrganismLoop(seed=171)
    loop.run(steps=72)
    before = loop.snapshot().__dict__["emotion"]
    path = tmp_path / "brain.json"
    save_loop(loop, path, seed=171, note="emotion persistence test")
    restored, meta = load_loop(path)
    after = restored.snapshot().__dict__["emotion"]
    assert meta["loaded"] is True
    assert after["sample_count"] == before["sample_count"]
    assert after["trait_count"] == before["trait_count"]
    assert after["dominant_mode"] == before["dominant_mode"]


def test_emotional_regulation_field_state_roundtrip():
    loop = OrganismLoop(seed=23)
    loop.run(steps=48)
    field = EmotionalRegulationField.from_state(loop.emotional_regulation.state())
    snap = field.snapshot()
    assert snap["sample_count"] == loop.emotional_regulation.snapshot()["sample_count"]
    assert snap["trait_count"] >= 3
