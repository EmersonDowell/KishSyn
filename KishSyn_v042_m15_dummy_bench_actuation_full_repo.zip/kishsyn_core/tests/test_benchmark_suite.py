from kishsyn_core.benchmark import BenchmarkPlaygroundSuite
from kishsyn_core.evidence import IntelligenceEvidenceEvaluator


def test_benchmark_suite_runs_controlled_tasks_without_consciousness_claim():
    report = BenchmarkPlaygroundSuite().evaluate(seeds=(337,), steps=180)
    payload = report.as_dict()
    names = {task["name"] for task in payload["tasks"]}
    assert payload["consciousness_claimed"] is False
    assert payload["summary_score"] >= 0.5
    assert "delayed symbol-object matching" in names
    assert "changed-object surprise" in names
    assert "symbol recall after save-load" in names
    assert "target pursuit continuity" in names
    assert "survival-symbol conflict arbitration" in names
    assert "cross-modal binding" in names
    assert "intent persistence" in names
    assert "counterfactual replay proto-planning" in names
    assert "apple across worlds contextual affordance" in names


def test_evidence_report_includes_benchmark_suite_summary():
    report = IntelligenceEvidenceEvaluator().evaluate(seed=337, steps=180, ablation_steps=36)
    payload = report.as_dict()
    assert "benchmarks" in payload
    assert payload["benchmarks"]["consciousness_claimed"] is False
    assert payload["metrics"]["benchmark_summary_score"] >= 0.5
    assert any(item["name"] == "benchmark playground suite" for item in payload["criteria"])
    assert any(item["name"] == "cross-modal binding" for item in payload["criteria"])
    assert any(item["name"] == "intent persistence" for item in payload["criteria"])
    assert any(item["name"] == "counterfactual replay proto-planning" for item in payload["criteria"])
