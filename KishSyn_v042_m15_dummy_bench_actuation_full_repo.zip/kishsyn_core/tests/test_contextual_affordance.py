from pathlib import Path

from kishsyn_core.contextual_affordance import (
    ActorProfile,
    ContextualAffordanceCortex,
    RealityProvenance,
    WorldContext,
    object_kind_from_features,
)
from kishsyn_core.contracts import Action, Outcome
from kishsyn_core.loop import OrganismLoop
from kishsyn_core.neural_graph import NeuralGrowthGraph
from kishsyn_core.state import load_loop, save_loop


def test_object_kind_signature_reuses_pattern_not_instance_noise() -> None:
    apple_a = (
        "vision:object=apple_A",
        "vision:color=red",
        "vision:shape=round",
        "vision:quantity=available",
        "place:cell=1,2",
        "terrain:terrain=grove",
    )
    apple_b = (
        "vision:object=apple_B",
        "vision:shape=round",
        "vision:color=red",
        "vision:quantity=depleted",
        "place:cell=9,4",
        "terrain:terrain=plain",
    )

    assert object_kind_from_features(apple_a).signature_id == object_kind_from_features(apple_b).signature_id
    assert "object" not in object_kind_from_features(apple_a).signature_id
    assert "quantity" not in object_kind_from_features(apple_a).signature_id


def test_same_apple_kind_splits_by_actor_context_action_and_outcome() -> None:
    graph = NeuralGrowthGraph()
    cortex = ContextualAffordanceCortex()
    apple = object_kind_from_features(("vision:color=red", "vision:shape=round", "vision:object=apple_A"))

    game_avatar = ActorProfile(actor_id="player", kind="game_avatar", body_schema="hp_body", can_receive_game_hp=True)
    robot = ActorProfile(actor_id="kishsyn:self", kind="robot_body", body_schema="mobile_robot", can_metabolize_organic_food=False)
    game_a = WorldContext(context_id="game_a", kind="game", rule_surface="apple_heals_hp")
    game_b = WorldContext(context_id="game_b", kind="game", rule_surface="apple_is_scenery")
    real = WorldContext(context_id="garden_robot_field", kind="robot_world", rule_surface="physical_ecology")

    for tick in range(4):
        cortex.record(
            tick=tick,
            graph=graph,
            actor=game_avatar,
            context=game_a,
            target_features=apple.features,
            action=Action("eat", "apple_A", "game action"),
            outcome=Outcome("relief", target_id="apple_A", message="hp +5"),
            prediction_error=0.1,
            provenance=RealityProvenance(source="self_action"),
        )
    cortex.record(
        tick=5,
        graph=graph,
        actor=game_avatar,
        context=game_b,
        target_features=apple.features,
        action=Action("touch", "apple_tree", "try interact"),
        outcome=Outcome("neutral", target_id="apple_tree", message="scenery only"),
        prediction_error=0.2,
        provenance=RealityProvenance(source="self_action"),
    )
    cortex.record(
        tick=6,
        graph=graph,
        actor=robot,
        context=real,
        target_features=apple.features,
        action=Action("inspect", "apple_real", "identify for others"),
        outcome=Outcome("novelty", target_id="apple_real", message="food for humans/animals, seed source"),
        prediction_error=0.25,
        provenance=RealityProvenance(source="observation"),
    )

    snap = cortex.snapshot()
    assert snap["record_count"] == 3
    assert snap["context_count"] == 3
    assert snap["actor_count"] == 2

    same_context = cortex.propose_transfer(object_kind=apple, action_kind="eat", target_context=game_a, target_actor=game_avatar)
    cross_context = cortex.propose_transfer(object_kind=apple, action_kind="eat", target_context=real, target_actor=robot)
    assert same_context[0].strength > cross_context[0].strength
    assert "inhibited" in cross_context[0].reason
    assert any(node_id.startswith("affordance:") for node_id in graph.neurons)


def test_apple_across_worlds_bias_contracts_do_not_make_universal_edibility() -> None:
    graph = NeuralGrowthGraph()
    cortex = ContextualAffordanceCortex()
    apple_features = (
        "vision:object=apple_A",
        "vision:color=red",
        "vision:shape=round",
        "vision:quantity=available",
        "place:cell=2,3",
    )
    apple_kind = object_kind_from_features(apple_features)
    avatar = ActorProfile(actor_id="player", kind="game_avatar", body_schema="hp_body", can_receive_game_hp=True)
    robot = ActorProfile(actor_id="kishsyn:self", kind="robot_body", body_schema="mobile_robot", can_metabolize_organic_food=False)
    healing_game = WorldContext(context_id="game_a", kind="game", rule_surface="apple_heals_hp")
    scenery_game = WorldContext(context_id="game_b", kind="game", rule_surface="apple_is_scenery")
    crafting_game = WorldContext(context_id="game_c", kind="game", rule_surface="apple_is_ingredient")
    robot_field = WorldContext(context_id="garden_robot_field", kind="robot_world", rule_surface="physical_ecology")

    for tick in range(8):
        cortex.record(
            tick=tick,
            graph=graph,
            actor=avatar,
            context=healing_game,
            target_features=apple_features,
            action=Action("eat", "apple_A", "game consume"),
            outcome=Outcome("relief", target_id="apple_A", message="hp +5"),
            prediction_error=0.05,
        )
    for tick in range(8, 12):
        cortex.record(
            tick=tick,
            graph=graph,
            actor=avatar,
            context=scenery_game,
            target_features=apple_features,
            action=Action("touch", "apple_tree", "try scenery interaction"),
            outcome=Outcome("neutral", target_id="apple_tree", message="not interactable"),
            prediction_error=0.12,
        )
    for tick in range(12, 16):
        cortex.record(
            tick=tick,
            graph=graph,
            actor=avatar,
            context=crafting_game,
            target_features=apple_features,
            action=Action("inspect", "apple_A", "ingredient inspection"),
            outcome=Outcome("novelty", target_id="apple_A", message="ingredient value"),
            prediction_error=0.10,
        )
    for tick in range(16, 20):
        cortex.record(
            tick=tick,
            graph=graph,
            actor=robot,
            context=robot_field,
            target_features=apple_features,
            action=Action("inspect", "apple_real", "food-for-others seed-source inspection"),
            outcome=Outcome("novelty", target_id="apple_real", message="food for others and possible seed source"),
            prediction_error=0.18,
            provenance=RealityProvenance(source="observation"),
        )

    healing_eat = cortex.bias_contract(object_kind=apple_kind, action_kind="eat", target_context=healing_game, target_actor=avatar)
    robot_eat = cortex.bias_contract(object_kind=apple_kind, action_kind="eat", target_context=robot_field, target_actor=robot)
    robot_inspect = cortex.bias_contract(object_kind=apple_kind, action_kind="inspect", target_context=robot_field, target_actor=robot)

    assert healing_eat.local_confidence >= 0.9
    assert healing_eat.bias > 0.25
    assert healing_eat.inhibited is False
    assert robot_eat.local_record_id is None
    assert robot_eat.inhibited is True
    assert robot_eat.bias <= 0.08
    assert robot_eat.may_command_action is False
    assert robot_inspect.local_confidence > robot_eat.transfer_strength
    assert robot_inspect.bias > robot_eat.bias

    snap = cortex.snapshot()
    assert snap["object_kind_count"] == 1
    assert snap["context_count"] == 4
    assert snap["actor_count"] == 2


def test_loop_records_contextual_affordance_and_persists(tmp_path: Path) -> None:
    loop = OrganismLoop(seed=337)
    loop.run(steps=96)
    snap = loop.snapshot().__dict__
    assert snap["contextual_affordance"]["record_count"] >= 1
    assert snap["contextual_affordance"]["record_updates"] >= 1
    assert snap["score"]["contextual_affordance_records"] >= 1

    path = tmp_path / "brain.json"
    save_loop(loop, path, seed=337, note="contextual affordance persistence")
    restored, meta = load_loop(path)
    restored_snap = restored.snapshot().__dict__
    assert meta["loaded"] is True
    assert restored_snap["contextual_affordance"]["record_count"] == snap["contextual_affordance"]["record_count"]
