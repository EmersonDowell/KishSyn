from kishsyn_core.neural_graph import NeuralGrowthGraph
from kishsyn_core.symbol_choice import SymbolChoiceProbe
from kishsyn_core.loop import OrganismLoop


def _seed_red_symbol_graph() -> NeuralGrowthGraph:
    graph = NeuralGrowthGraph()
    graph.ensure_neuron("symbol:token=red", kind="symbol", label="token=red", tick=0)
    graph.ensure_neuron("concept:color=red", kind="concept", label="color=red", tick=0)
    graph.ensure_neuron("concept:color=blue", kind="concept", label="color=blue", tick=0)
    graph.ensure_neuron("vision:color=red", kind="feature", label="vision:color=red", tick=0)
    graph.ensure_neuron("vision:color=blue", kind="feature", label="vision:color=blue", tick=0)
    graph.reinforce("symbol:token=red", "concept:color=red", amount=0.7, tick=0, reason="test grounding")
    graph.reinforce("vision:color=red", "concept:color=red", amount=0.4, tick=0, reason="test abstraction")
    graph.reinforce("vision:color=blue", "concept:color=blue", amount=0.4, tick=0, reason="test abstraction")
    return graph


def test_symbol_cue_scores_matching_concept_above_distractor():
    graph = _seed_red_symbol_graph()
    match_score, evidence = graph.symbol_cue_score(("vision:symbol_token=red",), ("vision:color=red",))
    distract_score, _ = graph.symbol_cue_score(("vision:symbol_token=red",), ("vision:color=blue",))
    assert match_score > distract_score
    assert evidence
    ablated = graph.symbol_ablated_copy(keep_neurons=True)
    ablated_score, _ = ablated.symbol_cue_score(("vision:symbol_token=red",), ("vision:color=red",))
    assert match_score > ablated_score


def test_symbol_choice_probe_detects_ablation_sensitive_choice():
    graph = _seed_red_symbol_graph()
    report = SymbolChoiceProbe().evaluate(graph)
    assert report.trial_count >= 1
    assert report.passed_count >= 1
    assert report.ablation_delta > 0.01


def test_loop_snapshot_exposes_symbol_choice_probe_after_learning():
    loop = OrganismLoop(seed=337)
    loop.run(steps=180)
    snapshot = loop.snapshot()
    assert snapshot.symbol_choice["trial_count"] >= 1
    assert snapshot.score["symbol_choice_ablation_delta"] >= 0.0
