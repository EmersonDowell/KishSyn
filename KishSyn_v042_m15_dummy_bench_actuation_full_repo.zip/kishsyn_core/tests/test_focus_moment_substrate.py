from kishsyn_core.focus import FocusGate
from kishsyn_core.loop import OrganismLoop
from kishsyn_core.state import load_loop, save_loop


def test_focus_gate_selects_bounded_active_frame():
    loop = OrganismLoop(seed=337)
    raw = loop.text_crib.inject_features(tick=0, frame=loop.world.observe(loop.body))
    report = FocusGate(max_features=12).select(
        tick=0,
        frame=raw,
        body=loop.body,
        graph=loop.graph,
        active_symbol_tokens=("red",),
    )
    focused = report.to_frame(raw)
    assert report.raw_count == len(raw.features)
    assert 1 <= len(focused.features) <= 12
    assert report.selected_count == len(focused.features)
    assert report.selectivity > 0.0
    assert any(signal.token == "body:need=uncertainty" for signal in report.selected_signals)


def test_moment_binding_and_anatomy_grow_from_loop():
    loop = OrganismLoop(seed=337)
    loop.run(steps=96)
    snap = loop.snapshot().__dict__
    assert snap["focus"]["mean_selectivity"] >= 0.15
    assert snap["moments"]["count"] >= 64
    assert snap["binding"]["stable_count"] >= 1
    assert snap["anatomy"]["circuit_count"] >= 1
    assert snap["score"]["circuit_promotions"] >= 1.0


def test_focused_substrate_persists_in_brain_state(tmp_path):
    loop = OrganismLoop(seed=337)
    loop.run(steps=80)
    path = tmp_path / "brain.json"
    save_loop(loop, path, seed=337, note="focus substrate test")
    restored, _ = load_loop(path)
    snap = restored.snapshot().__dict__
    assert snap["focus"]["report_count"] > 0
    assert snap["moments"]["count"] > 0
    assert snap["binding"]["candidate_count"] > 0
    assert snap["anatomy"]["circuit_count"] >= 0
