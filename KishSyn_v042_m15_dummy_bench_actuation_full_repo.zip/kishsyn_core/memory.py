"""Trace memory and replay."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass

from .contracts import TickTrace
from .neural_graph import NeuralGrowthGraph


@dataclass(frozen=True)
class ReplayEvent:
    tick: int
    source_tick: int
    reason: str
    strengthened_edges: int


class TraceMemory:
    """Bounded episodic trace memory."""

    def __init__(self, *, capacity: int = 512) -> None:
        self.traces: deque[TickTrace] = deque(maxlen=capacity)
        self.replays: list[ReplayEvent] = []

    def append(self, trace: TickTrace) -> None:
        self.traces.append(trace)

    def important_traces(self, *, limit: int = 5) -> list[TickTrace]:
        ranked = sorted(
            self.traces,
            key=lambda trace: (abs(trace.prediction_error), 1 if trace.outcome.kind in {"pain", "relief"} else 0),
            reverse=True,
        )
        return ranked[:limit]

    def replay(self, *, tick: int, graph: NeuralGrowthGraph) -> ReplayEvent | None:
        if not self.traces:
            return None
        trace = self.important_traces(limit=1)[0]
        strengthened = 0
        for event in trace.plasticity:
            amount = 0.018 if event.after >= 0 else -0.010
            graph.reinforce(event.source, event.target, amount=amount, tick=tick, reason="memory replay")
            strengthened += 1
        replay_event = ReplayEvent(tick=tick, source_tick=trace.tick, reason="surprise/relief replay", strengthened_edges=strengthened)
        self.replays.append(replay_event)
        return replay_event

    def snapshot(self) -> dict[str, object]:
        recent = list(self.traces)[-12:]
        return {
            "trace_count": len(self.traces),
            "recent": [
                {
                    "tick": trace.tick,
                    "action": trace.action.kind,
                    "target": trace.action.target_id,
                    "outcome": trace.outcome.kind,
                    "message": trace.outcome.message,
                    "prediction": trace.prediction.expected_outcome,
                    "prediction_error": round(trace.prediction_error, 4),
                }
                for trace in recent
            ],
            "replays": [event.__dict__ for event in self.replays[-8:]],
        }
