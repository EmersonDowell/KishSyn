"""Budgeted neural graph projection for viewport rendering.

The living graph is KishSyn anatomy. The synaptic viewport is only a camera. This
module prevents the GUI from pulling and drawing the whole brain every frame by
projecting a deterministic, inspectable subset of the graph under explicit
budgets.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import log1p
from typing import Any

from .neural_graph import NeuralGrowthGraph, Neuron, Synapse


@dataclass(frozen=True)
class GraphViewportBudget:
    """Rendering budget for GUI graph views.

    Pattern: Value Object. The budget is explicit so web, desktop, and future
    .exe shells share the same constraint vocabulary instead of each inventing
    their own hidden performance hacks.
    """

    node_limit: int = 420
    edge_limit: int = 760
    recent_window: int = 48
    min_edge_weight: float = 0.01

    def normalized(self) -> "GraphViewportBudget":
        return GraphViewportBudget(
            node_limit=max(64, min(2500, int(self.node_limit))),
            edge_limit=max(64, min(5000, int(self.edge_limit))),
            recent_window=max(4, min(2000, int(self.recent_window))),
            min_edge_weight=max(0.0, min(1.0, float(self.min_edge_weight))),
        )


class GraphViewportProjector:
    """Creates a deterministic graph read-model for high performance views.

    Pattern: Facade + Read Model + Budgeted Projection. It does not mutate the
    neural graph. It selects active, recent, high-degree, and structurally useful
    anatomy for display while preserving full counts for honesty.
    """

    doctrine = (
        "The synaptic viewport is a bounded camera over brain anatomy. It must "
        "render useful structure without requiring the browser or desktop shell "
        "to draw every neuron and synapse every frame."
    )

    def project(
        self,
        *,
        graph: NeuralGrowthGraph,
        tick: int,
        budget: GraphViewportBudget | None = None,
    ) -> dict[str, object]:
        budget = (budget or GraphViewportBudget()).normalized()
        all_nodes = tuple(graph.neurons.values())
        all_edges = tuple(s for s in graph.synapses.values() if abs(s.weight) > budget.min_edge_weight)
        degree = _degree_map(all_edges)

        scored_nodes = sorted(
            all_nodes,
            key=lambda node: (-self._node_score(node=node, tick=tick, degree=degree, budget=budget), node.node_id),
        )
        selected_nodes = list(scored_nodes[: budget.node_limit])
        selected_ids = {node.node_id for node in selected_nodes}

        # Preserve strong/recent edge endpoints when there is spare budget. This
        # prevents the viewport from showing isolated dots while hiding the
        # synapses that made those dots interesting.
        edge_candidates = sorted(
            all_edges,
            key=lambda syn: (-self._edge_score(syn=syn, tick=tick, budget=budget), syn.source, syn.target),
        )
        for syn in edge_candidates:
            if len(selected_ids) >= budget.node_limit:
                break
            if syn.source in selected_ids and syn.target in selected_ids:
                continue
            if self._edge_score(syn=syn, tick=tick, budget=budget) < 0.22:
                break
            for node_id in (syn.source, syn.target):
                if len(selected_ids) >= budget.node_limit:
                    break
                if node_id not in selected_ids:
                    node = graph.neurons.get(node_id)
                    if node is not None:
                        selected_nodes.append(node)
                        selected_ids.add(node_id)

        selected_edges = [syn for syn in edge_candidates if syn.source in selected_ids and syn.target in selected_ids][: budget.edge_limit]
        return {
            "nodes": [self._node_view(node) for node in sorted(selected_nodes, key=lambda item: item.node_id)],
            "edges": [self._edge_view(syn) for syn in selected_edges],
            "node_count": len(all_nodes),
            "edge_count": len(all_edges),
            "viewport": {
                "mode": "budgeted",
                "limited": len(selected_nodes) < len(all_nodes) or len(selected_edges) < len(all_edges),
                "rendered_node_count": len(selected_nodes),
                "rendered_edge_count": len(selected_edges),
                "omitted_node_count": max(0, len(all_nodes) - len(selected_nodes)),
                "omitted_edge_count": max(0, len(all_edges) - len(selected_edges)),
                "node_limit": budget.node_limit,
                "edge_limit": budget.edge_limit,
                "recent_window": budget.recent_window,
                "min_edge_weight": budget.min_edge_weight,
                "doctrine": self.doctrine,
            },
            "concepts": graph.concept_snapshot(),
            "symbols": graph.symbol_snapshot(),
        }

    def _node_score(self, *, node: Neuron, tick: int, degree: dict[str, int], budget: GraphViewportBudget) -> float:
        age_since_active = max(0, tick - int(node.last_active))
        recent = max(0.0, 1.0 - age_since_active / float(budget.recent_window))
        activation = max(0.0, min(1.0, float(node.activation)))
        structural = min(1.0, log1p(degree.get(node.node_id, 0)) / 4.0)
        kind_bonus = _kind_priority(node.kind)
        return activation * 3.2 + recent * 1.8 + structural * 0.9 + kind_bonus

    def _edge_score(self, *, syn: Synapse, tick: int, budget: GraphViewportBudget) -> float:
        age_since_update = max(0, tick - int(syn.last_updated))
        recent = max(0.0, 1.0 - age_since_update / float(budget.recent_window))
        strength = min(1.0, abs(float(syn.weight)))
        update_score = min(1.0, log1p(int(syn.updates)) / 5.0)
        return strength * 2.4 + recent * 1.2 + update_score * 0.45

    def _node_view(self, node: Neuron) -> dict[str, object]:
        return {
            "id": node.node_id,
            "kind": node.kind,
            "label": node.label,
            "activation": round(float(node.activation), 4),
            "created_at": node.created_at,
            "last_active": node.last_active,
        }

    def _edge_view(self, syn: Synapse) -> dict[str, object]:
        return {
            "source": syn.source,
            "target": syn.target,
            "weight": round(float(syn.weight), 4),
            "updates": syn.updates,
            "last_updated": syn.last_updated,
        }


def _degree_map(edges: tuple[Synapse, ...]) -> dict[str, int]:
    degree: dict[str, int] = {}
    for syn in edges:
        degree[syn.source] = degree.get(syn.source, 0) + 1
        degree[syn.target] = degree.get(syn.target, 0) + 1
    return degree


def _kind_priority(kind: str) -> float:
    # Keep high-level cognitive anatomy visible even when activation is quiet.
    if kind in {"concept", "object_file", "memory_summary", "contextual_affordance", "ui_element", "interface", "plan", "play", "language"}:
        return 0.28
    if kind in {"emotion", "binding", "circuit", "symbol", "tutor", "text", "screen", "console"}:
        return 0.22
    if kind in {"need", "self", "action", "outcome", "target"}:
        return 0.18
    return 0.08
