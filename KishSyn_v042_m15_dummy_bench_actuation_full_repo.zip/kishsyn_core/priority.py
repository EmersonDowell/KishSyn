"""Priority arbitration between survival, exploration, and symbolic goals.

A symbol goal is not a command. It is a working pressure that may compete with
body survival. This arbiter decides whether the token is allowed to bias action
on this tick, should be deferred, or must be suppressed by crisis regulation.
"""

from __future__ import annotations

from dataclasses import dataclass

from .contracts import BodyState, PlasticityEvent
from .neural_graph import NeuralGrowthGraph
from .symbol_goal import ActiveSymbolGoalMemory


@dataclass(frozen=True)
class PriorityDecision:
    """One tick of goal arbitration."""

    mode: str
    reason: str
    active_symbol_tokens: tuple[str, ...] = ()
    symbol_bias: float = 0.0
    survival_pressure: float = 0.0
    symbol_strength: float = 0.0
    deferred: bool = False


class PriorityArbitrator:
    """Scarce arbitration layer for competing pressures.

    The arbiter does not know what tokens mean. It only decides whether an
    already-active symbolic goal may influence the selector given the current
    body state and developmental focus.
    """

    def __init__(self) -> None:
        self.honor_count = 0
        self.defer_count = 0
        self.survival_override_count = 0
        self.resume_count = 0
        self.last_mode = "none"
        self.last_reason = "no arbitration yet"
        self.last_symbol_bias = 0.0
        self.last_survival_pressure = 0.0
        self.last_symbol_strength = 0.0
        self._was_deferred = False

    def decide(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph,
        body: BodyState,
        symbol_goal: ActiveSymbolGoalMemory,
        focus: object | None = None,
    ) -> tuple[PriorityDecision, tuple[PlasticityEvent, ...]]:
        state = symbol_goal.active_state(tick)
        needs = body.needs()
        survival_pressure = max(needs["energy"], needs["hydration"], needs["integrity"], needs["fatigue"])
        developmental_mode = getattr(focus, "mode", "explore") if focus is not None else "explore"
        events: list[PlasticityEvent] = []

        if state is None:
            decision = PriorityDecision(
                mode="body_guided",
                reason=f"no active symbol goal; {developmental_mode} body/world loop",
                survival_pressure=round(survival_pressure, 4),
            )
            self._remember(decision)
            return decision, tuple(events)

        critical = body.energy < 0.13 or body.hydration < 0.13 or body.integrity < 0.38 or body.fatigue > 0.90
        high_pressure = survival_pressure > 0.80 or body.energy < 0.24 or body.hydration < 0.24 or body.fatigue > 0.82
        unstable = body.uncertainty > 0.88 and developmental_mode == "stabilize"
        token = state.token
        strength = state.strength

        if critical:
            self.survival_override_count += 1
            self.defer_count += 1
            self._was_deferred = True
            events.extend(symbol_goal.defer(
                tick=tick,
                graph=graph,
                reason="critical body pressure preserved symbol goal for later",
                ttl_extension=10,
            ))
            decision = PriorityDecision(
                mode="survival_override",
                reason=f"suppressed symbol {token}: critical body pressure {survival_pressure:.2f}",
                survival_pressure=round(survival_pressure, 4),
                symbol_strength=round(strength, 4),
                deferred=True,
            )
            events.extend(self._record_decision(graph=graph, tick=tick, token=token, decision=decision))
            self._remember(decision)
            return decision, tuple(events)

        if high_pressure or unstable:
            self.defer_count += 1
            self._was_deferred = True
            events.extend(symbol_goal.defer(
                tick=tick,
                graph=graph,
                reason="body pressure deferred symbol goal",
                ttl_extension=6,
            ))
            decision = PriorityDecision(
                mode="defer_symbol",
                reason=f"deferred symbol {token}: body pressure {survival_pressure:.2f}",
                survival_pressure=round(survival_pressure, 4),
                symbol_strength=round(strength, 4),
                deferred=True,
            )
            events.extend(self._record_decision(graph=graph, tick=tick, token=token, decision=decision))
            self._remember(decision)
            return decision, tuple(events)

        self.honor_count += 1
        if self._was_deferred:
            self.resume_count += 1
        self._was_deferred = False
        novelty_bias = float(getattr(focus, "novelty_bias", 0.0)) if focus is not None else 0.0
        symbol_bias = min(0.52, 0.18 + strength * 0.28 + novelty_bias * 0.10)
        decision = PriorityDecision(
            mode="honor_symbol",
            reason=f"honoring symbol {token}: body stable enough for cue pursuit",
            active_symbol_tokens=(token,),
            symbol_bias=round(symbol_bias, 4),
            survival_pressure=round(survival_pressure, 4),
            symbol_strength=round(strength, 4),
        )
        events.extend(self._record_decision(graph=graph, tick=tick, token=token, decision=decision))
        self._remember(decision)
        return decision, tuple(events)

    def snapshot(self) -> dict[str, object]:
        return {
            "mode": self.last_mode,
            "reason": self.last_reason,
            "symbol_bias": self.last_symbol_bias,
            "survival_pressure": self.last_survival_pressure,
            "symbol_strength": self.last_symbol_strength,
            "honor_count": self.honor_count,
            "defer_count": self.defer_count,
            "survival_override_count": self.survival_override_count,
            "resume_count": self.resume_count,
        }

    def _remember(self, decision: PriorityDecision) -> None:
        self.last_mode = decision.mode
        self.last_reason = decision.reason
        self.last_symbol_bias = decision.symbol_bias
        self.last_survival_pressure = decision.survival_pressure
        self.last_symbol_strength = decision.symbol_strength

    def _record_decision(
        self,
        *,
        graph: NeuralGrowthGraph,
        tick: int,
        token: str,
        decision: PriorityDecision,
    ) -> tuple[PlasticityEvent, ...]:
        mode_node = f"priority:{decision.mode}"
        token_node = f"symbol:token={token}"
        graph.ensure_neuron(mode_node, kind="priority", label=decision.mode, tick=tick)
        graph.ensure_neuron(token_node, kind="symbol", label=f"token={token}", tick=tick)
        graph.activate(mode_node, amount=0.50 + abs(decision.symbol_bias), tick=tick)
        amount = 0.040 if decision.mode == "honor_symbol" else 0.022
        return (
            graph.reinforce(mode_node, token_node, amount=amount, tick=tick, reason="priority arbitration referenced symbol goal"),
        )
