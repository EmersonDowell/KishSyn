"""Emotional regulation field for KishSyn Core.

M6 treats emotion as regulation weather, not roleplay and not a hardcoded
personality mask. The field observes body pressure, prediction error,
controllability, safety, novelty, fatigue, and blocked intent. Stable patterns
become graph-visible emotion nodes and traits only through repeated regulation
updates.
"""

from __future__ import annotations

from collections import Counter, deque
from dataclasses import asdict, dataclass
from statistics import mean, pstdev
from typing import Any

from .contracts import Action, BodyState, Outcome, PlasticityEvent, Prediction
from .neural_graph import NeuralGrowthGraph


@dataclass(frozen=True)
class EmotionSample:
    """One regulation-weather sample from a completed organism tick.

    Pattern: Memento. Samples are replayable audit records; they are not claims
    of felt experience. They name the internal regulation mode that best fits
    measurable pressure/control dynamics.
    """

    tick: int
    mode: str
    arousal: float
    valence: float
    control: float
    safety: float
    uncertainty: float
    curiosity: float
    fatigue: float
    frustration: float
    relief: float
    confidence: float
    pressure_before: float
    pressure_after: float
    prediction_error: float
    outcome_kind: str
    action_kind: str
    reason: str

    def as_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        for key in (
            "arousal",
            "valence",
            "control",
            "safety",
            "uncertainty",
            "curiosity",
            "fatigue",
            "frustration",
            "relief",
            "confidence",
            "pressure_before",
            "pressure_after",
            "prediction_error",
        ):
            payload[key] = round(float(payload[key]), 4)
        return payload


@dataclass(frozen=True)
class EmotionTrait:
    """Slow regulation tendency accumulated from repeated emotion samples."""

    name: str
    strength: float
    updates: int

    def as_dict(self) -> dict[str, Any]:
        return {"name": self.name, "strength": round(float(self.strength), 4), "updates": int(self.updates)}


@dataclass(frozen=True)
class EmotionBiasContract:
    """Governed emotional nudge exported to attention/expression.

    Pattern: Contract + Policy. This is not a personality engine and not a
    command surface. It exposes a tiny bounded bias derived from the previous
    regulation sample so the next tick may pay slightly more attention to safety,
    novelty, blocked intent, or recovery evidence.
    """

    tick: int
    mode: str
    focus_bias: float
    expression_bias: float
    safety_bias: float
    curiosity_bias: float
    frustration_bias: float
    reason: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "tick": self.tick,
            "mode": self.mode,
            "focus_bias": round(float(self.focus_bias), 4),
            "expression_bias": round(float(self.expression_bias), 4),
            "safety_bias": round(float(self.safety_bias), 4),
            "curiosity_bias": round(float(self.curiosity_bias), 4),
            "frustration_bias": round(float(self.frustration_bias), 4),
            "reason": self.reason,
        }


class EmotionalRegulationField:
    """Turns regulation dynamics into graph-visible emotional weather.

    Pattern: Observer + State + Memento. The field observes completed ticks,
    classifies regulation modes conservatively, accumulates slow traits, and
    writes explicit graph traces for inspection. M7 allows only a bounded bias
    contract into focus and expression; it still cannot select actions directly.
    """

    def __init__(self, *, history: int = 96) -> None:
        self.history: deque[EmotionSample] = deque(maxlen=max(16, int(history)))
        self.traits: dict[str, EmotionTrait] = {}
        self.update_count = 0
        self.graph_event_count = 0
        self.mode_counts: Counter[str] = Counter()
        self.bias_count = 0
        self.last_bias: EmotionBiasContract | None = None
        self.last_sample: EmotionSample | None = None

    def observe(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph,
        body_before: BodyState,
        body_after: BodyState,
        action: Action,
        prediction: Prediction,
        outcome: Outcome,
        prediction_error: float,
        self_causation: float,
        world_causation: float,
        focus_report: object | None = None,
        intent_snapshot: dict[str, Any] | None = None,
        planning_snapshot: dict[str, Any] | None = None,
    ) -> tuple[PlasticityEvent, ...]:
        sample = self._sample(
            tick=tick,
            body_before=body_before,
            body_after=body_after,
            action=action,
            prediction=prediction,
            outcome=outcome,
            prediction_error=prediction_error,
            self_causation=self_causation,
            world_causation=world_causation,
            focus_report=focus_report,
            intent_snapshot=intent_snapshot or {},
            planning_snapshot=planning_snapshot or {},
        )
        self.history.append(sample)
        self.last_sample = sample
        self.update_count += 1
        self.mode_counts[sample.mode] += 1
        self._update_traits(sample)
        events = list(self._write_graph(graph=graph, tick=tick, sample=sample, action=action, prediction=prediction, outcome=outcome))
        self.graph_event_count += len(events)
        return tuple(events)

    def snapshot(self) -> dict[str, Any]:
        samples = list(self.history)
        traits = sorted((trait.as_dict() for trait in self.traits.values()), key=lambda item: (-float(item["strength"]), item["name"]))
        arousals = [sample.arousal for sample in samples]
        valences = [sample.valence for sample in samples]
        controls = [sample.control for sample in samples]
        modes = dict(sorted(self.mode_counts.items(), key=lambda item: (-item[1], item[0])))
        dominant_mode = samples[-1].mode if samples else "none"
        if modes:
            dominant_mode = max(modes.items(), key=lambda item: (item[1], item[0]))[0]
        stability = 1.0 - min(1.0, (pstdev(arousals) if len(arousals) > 1 else 0.0) + (pstdev(valences) if len(valences) > 1 else 0.0))
        trait_mass = sum(float(item["strength"]) for item in traits)
        return {
            "sample_count": len(samples),
            "update_count": self.update_count,
            "graph_event_count": self.graph_event_count,
            "dominant_mode": dominant_mode,
            "mode_counts": modes,
            "distinct_modes": len(modes),
            "mean_arousal": round(mean(arousals) if arousals else 0.0, 4),
            "mean_valence": round(mean(valences) if valences else 0.0, 4),
            "mean_control": round(mean(controls) if controls else 0.0, 4),
            "emotional_stability": round(stability, 4),
            "trait_count": len(traits),
            "trait_mass": round(trait_mass, 4),
            "traits": traits[:8],
            "bias_count": self.bias_count,
            "last_bias": None if self.last_bias is None else self.last_bias.as_dict(),
            "last": None if self.last_sample is None else self.last_sample.as_dict(),
            "recent": [sample.as_dict() for sample in samples[-8:]],
        }

    def state(self) -> dict[str, Any]:
        return {
            "update_count": self.update_count,
            "graph_event_count": self.graph_event_count,
            "mode_counts": dict(self.mode_counts),
            "bias_count": self.bias_count,
            "last_bias": None if self.last_bias is None else self.last_bias.as_dict(),
            "traits": [trait.as_dict() for trait in self.traits.values()],
            "history": [sample.as_dict() for sample in self.history],
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "EmotionalRegulationField":
        field = cls()
        field.update_count = int(data.get("update_count", 0))
        field.graph_event_count = int(data.get("graph_event_count", 0))
        field.mode_counts = Counter({str(k): int(v) for k, v in dict(data.get("mode_counts", {})).items()})
        field.bias_count = int(data.get("bias_count", 0))
        if data.get("last_bias"):
            field.last_bias = _bias_from_dict(data["last_bias"])
        for item in data.get("traits", []):
            trait = _trait_from_dict(item)
            field.traits[trait.name] = trait
        for item in data.get("history", [])[-field.history.maxlen :]:
            sample = _sample_from_dict(item)
            field.history.append(sample)
            field.last_sample = sample
        return field

    def bias_contract(self, *, tick: int, body: BodyState | None = None) -> EmotionBiasContract:
        """Export a bounded previous-sample bias for the next attention pass.

        Emotion may nudge what gets noticed and when grounded expression is
        emitted. It may not invent goals, overwrite memories, choose actions, or
        generate a persona. The bias is capped below direct body/goal pressure.
        """

        sample = self.last_sample
        if sample is None:
            bias = EmotionBiasContract(
                tick=tick,
                mode="settled",
                focus_bias=0.0,
                expression_bias=0.0,
                safety_bias=0.0,
                curiosity_bias=0.0,
                frustration_bias=0.0,
                reason="no prior regulation sample",
            )
        else:
            body_pressure = _pressure(body) if body is not None else sample.pressure_after
            safety_bias = _clip01(max(0.0, 0.62 - sample.safety) + (0.18 if sample.mode == "caution" else 0.0))
            curiosity_bias = _clip01(sample.curiosity * (0.62 if sample.mode == "curiosity" else 0.28))
            frustration_bias = _clip01(sample.frustration * (0.70 if sample.mode == "frustration" else 0.32))
            focus_bias = min(0.28, safety_bias * 0.16 + curiosity_bias * 0.12 + frustration_bias * 0.10 + body_pressure * 0.04)
            expression_bias = min(0.30, sample.arousal * 0.10 + frustration_bias * 0.10 + sample.relief * 0.06 + sample.prediction_error * 0.08)
            bias = EmotionBiasContract(
                tick=tick,
                mode=sample.mode,
                focus_bias=focus_bias,
                expression_bias=expression_bias,
                safety_bias=min(0.32, safety_bias * 0.22),
                curiosity_bias=min(0.26, curiosity_bias * 0.20),
                frustration_bias=min(0.24, frustration_bias * 0.18),
                reason=f"previous regulation mode {sample.mode} bounded attention/expression nudge",
            )
        self.bias_count += 1
        self.last_bias = bias
        return bias

    def _sample(
        self,
        *,
        tick: int,
        body_before: BodyState,
        body_after: BodyState,
        action: Action,
        prediction: Prediction,
        outcome: Outcome,
        prediction_error: float,
        self_causation: float,
        world_causation: float,
        focus_report: object | None,
        intent_snapshot: dict[str, Any],
        planning_snapshot: dict[str, Any],
    ) -> EmotionSample:
        pressure_before = _pressure(body_before)
        pressure_after = _pressure(body_after)
        pressure_drop = max(0.0, pressure_before - pressure_after)
        pressure_rise = max(0.0, pressure_after - pressure_before)
        focus_overload = float(getattr(focus_report, "overload", 0.0) or 0.0)
        relief_signal = (0.45 if outcome.kind == "relief" else 0.0) + pressure_drop * 1.8
        novelty_signal = 0.28 if outcome.kind == "novelty" else 0.0
        pain_signal = 0.42 if outcome.kind == "pain" else 0.0
        blocked_signal = 0.28 if outcome.kind in {"blocked", "depleted"} else 0.0
        terminal_count = float(intent_snapshot.get("terminal_count", 0.0) or 0.0)
        active_intent = 1.0 if intent_snapshot.get("active") else 0.0
        plan_alignment = float(planning_snapshot.get("alignment_ratio", 0.0) or 0.0)
        arousal = _clip01(0.14 + pressure_after * 0.38 + prediction_error * 0.24 + body_after.fatigue * 0.16 + pain_signal * 0.24 + focus_overload * 0.18)
        valence = _clip01(0.50 + relief_signal * 0.38 + novelty_signal * 0.18 - pain_signal * 0.44 - blocked_signal * 0.30 - pressure_rise * 0.72 - prediction_error * 0.08)
        control = _clip01(self_causation * 0.45 + (1.0 - prediction_error) * 0.25 + plan_alignment * 0.20 + (0.10 if prediction.expected_outcome == outcome.kind else 0.0))
        safety = _clip01(body_after.integrity - pain_signal * 0.35 - blocked_signal * 0.10 + relief_signal * 0.08)
        uncertainty = _clip01(body_after.uncertainty * 0.55 + prediction_error * 0.38 + world_causation * 0.10)
        curiosity = _clip01(body_after.curiosity + novelty_signal * 0.32 + max(0.0, 0.45 - pressure_after) * 0.12)
        fatigue = _clip01(body_after.fatigue)
        frustration = _clip01(blocked_signal + prediction_error * 0.34 + pressure_rise * 0.65 + active_intent * terminal_count * 0.015 - relief_signal * 0.25)
        relief = _clip01(relief_signal + (0.16 if prediction.expected_outcome == outcome.kind and outcome.kind == "relief" else 0.0))
        confidence = _clip01(control * 0.42 + (1.0 - prediction_error) * 0.32 + self_causation * 0.20 + (0.12 if outcome.kind == prediction.expected_outcome else 0.0))
        mode, reason = self._classify(
            arousal=arousal,
            valence=valence,
            control=control,
            safety=safety,
            uncertainty=uncertainty,
            curiosity=curiosity,
            frustration=frustration,
            relief=relief,
            confidence=confidence,
            outcome_kind=outcome.kind,
        )
        return EmotionSample(
            tick=tick,
            mode=mode,
            arousal=arousal,
            valence=valence,
            control=control,
            safety=safety,
            uncertainty=uncertainty,
            curiosity=curiosity,
            fatigue=fatigue,
            frustration=frustration,
            relief=relief,
            confidence=confidence,
            pressure_before=pressure_before,
            pressure_after=pressure_after,
            prediction_error=prediction_error,
            outcome_kind=outcome.kind,
            action_kind=action.kind,
            reason=reason,
        )

    def _classify(self, **values: Any) -> tuple[str, str]:
        outcome_kind = str(values["outcome_kind"])
        if values["safety"] < 0.45 or outcome_kind == "pain":
            return "caution", "low safety or pain consequence raised protective regulation"
        if values["frustration"] >= 0.52:
            return "frustration", "blocked/depleted or mismatched intent raised unresolved pressure"
        if values["relief"] >= 0.36 and values["valence"] >= 0.52:
            return "relief", "pressure dropped after useful consequence"
        if values["confidence"] >= 0.62 and values["control"] >= 0.50:
            return "confidence", "prediction and self-caused consequence aligned"
        if values["curiosity"] >= 0.48 and values["uncertainty"] <= 0.64:
            return "curiosity", "safe novelty or exploration pressure remained workable"
        if values["arousal"] >= 0.58 and values["valence"] < 0.48:
            return "strain", "high arousal with degraded valence produced regulatory strain"
        return "settled", "regulation remained within workable pressure bounds"

    def _update_traits(self, sample: EmotionSample) -> None:
        trait_inputs = {
            "curiosity": sample.curiosity * (1.0 if sample.mode == "curiosity" else 0.45),
            "confidence": sample.confidence * (1.0 if sample.mode == "confidence" else 0.45),
            "caution": (1.0 - sample.safety) * (1.0 if sample.mode == "caution" else 0.35),
            "frustration_tolerance": max(0.0, 1.0 - sample.frustration) * 0.55 + sample.control * 0.25,
            "recovery": sample.relief * 0.65 + max(0.0, 0.55 - sample.pressure_after) * 0.25,
        }
        for name, signal in trait_inputs.items():
            prior = self.traits.get(name, EmotionTrait(name=name, strength=0.0, updates=0))
            strength = _clip01(prior.strength * 0.965 + _clip01(signal) * 0.055)
            self.traits[name] = EmotionTrait(name=name, strength=strength, updates=prior.updates + 1)

    def _write_graph(
        self,
        *,
        graph: NeuralGrowthGraph,
        tick: int,
        sample: EmotionSample,
        action: Action,
        prediction: Prediction,
        outcome: Outcome,
    ) -> tuple[PlasticityEvent, ...]:
        mode_node = f"emotion:mode={sample.mode}"
        arousal_node = f"emotion:arousal={_band(sample.arousal)}"
        valence_node = f"emotion:valence={_band(sample.valence)}"
        control_node = f"emotion:control={_band(sample.control)}"
        need_node = f"need:{_dominant_pressure_name(sample)}"
        action_node = f"action:{action.kind}"
        outcome_node = f"outcome:{outcome.kind}"
        predicted_node = f"predicted:{prediction.expected_outcome}"
        for node, kind, label in (
            (mode_node, "emotion", f"mode={sample.mode}"),
            (arousal_node, "emotion", f"arousal={_band(sample.arousal)}"),
            (valence_node, "emotion", f"valence={_band(sample.valence)}"),
            (control_node, "emotion", f"control={_band(sample.control)}"),
            (need_node, "need", need_node.split(":", 1)[1]),
            (action_node, "action", action.kind),
            (outcome_node, "outcome", outcome.kind),
            (predicted_node, "prediction", prediction.expected_outcome),
        ):
            graph.ensure_neuron(node, kind=kind, label=label, tick=tick)
            graph.activate(node, amount=0.66 if kind == "emotion" else 0.48, tick=tick)
        events = [
            graph.reinforce(need_node, mode_node, amount=0.018 + sample.arousal * 0.010, tick=tick, reason="emotion field grounded in body pressure"),
            graph.reinforce(action_node, mode_node, amount=0.014 + sample.control * 0.010, tick=tick, reason="emotion field grounded in action consequence"),
            graph.reinforce(outcome_node, mode_node, amount=0.022 + abs(sample.valence - 0.5) * 0.016, tick=tick, reason="emotion field grounded in lived outcome"),
            graph.reinforce(predicted_node, mode_node, amount=0.010 + sample.prediction_error * 0.012, tick=tick, reason="emotion field tracks prediction fit/mismatch"),
            graph.reinforce(mode_node, arousal_node, amount=0.012, tick=tick, reason="emotion mode records arousal band"),
            graph.reinforce(mode_node, valence_node, amount=0.012, tick=tick, reason="emotion mode records valence band"),
            graph.reinforce(mode_node, control_node, amount=0.012, tick=tick, reason="emotion mode records controllability band"),
        ]
        for trait in self.traits.values():
            if trait.strength < 0.10:
                continue
            trait_node = f"emotion:trait={trait.name}"
            graph.ensure_neuron(trait_node, kind="emotion", label=f"trait={trait.name}", tick=tick)
            graph.activate(trait_node, amount=min(1.0, 0.30 + trait.strength), tick=tick)
            events.append(graph.reinforce(mode_node, trait_node, amount=0.006 + trait.strength * 0.006, tick=tick, reason="repeated regulation weather crystallizes a trait tendency"))
        return tuple(events)


def _pressure(body: BodyState) -> float:
    needs = body.needs()
    return _clip01(sum(needs.values()) / max(1.0, float(len(needs))))


def _dominant_pressure_name(sample: EmotionSample) -> str:
    pressures = {
        "arousal": sample.arousal,
        "uncertainty": sample.uncertainty,
        "fatigue": sample.fatigue,
        "frustration": sample.frustration,
        "curiosity": sample.curiosity,
        "safety": 1.0 - sample.safety,
    }
    return max(pressures.items(), key=lambda item: item[1])[0]


def _band(value: float) -> str:
    value = _clip01(value)
    if value < 0.33:
        return "low"
    if value < 0.66:
        return "mid"
    return "high"


def _clip01(value: float) -> float:
    return max(0.0, min(1.0, float(value)))


def _trait_from_dict(data: dict[str, Any]) -> EmotionTrait:
    return EmotionTrait(name=str(data.get("name", "unknown")), strength=float(data.get("strength", 0.0)), updates=int(data.get("updates", 0)))


def _bias_from_dict(data: dict[str, Any]) -> EmotionBiasContract:
    return EmotionBiasContract(
        tick=int(data.get("tick", 0)),
        mode=str(data.get("mode", "settled")),
        focus_bias=float(data.get("focus_bias", 0.0)),
        expression_bias=float(data.get("expression_bias", 0.0)),
        safety_bias=float(data.get("safety_bias", 0.0)),
        curiosity_bias=float(data.get("curiosity_bias", 0.0)),
        frustration_bias=float(data.get("frustration_bias", 0.0)),
        reason=str(data.get("reason", "restored bias")),
    )


def _sample_from_dict(data: dict[str, Any]) -> EmotionSample:
    return EmotionSample(
        tick=int(data.get("tick", 0)),
        mode=str(data.get("mode", "settled")),
        arousal=float(data.get("arousal", 0.0)),
        valence=float(data.get("valence", 0.5)),
        control=float(data.get("control", 0.0)),
        safety=float(data.get("safety", 0.0)),
        uncertainty=float(data.get("uncertainty", 0.0)),
        curiosity=float(data.get("curiosity", 0.0)),
        fatigue=float(data.get("fatigue", 0.0)),
        frustration=float(data.get("frustration", 0.0)),
        relief=float(data.get("relief", 0.0)),
        confidence=float(data.get("confidence", 0.0)),
        pressure_before=float(data.get("pressure_before", 0.0)),
        pressure_after=float(data.get("pressure_after", 0.0)),
        prediction_error=float(data.get("prediction_error", 0.0)),
        outcome_kind=str(data.get("outcome_kind", "neutral")),
        action_kind=str(data.get("action_kind", "wait")),
        reason=str(data.get("reason", "restored")),
    )
