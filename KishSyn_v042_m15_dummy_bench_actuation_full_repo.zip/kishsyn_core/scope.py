"""Governed project-scope inventory for KishSyn Core.

The living line must be measurable without walking archive folders, generated
stores, cloud placeholders, or old patch payloads. This module is the single
source of truth for active source/doc budget checks used by tests and dev gates.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class ScopeInventory:
    """Active source/document inventory for the governed living project line."""

    python_files: tuple[Path, ...]
    markdown_files: tuple[Path, ...]


@dataclass(frozen=True)
class ProjectScopePolicy:
    """Repository scope policy that deliberately excludes archives and stores."""

    root: Path
    max_active_python_files: int = 116
    max_markdown_docs: int = 32

    def inventory(self) -> ScopeInventory:
        py_files = tuple(
            sorted(
                path
                for path in (self.root / "kishsyn_core").rglob("*.py")
                if "__pycache__" not in path.parts
            )
        )
        md_files = tuple(self._active_markdown_files())
        return ScopeInventory(python_files=py_files, markdown_files=md_files)

    def validate(self) -> ScopeInventory:
        inventory = self.inventory()
        if len(inventory.python_files) > self.max_active_python_files:
            raise AssertionError(
                f"scope gate failed: {len(inventory.python_files)} python files > {self.max_active_python_files}"
            )
        if len(inventory.markdown_files) > self.max_markdown_docs:
            raise AssertionError(
                f"doc gate failed: {len(inventory.markdown_files)} markdown files > {self.max_markdown_docs}"
            )
        return inventory

    def _active_markdown_files(self) -> tuple[Path, ...]:
        """Return living markdown docs without traversing archives or broken paths.

        Only root-level project docs and first-level docs/*.md files are governed
        by the constitution budget. Old patches, generated stores, OneDrive
        placeholder/reparse folders, and historical bundles are intentionally not
        traversed here.
        """

        found: list[Path] = []
        for candidate in sorted(self.root.glob("*.md")):
            if candidate.is_file():
                found.append(candidate)

        docs_root = self.root / "docs"
        if docs_root.exists():
            for candidate in sorted(docs_root.glob("*.md")):
                if candidate.is_file():
                    found.append(candidate)

        return tuple(found)
