"""Scarce global broadcast surface."""

from __future__ import annotations

from collections import deque

from .contracts import TickTrace


class GlobalWorkspace:
    """Broadcasts only high-importance loop events.

    This is not consciousness. It is a limited attention/broadcast contract.
    """

    def __init__(self, *, capacity: int = 64) -> None:
        self.events: deque[str] = deque(maxlen=capacity)

    def evaluate(self, trace: TickTrace) -> tuple[str, ...]:
        messages: list[str] = []
        if trace.prediction_error > 0.65:
            messages.append(f"surprise: expected {trace.prediction.expected_outcome}, got {trace.outcome.kind}")
        if trace.outcome.kind == "pain":
            messages.append(f"danger: {trace.outcome.target_id} caused pain")
        if trace.outcome.kind == "relief":
            messages.append(f"relief: {trace.outcome.target_id} reduced pressure")
        if trace.action.kind == "inspect":
            messages.append(f"curiosity: inspected {trace.action.target_id}")
        for message in messages:
            self.events.append(f"t{trace.tick}: {message}")
        return tuple(messages)

    def snapshot(self) -> dict[str, object]:
        return {"events": list(self.events)[-16:]}
