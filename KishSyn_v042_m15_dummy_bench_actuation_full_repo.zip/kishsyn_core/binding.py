"""Cross-feature binding engine for focused moments.

Bindings are provisional object/event assemblies. They are not semantic truth;
they are repeated focused co-activations that deserve a reusable graph handle.
"""

from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass
from typing import Any

from .contracts import PlasticityEvent
from .moment import MomentFrame
from .neural_graph import NeuralGrowthGraph


@dataclass
class BindingCandidate:
    binding_id: str
    signature: str
    first_tick: int
    last_tick: int
    count: int = 0
    stability: float = 0.0
    last_outcome: str = "neutral"
    last_need: str = "unknown"
    modalities: tuple[str, ...] = ()
    modality_span: int = 0

    def as_dict(self) -> dict[str, Any]:
        return {
            "binding_id": self.binding_id,
            "signature": self.signature,
            "first_tick": self.first_tick,
            "last_tick": self.last_tick,
            "count": self.count,
            "stability": round(float(self.stability), 4),
            "last_outcome": self.last_outcome,
            "last_need": self.last_need,
            "modalities": list(self.modalities),
            "modality_span": int(self.modality_span),
            "cross_modal": self.modality_span >= 3,
        }


class BindingEngine:
    """Stabilizes repeated focused co-activations into event binding handles.

    Pattern: Repository + Factory. The engine owns binding candidates and creates
    graph nodes only through explicit repeated focused moments.
    """

    def __init__(self, *, capacity: int = 192) -> None:
        self.capacity = max(16, int(capacity))
        self.candidates: dict[str, BindingCandidate] = {}
        self.history: deque[str] = deque(maxlen=self.capacity)
        self.last_binding: BindingCandidate | None = None
        self.update_count = 0

    def observe(self, *, tick: int, graph: NeuralGrowthGraph, moment: MomentFrame) -> tuple[PlasticityEvent, ...]:
        signature = self._signature(moment)
        binding_id = "binding:event=" + self._safe(signature)
        candidate = self.candidates.get(signature)
        if candidate is None:
            candidate = BindingCandidate(binding_id=binding_id, signature=signature, first_tick=tick, last_tick=tick)
            self.candidates[signature] = candidate
        candidate.count += 1
        candidate.last_tick = tick
        candidate.last_outcome = moment.outcome
        candidate.last_need = moment.dominant_need
        modalities = _modalities_for(moment)
        candidate.modalities = modalities
        candidate.modality_span = len(modalities)
        cross_modal_bonus = 0.035 * max(0, candidate.modality_span - 2)
        candidate.stability = min(
            1.0,
            0.16 * candidate.count
            + max(0.0, moment.self_causation) * 0.18
            + max(0.0, 1.0 - moment.prediction_error) * 0.12
            + cross_modal_bonus,
        )
        self.last_binding = candidate
        self.history.append(signature)
        self.update_count += 1

        graph.ensure_neuron(candidate.binding_id, kind="binding", label=signature[:96], tick=tick)
        graph.activate(candidate.binding_id, amount=max(0.25, candidate.stability), tick=tick)
        events: list[PlasticityEvent] = []
        need_node = f"need:{moment.dominant_need}"
        outcome_node = f"outcome:{moment.outcome}"
        graph.ensure_neuron(need_node, kind="need", label=moment.dominant_need, tick=tick)
        graph.ensure_neuron(outcome_node, kind="outcome", label=moment.outcome, tick=tick)
        events.append(graph.reinforce(need_node, candidate.binding_id, amount=0.018, tick=tick, reason="focused moment binding need"))
        events.append(graph.reinforce(candidate.binding_id, outcome_node, amount=0.020, tick=tick, reason="focused moment binding outcome"))
        for token in tuple(moment.focused_tokens[:8]) + tuple(moment.target_tokens[:6]):
            kind = _kind_from_token(token)
            graph.ensure_neuron(token, kind=kind, label=token, tick=tick)
            graph.activate(token, amount=0.52, tick=tick)
            events.append(graph.reinforce(token, candidate.binding_id, amount=0.012 + candidate.stability * 0.012, tick=tick, reason="focused moment coactivation"))
            if candidate.stability >= 0.45:
                events.append(graph.reinforce(candidate.binding_id, token, amount=0.006, tick=tick, reason="stable binding recall"))
        return tuple(events)

    def snapshot(self) -> dict[str, Any]:
        candidates = sorted(self.candidates.values(), key=lambda item: (-item.stability, -item.count, item.signature))
        cross_modal = [item for item in candidates if item.modality_span >= 3]
        return {
            "candidate_count": len(candidates),
            "stable_count": sum(1 for item in candidates if item.stability >= 0.45),
            "cross_modal_count": len(cross_modal),
            "stable_cross_modal_count": sum(1 for item in cross_modal if item.stability >= 0.45),
            "best_modality_span": max((item.modality_span for item in candidates), default=0),
            "update_count": self.update_count,
            "last": None if self.last_binding is None else self.last_binding.as_dict(),
            "top": [item.as_dict() for item in candidates[:12]],
        }

    def state(self) -> dict[str, Any]:
        return {
            "capacity": self.capacity,
            "update_count": self.update_count,
            "history": list(self.history),
            "last_signature": None if self.last_binding is None else self.last_binding.signature,
            "candidates": [candidate.as_dict() for candidate in self.candidates.values()],
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "BindingEngine":
        engine = cls(capacity=int(data.get("capacity", 192)))
        engine.update_count = int(data.get("update_count", 0))
        for item in data.get("candidates", []):
            candidate = BindingCandidate(
                binding_id=str(item.get("binding_id", "")),
                signature=str(item.get("signature", "")),
                first_tick=int(item.get("first_tick", 0)),
                last_tick=int(item.get("last_tick", 0)),
                count=int(item.get("count", 0)),
                stability=float(item.get("stability", 0.0)),
                last_outcome=str(item.get("last_outcome", "neutral")),
                last_need=str(item.get("last_need", "unknown")),
                modalities=tuple(str(v) for v in item.get("modalities", [])),
                modality_span=int(item.get("modality_span", 0)),
            )
            if candidate.signature:
                engine.candidates[candidate.signature] = candidate
        engine.history = deque((str(item) for item in data.get("history", [])), maxlen=engine.capacity)
        last_signature = data.get("last_signature")
        if last_signature in engine.candidates:
            engine.last_binding = engine.candidates[last_signature]
        return engine

    def _signature(self, moment: MomentFrame) -> str:
        feature_head = "+".join(_compress_token(token) for token in (moment.focused_tokens[:5] + moment.target_tokens[:4]))
        return f"{moment.dominant_need}|{moment.action}|{moment.outcome}|{feature_head}"

    def _safe(self, value: str) -> str:
        return "".join(ch if ch.isalnum() or ch in "=_-." else "_" for ch in value)[:144]


def _kind_from_token(token: str) -> str:
    if token.startswith("vision:"):
        return "feature"
    if token.startswith("body:"):
        return "need"
    if token.startswith("place:"):
        return "place"
    if token.startswith("terrain:"):
        return "terrain"
    if token.startswith("text:"):
        return "text"
    if token.startswith("concept:"):
        return "concept"
    if token.startswith("symbol:"):
        return "symbol"
    return "feature"


def _modalities_for(moment: MomentFrame) -> tuple[str, ...]:
    modalities = {token.split(":", 1)[0] for token in tuple(moment.focused_tokens) + tuple(moment.target_tokens) if ":" in token}
    modalities.add("action")
    modalities.add("outcome")
    modalities.add("need")
    if moment.self_causation > 0.25:
        modalities.add("self")
    return tuple(sorted(modalities))


def _compress_token(token: str) -> str:
    if len(token) <= 36:
        return token
    return token[:33] + "..."
