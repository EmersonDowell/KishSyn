"""Place and route memory for the reflex-first organism.

This module is intentionally small. It does not invent a planning mind. It turns
place/action/outcome transitions into route-valued synapses so future action
selection can bias toward places that previously reduced body pressure and away
from places that caused pain.
"""

from __future__ import annotations

from dataclasses import dataclass

from .contracts import Action, Outcome, PlasticityEvent
from .neural_graph import NeuralGrowthGraph


@dataclass(frozen=True)
class RouteStep:
    tick: int
    from_place: str
    to_place: str
    action: str
    target_id: str | None
    outcome: str
    value_delta: float


class RouteMemory:
    """Hippocampal-style route trace memory."""

    def __init__(self, *, capacity: int = 256) -> None:
        self.capacity = capacity
        self.steps: list[RouteStep] = []
        self.best_places: dict[str, float] = {}

    def record(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph,
        from_place: str,
        to_place: str,
        action: Action,
        outcome: Outcome,
        dominant_need: str,
    ) -> tuple[PlasticityEvent, ...]:
        value_delta = self._outcome_value(outcome.kind)
        step = RouteStep(tick, from_place, to_place, action.kind, action.target_id, outcome.kind, value_delta)
        self.steps.append(step)
        if len(self.steps) > self.capacity:
            self.steps = self.steps[-self.capacity:]
        self.best_places[to_place] = self.best_places.get(to_place, 0.0) * 0.98 + value_delta

        events: list[PlasticityEvent] = []
        from_node = f"route:from={from_place}"
        to_node = f"route:to={to_place}"
        need_node = f"need:{dominant_need}"
        outcome_node = f"outcome:{outcome.kind}"
        for node_id, kind, label in (
            (from_node, "route", from_place),
            (to_node, "route", to_place),
            (need_node, "need", dominant_need),
            (outcome_node, "outcome", outcome.kind),
        ):
            graph.ensure_neuron(node_id, kind=kind, label=label, tick=tick)
        graph.activate(from_node, amount=0.62, tick=tick)
        graph.activate(to_node, amount=0.76, tick=tick)

        route_amount = value_delta * 0.11
        need_amount = value_delta * 0.07
        if abs(route_amount) > 0.001:
            events.append(graph.reinforce(from_node, to_node, amount=route_amount, tick=tick, reason="route consequence"))
            events.append(graph.reinforce(to_node, outcome_node, amount=route_amount, tick=tick, reason="place outcome memory"))
            events.append(graph.reinforce(need_node, to_node, amount=need_amount, tick=tick, reason="need route bias"))
        if action.target_id is not None:
            target_node = f"target:{action.target_id}"
            graph.ensure_neuron(target_node, kind="target", label=action.target_id, tick=tick)
            graph.activate(target_node, amount=0.58, tick=tick)
            events.append(graph.reinforce(to_node, target_node, amount=max(-0.05, min(0.08, route_amount)), tick=tick, reason="place target association"))
        return tuple(events)

    def score_place(self, *, place_key: str, need: str, graph: NeuralGrowthGraph) -> float:
        node = f"route:to={place_key}"
        learned = self.best_places.get(place_key, 0.0) * 0.18
        learned += graph.weight(f"need:{need}", node) * 0.95
        learned += graph.weight(node, "outcome:relief") * 0.60
        learned -= graph.weight(node, "outcome:pain") * 0.85
        return max(-0.55, min(0.55, learned))

    def snapshot(self) -> dict[str, object]:
        ranked = sorted(self.best_places.items(), key=lambda item: item[1], reverse=True)[:8]
        return {
            "step_count": len(self.steps),
            "recent": [step.__dict__ for step in self.steps[-12:]],
            "best_places": [{"place": place, "value": round(value, 4)} for place, value in ranked],
        }

    def _outcome_value(self, outcome: str) -> float:
        if outcome == "relief":
            return 1.0
        if outcome == "novelty":
            return 0.42
        if outcome == "pain":
            return -1.0
        if outcome in {"blocked", "depleted"}:
            return -0.32
        return -0.015
