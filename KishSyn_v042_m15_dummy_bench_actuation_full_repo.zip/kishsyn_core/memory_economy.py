"""Retention pressure and memory economy for KishSyn Core.

M10 doctrine: the graph is reusable anatomy, the ledger is event history, and
retention pressure decides what earns durable memory. This layer observes a
completed TickTrace after lived outcome and compresses repeated low/mid-pressure
experience into reusable summary records instead of creating one durable memory
node per tick.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal

from .contracts import PlasticityEvent, TickTrace
from .neural_graph import NeuralGrowthGraph

RetentionDecision = Literal["transient", "summarize", "preserve", "consolidate"]


@dataclass(frozen=True)
class RetentionPressure:
    """Inspectable pressure score explaining why a trace should or should not stay.

    Pattern: Value Object. The score is not a command; it is an audit record for
    consolidation. High surprise, danger/relief, goal pressure, instruction-like
    cues, and self-caused utility increase retention.
    """

    tick: int
    score: float
    decision: RetentionDecision
    dominant_need: str
    surprise: float
    outcome_weight: float
    need_pressure: float
    instruction_pressure: float
    self_causation: float
    utility: float
    reason: str

    def as_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        for key in ("score", "surprise", "outcome_weight", "need_pressure", "instruction_pressure", "self_causation", "utility"):
            payload[key] = round(float(payload[key]), 4)
        return payload


@dataclass
class MemorySummary:
    """Reusable compressed memory bucket.

    Pattern: Flyweight. Many event traces strengthen one summary keyed by target,
    action, outcome, causation, and dominant need. This gives recallable shape
    without turning every tick into permanent graph anatomy.
    """

    summary_id: str
    target_id: str
    action_kind: str
    outcome_kind: str
    dominant_need: str
    causation_label: str
    evidence_count: int = 0
    first_tick: int = 0
    last_tick: int = 0
    max_pressure: float = 0.0
    total_pressure: float = 0.0
    total_prediction_error: float = 0.0
    world_event_count: int = 0
    decisions: dict[str, int] = field(default_factory=dict)

    def observe(self, *, pressure: RetentionPressure, trace: TickTrace) -> None:
        if self.evidence_count == 0:
            self.first_tick = int(trace.tick)
        self.evidence_count += 1
        self.last_tick = int(trace.tick)
        self.max_pressure = max(float(self.max_pressure), float(pressure.score))
        self.total_pressure += float(pressure.score)
        self.total_prediction_error += float(trace.prediction_error)
        self.world_event_count += len(trace.world_events)
        self.decisions[pressure.decision] = self.decisions.get(pressure.decision, 0) + 1

    @property
    def mean_pressure(self) -> float:
        return self.total_pressure / max(1, self.evidence_count)

    @property
    def mean_prediction_error(self) -> float:
        return self.total_prediction_error / max(1, self.evidence_count)

    @property
    def consolidated(self) -> bool:
        return self.max_pressure >= 0.78 or self.evidence_count >= 12 or self.decisions.get("consolidate", 0) > 0

    def as_dict(self) -> dict[str, Any]:
        return {
            "summary_id": self.summary_id,
            "target_id": self.target_id,
            "action_kind": self.action_kind,
            "outcome_kind": self.outcome_kind,
            "dominant_need": self.dominant_need,
            "causation_label": self.causation_label,
            "evidence_count": self.evidence_count,
            "first_tick": self.first_tick,
            "last_tick": self.last_tick,
            "max_pressure": round(float(self.max_pressure), 4),
            "mean_pressure": round(float(self.mean_pressure), 4),
            "mean_prediction_error": round(float(self.mean_prediction_error), 4),
            "world_event_count": self.world_event_count,
            "consolidated": self.consolidated,
            "decisions": dict(sorted(self.decisions.items())),
        }

    def state(self) -> dict[str, Any]:
        return {
            "summary_id": self.summary_id,
            "target_id": self.target_id,
            "action_kind": self.action_kind,
            "outcome_kind": self.outcome_kind,
            "dominant_need": self.dominant_need,
            "causation_label": self.causation_label,
            "evidence_count": self.evidence_count,
            "first_tick": self.first_tick,
            "last_tick": self.last_tick,
            "max_pressure": self.max_pressure,
            "total_pressure": self.total_pressure,
            "total_prediction_error": self.total_prediction_error,
            "world_event_count": self.world_event_count,
            "decisions": dict(self.decisions),
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "MemorySummary":
        return cls(
            summary_id=str(data.get("summary_id", "unknown")),
            target_id=str(data.get("target_id", "none")),
            action_kind=str(data.get("action_kind", "wait")),
            outcome_kind=str(data.get("outcome_kind", "neutral")),
            dominant_need=str(data.get("dominant_need", "uncertainty")),
            causation_label=str(data.get("causation_label", "unknown")),
            evidence_count=int(data.get("evidence_count", 0)),
            first_tick=int(data.get("first_tick", 0)),
            last_tick=int(data.get("last_tick", 0)),
            max_pressure=float(data.get("max_pressure", 0.0)),
            total_pressure=float(data.get("total_pressure", 0.0)),
            total_prediction_error=float(data.get("total_prediction_error", 0.0)),
            world_event_count=int(data.get("world_event_count", 0)),
            decisions={str(k): int(v) for k, v in dict(data.get("decisions", {})).items()},
        )


class MemoryPressureGovernor:
    """Retention policy and compressed memory repository.

    Pattern: Strategy + Repository. The Strategy scores whether a trace should
    be transient, summarized, preserved, or consolidated. The Repository stores
    bounded summaries. It does not own the action loop and cannot choose actions.
    """

    def __init__(self, *, capacity: int = 256, history_capacity: int = 192) -> None:
        self.capacity = max(16, int(capacity))
        self.history_capacity = max(32, int(history_capacity))
        self.summaries: dict[str, MemorySummary] = {}
        self.pressure_history: list[RetentionPressure] = []
        self.observed_count = 0
        self.summary_updates = 0
        self.preserved_count = 0
        self.consolidated_count = 0
        self.transient_count = 0
        self.last_pressure: RetentionPressure | None = None

    def observe(self, *, tick: int, graph: NeuralGrowthGraph, trace: TickTrace) -> tuple[PlasticityEvent, ...]:
        pressure = self.score_trace(trace)
        self.observed_count += 1
        self.last_pressure = pressure
        self.pressure_history.append(pressure)
        self.pressure_history = self.pressure_history[-self.history_capacity:]
        if pressure.decision == "transient":
            self.transient_count += 1
            return ()
        summary_id = self._summary_id(trace)
        summary = self.summaries.get(summary_id)
        if summary is None:
            summary = MemorySummary(
                summary_id=summary_id,
                target_id=trace.action.target_id or "none",
                action_kind=trace.action.kind,
                outcome_kind=trace.outcome.kind,
                dominant_need=trace.body_before.dominant_need(),
                causation_label=trace.causation_label,
            )
            self.summaries[summary_id] = summary
            self._trim_summaries()
        summary.observe(pressure=pressure, trace=trace)
        self.summary_updates += 1
        if pressure.decision in {"preserve", "consolidate"}:
            self.preserved_count += 1
        if pressure.decision == "consolidate" or summary.consolidated:
            self.consolidated_count += 1
        return self._write_graph(graph=graph, tick=tick, pressure=pressure, summary=summary)

    def score_trace(self, trace: TickTrace) -> RetentionPressure:
        needs = trace.body_before.needs()
        dominant_need, need_pressure = max(needs.items(), key=lambda item: item[1])
        surprise = max(0.0, min(1.0, abs(float(trace.prediction_error))))
        outcome_weight = {
            "pain": 0.92,
            "relief": 0.78,
            "novelty": 0.48,
            "communication": 0.64,
            "blocked": 0.36,
            "depleted": 0.42,
            "neutral": 0.12,
        }.get(trace.outcome.kind, 0.12)
        tokens = trace.frame.tokens()
        instruction_pressure = 0.0
        remember_words = ("remember", "memorize", "study", "recall", "page", "teach")
        if any(token.startswith(("text:", "console:")) for token in tokens):
            instruction_pressure += 0.10
        if any(any(word in token.lower() for word in remember_words) for token in tokens):
            instruction_pressure += 0.28
        self_causation = max(0.0, min(1.0, float(trace.self_causation)))
        utility = 0.0
        if trace.outcome.kind in {"relief", "communication"}:
            utility += 0.20
        if trace.action.target_id:
            utility += 0.08
        if trace.world_events:
            utility += 0.08
        score = (
            surprise * 0.28
            + outcome_weight * 0.24
            + max(0.0, min(1.0, need_pressure)) * 0.18
            + min(1.0, instruction_pressure) * 0.14
            + self_causation * 0.08
            + min(1.0, utility) * 0.08
        )
        score = max(0.0, min(1.0, score))
        if score >= 0.78:
            decision: RetentionDecision = "consolidate"
        elif score >= 0.55:
            decision = "preserve"
        elif score >= 0.28:
            decision = "summarize"
        else:
            decision = "transient"
        reason = (
            f"{decision}: surprise={surprise:.2f}, outcome={trace.outcome.kind}, "
            f"need={dominant_need}:{need_pressure:.2f}, instruction={instruction_pressure:.2f}"
        )
        return RetentionPressure(
            tick=trace.tick,
            score=score,
            decision=decision,
            dominant_need=dominant_need,
            surprise=surprise,
            outcome_weight=outcome_weight,
            need_pressure=need_pressure,
            instruction_pressure=min(1.0, instruction_pressure),
            self_causation=self_causation,
            utility=min(1.0, utility),
            reason=reason,
        )

    def snapshot(self) -> dict[str, Any]:
        summaries = sorted((summary.as_dict() for summary in self.summaries.values()), key=lambda item: (-float(item["max_pressure"]), -int(item["evidence_count"]), str(item["summary_id"])))
        consolidated = sum(1 for summary in self.summaries.values() if summary.consolidated)
        return {
            "observed_count": self.observed_count,
            "summary_count": len(self.summaries),
            "summary_updates": self.summary_updates,
            "transient_count": self.transient_count,
            "preserved_count": self.preserved_count,
            "consolidated_count": consolidated,
            "last_pressure": None if self.last_pressure is None else self.last_pressure.as_dict(),
            "top_summaries": summaries[:12],
            "recent_pressure": [item.as_dict() for item in self.pressure_history[-12:]],
        }

    def state(self) -> dict[str, Any]:
        return {
            "capacity": self.capacity,
            "history_capacity": self.history_capacity,
            "observed_count": self.observed_count,
            "summary_updates": self.summary_updates,
            "transient_count": self.transient_count,
            "preserved_count": self.preserved_count,
            "consolidated_count": self.consolidated_count,
            "last_pressure": None if self.last_pressure is None else self.last_pressure.as_dict(),
            "pressure_history": [item.as_dict() for item in self.pressure_history[-self.history_capacity:]],
            "summaries": [summary.state() for summary in self.summaries.values()],
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "MemoryPressureGovernor":
        governor = cls(capacity=int(data.get("capacity", 256)), history_capacity=int(data.get("history_capacity", 192)))
        governor.observed_count = int(data.get("observed_count", 0))
        governor.summary_updates = int(data.get("summary_updates", 0))
        governor.transient_count = int(data.get("transient_count", 0))
        governor.preserved_count = int(data.get("preserved_count", 0))
        governor.consolidated_count = int(data.get("consolidated_count", 0))
        governor.summaries = {str(item.get("summary_id", "unknown")): MemorySummary.from_state(dict(item)) for item in data.get("summaries", [])}
        governor.pressure_history = [_pressure_from_state(dict(item)) for item in data.get("pressure_history", [])][-governor.history_capacity:]
        if data.get("last_pressure"):
            governor.last_pressure = _pressure_from_state(dict(data["last_pressure"]))
        elif governor.pressure_history:
            governor.last_pressure = governor.pressure_history[-1]
        return governor

    def _write_graph(self, *, graph: NeuralGrowthGraph, tick: int, pressure: RetentionPressure, summary: MemorySummary) -> tuple[PlasticityEvent, ...]:
        summary_node = f"memory_summary:{summary.summary_id}"
        decision_node = f"retention:{pressure.decision}"
        need_node = f"need:{pressure.dominant_need}"
        action_node = f"action:{summary.action_kind}"
        outcome_node = f"outcome:{summary.outcome_kind}"
        graph.ensure_neuron(summary_node, kind="memory_summary", label=summary.summary_id, tick=tick)
        graph.ensure_neuron(decision_node, kind="retention", label=pressure.decision, tick=tick)
        graph.ensure_neuron(need_node, kind="need", label=pressure.dominant_need, tick=tick)
        graph.ensure_neuron(action_node, kind="action", label=summary.action_kind, tick=tick)
        graph.ensure_neuron(outcome_node, kind="outcome", label=summary.outcome_kind, tick=tick)
        graph.activate(summary_node, amount=max(0.20, min(1.0, pressure.score)), tick=tick)
        amount = 0.010 + min(0.030, pressure.score * 0.025)
        events: list[PlasticityEvent] = [
            graph.reinforce(summary_node, decision_node, amount=amount, tick=tick, reason="retention pressure decision evidence"),
            graph.reinforce(need_node, summary_node, amount=amount * 0.75, tick=tick, reason="memory summary need pressure"),
            graph.reinforce(summary_node, action_node, amount=amount * 0.45, tick=tick, reason="memory summary action evidence"),
            graph.reinforce(summary_node, outcome_node, amount=amount * 0.55, tick=tick, reason="memory summary outcome evidence"),
        ]
        if summary.consolidated:
            consolidated_node = "retention:consolidated_summary"
            graph.ensure_neuron(consolidated_node, kind="retention", label="consolidated_summary", tick=tick)
            events.append(graph.reinforce(summary_node, consolidated_node, amount=0.020, tick=tick, reason="memory summary crossed consolidation threshold"))
        return tuple(events)

    def _summary_id(self, trace: TickTrace) -> str:
        target = _safe(trace.action.target_id or "none")
        return ":".join((
            _safe(trace.body_before.dominant_need()),
            _safe(trace.action.kind),
            target,
            _safe(trace.outcome.kind),
            _safe(trace.causation_label),
        ))

    def _trim_summaries(self) -> None:
        if len(self.summaries) <= self.capacity:
            return
        ranked = sorted(self.summaries.values(), key=lambda item: (item.consolidated, item.max_pressure, item.evidence_count, item.last_tick), reverse=True)
        keep = {item.summary_id for item in ranked[: self.capacity]}
        self.summaries = {key: value for key, value in self.summaries.items() if key in keep}


def _pressure_from_state(data: dict[str, Any]) -> RetentionPressure:
    decision = str(data.get("decision", "transient"))
    if decision not in {"transient", "summarize", "preserve", "consolidate"}:
        decision = "transient"
    return RetentionPressure(
        tick=int(data.get("tick", 0)),
        score=float(data.get("score", 0.0)),
        decision=decision,  # type: ignore[arg-type]
        dominant_need=str(data.get("dominant_need", "uncertainty")),
        surprise=float(data.get("surprise", 0.0)),
        outcome_weight=float(data.get("outcome_weight", 0.0)),
        need_pressure=float(data.get("need_pressure", 0.0)),
        instruction_pressure=float(data.get("instruction_pressure", 0.0)),
        self_causation=float(data.get("self_causation", 0.0)),
        utility=float(data.get("utility", 0.0)),
        reason=str(data.get("reason", "restored retention pressure")),
    )


def _safe(value: object) -> str:
    text = str(value).strip().replace(" ", "_").replace("/", "_").replace("\\", "_")
    return "".join(ch for ch in text if ch.isalnum() or ch in {"_", "-", ":", ",", "="})[:96] or "unknown"
