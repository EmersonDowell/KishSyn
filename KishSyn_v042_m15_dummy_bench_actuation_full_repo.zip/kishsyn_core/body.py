"""Body-state regulation for the reflex loop."""

from __future__ import annotations

from .contracts import BodyState, Outcome


class BodyRegulator:
    """Applies metabolism and consequences to the body surface."""

    def metabolic_drift(self, state: BodyState) -> BodyState:
        return BodyState(
            energy=state.energy - 0.0006875,
            hydration=state.hydration - 0.0007500,
            integrity=state.integrity - 0.0001500,
            fatigue=state.fatigue + 0.0004000,
            curiosity=min(1.0, state.curiosity + 0.0004375),
            uncertainty=min(1.0, state.uncertainty + 0.0002750),
        ).clipped()

    def apply_outcome(self, state: BodyState, outcome: Outcome) -> BodyState:
        values = {
            "energy": state.energy,
            "hydration": state.hydration,
            "integrity": state.integrity,
            "fatigue": state.fatigue,
            "curiosity": state.curiosity,
            "uncertainty": state.uncertainty,
        }
        for key, delta in outcome.delta_body.items():
            if key in values:
                values[key] += delta
        if outcome.kind == "relief":
            values["curiosity"] -= 0.02
            values["uncertainty"] -= 0.08
            values["fatigue"] -= 0.010
        elif outcome.kind == "pain":
            values["uncertainty"] += 0.10
            values["curiosity"] -= 0.03
        elif outcome.kind == "novelty":
            values["curiosity"] -= 0.06
            values["uncertainty"] -= 0.04
        elif outcome.kind in {"blocked", "depleted"}:
            values["uncertainty"] += 0.04
        return BodyState(**values).clipped()
