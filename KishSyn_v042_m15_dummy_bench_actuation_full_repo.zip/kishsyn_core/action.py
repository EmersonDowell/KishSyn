"""Action selection for the reflex-first organism."""

from __future__ import annotations

from dataclasses import dataclass

from .contracts import Action, BodyState, SensoryFrame
from .neural_graph import NeuralGrowthGraph
from .world import MiniEcologyWorld
from .route_memory import RouteMemory
from .comfort import ComfortAttractorMemory
from .body_map import ProtoBodyMap
from .motor_experiment import MotorExperimentIntent
from .play import PlayIntent


@dataclass(frozen=True)
class ActionCandidate:
    action: Action
    score: float
    reason: str

    def as_dict(self) -> dict[str, object]:
        return {
            "action": self.action.kind,
            "target": self.action.target_id,
            "score": round(float(self.score), 4),
            "reason": self.reason,
        }


class ActionSelector:
    """Selects actions from need pressure, curiosity, risk, and learned affordance."""

    def __init__(self, graph: NeuralGrowthGraph) -> None:
        self.graph = graph
        self._last_decision: dict[str, object] = {
            "dominant_need": "unknown",
            "mode": "none",
            "candidate_count": 0,
            "top_candidates": [],
            "selected": None,
            "final": None,
            "stabilized": False,
        }

    def choose(
        self,
        *,
        frame: SensoryFrame,
        body: BodyState,
        world: MiniEcologyWorld,
        route_memory: RouteMemory | None = None,
        comfort_memory: ComfortAttractorMemory | None = None,
        body_map: ProtoBodyMap | None = None,
        learning_focus: object | None = None,
        motor_experiment: MotorExperimentIntent | None = None,
        active_symbol_tokens: tuple[str, ...] = (),
        priority_focus: object | None = None,
        play_intent: PlayIntent | None = None,
    ) -> ActionCandidate:
        need = body.dominant_need()
        candidates: list[ActionCandidate] = []
        for obj in world.foraging_candidates(limit=18):
            features = world.target_features(obj.object_id)
            learned = self.graph.score_target_for_need(features, need)
            distance = max(1, world.distance_to(obj.object_id))
            novelty = 0.16 if not obj.discovered else 0.0
            novelty += self._focus_bias(learning_focus, "novelty_bias") if not obj.discovered else 0.0
            depleted_penalty = -4.00 if obj.quantity <= 0 else 0.0
            visit_count = world.visit_counts.get((obj.x, obj.y), 0)
            underexplored_bonus = min(0.34, 0.045 * max(0, distance - 4)) if visit_count <= 1 and obj.quantity > 0 else 0.0
            distance_penalty = 0.018 * distance
            safety_bias = self._focus_bias(learning_focus, "safety_bias")
            hazard_hint = (-0.42 - safety_bias) if "spike" in obj.shape or "jagged" in obj.shape else 0.0
            terrain_hint = self._terrain_hint(need, world.terrain_at(obj.x, obj.y))
            primitive_need_hint = self._primitive_need_hint(need, obj.color, obj.shape)
            target_place = world.place_key(obj.x, obj.y)
            target_terrain = world.terrain_at(obj.x, obj.y)
            route_focus = self._focus_bias(learning_focus, "route_bias")
            comfort_focus = self._focus_bias(learning_focus, "comfort_bias")
            place_bias = 0.0 if route_memory is None else route_memory.score_place(place_key=target_place, need=need, graph=self.graph) * (1.0 + route_focus)
            comfort_bias = 0.0 if comfort_memory is None else comfort_memory.score_place(place_key=target_place, body=body, terrain=target_terrain) * (1.0 + comfort_focus)
            scene_tokens = frame.tokens() + tuple(f"vision:symbol_token={token}" for token in active_symbol_tokens)
            symbol_cue_bias, symbol_evidence = self.graph.symbol_cue_score(scene_tokens, features)
            active_goal_bonus = 0.34 if active_symbol_tokens and symbol_evidence else 0.0
            priority_symbol_bias = 0.0 if priority_focus is None else float(getattr(priority_focus, "symbol_bias", 0.0))
            symbol_bias = symbol_cue_bias * (0.68 + active_goal_bonus + priority_symbol_bias + 0.18 * max(0.0, self._focus_bias(learning_focus, "novelty_bias")))
            score = learned + primitive_need_hint + terrain_hint + place_bias + comfort_bias + novelty + underexplored_bonus + depleted_penalty + hazard_hint + symbol_bias - distance_penalty
            mode = getattr(learning_focus, "mode", "explore") if learning_focus is not None else "explore"
            inspect_threshold = 0.30 if mode in {"explore", "verify"} else 0.48
            if obj.discovered is False and body.curiosity > inspect_threshold and learned > -0.25:
                kind = "inspect"
                score += body.curiosity * (0.30 + max(0.0, self._focus_bias(learning_focus, "novelty_bias")))
                reason = f"curiosity inspecting {obj.color}/{obj.shape}"
            else:
                kind = "touch"
                reason = f"{need} pressure + learned {learned:.2f} route {place_bias:.2f} comfort {comfort_bias:.2f} symbol {symbol_bias:.2f} forage {underexplored_bonus:.2f}"
                if symbol_evidence:
                    cue_label = "active goal" if active_symbol_tokens else "cue"
                    reason = f"{reason}; {cue_label} {symbol_evidence[0]}"
            if world.distance_to(obj.object_id) > 0:
                kind = "move"
                reason = f"moving toward {obj.color}/{obj.shape}; {reason}"
            motor_bias = 0.0 if body_map is None else body_map.confidence(kind) * 0.035
            score += motor_bias
            if motor_bias:
                reason = f"{reason}; motor confidence {motor_bias:.2f}"
            candidates.append(ActionCandidate(Action(kind, obj.object_id, reason), score, reason))

        if motor_experiment is not None and motor_experiment.active:
            probe_reason = f"{motor_experiment.reason}; proposed score {motor_experiment.score_boost:.2f}"
            candidates.append(
                ActionCandidate(
                    Action(motor_experiment.action_kind, motor_experiment.target_id, probe_reason),
                    motor_experiment.score_boost,
                    probe_reason,
                )
            )

        if play_intent is not None and play_intent.active:
            play_reason = f"{play_intent.reason}; bounded play score {play_intent.score_boost:.2f}"
            candidates.append(
                ActionCandidate(
                    Action(play_intent.action_kind, play_intent.target_id, play_reason),
                    play_intent.score_boost,
                    play_reason,
                )
            )

        if getattr(learning_focus, "mode", "") == "consolidate":
            candidates.append(ActionCandidate(Action("wait", None, "developmental consolidation pause"), 0.18 + self._focus_bias(learning_focus, "replay_bias"), "developmental consolidation pause"))
        if body.fatigue > 0.72:
            rest_target = self._nearest_by_shape(world, "soft")
            if rest_target is not None:
                kind = "move" if world.distance_to(rest_target) > 0 else "touch"
                motor_bias = 0.0 if body_map is None else body_map.confidence(kind) * 0.035
                candidates.append(ActionCandidate(Action(kind, rest_target, "fatigue pressure seeking soft rest"), body.fatigue + 0.20 + motor_bias, "fatigue pressure seeking soft rest"))
            else:
                candidates.append(ActionCandidate(Action("wait", None, "fatigue pressure fallback"), body.fatigue - 0.20, "fatigue pressure fallback"))
        candidates.append(ActionCandidate(Action("wait", None, "low confidence fallback"), -0.35, "low confidence fallback"))
        selected = max(candidates, key=lambda candidate: candidate.score)
        self._remember_decision(
            candidates=candidates,
            selected=selected,
            need=need,
            world=world,
            learning_focus=learning_focus,
            priority_focus=priority_focus,
            active_symbol_tokens=active_symbol_tokens,
            play_intent=play_intent,
        )
        return selected

    def note_final_choice(self, candidate: ActionCandidate, *, world: MiniEcologyWorld) -> None:
        """Record post-continuity action choice for the Observatory.

        Pattern: Memento. The selector keeps a compact immutable view of the last
        scoring event so the GUI can explain behavior without changing the
        organism's action policy.
        """

        selected = self._last_decision.get("selected")
        final = self._candidate_view(candidate, world)
        stabilized = True
        if isinstance(selected, dict):
            stabilized = (selected.get("action"), selected.get("target")) != (final.get("action"), final.get("target"))
        self._last_decision = {**self._last_decision, "final": final, "stabilized": stabilized}

    def decision_snapshot(self) -> dict[str, object]:
        return dict(self._last_decision)

    def _remember_decision(
        self,
        *,
        candidates: list[ActionCandidate],
        selected: ActionCandidate,
        need: str,
        world: MiniEcologyWorld,
        learning_focus: object | None,
        priority_focus: object | None,
        active_symbol_tokens: tuple[str, ...],
        play_intent: PlayIntent | None,
    ) -> None:
        mode = getattr(learning_focus, "mode", "explore") if learning_focus is not None else "explore"
        priority_mode = getattr(priority_focus, "mode", "body_guided") if priority_focus is not None else "body_guided"
        ranked = sorted(candidates, key=lambda candidate: candidate.score, reverse=True)
        self._last_decision = {
            "dominant_need": need,
            "mode": mode,
            "priority_mode": priority_mode,
            "active_symbol_tokens": list(active_symbol_tokens),
            "play_intent": None if play_intent is None else play_intent.as_dict(),
            "candidate_count": len(candidates),
            "selected": self._candidate_view(selected, world),
            "final": self._candidate_view(selected, world),
            "stabilized": False,
            "top_candidates": [self._candidate_view(candidate, world) for candidate in ranked[:6]],
        }

    def _candidate_view(self, candidate: ActionCandidate, world: MiniEcologyWorld) -> dict[str, object]:
        view = candidate.as_dict()
        target_id = candidate.action.target_id
        if target_id in world.objects:
            obj = world.objects[target_id]
            view.update(
                {
                    "target_color": obj.color,
                    "target_shape": obj.shape,
                    "distance": world.distance_to(target_id),
                    "x": obj.x,
                    "y": obj.y,
                    "quantity": obj.quantity,
                    "zone": world.place_key(obj.x, obj.y).split(":", 1)[0],
                    "terrain": world.terrain_at(obj.x, obj.y),
                }
            )
        return view

    def _nearest_by_shape(self, world: MiniEcologyWorld, shape: str) -> str | None:
        matches = [obj for obj in world.living_objects() if obj.shape == shape and obj.quantity > 0]
        if not matches:
            return None
        return min(matches, key=lambda obj: world.distance_to(obj.object_id)).object_id

    def _terrain_hint(self, need: str, terrain: str) -> float:
        if need == "hydration" and terrain == "spring":
            return 0.10
        if need == "fatigue" and terrain == "grove":
            return 0.06
        if need == "curiosity" and terrain in {"grove", "spring"}:
            return 0.05
        if terrain == "rough":
            return -0.08
        return 0.0

    def _primitive_need_hint(self, need: str, color: str, shape: str) -> float:
        """Tiny congenital reflex prior. Consequence learning can override this."""
        if need == "energy" and shape == "round":
            return 0.20
        if need == "hydration" and shape == "tall":
            return 0.22
        if need == "fatigue" and shape == "soft":
            return 0.24
        if need == "integrity" and shape in {"soft", "round"}:
            return 0.08
        if need in {"curiosity", "uncertainty"} and shape in {"glow", "glyph"}:
            return 0.22
        if need in {"curiosity", "uncertainty"} and color in {"gold", "green", "cyan", "white"}:
            return 0.14
        return 0.0

    def _focus_bias(self, learning_focus: object | None, name: str) -> float:
        if learning_focus is None:
            return 0.0
        return float(getattr(learning_focus, name, 0.0))
