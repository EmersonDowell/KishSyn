"""KishSyn Core Observatory server.

The observatory owns one persistent organism session. By default the session
runs autonomously on a background tick thread, loads prior brain state when
available, and may run a bounded autonomous tutor; the webpage is only a witness.
"""

from __future__ import annotations

import argparse
import json
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from kishsyn_core.benchmark import BenchmarkPlaygroundSuite
from kishsyn_core.evidence import IntelligenceEvidenceEvaluator
from kishsyn_core.loop import OrganismLoop
from kishsyn_core.graph_viewport import GraphViewportBudget, GraphViewportProjector
from kishsyn_core.atlas_inspector import NeuralAtlasInspector
from kishsyn_core.state import DEFAULT_STATE_PATH, load_loop, save_loop

STATIC_DIR = Path(__file__).resolve().parent / "static"
DEFAULT_BENCHMARK_REPORT_PATH = Path("stores/_demo/benchmark_suite_report.json")
DEFAULT_EVIDENCE_REPORT_PATH = Path("stores/_demo/intelligence_evidence_report.json")
DEFAULT_REPORT_HISTORY_PATH = Path("stores/_demo/report_history.jsonl")


@dataclass(frozen=True)
class ReportHistoryRecord:
    """A compact historical report event for regression/progress tracking.

    Pattern: Memento. The observatory keeps append-only score snapshots so the
    project can compare the living line across patches without depending on a
    single latest green run.
    """

    kind: str
    score: float
    verdict: str
    status_counts: dict[str, int]
    observed: dict[str, float]
    params: dict[str, object]
    created_at: str

    def as_dict(self) -> dict[str, object]:
        return {
            "kind": self.kind,
            "score": round(float(self.score), 4),
            "verdict": self.verdict,
            "status_counts": dict(self.status_counts),
            "observed": {key: round(float(value), 4) for key, value in self.observed.items()},
            "params": dict(self.params),
            "created_at": self.created_at,
        }


class ReportHistoryStore:
    """Append-only score history for the Observatory report panel.

    Pattern: Repository + Memento. Reports remain normal JSON files, while the
    history store records small immutable run summaries for trend inspection.
    """

    def __init__(self, path: Path = DEFAULT_REPORT_HISTORY_PATH, *, max_records: int = 64) -> None:
        self.path = Path(path)
        self.max_records = max(4, int(max_records))

    def append(self, *, kind: str, report: dict[str, object], params: dict[str, object]) -> dict[str, object]:
        record = self._record_from_report(kind=kind, report=report, params=params).as_dict()
        records = [*self.records(), record][-self.max_records :]
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text("".join(json.dumps(item, sort_keys=True) + "\n" for item in records), encoding="utf-8")
        return self.snapshot()

    def records(self) -> list[dict[str, object]]:
        try:
            if not self.path.exists():
                return []
            out: list[dict[str, object]] = []
            for line in self.path.read_text(encoding="utf-8").splitlines():
                if not line.strip():
                    continue
                item = json.loads(line)
                if isinstance(item, dict):
                    out.append(item)
            return out[-self.max_records :]
        except (OSError, json.JSONDecodeError):
            return []

    def snapshot(self) -> dict[str, object]:
        records = self.records()
        return {"path": str(self.path), "summary": self._summary(records), "records": records[-16:]}

    def _record_from_report(self, *, kind: str, report: dict[str, object], params: dict[str, object]) -> ReportHistoryRecord:
        items_key = "tasks" if kind == "benchmark" else "criteria"
        items = report.get(items_key, [])
        status_counts = self._status_counts(items if isinstance(items, list) else [])
        observed = self._observed(items if isinstance(items, list) else [])
        return ReportHistoryRecord(
            kind=kind,
            score=float(report.get("summary_score", 0.0) or 0.0),
            verdict=str(report.get("verdict", "unknown")),
            status_counts=status_counts,
            observed=observed,
            params=params,
            created_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
        )

    @staticmethod
    def _status_counts(items: list[object]) -> dict[str, int]:
        counts = {"pass": 0, "watch": 0, "fail": 0}
        for item in items:
            if isinstance(item, dict):
                status = str(item.get("status", "")).lower()
                if status in counts:
                    counts[status] += 1
        return counts

    @staticmethod
    def _observed(items: list[object]) -> dict[str, float]:
        observed: dict[str, float] = {}
        for item in items:
            if not isinstance(item, dict):
                continue
            name = str(item.get("name", "")).strip()
            if not name:
                continue
            observed[name] = float(item.get("observed", 0.0) or 0.0)
        return observed

    @staticmethod
    def _summary(records: list[dict[str, object]]) -> dict[str, object]:
        if not records:
            return {"count": 0, "benchmark_runs": 0, "evidence_runs": 0, "latest_delta": 0.0}
        latest = records[-1]
        same_kind_prior = [item for item in records[:-1] if item.get("kind") == latest.get("kind")]
        prior_score = float(same_kind_prior[-1].get("score", 0.0)) if same_kind_prior else float(latest.get("score", 0.0))
        latest_score = float(latest.get("score", 0.0) or 0.0)
        benchmark_scores = [float(item.get("score", 0.0) or 0.0) for item in records if item.get("kind") == "benchmark"]
        evidence_scores = [float(item.get("score", 0.0) or 0.0) for item in records if item.get("kind") == "evidence"]
        status_counts = latest.get("status_counts", {}) if isinstance(latest.get("status_counts"), dict) else {}
        return {
            "count": len(records),
            "benchmark_runs": len(benchmark_scores),
            "evidence_runs": len(evidence_scores),
            "latest_kind": latest.get("kind", "unknown"),
            "latest_score": round(latest_score, 4),
            "latest_delta": round(latest_score - prior_score, 4),
            "latest_verdict": latest.get("verdict", "unknown"),
            "latest_fail_count": int(status_counts.get("fail", 0) or 0),
            "best_benchmark_score": round(max(benchmark_scores), 4) if benchmark_scores else 0.0,
            "best_evidence_score": round(max(evidence_scores), 4) if evidence_scores else 0.0,
        }



class ObservatorySession:
    """Thread-safe persistent runtime for the observatory."""

    def __init__(
        self,
        *,
        seed: int = 337,
        hz: float = 4.0,
        autostart: bool = False,
        state_path: Path = DEFAULT_STATE_PATH,
        load_state: bool = False,
        autosave_every: int = 120,
        report_history_path: Path = DEFAULT_REPORT_HISTORY_PATH,
    ) -> None:
        self.seed = seed
        self.state_path = Path(state_path)
        self.autosave_every = max(0, int(autosave_every))
        self.last_state_event: dict[str, object] = {"path": str(self.state_path), "loaded": False, "saved": False, "tick": 0}
        if load_state and self.state_path.exists():
            self.loop, loaded = load_loop(self.state_path)
            self.seed = int(loaded.get("seed", seed) or seed)
            self.last_state_event = loaded
        else:
            self.loop = OrganismLoop(seed=seed)
        self.hz = max(0.25, min(30.0, float(hz)))
        self._lock = threading.RLock()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._last_autosave_tick = self.loop.tick
        self.report_history = ReportHistoryStore(report_history_path)
        self.graph_viewport = GraphViewportProjector()
        self.last_report_history: dict[str, object] = self.report_history.snapshot()
        self.last_benchmark_report: dict[str, object] | None = self._load_report(DEFAULT_BENCHMARK_REPORT_PATH)
        self.last_evidence_report: dict[str, object] | None = self._load_report(DEFAULT_EVIDENCE_REPORT_PATH)
        self.last_report_event: dict[str, object] = {"benchmark_loaded": self.last_benchmark_report is not None, "evidence_loaded": self.last_evidence_report is not None}
        if autostart:
            self.start(hz=self.hz)

    def reset(self, *, seed: int | None = None, autostart: bool | None = None, graph_view: str = "full") -> dict[str, object]:
        was_running = self.running if autostart is None else autostart
        self.stop()
        with self._lock:
            if seed is not None:
                self.seed = seed
            self.loop = OrganismLoop(seed=self.seed)
            self._last_autosave_tick = self.loop.tick
        if was_running:
            self.start(hz=self.hz)
        return self.snapshot(graph_view=graph_view)

    def tick(self, *, steps: int = 1, graph_view: str = "full") -> dict[str, object]:
        with self._lock:
            for _ in range(max(1, min(steps, 256))):
                self.loop.step()
                self._autosave_if_due_locked()
            return self.snapshot_locked(graph_view=graph_view)

    def receive_text(self, *, text: str, source: str = "user", steps: int = 2, graph_view: str = "full") -> dict[str, object]:
        with self._lock:
            self.loop.sensory_hub.receive_console(tick=self.loop.tick, text=text, source=source)
            self.loop.text_crib.receive_text(tick=self.loop.tick, text=text, source=source)
            for _ in range(max(1, min(steps, 24))):
                self.loop.step()
                self._autosave_if_due_locked()
            return self.snapshot_locked(graph_view=graph_view)
    def receive_sensory(self, *, modality: str, payload: str, source: str = "user", steps: int = 2, graph_view: str = "full") -> dict[str, object]:
        with self._lock:
            if modality == "math":
                self.loop.sensory_hub.receive_math(tick=self.loop.tick, expression=payload, source=source)
            elif modality == "screen":
                self.loop.sensory_hub.receive_screen_probe(tick=self.loop.tick, description=payload, source=source)
            elif modality == "image":
                self.loop.sensory_hub.receive_image_probe(tick=self.loop.tick, description=payload, source=source)
            elif modality == "audio":
                self.loop.sensory_hub.receive_audio_probe(tick=self.loop.tick, description=payload, source=source)
            elif modality == "console":
                self.loop.sensory_hub.receive_console(tick=self.loop.tick, text=payload, source=source)
                self.loop.text_crib.receive_text(tick=self.loop.tick, text=payload, source=source)
            else:
                self.loop.sensory_hub.receive(tick=self.loop.tick, source=source, modality="sensor", payload=payload)
            for _ in range(max(1, min(steps, 24))):
                self.loop.step()
                self._autosave_if_due_locked()
            return self.snapshot_locked(graph_view=graph_view)


    def receive_tutor(self, *, text: str, source: str = "user", mode: str = "local", steps: int = 4, graph_view: str = "full") -> dict[str, object]:
        with self._lock:
            self.loop.tutor.receive(
                tick=self.loop.tick,
                message=text,
                text_crib=self.loop.text_crib,
                graph=self.loop.graph,
                symbol_goal=self.loop.symbol_goal,
                source=source,
                mode=mode,
            )
            for _ in range(max(1, min(steps, 48))):
                self.loop.step()
                self._autosave_if_due_locked()
            return self.snapshot_locked()

    def atlas_index(self, *, limit: int = 120) -> dict[str, object]:
        with self._lock:
            return NeuralAtlasInspector().atlas_index(graph=self.loop.graph, tick=self.loop.tick, limit=limit)

    def inspect_atlas_node(self, *, node_id: str) -> dict[str, object]:
        with self._lock:
            return NeuralAtlasInspector().inspect_node(
                graph=self.loop.graph,
                node_id=node_id,
                tick=self.loop.tick,
                last_trace=self.loop.last_trace,
            ).as_dict()

    def inspect_atlas_synapse(self, *, source: str, target: str) -> dict[str, object]:
        with self._lock:
            return NeuralAtlasInspector().inspect_synapse(
                graph=self.loop.graph,
                source=source,
                target=target,
                tick=self.loop.tick,
                last_trace=self.loop.last_trace,
            ).as_dict()


    def reports_snapshot(self) -> dict[str, object]:
        with self._lock:
            return {
                "benchmark": self.last_benchmark_report,
                "evidence": self.last_evidence_report,
                "event": self.last_report_event,
                "history": self.last_report_history,
            }

    def run_benchmark_report(
        self,
        *,
        seeds: tuple[int, ...] = (337, 171, 23),
        steps: int = 240,
        out: Path = DEFAULT_BENCHMARK_REPORT_PATH,
    ) -> dict[str, object]:
        report = BenchmarkPlaygroundSuite().evaluate(seeds=seeds, steps=steps).as_dict()
        self._write_report(out, report)
        history = self.report_history.append(kind="benchmark", report=report, params={"steps": steps, "seeds": list(seeds), "path": str(out)})
        with self._lock:
            self.last_benchmark_report = report
            self.last_report_history = history
            self.last_report_event = {
                "kind": "benchmark",
                "path": str(out),
                "steps": steps,
                "seeds": list(seeds),
                "score": report.get("summary_score"),
                "verdict": report.get("verdict"),
            }
            return self.reports_snapshot()

    def run_evidence_report(
        self,
        *,
        seed: int = 337,
        steps: int = 240,
        ablation_steps: int = 48,
        benchmark_seeds: tuple[int, ...] = (337, 171, 23),
        out: Path = DEFAULT_EVIDENCE_REPORT_PATH,
    ) -> dict[str, object]:
        report = IntelligenceEvidenceEvaluator().evaluate(
            seed=seed,
            steps=steps,
            ablation_steps=ablation_steps,
            benchmark_seeds=benchmark_seeds,
        ).as_dict()
        self._write_report(out, report)
        history = self.report_history.append(kind="evidence", report=report, params={"steps": steps, "seed": seed, "ablation_steps": ablation_steps, "benchmark_seeds": list(benchmark_seeds), "path": str(out)})
        with self._lock:
            self.last_evidence_report = report
            self.last_report_history = history
            if isinstance(report.get("benchmarks"), dict):
                self.last_benchmark_report = report["benchmarks"]  # type: ignore[index]
            self.last_report_event = {
                "kind": "evidence",
                "path": str(out),
                "steps": steps,
                "seed": seed,
                "ablation_steps": ablation_steps,
                "benchmark_seeds": list(benchmark_seeds),
                "score": report.get("summary_score"),
                "verdict": report.get("verdict"),
            }
            return self.reports_snapshot()

    def reload_reports(self) -> dict[str, object]:
        with self._lock:
            self.last_benchmark_report = self._load_report(DEFAULT_BENCHMARK_REPORT_PATH)
            self.last_evidence_report = self._load_report(DEFAULT_EVIDENCE_REPORT_PATH)
            self.last_report_history = self.report_history.snapshot()
            self.last_report_event = {
                "kind": "load",
                "benchmark_loaded": self.last_benchmark_report is not None,
                "evidence_loaded": self.last_evidence_report is not None,
            }
            return self.reports_snapshot()

    @staticmethod
    def _write_report(path: Path, payload: dict[str, object]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")

    @staticmethod
    def _load_report(path: Path) -> dict[str, object] | None:
        try:
            if not path.exists():
                return None
            data = json.loads(path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else None
        except (OSError, json.JSONDecodeError):
            return None

    def configure_autopilot(self, *, enabled: bool | None = None, interval: int | None = None, graph_view: str = "full") -> dict[str, object]:
        with self._lock:
            if enabled is not None:
                self.loop.autopilot.enabled = enabled
            if interval is not None:
                self.loop.autopilot.interval = max(12, min(600, int(interval)))
            return self.snapshot_locked(graph_view=graph_view)

    def save_state(self, *, note: str = "observatory save", graph_view: str = "full") -> dict[str, object]:
        with self._lock:
            self.last_state_event = save_loop(self.loop, self.state_path, seed=self.seed, note=note)
            self._last_autosave_tick = self.loop.tick
            return self.snapshot_locked(graph_view=graph_view)

    def load_state(self, *, autostart: bool | None = None, graph_view: str = "full") -> dict[str, object]:
        was_running = self.running if autostart is None else autostart
        self.stop()
        with self._lock:
            if self.state_path.exists():
                self.loop, self.last_state_event = load_loop(self.state_path)
                self._last_autosave_tick = self.loop.tick
            else:
                self.last_state_event = {"path": str(self.state_path), "loaded": False, "error": "state file missing", "tick": self.loop.tick}
        if was_running:
            self.start(hz=self.hz)
        return self.snapshot(graph_view=graph_view)

    def _autosave_if_due_locked(self) -> None:
        if self.autosave_every <= 0:
            return
        if self.loop.tick <= 0:
            return
        if self.loop.tick - self._last_autosave_tick < self.autosave_every:
            return
        self.last_state_event = save_loop(self.loop, self.state_path, seed=self.seed, note="autosave")
        self._last_autosave_tick = self.loop.tick

    def start(self, *, hz: float | None = None) -> dict[str, object]:
        if hz is not None:
            self.hz = max(0.25, min(30.0, float(hz)))
        if self.running:
            return self.status()
        self._stop.clear()
        self._thread = threading.Thread(target=self._run_loop, name="kishsyn-observatory-loop", daemon=True)
        self._thread.start()
        return self.status()

    def stop(self) -> dict[str, object]:
        self._stop.set()
        thread = self._thread
        if thread is not None and thread.is_alive():
            thread.join(timeout=1.0)
        self._thread = None
        return self.status()

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive() and not self._stop.is_set()

    def status(self) -> dict[str, object]:
        with self._lock:
            return {"running": self.running, "hz": self.hz, "tick": self.loop.tick, "seed": self.seed}

    def snapshot(self, *, graph_view: str = "full", node_limit: int = 420, edge_limit: int = 760) -> dict[str, object]:
        with self._lock:
            return self.snapshot_locked(graph_view=graph_view, node_limit=node_limit, edge_limit=edge_limit)

    def snapshot_locked(self, *, graph_view: str = "full", node_limit: int = 420, edge_limit: int = 760) -> dict[str, object]:
        payload = self.loop.snapshot().__dict__
        if graph_view != "full":
            payload["graph"] = self.graph_viewport.project(
                graph=self.loop.graph,
                tick=self.loop.tick,
                budget=GraphViewportBudget(node_limit=node_limit, edge_limit=edge_limit),
            )
        payload["run"] = {"running": self.running, "hz": self.hz, "seed": self.seed}
        payload["persistence"] = {"state_path": str(self.state_path), "autosave_every": self.autosave_every, "last_event": self.last_state_event}
        payload["reports"] = self.reports_snapshot()
        return payload

    def _run_loop(self) -> None:
        next_tick = time.monotonic()
        while not self._stop.is_set():
            with self._lock:
                self.loop.step()
                self._autosave_if_due_locked()
            interval = 1.0 / self.hz
            next_tick += interval
            delay = max(0.0, next_tick - time.monotonic())
            if self._stop.wait(delay):
                break
            if delay == 0.0:
                next_tick = time.monotonic()


SESSION = ObservatorySession()


class Handler(BaseHTTPRequestHandler):
    server_version = "KishSynCoreObservatory/0.32"

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlparse(self.path)
        if parsed.path == "/":
            self._send_file(STATIC_DIR / "index.html", "text/html; charset=utf-8")
            return
        if parsed.path == "/api/snapshot":
            query = parse_qs(parsed.query)
            graph_view = query.get("graph", ["viewport"])[0].lower()
            node_limit = int(query.get("node_limit", ["420"])[0])
            edge_limit = int(query.get("edge_limit", ["760"])[0])
            self._send_json(SESSION.snapshot(graph_view=graph_view, node_limit=node_limit, edge_limit=edge_limit))
            return
        if parsed.path == "/api/tick":
            query = parse_qs(parsed.query)
            steps = int(query.get("steps", ["1"])[0])
            self._send_json(SESSION.tick(steps=steps, graph_view="viewport"))
            return
        if parsed.path == "/api/reset":
            query = parse_qs(parsed.query)
            seed = int(query.get("seed", [SESSION.seed])[0])
            autostart = query.get("autostart", ["true"])[0].lower() not in {"0", "false", "no"}
            self._send_json(SESSION.reset(seed=seed, autostart=autostart, graph_view="viewport"))
            return
        if parsed.path == "/api/run/start":
            query = parse_qs(parsed.query)
            hz = float(query.get("hz", [str(SESSION.hz)])[0])
            self._send_json(SESSION.start(hz=hz))
            return
        if parsed.path == "/api/run/stop":
            self._send_json(SESSION.stop())
            return
        if parsed.path == "/api/run/status":
            self._send_json(SESSION.status())
            return
        if parsed.path == "/api/text/input":
            query = parse_qs(parsed.query)
            message = query.get("message", [""])[0]
            source = query.get("source", ["user"])[0]
            steps = int(query.get("steps", ["2"])[0])
            self._send_json(SESSION.receive_text(text=message, source=source, steps=steps, graph_view="viewport"))
            return
        if parsed.path == "/api/text/history":
            self._send_json({"text_crib": SESSION.snapshot().get("text_crib", {})})
            return
        if parsed.path == "/api/sensory/input":
            query = parse_qs(parsed.query)
            modality = query.get("modality", ["console"])[0].lower()
            payload = query.get("payload", query.get("message", [""]))[0]
            source = query.get("source", ["user"])[0]
            steps = int(query.get("steps", ["2"])[0])
            self._send_json(SESSION.receive_sensory(modality=modality, payload=payload, source=source, steps=steps, graph_view="viewport"))
            return
        if parsed.path == "/api/tutor/input":
            query = parse_qs(parsed.query)
            message = query.get("message", [""])[0]
            source = query.get("source", ["user"])[0]
            mode = query.get("mode", ["local"])[0]
            steps = int(query.get("steps", ["4"])[0])
            self._send_json(SESSION.receive_tutor(text=message, source=source, mode=mode, steps=steps, graph_view="viewport"))
            return
        if parsed.path == "/api/tutor/history":
            self._send_json({"tutor": SESSION.snapshot().get("tutor", {})})
            return
        if parsed.path == "/api/autopilot/config":
            query = parse_qs(parsed.query)
            enabled_value = query.get("enabled", [""])[0].lower()
            enabled = None if enabled_value == "" else enabled_value not in {"0", "false", "no", "off"}
            interval = int(query["interval"][0]) if "interval" in query else None
            self._send_json(SESSION.configure_autopilot(enabled=enabled, interval=interval, graph_view="viewport"))
            return
        if parsed.path == "/api/state/save":
            query = parse_qs(parsed.query)
            note = query.get("note", ["manual observatory save"])[0]
            self._send_json(SESSION.save_state(note=note, graph_view="viewport"))
            return
        if parsed.path == "/api/state/load":
            query = parse_qs(parsed.query)
            autostart = query.get("autostart", ["true"])[0].lower() not in {"0", "false", "no"}
            self._send_json(SESSION.load_state(autostart=autostart, graph_view="viewport"))
            return
        if parsed.path == "/api/reports/latest":
            query = parse_qs(parsed.query)
            reload_files = query.get("reload", ["false"])[0].lower() in {"1", "true", "yes"}
            self._send_json(SESSION.reload_reports() if reload_files else SESSION.reports_snapshot())
            return
        if parsed.path == "/api/reports/history":
            query = parse_qs(parsed.query)
            reload_files = query.get("reload", ["false"])[0].lower() in {"1", "true", "yes"}
            if reload_files:
                SESSION.reload_reports()
            self._send_json({"history": SESSION.reports_snapshot().get("history", {})})
            return
        if parsed.path == "/api/reports/benchmark/run":
            query = parse_qs(parsed.query)
            steps = int(query.get("steps", ["240"])[0])
            seeds = _parse_seeds(query.get("seeds", ["337,171,23"])[0])
            self._send_json(SESSION.run_benchmark_report(seeds=seeds, steps=steps))
            return
        if parsed.path == "/api/reports/evidence/run":
            query = parse_qs(parsed.query)
            steps = int(query.get("steps", ["240"])[0])
            seed = int(query.get("seed", ["337"])[0])
            ablation_steps = int(query.get("ablation_steps", ["48"])[0])
            benchmark_seeds = _parse_seeds(query.get("benchmark_seeds", ["337,171,23"])[0])
            self._send_json(SESSION.run_evidence_report(seed=seed, steps=steps, ablation_steps=ablation_steps, benchmark_seeds=benchmark_seeds))
            return
        if parsed.path == "/api/atlas/index":
            query = parse_qs(parsed.query)
            limit = int(query.get("limit", ["120"])[0])
            self._send_json(SESSION.atlas_index(limit=limit))
            return
        if parsed.path == "/api/atlas/node":
            query = parse_qs(parsed.query)
            node_id = query.get("id", [""])[0]
            self._send_json(SESSION.inspect_atlas_node(node_id=node_id))
            return
        if parsed.path == "/api/atlas/synapse":
            query = parse_qs(parsed.query)
            source = query.get("source", [""])[0]
            target = query.get("target", [""])[0]
            self._send_json(SESSION.inspect_atlas_synapse(source=source, target=target))
            return
        if parsed.path == "/api/doctrine":
            self._send_json(
                {
                    "name": "KishSyn Core v031 M6",
                    "rule": "One recursive organism loop inside a larger living ecology: sensory -> body -> prediction -> action -> efference -> consequence -> self-boundary -> plasticity -> memory -> workspace.",
                    "consciousness_claimed": False,
                    "scope_rule": "No feature enters the living core unless it senses, predicts, biases action, and changes plastic pathways.",
                    "runtime_rule": "The observatory autostarts, loads prior state by default, exposes bounded autonomous tutoring, universal sensory adapter input, graph-grounded expression, neural atlas mirroring, and benchmark/evidence history. KishSyn remains the learner and no chatbot mask is used.",
                }
            )
            return
        self.send_error(404, "not found")

    def log_message(self, format: str, *args: object) -> None:  # noqa: A002
        return

    def _send_json(self, payload: dict[str, object]) -> None:
        data = json.dumps(payload, indent=2).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _send_file(self, path: Path, content_type: str) -> None:
        data = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)


def _parse_seeds(value: str) -> tuple[int, ...]:
    seeds = tuple(int(piece.strip()) for piece in value.split(",") if piece.strip())
    return seeds or (337,)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the KishSyn Core Observatory.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8797)
    parser.add_argument("--seed", type=int, default=337)
    parser.add_argument("--hz", type=float, default=4.0, help="Autonomous organism ticks per second.")
    parser.add_argument("--paused", action="store_true", help="Start server without the autonomous organism loop running.")
    parser.add_argument("--state", type=Path, default=DEFAULT_STATE_PATH, help="Brain-state JSON path used by save/load/autosave.")
    parser.add_argument("--load-state", action="store_true", help="Compatibility flag: load the saved brain state before starting. Loading is now the default when the state file exists.")
    parser.add_argument("--fresh-state", action="store_true", help="Start from a fresh organism instead of loading an existing brain-state file.")
    parser.add_argument("--autosave-every", type=int, default=120, help="Autosave every N ticks. Use 0 to disable.")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    global SESSION
    should_load = (args.load_state or args.state.exists()) and not args.fresh_state
    SESSION = ObservatorySession(seed=args.seed, hz=args.hz, autostart=not args.paused, state_path=args.state, load_state=should_load, autosave_every=args.autosave_every)
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    mode = "paused" if args.paused else f"running at {SESSION.hz:.2f} Hz"
    if should_load and SESSION.last_state_event.get("loaded"):
        mode += f", loaded state t{SESSION.last_state_event.get('tick', 0)}"
    print(f"[KishSyn Core] observatory at http://{args.host}:{args.port}/ ({mode})")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[KishSyn Core] observatory stopped")
    finally:
        SESSION.save_state(note="shutdown save")
        SESSION.stop()
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
