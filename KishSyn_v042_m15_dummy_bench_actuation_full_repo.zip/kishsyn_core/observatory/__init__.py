"""Live witness GUI for KishSyn Core."""
