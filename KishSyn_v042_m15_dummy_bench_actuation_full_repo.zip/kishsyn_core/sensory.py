"""Universal sensory adapter surface for KishSyn Core.

M4 begins here: screen, image, audio, math, console, hardware, and future
surfaces are not privileged channels. They become replayable sensory packets,
then normalized sensory features, then pass through the same FocusGate,
MomentFrame, binding, anatomy, and graph contracts as the toy ecology.
"""

from __future__ import annotations

import re
from collections import deque
from dataclasses import asdict, dataclass
from typing import Any, Literal

from .contracts import SensoryFeature, SensoryFrame

AdapterModality = Literal["console", "screen", "image", "audio", "math", "sensor"]
_WORD_RE = re.compile(r"[a-zA-Z0-9_]+")
_MATH_RE = re.compile(r"^\s*(-?\d+(?:\.\d+)?)\s*([+\-*/xX])\s*(-?\d+(?:\.\d+)?)\s*=\s*(-?\d+(?:\.\d+)?)\s*$")


@dataclass(frozen=True)
class SensoryPacket:
    """One external sensory packet before focus selection.

    Pattern: Adapter DTO. Every future surface must normalize into this shape
    before it can affect KishSyn. The packet is not a command and not a mind;
    it is a replayable sensory event.
    """

    tick: int
    source: str
    modality: AdapterModality
    payload: str
    intensity: float = 1.0
    ttl: int = 18
    metadata: dict[str, str] | None = None

    @property
    def expires_tick(self) -> int:
        return self.tick + max(1, int(self.ttl))

    def as_dict(self) -> dict[str, object]:
        return {
            "tick": self.tick,
            "source": self.source,
            "modality": self.modality,
            "payload": self.payload,
            "intensity": round(float(self.intensity), 4),
            "ttl": self.ttl,
            "expires_tick": self.expires_tick,
            "metadata": dict(self.metadata or {}),
        }


@dataclass(frozen=True)
class AdapterReport:
    """A visible normalized sensory-adapter event."""

    tick: int
    packet_count: int
    feature_count: int
    modalities: tuple[str, ...]
    features: tuple[str, ...]

    def as_dict(self) -> dict[str, object]:
        return {
            "tick": self.tick,
            "packet_count": self.packet_count,
            "feature_count": self.feature_count,
            "modalities": list(self.modalities),
            "features": list(self.features[:24]),
        }


class SensoryAdapterHub:
    """Normalizes arbitrary external surfaces into sensory features.

    Pattern: Facade + Adapter + Memento. External inputs are queued as packets,
    translated into typed sensory features, and retained for inspection. No
    adapter may bypass the organism loop.
    """

    def __init__(self, *, history_limit: int = 96) -> None:
        self.packets: deque[SensoryPacket] = deque(maxlen=max(16, int(history_limit)))
        self.reports: deque[AdapterReport] = deque(maxlen=max(16, int(history_limit)))
        self.packet_count = 0
        self.feature_count = 0
        self.modality_counts: dict[str, int] = {}

    def receive_console(self, *, tick: int, text: str, source: str = "user", ttl: int = 18, intensity: float = 0.82) -> SensoryPacket:
        return self.receive(tick=tick, source=source, modality="console", payload=text, ttl=ttl, intensity=intensity)

    def receive_math(self, *, tick: int, expression: str, source: str = "math_surface", ttl: int = 22, intensity: float = 0.86) -> SensoryPacket:
        return self.receive(tick=tick, source=source, modality="math", payload=expression, ttl=ttl, intensity=intensity)

    def receive_screen_probe(self, *, tick: int, description: str, source: str = "screen", ttl: int = 12, intensity: float = 0.72) -> SensoryPacket:
        return self.receive(tick=tick, source=source, modality="screen", payload=description, ttl=ttl, intensity=intensity)

    def receive_image_probe(self, *, tick: int, description: str, source: str = "image", ttl: int = 14, intensity: float = 0.74) -> SensoryPacket:
        return self.receive(tick=tick, source=source, modality="image", payload=description, ttl=ttl, intensity=intensity)

    def receive_audio_probe(self, *, tick: int, description: str, source: str = "audio", ttl: int = 12, intensity: float = 0.70) -> SensoryPacket:
        return self.receive(tick=tick, source=source, modality="audio", payload=description, ttl=ttl, intensity=intensity)

    def receive(
        self,
        *,
        tick: int,
        source: str,
        modality: AdapterModality,
        payload: str,
        ttl: int = 18,
        intensity: float = 1.0,
        metadata: dict[str, str] | None = None,
    ) -> SensoryPacket:
        packet = SensoryPacket(
            tick=int(tick),
            source=(source or "external")[:40],
            modality=modality,
            payload=str(payload)[:700],
            intensity=max(0.0, min(1.0, float(intensity))),
            ttl=max(1, int(ttl)),
            metadata=dict(metadata or {}),
        )
        self.packets.append(packet)
        self.packet_count += 1
        self.modality_counts[modality] = self.modality_counts.get(modality, 0) + 1
        return packet

    def inject_features(self, *, tick: int, frame: SensoryFrame) -> SensoryFrame:
        active = [packet for packet in self.packets if tick <= packet.expires_tick]
        if not active:
            report = AdapterReport(tick=tick, packet_count=0, feature_count=0, modalities=(), features=())
            self.reports.append(report)
            return frame
        additions: list[SensoryFeature] = []
        modalities: list[str] = []
        for packet in active[-6:]:
            modalities.append(packet.modality)
            additions.extend(self._packet_features(packet, tick=tick))
        features = tuple(frame.features) + tuple(additions)
        raw = dict(frame.raw)
        report = AdapterReport(
            tick=tick,
            packet_count=len(active),
            feature_count=len(additions),
            modalities=tuple(sorted(set(modalities))),
            features=tuple(feature.token for feature in additions),
        )
        self.feature_count += len(additions)
        self.reports.append(report)
        raw["sensory_adapter"] = report.as_dict()
        return SensoryFrame(tick=frame.tick, features=features, raw=raw)

    def snapshot(self) -> dict[str, object]:
        reports = list(self.reports)
        return {
            "packet_count": self.packet_count,
            "feature_count": self.feature_count,
            "modality_counts": dict(sorted(self.modality_counts.items())),
            "active_packet_count": len([packet for packet in self.packets if reports and reports[-1].tick <= packet.expires_tick]),
            "last": reports[-1].as_dict() if reports else None,
            "recent_packets": [packet.as_dict() for packet in list(self.packets)[-8:]],
            "recent_reports": [report.as_dict() for report in reports[-8:]],
        }

    def state(self) -> dict[str, object]:
        return {
            "packet_count": self.packet_count,
            "feature_count": self.feature_count,
            "modality_counts": dict(self.modality_counts),
            "packets": [packet.as_dict() for packet in self.packets],
            "reports": [report.as_dict() for report in self.reports],
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "SensoryAdapterHub":
        hub = cls()
        hub.packet_count = int(data.get("packet_count", 0))
        hub.feature_count = int(data.get("feature_count", 0))
        hub.modality_counts = {str(k): int(v) for k, v in dict(data.get("modality_counts", {})).items()}
        for item in data.get("packets", [])[-hub.packets.maxlen :]:
            if isinstance(item, dict):
                hub.packets.append(_packet_from_dict(item))
        for item in data.get("reports", [])[-hub.reports.maxlen :]:
            if isinstance(item, dict):
                hub.reports.append(_report_from_dict(item))
        return hub

    def _packet_features(self, packet: SensoryPacket, *, tick: int) -> list[SensoryFeature]:
        intensity = max(0.05, min(1.0, packet.intensity))
        features: list[SensoryFeature] = [
            SensoryFeature("surface", packet.modality, packet.modality, intensity * 0.70),
            SensoryFeature("source", packet.source, packet.modality, intensity * 0.34),
            SensoryFeature("age", _age_band(tick - packet.tick), packet.modality, intensity * 0.28),
        ]
        words = tuple(_WORD_RE.findall(packet.payload.lower()))[:12]
        if packet.modality == "console":
            features.append(SensoryFeature("surface", "console", "text", intensity * 0.82))
            if "?" in packet.payload:
                features.append(SensoryFeature("punctuation", "question", "text", intensity * 0.52))
            for word in words[:8]:
                features.append(SensoryFeature("word", word, "text", intensity * 0.68))
                if len(word) == 1:
                    features.append(SensoryFeature("glyph", word.upper(), "text", intensity * 0.50))
                if word.isdigit():
                    features.append(SensoryFeature("number", word, "text", intensity * 0.55))
        elif packet.modality == "math":
            features.extend(_math_features(packet.payload, intensity=intensity))
        else:
            # Screen/image/audio probes are intentionally descriptive in M4.
            # Real capture/OCR/vision models can later feed the same packet contract.
            features.append(SensoryFeature("descriptor_count", _count_band(len(words)), packet.modality, intensity * 0.40))
            for word in words[:8]:
                features.append(SensoryFeature("descriptor", word, packet.modality, intensity * 0.58))
        for key, value in (packet.metadata or {}).items():
            features.append(SensoryFeature(str(key)[:32], str(value)[:64], packet.modality, intensity * 0.42))
        return features


def _math_features(expression: str, *, intensity: float) -> list[SensoryFeature]:
    features: list[SensoryFeature] = [SensoryFeature("surface", "arithmetic", "math", intensity * 0.82)]
    match = _MATH_RE.match(expression)
    if not match:
        for word in _WORD_RE.findall(expression.lower())[:8]:
            features.append(SensoryFeature("token", word, "math", intensity * 0.52))
        return features
    left, op, right, result = match.groups()
    op_name = {"+": "add", "-": "subtract", "*": "multiply", "x": "multiply", "X": "multiply", "/": "divide"}[op]
    features.extend(
        [
            SensoryFeature("operator", op_name, "math", intensity * 0.86),
            SensoryFeature("left", _num_band(left), "math", intensity * 0.66),
            SensoryFeature("right", _num_band(right), "math", intensity * 0.66),
            SensoryFeature("result", _num_band(result), "math", intensity * 0.76),
            SensoryFeature("equation_form", "binary_result", "math", intensity * 0.62),
        ]
    )
    try:
        lf, rf, of = float(left), float(right), float(result)
        expected = {"add": lf + rf, "subtract": lf - rf, "multiply": lf * rf, "divide": lf / rf if rf else float("inf")}[op_name]
        truth = "true" if abs(expected - of) <= 1e-6 else "false"
        features.append(SensoryFeature("truth", truth, "math", intensity * 0.82))
        if float(result).is_integer():
            features.append(SensoryFeature("result_parity", "even" if int(float(result)) % 2 == 0 else "odd", "math", intensity * 0.48))
    except (ValueError, OverflowError):
        features.append(SensoryFeature("truth", "unknown", "math", intensity * 0.35))
    return features


def _num_band(value: str) -> str:
    try:
        number = float(value)
    except ValueError:
        return "unknown"
    if number < 0:
        return "negative"
    if number == 0:
        return "zero"
    if number == 1:
        return "one"
    if number == 2:
        return "two"
    if number == 3:
        return "three"
    if number <= 5:
        return "small"
    if number <= 10:
        return "medium"
    return "large"


def _count_band(count: int) -> str:
    if count <= 0:
        return "none"
    if count == 1:
        return "one"
    if count <= 3:
        return "few"
    if count <= 8:
        return "some"
    return "many"


def _age_band(age: int) -> str:
    if age <= 0:
        return "new"
    if age <= 3:
        return "fresh"
    if age <= 9:
        return "active"
    return "fading"


def _packet_from_dict(data: dict[str, Any]) -> SensoryPacket:
    modality = str(data.get("modality", "sensor"))
    if modality not in {"console", "screen", "image", "audio", "math", "sensor"}:
        modality = "sensor"
    return SensoryPacket(
        tick=int(data.get("tick", 0)),
        source=str(data.get("source", "external")),
        modality=modality,  # type: ignore[arg-type]
        payload=str(data.get("payload", "")),
        intensity=float(data.get("intensity", 1.0)),
        ttl=int(data.get("ttl", 18)),
        metadata={str(k): str(v) for k, v in dict(data.get("metadata", {})).items()},
    )


def _report_from_dict(data: dict[str, Any]) -> AdapterReport:
    return AdapterReport(
        tick=int(data.get("tick", 0)),
        packet_count=int(data.get("packet_count", 0)),
        feature_count=int(data.get("feature_count", 0)),
        modalities=tuple(str(v) for v in data.get("modalities", [])),
        features=tuple(str(v) for v in data.get("features", [])),
    )
