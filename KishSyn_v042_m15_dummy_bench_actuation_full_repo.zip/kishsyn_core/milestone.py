"""Milestone lock evaluators for KishSyn Core.

Milestones are governed contracts, not vibes. A milestone is locked only when its
named substrate surface passes deterministic criteria and the benchmark suite has
no watch/fail tasks under the declared seeds.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from statistics import mean
from typing import Any, Literal

from .benchmark import BenchmarkPlaygroundSuite
from .loop import OrganismLoop
from .atlas_inspector import NeuralAtlasInspector

MilestoneStatus = Literal["pass", "watch", "fail"]


@dataclass(frozen=True)
class MilestoneCriterion:
    """One audited lock criterion for a governed milestone.

    Pattern: Specification. Each lock criterion names the observed value and the
    threshold that made the milestone pass, watch, or fail.
    """

    name: str
    observed: float
    pass_at: float
    watch_at: float
    status: MilestoneStatus
    reason: str

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class MilestoneLockReport:
    """Composite lock report for a named project milestone."""

    milestone_id: str
    name: str
    locked: bool
    verdict: str
    summary_score: float
    seed: int
    seeds: tuple[int, ...]
    steps: int
    criteria: tuple[MilestoneCriterion, ...]
    benchmark: dict[str, Any]
    evidence: dict[str, Any]
    metrics: dict[str, float]

    def as_dict(self) -> dict[str, Any]:
        return {
            "milestone_id": self.milestone_id,
            "name": self.name,
            "locked": self.locked,
            "verdict": self.verdict,
            "summary_score": round(float(self.summary_score), 4),
            "seed": self.seed,
            "seeds": list(self.seeds),
            "steps": self.steps,
            "criteria": [criterion.as_dict() for criterion in self.criteria],
            "benchmark": dict(self.benchmark),
            "evidence": dict(self.evidence),
            "metrics": {key: round(float(value), 4) for key, value in self.metrics.items()},
        }


class MilestoneM1LockEvaluator:
    """Evaluates Milestone M1: Focused Moment Substrate.

    Lock definition:
    raw sensory flow is focus-selected into MomentFrames; repeated focused
    moments stabilize binding candidates; stable bindings promote provisional
    circuits; the controlled benchmark suite has no watch/fail tasks.
    """

    milestone_id = "M1"
    name = "Focused Moment Substrate"

    def evaluate(
        self,
        *,
        seed: int = 337,
        seeds: tuple[int, ...] = (337, 171, 23),
        steps: int = 240,
        ablation_steps: int = 48,
    ) -> MilestoneLockReport:
        loop = OrganismLoop(seed=seed)
        loop.run(steps=steps)
        snap = loop.snapshot().__dict__
        focus = snap["focus"]
        moments = snap["moments"]
        binding = snap["binding"]
        anatomy = snap["anatomy"]
        graph = snap["graph"]
        world = snap["world"]
        foraging = world.get("foraging", {})

        benchmark = BenchmarkPlaygroundSuite().evaluate(seeds=seeds, steps=steps)
        benchmark_failures = sum(1 for task in benchmark.tasks if task.status == "fail")
        benchmark_watches = sum(1 for task in benchmark.tasks if task.status == "watch")
        focused_substrate_score = (
            float(focus.get("mean_selectivity", 0.0))
            + float(moments.get("count", 0.0)) * 0.004
            + float(binding.get("stable_count", 0.0)) * 0.035
            + float(anatomy.get("circuit_count", 0.0)) * 0.020
        )

        metrics = {
            "focus_selectivity": float(focus.get("mean_selectivity", 0.0)),
            "focus_report_count": float(focus.get("report_count", 0.0)),
            "moment_count": float(moments.get("count", 0.0)),
            "stable_bindings": float(binding.get("stable_count", 0.0)),
            "binding_candidates": float(binding.get("candidate_count", 0.0)),
            "circuit_count": float(anatomy.get("circuit_count", 0.0)),
            "circuit_promotions": float(anatomy.get("promotion_count", 0.0)),
            "graph_node_count": float(graph.get("node_count", 0.0)),
            "graph_edge_count": float(graph.get("edge_count", 0.0)),
            "visited_cells": float(foraging.get("visited_cells", 0.0)),
            "depletion_events": float(foraging.get("depletion_count", foraging.get("depleted_resources", 0.0))),
            "benchmark_score": float(benchmark.summary_score),
            "benchmark_failures": float(benchmark_failures),
            "benchmark_watches": float(benchmark_watches),
            "focused_substrate_score": float(focused_substrate_score),
        }

        criteria = (
            self._criterion("focus selectivity", metrics["focus_selectivity"], pass_at=0.20, watch_at=0.10, reason="raw sensory flow is reduced into a bounded active moment"),
            self._criterion("moment ledger", metrics["moment_count"], pass_at=64.0, watch_at=32.0, reason="focused experience persists as replayable MomentFrames"),
            self._criterion("binding stability", metrics["stable_bindings"], pass_at=3.0, watch_at=1.0, reason="repeated focused coactivations stabilize binding candidates"),
            self._criterion("provisional circuit growth", metrics["circuit_count"], pass_at=1.0, watch_at=0.5, reason="stable bindings promote into graph-level circuit anatomy"),
            self._criterion("synapse graph support", metrics["graph_node_count"] + metrics["graph_edge_count"], pass_at=160.0, watch_at=96.0, reason="focused moments feed the associative synapse graph"),
            self._criterion("foraging pressure remains live", metrics["visited_cells"] + metrics["depletion_events"] * 2.0, pass_at=96.0, watch_at=42.0, reason="the organism keeps interacting with finite resources while moments form"),
            self._criterion("benchmark lock", 1.0 - min(1.0, (metrics["benchmark_failures"] * 1.0 + metrics["benchmark_watches"] * 0.5) / 3.0), pass_at=1.0, watch_at=0.67, reason="formal benchmark suite has no watch/fail tasks"),
            self._criterion("focused substrate score", metrics["focused_substrate_score"], pass_at=0.82, watch_at=0.42, reason="focus, moments, bindings, and provisional circuits jointly clear the substrate threshold"),
        )
        summary_score = round(mean(1.0 if c.status == "pass" else 0.5 if c.status == "watch" else 0.0 for c in criteria), 4)
        locked = all(c.status == "pass" for c in criteria) and benchmark_failures == 0 and benchmark_watches == 0
        verdict = "M1 locked: Focused Moment Substrate is controlled and repeatable" if locked else "M1 candidate: continue hardening before lock"
        return MilestoneLockReport(
            milestone_id=self.milestone_id,
            name=self.name,
            locked=locked,
            verdict=verdict,
            summary_score=summary_score,
            seed=seed,
            seeds=seeds,
            steps=steps,
            criteria=criteria,
            benchmark=benchmark.as_dict(),
            evidence={
                "summary_score": round(min(1.0, float(focused_substrate_score) / 0.82), 4),
                "focused_substrate_score": round(float(focused_substrate_score), 4),
                "criteria": [
                    {"name": "focus selectivity", "observed": round(float(focus.get("mean_selectivity", 0.0)), 4)},
                    {"name": "moment count", "observed": round(float(moments.get("count", 0.0)), 4)},
                    {"name": "stable bindings", "observed": round(float(binding.get("stable_count", 0.0)), 4)},
                    {"name": "circuit count", "observed": round(float(anatomy.get("circuit_count", 0.0)), 4)},
                ],
            },
            metrics=metrics,
        )

    def _criterion(self, name: str, observed: float, *, pass_at: float, watch_at: float, reason: str) -> MilestoneCriterion:
        if observed >= pass_at:
            status: MilestoneStatus = "pass"
        elif observed >= watch_at:
            status = "watch"
        else:
            status = "fail"
        return MilestoneCriterion(
            name=name,
            observed=round(float(observed), 4),
            pass_at=round(float(pass_at), 4),
            watch_at=round(float(watch_at), 4),
            status=status,
            reason=reason,
        )


class MilestoneM2LockEvaluator:
    """Evaluates Milestone M2: Cross-Modal Binding and Intent Persistence.

    Lock definition:
    the M1 focused moment substrate remains locked; repeated moments bind across
    multiple signal kinds; selected targets persist across time; and the benchmark
    suite has no watch/fail tasks under the declared seeds.
    """

    milestone_id = "M2"
    name = "Cross-Modal Binding and Intent Persistence"

    def evaluate(
        self,
        *,
        seed: int = 337,
        seeds: tuple[int, ...] = (337, 171, 23),
        steps: int = 160,
        ablation_steps: int = 32,
    ) -> MilestoneLockReport:
        m1 = MilestoneM1LockEvaluator().evaluate(seed=seed, seeds=seeds, steps=steps, ablation_steps=ablation_steps)
        loop = OrganismLoop(seed=seed)
        loop.run(steps=steps)
        snap = loop.snapshot().__dict__
        binding = snap["binding"]
        intent = snap["intent"]
        moments = snap["moments"]
        graph = snap["graph"]
        benchmark = m1.benchmark
        benchmark_tasks = benchmark.get("tasks", []) if isinstance(benchmark, dict) else []
        benchmark_failures = sum(1 for task in benchmark_tasks if isinstance(task, dict) and task.get("status") == "fail")
        benchmark_watches = sum(1 for task in benchmark_tasks if isinstance(task, dict) and task.get("status") == "watch")
        m2_score = (
            float(binding.get("stable_cross_modal_count", 0.0)) * 0.035
            + float(binding.get("best_modality_span", 0.0)) * 0.08
            + float(intent.get("continuity_ratio", 0.0))
            + float(intent.get("completed_count", 0.0)) * 0.06
        )
        metrics = {
            "m1_locked": 1.0 if m1.locked else 0.0,
            "moment_count": float(moments.get("count", 0.0)),
            "cross_modal_bindings": float(binding.get("stable_cross_modal_count", 0.0)),
            "best_modality_span": float(binding.get("best_modality_span", 0.0)),
            "intent_continuity": float(intent.get("continuity_ratio", 0.0)),
            "intent_completed": float(intent.get("completed_count", 0.0)),
            "intent_terminal": float(intent.get("terminal_count", 0.0)),
            "graph_node_count": float(graph.get("node_count", 0.0)),
            "graph_edge_count": float(graph.get("edge_count", 0.0)),
            "benchmark_score": float(benchmark.get("summary_score", 0.0) if isinstance(benchmark, dict) else 0.0),
            "benchmark_failures": float(benchmark_failures),
            "benchmark_watches": float(benchmark_watches),
            "m2_score": float(m2_score),
        }
        criteria = (
            self._criterion("M1 remains locked", metrics["m1_locked"], pass_at=1.0, watch_at=0.5, reason="M2 cannot replace the focused moment substrate; it must build on it"),
            self._criterion("cross-modal binding stability", metrics["cross_modal_bindings"], pass_at=3.0, watch_at=1.0, reason="stable bindings span multiple sensory/action/outcome modalities"),
            self._criterion("modality span", metrics["best_modality_span"], pass_at=5.0, watch_at=3.0, reason="event assemblies include several signal kinds rather than one feature type"),
            self._criterion("intent continuity", metrics["intent_continuity"], pass_at=0.55, watch_at=0.30, reason="selected targets persist across several moments instead of jittering"),
            self._criterion("intent completion", metrics["intent_completed"], pass_at=1.0, watch_at=0.5, reason="at least one persisted intent resolves through consequence"),
            self._criterion("moment support", metrics["moment_count"], pass_at=64.0, watch_at=32.0, reason="binding and intent must be grounded in retained MomentFrames"),
            self._criterion("graph support", metrics["graph_node_count"] + metrics["graph_edge_count"], pass_at=180.0, watch_at=120.0, reason="M2 surfaces write reusable graph structure"),
            self._criterion("benchmark lock", 1.0 - min(1.0, (metrics["benchmark_failures"] + metrics["benchmark_watches"] * 0.5) / 3.0), pass_at=1.0, watch_at=0.67, reason="formal benchmark suite has no watch/fail tasks"),
            self._criterion("M2 composite score", metrics["m2_score"], pass_at=1.20, watch_at=0.70, reason="cross-modal binding and intent persistence jointly clear the milestone threshold"),
        )
        summary_score = round(mean(1.0 if c.status == "pass" else 0.5 if c.status == "watch" else 0.0 for c in criteria), 4)
        locked = all(c.status == "pass" for c in criteria) and benchmark_failures == 0 and benchmark_watches == 0
        verdict = "M2 locked: cross-modal binding and intent persistence are controlled and repeatable" if locked else "M2 candidate: continue hardening before lock"
        return MilestoneLockReport(
            milestone_id=self.milestone_id,
            name=self.name,
            locked=locked,
            verdict=verdict,
            summary_score=summary_score,
            seed=seed,
            seeds=seeds,
            steps=steps,
            criteria=criteria,
            benchmark=dict(benchmark),
            evidence={
                "summary_score": round(min(1.0, float(m2_score) / 1.20), 4),
                "m2_score": round(float(m2_score), 4),
                "criteria": [
                    {"name": "cross modal bindings", "observed": round(float(binding.get("stable_cross_modal_count", 0.0)), 4)},
                    {"name": "modality span", "observed": round(float(binding.get("best_modality_span", 0.0)), 4)},
                    {"name": "intent continuity", "observed": round(float(intent.get("continuity_ratio", 0.0)), 4)},
                    {"name": "intent completed", "observed": round(float(intent.get("completed_count", 0.0)), 4)},
                ],
            },
            metrics=metrics,
        )

    def _criterion(self, name: str, observed: float, *, pass_at: float, watch_at: float, reason: str) -> MilestoneCriterion:
        if observed >= pass_at:
            status: MilestoneStatus = "pass"
        elif observed >= watch_at:
            status = "watch"
        else:
            status = "fail"
        return MilestoneCriterion(
            name=name,
            observed=round(float(observed), 4),
            pass_at=round(float(pass_at), 4),
            watch_at=round(float(watch_at), 4),
            status=status,
            reason=reason,
        )


class MilestoneM3LockEvaluator:
    """Evaluates Milestone M3: Counterfactual Replay and Proto-Planning.

    Lock definition:
    M2 remains locked; the organism rehearses multiple candidate consequences
    before action; replayed plans write graph traces; and the formal benchmark
    suite has no watch/fail tasks under the declared seeds.
    """

    milestone_id = "M3"
    name = "Counterfactual Replay and Proto-Planning"

    def evaluate(
        self,
        *,
        seed: int = 337,
        seeds: tuple[int, ...] = (337,),
        steps: int = 180,
        ablation_steps: int = 32,
    ) -> MilestoneLockReport:
        m2 = MilestoneM2LockEvaluator().evaluate(seed=seed, seeds=(seed,), steps=steps, ablation_steps=ablation_steps)
        loop = OrganismLoop(seed=seed)
        loop.run(steps=steps)
        snap = loop.snapshot().__dict__
        planning = snap["planning"]
        intent = snap["intent"]
        graph = snap["graph"]
        benchmark_report = BenchmarkPlaygroundSuite().evaluate(seeds=seeds, steps=steps)
        benchmark = benchmark_report.as_dict()
        benchmark_tasks = benchmark.get("tasks", [])
        benchmark_failures = sum(1 for task in benchmark_tasks if isinstance(task, dict) and task.get("status") == "fail")
        benchmark_watches = sum(1 for task in benchmark_tasks if isinstance(task, dict) and task.get("status") == "watch")
        plan_template_count = float(planning.get("plan_template_count", 0.0))
        if plan_template_count <= 0.0:
            plan_template_count = float(sum(1 for node in graph.get("nodes", []) if isinstance(node, dict) and node.get("kind") == "plan_template"))
        template_updates = float(planning.get("plan_template_updates", 0.0))
        m3_score = (
            float(planning.get("report_count", 0.0)) * 0.004
            + float(planning.get("mean_options", 0.0)) * 0.08
            + float(planning.get("alignment_ratio", 0.0)) * 0.30
            + min(0.30, float(planning.get("predicted_risk_count", 0.0)) * 0.01)
            + min(0.30, plan_template_count * 0.055)
            + min(0.25, template_updates * 0.0015)
        )
        metrics = {
            "m2_locked": 1.0 if m2.locked else 0.0,
            "planning_reports": float(planning.get("report_count", 0.0)),
            "mean_options": float(planning.get("mean_options", 0.0)),
            "predicted_risks": float(planning.get("predicted_risk_count", 0.0)),
            "replay_successes": float(planning.get("replay_successes", 0.0)),
            "replay_failures": float(planning.get("replay_failures", 0.0)),
            "alignment_ratio": float(planning.get("alignment_ratio", 0.0)),
            "plan_switches": float(planning.get("plan_switches", 0.0)),
            "plan_template_count": plan_template_count,
            "plan_template_updates": template_updates,
            "intent_continuity": float(intent.get("continuity_ratio", 0.0)),
            "benchmark_score": float(benchmark.get("summary_score", 0.0) if isinstance(benchmark, dict) else 0.0),
            "benchmark_failures": float(benchmark_failures),
            "benchmark_watches": float(benchmark_watches),
            "m3_score": float(m3_score),
        }
        criteria = (
            self._criterion("M2 remains locked", metrics["m2_locked"], pass_at=1.0, watch_at=0.5, reason="M3 cannot replace focused moment binding or intent; it must build on them"),
            self._criterion("counterfactual report cadence", metrics["planning_reports"], pass_at=96.0, watch_at=48.0, reason="planning runs repeatedly inside the living loop"),
            self._criterion("candidate option breadth", metrics["mean_options"], pass_at=3.0, watch_at=1.5, reason="the organism rehearses several current candidates instead of one reflex only"),
            self._criterion("risk imagination", metrics["predicted_risks"], pass_at=2.0, watch_at=1.0, reason="hazard/depletion possibilities enter imagined consequence scoring"),
            self._criterion("plan template graph traces", metrics["plan_template_count"], pass_at=3.0, watch_at=1.0, reason="counterfactual plans compress into reusable graph anatomy instead of tick-specific nodes"),
            self._criterion("plan template updates", metrics["plan_template_updates"], pass_at=96.0, watch_at=48.0, reason="repeated plan instances strengthen reusable templates"),
            self._criterion("replay/outcome alignment", metrics["alignment_ratio"], pass_at=0.12, watch_at=0.04, reason="some imagined outcomes align with lived consequence and can be reinforced"),
            self._criterion("intent still coherent", metrics["intent_continuity"], pass_at=0.45, watch_at=0.25, reason="planning must not destroy M2 target continuity"),
            self._criterion("benchmark lock", 1.0 - min(1.0, (metrics["benchmark_failures"] + metrics["benchmark_watches"] * 0.5) / 3.0), pass_at=1.0, watch_at=0.67, reason="formal benchmark suite has no watch/fail tasks"),
            self._criterion("M3 composite score", metrics["m3_score"], pass_at=1.40, watch_at=0.72, reason="counterfactual cadence, option breadth, risk imagination, and plan traces jointly clear threshold"),
        )
        summary_score = round(mean(1.0 if c.status == "pass" else 0.5 if c.status == "watch" else 0.0 for c in criteria), 4)
        locked = all(c.status == "pass" for c in criteria) and benchmark_failures == 0 and benchmark_watches == 0
        verdict = "M3 locked: counterfactual replay and proto-planning are controlled and repeatable" if locked else "M3 candidate: continue hardening before lock"
        return MilestoneLockReport(
            milestone_id=self.milestone_id,
            name=self.name,
            locked=locked,
            verdict=verdict,
            summary_score=summary_score,
            seed=seed,
            seeds=seeds,
            steps=steps,
            criteria=criteria,
            benchmark=dict(benchmark),
            evidence={
                "summary_score": round(min(1.0, float(m3_score) / 1.40), 4),
                "m3_score": round(float(m3_score), 4),
                "criteria": [
                    {"name": "planning reports", "observed": round(float(planning.get("report_count", 0.0)), 4)},
                    {"name": "mean options", "observed": round(float(planning.get("mean_options", 0.0)), 4)},
                    {"name": "alignment ratio", "observed": round(float(planning.get("alignment_ratio", 0.0)), 4)},
                    {"name": "plan templates", "observed": round(plan_template_count, 4)},
                    {"name": "plan template updates", "observed": round(template_updates, 4)},
                ],
            },
            metrics=metrics,
        )

    def _criterion(self, name: str, observed: float, *, pass_at: float, watch_at: float, reason: str) -> MilestoneCriterion:
        if observed >= pass_at:
            status: MilestoneStatus = "pass"
        elif observed >= watch_at:
            status = "watch"
        else:
            status = "fail"
        return MilestoneCriterion(
            name=name,
            observed=round(float(observed), 4),
            pass_at=round(float(pass_at), 4),
            watch_at=round(float(watch_at), 4),
            status=status,
            reason=reason,
        )


class MilestoneM4LockEvaluator:
    """Evaluates Milestone M4: Sensory Adapter and Expression Surface.

    Lock definition:
    M3 remains locked; external console/math/screen/image/audio packets enter
    through one adapter contract; focused moments select those signals; graph-
    grounded expression emits through a console motor surface; and the neural
    atlas mirrors all touched surfaces for GUI inspection.
    """

    milestone_id = "M4"
    name = "Sensory Adapter and Expression Surface"

    def evaluate(
        self,
        *,
        seed: int = 337,
        seeds: tuple[int, ...] = (337,),
        steps: int = 96,
        ablation_steps: int = 24,
    ) -> MilestoneLockReport:
        loop = OrganismLoop(seed=seed)
        loop.autopilot.enabled = False
        loop.sensory_hub.receive_console(tick=loop.tick, text="red round ?", source="m4_console", ttl=steps + 12)
        loop.sensory_hub.receive_math(tick=loop.tick, expression="2+2=4", source="m4_math", ttl=steps + 12)
        loop.sensory_hub.receive_screen_probe(tick=loop.tick, description="screen red circle near cursor", source="m4_screen", ttl=steps + 12)
        loop.sensory_hub.receive_image_probe(tick=loop.tick, description="image blue tall object glyph A", source="m4_image", ttl=steps + 12)
        loop.sensory_hub.receive_audio_probe(tick=loop.tick, description="audio soft tone syllable red", source="m4_audio", ttl=steps + 12)
        loop.run(steps=steps)
        snap = loop.snapshot().__dict__
        sensory = snap["sensory"]
        expression = snap["expression"]
        focus = snap["focus"]
        planning = snap["planning"]
        intent = snap["intent"]
        graph = snap["graph"]
        atlas = snap["atlas"]
        modality_counts = sensory.get("modality_counts", {}) if isinstance(sensory, dict) else {}
        atlas_surfaces = atlas.get("surface_counts", {}) if isinstance(atlas, dict) else {}
        graph_nodes = graph.get("nodes", []) if isinstance(graph, dict) else []
        external_node_count = float(sum(1 for node in graph_nodes if isinstance(node, dict) and node.get("kind") in {"text", "expression"}))
        external_surface_hits = float(sum(1 for surface in ("math", "screen", "image", "audio", "text", "expression") if float(atlas_surfaces.get(surface, 0.0) or 0.0) > 0))
        recent_focus = focus.get("recent", []) if isinstance(focus, dict) else []
        focused_adapter_hits = 0.0
        for report in recent_focus:
            if not isinstance(report, dict):
                continue
            for signal in report.get("selected", []):
                if isinstance(signal, dict) and signal.get("kind") in {"math", "screen", "image", "audio", "text", "console"}:
                    focused_adapter_hits += 1.0
        benchmark_report = BenchmarkPlaygroundSuite().evaluate(seeds=seeds, steps=max(180, steps))
        benchmark = benchmark_report.as_dict()
        benchmark_tasks = benchmark.get("tasks", [])
        benchmark_failures = sum(1 for task in benchmark_tasks if isinstance(task, dict) and task.get("status") == "fail")
        benchmark_watches = sum(1 for task in benchmark_tasks if isinstance(task, dict) and task.get("status") == "watch")
        m4_score = (
            float(sensory.get("packet_count", 0.0)) * 0.08
            + float(sensory.get("feature_count", 0.0)) * 0.006
            + float(expression.get("output_count", 0.0)) * 0.14
            + focused_adapter_hits * 0.012
            + external_surface_hits * 0.09
        )
        m3_preserved = 1.0 if (float(planning.get("report_count", 0.0)) >= 64 and float(planning.get("mean_options", 0.0)) >= 2.0 and float(intent.get("continuity_ratio", 0.0)) >= 0.30) else 0.0
        metrics = {
            "m3_locked": m3_preserved,
            "adapter_packets": float(sensory.get("packet_count", 0.0)),
            "adapter_features": float(sensory.get("feature_count", 0.0)),
            "modality_count": float(len(modality_counts)),
            "focused_adapter_hits": focused_adapter_hits,
            "expression_outputs": float(expression.get("output_count", 0.0)),
            "atlas_surface_hits": external_surface_hits,
            "external_node_count": external_node_count,
            "benchmark_score": float(benchmark.get("summary_score", 0.0)),
            "benchmark_failures": float(benchmark_failures),
            "benchmark_watches": float(benchmark_watches),
            "m4_score": float(m4_score),
        }
        criteria = (
            self._criterion("M3 substrate preserved", metrics["m3_locked"], pass_at=1.0, watch_at=0.5, reason="M4 cannot bypass focus, moment, binding, intent, or planning"),
            self._criterion("adapter packet normalization", metrics["adapter_packets"], pass_at=5.0, watch_at=3.0, reason="console, math, screen, image, and audio enter one adapter contract"),
            self._criterion("adapter feature production", metrics["adapter_features"], pass_at=36.0, watch_at=18.0, reason="external packets become replayable sensory features"),
            self._criterion("focused external signals", metrics["focused_adapter_hits"], pass_at=8.0, watch_at=3.0, reason="adapter features pass through FocusGate instead of bypassing attention"),
            self._criterion("grounded expression motor", metrics["expression_outputs"], pass_at=2.0, watch_at=1.0, reason="console expression is emitted from graph/body/outcome evidence"),
            self._criterion("atlas surface mirror", metrics["atlas_surface_hits"], pass_at=5.0, watch_at=3.0, reason="the neural atlas exposes touched sensory and expression surfaces for GUI inspection"),
            self._criterion("benchmark lock", 1.0 - min(1.0, (metrics["benchmark_failures"] + metrics["benchmark_watches"] * 0.5) / 3.0), pass_at=1.0, watch_at=0.67, reason="formal benchmark suite has no watch/fail tasks"),
            self._criterion("M4 composite score", metrics["m4_score"], pass_at=1.30, watch_at=0.70, reason="adapter normalization, focus entry, expression, and atlas mirroring jointly clear threshold"),
        )
        summary_score = round(mean(1.0 if c.status == "pass" else 0.5 if c.status == "watch" else 0.0 for c in criteria), 4)
        locked = all(c.status == "pass" for c in criteria) and benchmark_failures == 0 and benchmark_watches == 0
        verdict = "M4 locked: sensory adapters, expression, and neural atlas mirroring are controlled and repeatable" if locked else "M4 candidate: continue hardening before lock"
        return MilestoneLockReport(
            milestone_id=self.milestone_id,
            name=self.name,
            locked=locked,
            verdict=verdict,
            summary_score=summary_score,
            seed=seed,
            seeds=seeds,
            steps=steps,
            criteria=criteria,
            benchmark=benchmark,
            evidence={
                "summary_score": round(min(1.0, float(m4_score) / 1.30), 4),
                "m4_score": round(float(m4_score), 4),
                "criteria": [
                    {"name": "adapter packets", "observed": round(float(sensory.get("packet_count", 0.0)), 4)},
                    {"name": "adapter features", "observed": round(float(sensory.get("feature_count", 0.0)), 4)},
                    {"name": "expression outputs", "observed": round(float(expression.get("output_count", 0.0)), 4)},
                    {"name": "atlas surface hits", "observed": round(external_surface_hits, 4)},
                ],
            },
            metrics=metrics,
        )

    def _criterion(self, name: str, observed: float, *, pass_at: float, watch_at: float, reason: str) -> MilestoneCriterion:
        if observed >= pass_at:
            status: MilestoneStatus = "pass"
        elif observed >= watch_at:
            status = "watch"
        else:
            status = "fail"
        return MilestoneCriterion(
            name=name,
            observed=round(float(observed), 4),
            pass_at=round(float(pass_at), 4),
            watch_at=round(float(watch_at), 4),
            status=status,
            reason=reason,
        )


class MilestoneM5LockEvaluator:
    """Evaluates Milestone M5: Neural Atlas Inspector.

    Lock definition:
    M4 remains intact; the standardized atlas exposes inspectable neurons and
    synapses; node inspection explains surface/provenance/activation and
    connected pathways; synapse inspection explains weight/update history; and
    the formal benchmark suite has no watch/fail tasks.
    """

    milestone_id = "M5"
    name = "Neural Atlas Inspector and Synapse Introspection"

    def evaluate(
        self,
        *,
        seed: int = 337,
        seeds: tuple[int, ...] = (337,),
        steps: int = 128,
        ablation_steps: int = 24,
    ) -> MilestoneLockReport:
        m4 = MilestoneM4LockEvaluator().evaluate(seed=seed, seeds=seeds, steps=max(96, min(steps, 160)), ablation_steps=ablation_steps)
        loop = OrganismLoop(seed=seed)
        loop.sensory_hub.receive_console(tick=loop.tick, text="red round ?", source="m5_console", ttl=steps + 12)
        loop.sensory_hub.receive_math(tick=loop.tick, expression="2+2=4", source="m5_math", ttl=steps + 12)
        loop.sensory_hub.receive_screen_probe(tick=loop.tick, description="screen red circle near cursor", source="m5_screen", ttl=steps + 12)
        loop.run(steps=steps)
        snap = loop.snapshot().__dict__
        graph = snap["graph"]
        atlas = snap["atlas"]
        index = snap["atlas_inspector"]
        inspector = NeuralAtlasInspector()
        nodes = graph.get("nodes", []) if isinstance(graph, dict) else []
        edges = graph.get("edges", []) if isinstance(graph, dict) else []
        node_id = self._best_node_id(nodes)
        edge = self._best_edge(edges)
        node_report = inspector.inspect_node(graph=loop.graph, node_id=node_id, tick=loop.tick, last_trace=loop.last_trace).as_dict() if node_id else {"found": False, "top_inbound": [], "top_outbound": [], "recent_plasticity": []}
        synapse_report = inspector.inspect_synapse(graph=loop.graph, source=str(edge.get("source", "")), target=str(edge.get("target", "")), tick=loop.tick, last_trace=loop.last_trace).as_dict() if edge else {"found": False, "recent_plasticity": [], "connected_nodes": []}
        recent_plasticity_count = float(len(atlas.get("recent_plasticity", []) if isinstance(atlas, dict) else []))
        surface_count = float(len(atlas.get("surface_counts", {}) if isinstance(atlas, dict) else {}))
        node_inbound = float(len(node_report.get("top_inbound", []) if isinstance(node_report, dict) else []))
        node_outbound = float(len(node_report.get("top_outbound", []) if isinstance(node_report, dict) else []))
        node_recent = float(len(node_report.get("recent_plasticity", []) if isinstance(node_report, dict) else []))
        synapse_connected = float(len(synapse_report.get("connected_nodes", []) if isinstance(synapse_report, dict) else []))
        synapse_recent = float(len(synapse_report.get("recent_plasticity", []) if isinstance(synapse_report, dict) else []))
        benchmark_report = BenchmarkPlaygroundSuite().evaluate(seeds=seeds, steps=max(180, steps))
        benchmark = benchmark_report.as_dict()
        benchmark_tasks = benchmark.get("tasks", [])
        benchmark_failures = sum(1 for task in benchmark_tasks if isinstance(task, dict) and task.get("status") == "fail")
        benchmark_watches = sum(1 for task in benchmark_tasks if isinstance(task, dict) and task.get("status") == "watch")
        m5_score = (
            surface_count * 0.035
            + float(index.get("node_count", 0.0)) * 0.003
            + float(index.get("edge_count", 0.0)) * 0.002
            + node_inbound * 0.06
            + node_outbound * 0.06
            + node_recent * 0.08
            + synapse_connected * 0.12
            + synapse_recent * 0.10
            + recent_plasticity_count * 0.015
        )
        metrics = {
            "m4_locked": 1.0 if m4.locked else 0.0,
            "atlas_surface_count": surface_count,
            "inspectable_nodes": float(index.get("node_count", 0.0)),
            "inspectable_synapses": float(index.get("edge_count", 0.0)),
            "active_node_rows": float(len(index.get("nodes", []) if isinstance(index, dict) else [])),
            "active_synapse_rows": float(len(index.get("synapses", []) if isinstance(index, dict) else [])),
            "node_inspection_found": 1.0 if node_report.get("found") else 0.0,
            "node_inbound": node_inbound,
            "node_outbound": node_outbound,
            "node_recent_plasticity": node_recent,
            "synapse_inspection_found": 1.0 if synapse_report.get("found") else 0.0,
            "synapse_connected_nodes": synapse_connected,
            "synapse_recent_plasticity": synapse_recent,
            "recent_plasticity": recent_plasticity_count,
            "benchmark_score": float(benchmark.get("summary_score", 0.0)),
            "benchmark_failures": float(benchmark_failures),
            "benchmark_watches": float(benchmark_watches),
            "m5_score": float(m5_score),
        }
        criteria = (
            self._criterion("M4 remains locked", metrics["m4_locked"], pass_at=1.0, watch_at=0.5, reason="M5 is a GUI/read-model milestone and cannot bypass sensory adapter/expression doctrine"),
            self._criterion("atlas surface coverage", metrics["atlas_surface_count"], pass_at=10.0, watch_at=6.0, reason="multiple organism surfaces must be visible in one standardized atlas"),
            self._criterion("node inspection", metrics["node_inspection_found"] + min(1.0, (metrics["node_inbound"] + metrics["node_outbound"]) / 2.0), pass_at=1.5, watch_at=0.8, reason="clicking a neuron exposes provenance and nearby pathways"),
            self._criterion("synapse inspection", metrics["synapse_inspection_found"] + min(1.0, metrics["synapse_connected_nodes"] / 2.0), pass_at=1.5, watch_at=0.8, reason="clicking a synapse exposes weight/update and connected endpoint nodes"),
            self._criterion("recent plasticity mirror", metrics["recent_plasticity"] + metrics["node_recent_plasticity"] + metrics["synapse_recent_plasticity"], pass_at=6.0, watch_at=2.0, reason="the inspector shows recent learning events instead of static graph decorations"),
            self._criterion("inspectable atlas index", metrics["active_node_rows"] + metrics["active_synapse_rows"], pass_at=80.0, watch_at=35.0, reason="GUI has enough standardized rows to select and inspect"),
            self._criterion("benchmark lock", 1.0 - min(1.0, (metrics["benchmark_failures"] + metrics["benchmark_watches"] * 0.5) / 3.0), pass_at=1.0, watch_at=0.67, reason="formal benchmark suite has no watch/fail tasks"),
            self._criterion("M5 composite score", metrics["m5_score"], pass_at=2.25, watch_at=1.10, reason="atlas coverage, node/synapse inspection, and plasticity mirror jointly clear threshold"),
        )
        summary_score = round(mean(1.0 if c.status == "pass" else 0.5 if c.status == "watch" else 0.0 for c in criteria), 4)
        locked = all(c.status == "pass" for c in criteria) and benchmark_failures == 0 and benchmark_watches == 0
        verdict = "M5 locked: neural atlas inspector and synapse introspection are controlled and repeatable" if locked else "M5 candidate: continue hardening before lock"
        return MilestoneLockReport(
            milestone_id=self.milestone_id,
            name=self.name,
            locked=locked,
            verdict=verdict,
            summary_score=summary_score,
            seed=seed,
            seeds=seeds,
            steps=steps,
            criteria=criteria,
            benchmark=benchmark,
            evidence={
                "summary_score": round(min(1.0, float(m5_score) / 2.25), 4),
                "m5_score": round(float(m5_score), 4),
                "criteria": [
                    {"name": "node inspection", "observed": round(metrics["node_inspection_found"], 4)},
                    {"name": "synapse inspection", "observed": round(metrics["synapse_inspection_found"], 4)},
                    {"name": "surface coverage", "observed": round(surface_count, 4)},
                    {"name": "recent plasticity", "observed": round(recent_plasticity_count, 4)},
                ],
            },
            metrics=metrics,
        )

    def _criterion(self, name: str, observed: float, *, pass_at: float, watch_at: float, reason: str) -> MilestoneCriterion:
        if observed >= pass_at:
            status: MilestoneStatus = "pass"
        elif observed >= watch_at:
            status = "watch"
        else:
            status = "fail"
        return MilestoneCriterion(
            name=name,
            observed=round(float(observed), 4),
            pass_at=round(float(pass_at), 4),
            watch_at=round(float(watch_at), 4),
            status=status,
            reason=reason,
        )

    def _best_node_id(self, nodes: list[object]) -> str | None:
        candidates = [node for node in nodes if isinstance(node, dict)]
        if not candidates:
            return None
        candidates.sort(key=lambda node: (-float(node.get("activation", 0.0) or 0.0), -float(node.get("last_active", 0.0) or 0.0), str(node.get("id", ""))))
        return str(candidates[0].get("id", "")) or None

    def _best_edge(self, edges: list[object]) -> dict[str, object] | None:
        candidates = [edge for edge in edges if isinstance(edge, dict)]
        if not candidates:
            return None
        candidates.sort(key=lambda edge: (-float(edge.get("last_updated", 0.0) or 0.0), -abs(float(edge.get("weight", 0.0) or 0.0)), str(edge.get("source", ""))))
        return candidates[0]



class MilestoneM6LockEvaluator:
    """Evaluates Milestone M6: Emotional Regulation Field.

    Lock definition:
    M5 atlas/inspection surfaces remain available; body pressure, prediction
    error, controllability, safety, novelty, fatigue, and blocked intent are
    converted into graph-visible regulation weather; repeated samples stabilize
    slow trait tendencies; and the formal benchmark suite has no watch/fail
    tasks.
    """

    milestone_id = "M6"
    name = "Emotional Regulation Field"

    def evaluate(
        self,
        *,
        seed: int = 337,
        seeds: tuple[int, ...] = (337,),
        steps: int = 160,
        ablation_steps: int = 24,
    ) -> MilestoneLockReport:
        loop = OrganismLoop(seed=seed)
        loop.sensory_hub.receive_console(tick=loop.tick, text="red round ?", source="m6_console", ttl=steps + 12)
        loop.sensory_hub.receive_math(tick=loop.tick, expression="2+2=4", source="m6_math", ttl=steps + 12)
        loop.sensory_hub.receive_screen_probe(tick=loop.tick, description="screen red circle near cursor", source="m6_screen", ttl=steps + 12)
        loop.run(steps=max(128, steps))
        snap = loop.snapshot().__dict__
        emotion = snap["emotion"]
        graph = snap["graph"]
        atlas = snap["atlas"]
        index = snap["atlas_inspector"]
        nodes = graph.get("nodes", []) if isinstance(graph, dict) else []
        edges = graph.get("edges", []) if isinstance(graph, dict) else []
        inspector = NeuralAtlasInspector()
        node_id = self._best_node_id(nodes)
        edge = self._best_edge(edges)
        node_report = inspector.inspect_node(graph=loop.graph, node_id=node_id, tick=loop.tick, last_trace=loop.last_trace).as_dict() if node_id else {"found": False}
        synapse_report = inspector.inspect_synapse(graph=loop.graph, source=str(edge.get("source", "")), target=str(edge.get("target", "")), tick=loop.tick, last_trace=loop.last_trace).as_dict() if edge else {"found": False}
        surface_count = float(len(atlas.get("surface_counts", {}) if isinstance(atlas, dict) else {}))
        emotion_nodes = float(sum(1 for node in nodes if isinstance(node, dict) and node.get("kind") == "emotion"))
        m5_surface_score = (
            surface_count * 0.06
            + float(index.get("node_count", 0.0)) * 0.004
            + float(index.get("edge_count", 0.0)) * 0.003
            + (1.0 if node_report.get("found") else 0.0)
            + (1.0 if synapse_report.get("found") else 0.0)
        )
        benchmark_report = BenchmarkPlaygroundSuite().evaluate(seeds=seeds, steps=max(180, steps))
        benchmark = benchmark_report.as_dict()
        benchmark_tasks = benchmark.get("tasks", [])
        benchmark_failures = sum(1 for task in benchmark_tasks if isinstance(task, dict) and task.get("status") == "fail")
        benchmark_watches = sum(1 for task in benchmark_tasks if isinstance(task, dict) and task.get("status") == "watch")
        m6_score = (
            float(emotion.get("sample_count", 0.0)) * 0.004
            + float(emotion.get("trait_count", 0.0)) * 0.10
            + float(emotion.get("trait_mass", 0.0)) * 0.35
            + float(emotion.get("distinct_modes", 0.0)) * 0.08
            + float(emotion.get("graph_event_count", 0.0)) * 0.0012
            + emotion_nodes * 0.035
            + float(emotion.get("mean_control", 0.0)) * 0.14
            + float(emotion.get("emotional_stability", 0.0)) * 0.10
        )
        metrics = {
            "m5_surface_score": float(m5_surface_score),
            "atlas_surface_count": surface_count,
            "inspectable_nodes": float(index.get("node_count", 0.0)),
            "inspectable_synapses": float(index.get("edge_count", 0.0)),
            "node_inspection_found": 1.0 if node_report.get("found") else 0.0,
            "synapse_inspection_found": 1.0 if synapse_report.get("found") else 0.0,
            "emotion_samples": float(emotion.get("sample_count", 0.0)),
            "emotion_updates": float(emotion.get("update_count", 0.0)),
            "trait_count": float(emotion.get("trait_count", 0.0)),
            "trait_mass": float(emotion.get("trait_mass", 0.0)),
            "distinct_modes": float(emotion.get("distinct_modes", 0.0)),
            "emotion_graph_events": float(emotion.get("graph_event_count", 0.0)),
            "emotion_nodes": emotion_nodes,
            "mean_arousal": float(emotion.get("mean_arousal", 0.0)),
            "mean_valence": float(emotion.get("mean_valence", 0.0)),
            "mean_control": float(emotion.get("mean_control", 0.0)),
            "emotional_stability": float(emotion.get("emotional_stability", 0.0)),
            "benchmark_score": float(benchmark.get("summary_score", 0.0)),
            "benchmark_failures": float(benchmark_failures),
            "benchmark_watches": float(benchmark_watches),
            "m6_score": float(m6_score),
        }
        criteria = (
            self._criterion("M5 atlas surface remains live", metrics["m5_surface_score"], pass_at=3.0, watch_at=1.5, reason="emotional regulation must ride on the inspectable atlas surface, not bypass it"),
            self._criterion("regulation samples", metrics["emotion_samples"], pass_at=90.0, watch_at=45.0, reason="completed ticks produce replayable regulation-weather samples"),
            self._criterion("trait crystallization", metrics["trait_count"] + metrics["trait_mass"], pass_at=4.8, watch_at=2.2, reason="repeated regulation states accumulate slow trait tendencies"),
            self._criterion("mode diversity", metrics["distinct_modes"], pass_at=2.0, watch_at=1.0, reason="the field differentiates more than one internal weather mode"),
            self._criterion("emotion graph mirror", metrics["emotion_nodes"] + metrics["emotion_graph_events"] * 0.004, pass_at=12.0, watch_at=5.0, reason="emotion modes and traits become visible neurons/synapses in the atlas"),
            self._criterion("control/stability", metrics["mean_control"] + metrics["emotional_stability"], pass_at=1.10, watch_at=0.60, reason="regulation tracks controllability while remaining stable enough to inspect"),
            self._criterion("benchmark lock", 1.0 - min(1.0, (metrics["benchmark_failures"] + metrics["benchmark_watches"] * 0.5) / 3.0), pass_at=1.0, watch_at=0.67, reason="formal benchmark suite has no watch/fail tasks"),
            self._criterion("M6 composite score", metrics["m6_score"], pass_at=3.8, watch_at=1.8, reason="samples, traits, graph visibility, controllability, and benchmark proof jointly clear threshold"),
        )
        summary_score = round(mean(1.0 if c.status == "pass" else 0.5 if c.status == "watch" else 0.0 for c in criteria), 4)
        locked = all(c.status == "pass" for c in criteria) and benchmark_failures == 0 and benchmark_watches == 0
        verdict = "M6 locked: emotional regulation field is controlled and repeatable" if locked else "M6 candidate: continue hardening before lock"
        return MilestoneLockReport(
            milestone_id=self.milestone_id,
            name=self.name,
            locked=locked,
            verdict=verdict,
            summary_score=summary_score,
            seed=seed,
            seeds=seeds,
            steps=steps,
            criteria=criteria,
            benchmark=benchmark,
            evidence={
                "summary_score": round(min(1.0, float(m6_score) / 3.8), 4),
                "m6_score": round(float(m6_score), 4),
                "criteria": [
                    {"name": "samples", "observed": round(metrics["emotion_samples"], 4)},
                    {"name": "traits", "observed": round(metrics["trait_count"], 4)},
                    {"name": "trait mass", "observed": round(metrics["trait_mass"], 4)},
                    {"name": "emotion graph nodes", "observed": round(metrics["emotion_nodes"], 4)},
                ],
            },
            metrics=metrics,
        )

    def _criterion(self, name: str, observed: float, *, pass_at: float, watch_at: float, reason: str) -> MilestoneCriterion:
        if observed >= pass_at:
            status: MilestoneStatus = "pass"
        elif observed >= watch_at:
            status = "watch"
        else:
            status = "fail"
        return MilestoneCriterion(
            name=name,
            observed=round(float(observed), 4),
            pass_at=round(float(pass_at), 4),
            watch_at=round(float(watch_at), 4),
            status=status,
            reason=reason,
        )

    def _best_node_id(self, nodes: list[object]) -> str | None:
        candidates = [node for node in nodes if isinstance(node, dict)]
        if not candidates:
            return None
        candidates.sort(key=lambda node: (-float(node.get("activation", 0.0) or 0.0), -float(node.get("last_active", 0.0) or 0.0), str(node.get("id", ""))))
        return str(candidates[0].get("id", "")) or None

    def _best_edge(self, edges: list[object]) -> dict[str, object] | None:
        candidates = [edge for edge in edges if isinstance(edge, dict)]
        if not candidates:
            return None
        candidates.sort(key=lambda edge: (-float(edge.get("last_updated", 0.0) or 0.0), -abs(float(edge.get("weight", 0.0) or 0.0)), str(edge.get("source", ""))))
        return candidates[0]


class MilestoneM7LockEvaluator:
    """Evaluates Milestone M7: Emotion-Biased Attention and Expression.

    Lock definition:
    M6 regulation weather remains audit-only anatomy, but it may export a tiny
    bounded bias contract into the next focus and expression pass. The contract
    must be inspectable, persisted, weaker than direct body/goal pressure, and
    forbidden from selecting actions or manufacturing personality text.
    """

    milestone_id = "M7"
    name = "Emotion-Biased Attention and Expression"

    def evaluate(
        self,
        *,
        seed: int = 337,
        seeds: tuple[int, ...] = (337,),
        steps: int = 160,
        ablation_steps: int = 24,
    ) -> MilestoneLockReport:
        loop = OrganismLoop(seed=seed)
        loop.sensory_hub.receive_console(tick=loop.tick, text="red round ?", source="m7_console", ttl=steps + 12)
        loop.sensory_hub.receive_math(tick=loop.tick, expression="2+2=4", source="m7_math", ttl=steps + 12)
        loop.sensory_hub.receive_screen_probe(tick=loop.tick, description="screen red circle near cursor", source="m7_screen", ttl=steps + 12)
        loop.run(steps=max(128, steps))
        snap = loop.snapshot().__dict__
        emotion = snap["emotion"]
        focus = snap["focus"]
        expression = snap["expression"]
        planning = snap["planning"]
        score = snap["score"]
        graph = snap["graph"]
        recent_focus = focus.get("recent", []) if isinstance(focus, dict) else []
        emotion_component_hits = 0.0
        emotion_selected_hits = 0.0
        max_emotion_component = 0.0
        for report in recent_focus:
            if not isinstance(report, dict):
                continue
            for group_name in ("selected", "rejected"):
                for signal in report.get(group_name, []):
                    if not isinstance(signal, dict):
                        continue
                    component = float(dict(signal.get("components", {})).get("emotion", 0.0) or 0.0)
                    if component > 0.0:
                        emotion_component_hits += 1.0
                        max_emotion_component = max(max_emotion_component, component)
                        if group_name == "selected":
                            emotion_selected_hits += 1.0
        last_bias = emotion.get("last_bias") if isinstance(emotion, dict) else None
        bias_present = 1.0 if isinstance(last_bias, dict) else 0.0
        bias_bounded = 1.0 if isinstance(last_bias, dict) and float(last_bias.get("focus_bias", 1.0)) <= 0.28 and float(last_bias.get("expression_bias", 1.0)) <= 0.30 and max_emotion_component <= 0.32 else 0.0
        expression_evidence_hits = 0.0
        for item in expression.get("outputs", []) if isinstance(expression, dict) else []:
            if not isinstance(item, dict):
                continue
            if any(str(ev).startswith("emotion_bias:") for ev in item.get("evidence", [])):
                expression_evidence_hits += 1.0
        plan_template_count = float(planning.get("plan_template_count", 0.0))
        tick_plan_nodes = float(sum(1 for node in graph.get("nodes", []) if isinstance(node, dict) and str(node.get("id", "")).startswith("plan:t")))
        benchmark_report = BenchmarkPlaygroundSuite().evaluate(seeds=seeds, steps=max(180, steps))
        benchmark = benchmark_report.as_dict()
        benchmark_tasks = benchmark.get("tasks", [])
        benchmark_failures = sum(1 for task in benchmark_tasks if isinstance(task, dict) and task.get("status") == "fail")
        benchmark_watches = sum(1 for task in benchmark_tasks if isinstance(task, dict) and task.get("status") == "watch")
        m7_score = (
            bias_present * 0.35
            + float(emotion.get("bias_count", 0.0)) * 0.004
            + min(0.55, emotion_component_hits * 0.018)
            + min(0.45, emotion_selected_hits * 0.012)
            + min(0.35, expression_evidence_hits * 0.07)
            + bias_bounded * 0.35
            + min(0.30, plan_template_count * 0.020)
            + (0.25 if tick_plan_nodes == 0.0 else 0.0)
        )
        metrics = {
            "bias_present": bias_present,
            "bias_count": float(emotion.get("bias_count", 0.0)),
            "emotion_component_hits": emotion_component_hits,
            "emotion_selected_hits": emotion_selected_hits,
            "max_emotion_component": max_emotion_component,
            "expression_evidence_hits": expression_evidence_hits,
            "bias_bounded": bias_bounded,
            "plan_template_count": plan_template_count,
            "tick_plan_nodes": tick_plan_nodes,
            "planning_template_updates": float(planning.get("plan_template_updates", 0.0)),
            "planning_alignment": float(planning.get("alignment_ratio", 0.0)),
            "survival": float(score.get("survival", 0.0)),
            "benchmark_score": float(benchmark.get("summary_score", 0.0)),
            "benchmark_failures": float(benchmark_failures),
            "benchmark_watches": float(benchmark_watches),
            "m7_score": float(m7_score),
        }
        criteria = (
            self._criterion("bias contract exists", metrics["bias_present"] + min(1.0, metrics["bias_count"] / 90.0), pass_at=1.8, watch_at=0.8, reason="emotion exports an inspectable previous-sample bias contract"),
            self._criterion("focus receives bounded emotion component", metrics["emotion_component_hits"], pass_at=16.0, watch_at=6.0, reason="focus scoring exposes emotion as a small component instead of a hidden override"),
            self._criterion("emotion-selected focus evidence", metrics["emotion_selected_hits"], pass_at=8.0, watch_at=3.0, reason="some selected signals carry the bounded emotion component"),
            self._criterion("expression carries bias evidence", metrics["expression_evidence_hits"], pass_at=1.0, watch_at=0.5, reason="expression may mention regulation mode only as grounded evidence"),
            self._criterion("bias remains bounded", metrics["bias_bounded"], pass_at=1.0, watch_at=0.5, reason="emotion bias cannot dominate direct body, goal, danger, or adapter pressure"),
            self._criterion("plan templates replace tick plans", metrics["plan_template_count"] + (1.0 if metrics["tick_plan_nodes"] == 0.0 else 0.0), pass_at=4.0, watch_at=2.0, reason="planning anatomy reuses templates rather than tick-id plan nodes"),
            self._criterion("benchmark lock", 1.0 - min(1.0, (metrics["benchmark_failures"] + metrics["benchmark_watches"] * 0.5) / 3.0), pass_at=1.0, watch_at=0.67, reason="formal benchmark suite has no watch/fail tasks"),
            self._criterion("M7 composite score", metrics["m7_score"], pass_at=2.40, watch_at=1.20, reason="bias contract, focus evidence, expression evidence, boundedness, and memory economy jointly clear threshold"),
        )
        summary_score = round(mean(1.0 if c.status == "pass" else 0.5 if c.status == "watch" else 0.0 for c in criteria), 4)
        locked = all(c.status == "pass" for c in criteria) and benchmark_failures == 0 and benchmark_watches == 0
        verdict = "M7 locked: emotion-biased attention and expression are controlled and repeatable" if locked else "M7 candidate: continue hardening before lock"
        return MilestoneLockReport(
            milestone_id=self.milestone_id,
            name=self.name,
            locked=locked,
            verdict=verdict,
            summary_score=summary_score,
            seed=seed,
            seeds=seeds,
            steps=steps,
            criteria=criteria,
            benchmark=benchmark,
            evidence={
                "summary_score": round(min(1.0, float(m7_score) / 2.40), 4),
                "m7_score": round(float(m7_score), 4),
                "criteria": [
                    {"name": "bias count", "observed": round(metrics["bias_count"], 4)},
                    {"name": "focus emotion hits", "observed": round(metrics["emotion_component_hits"], 4)},
                    {"name": "expression evidence", "observed": round(metrics["expression_evidence_hits"], 4)},
                    {"name": "plan templates", "observed": round(metrics["plan_template_count"], 4)},
                ],
            },
            metrics=metrics,
        )

    def _criterion(self, name: str, observed: float, *, pass_at: float, watch_at: float, reason: str) -> MilestoneCriterion:
        if observed >= pass_at:
            status: MilestoneStatus = "pass"
        elif observed >= watch_at:
            status = "watch"
        else:
            status = "fail"
        return MilestoneCriterion(
            name=name,
            observed=round(float(observed), 4),
            pass_at=round(float(pass_at), 4),
            watch_at=round(float(watch_at), 4),
            status=status,
            reason=reason,
        )
