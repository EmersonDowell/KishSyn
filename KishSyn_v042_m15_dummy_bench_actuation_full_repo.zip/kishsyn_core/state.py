"""Persistent brain-state storage for the KishSyn Core organism.

The state store is deliberately explicit JSON, not pickle. It preserves the
organism's learned developmental anatomy across program launches: graph,
world, body pressure, route memory, comfort basins, proto-body bindings,
priority state, symbol goals, workspace broadcasts, and replayable trace
memory.
"""

from __future__ import annotations

import ast
import json
from collections import deque
from dataclasses import asdict
from pathlib import Path
from random import Random
from typing import Any

from .anatomy import AnatomyGrowthEngine
from .autopilot import AutonomousTutorCurriculum, AutopilotLesson
from .binding import BindingEngine
from .body_map import MotorBinding, ProtoBodyMap
from .comfort import ComfortAttractorMemory, ComfortBasin
from .contracts import Action, BodyState, EfferenceCopy, Outcome, PlasticityEvent, Prediction, SensoryFeature, SensoryFrame, TickTrace
from .contextual_affordance import ActorProfile, ContextualAffordanceCortex, WorldContext
from .development import DevelopmentalRegulator, LearningFocus
from .dummy_bench import DummyBenchActuator
from .focus import FocusGate
from .grounded_language import GroundedLanguageCortex
from .interface_affordance import InterfaceAffordanceCortex
from .expression import ExpressionSurface
from .emotion import EmotionalRegulationField
from .external_interface import ExternalAdapterRegistry
from .desktop_observation import OSObservationSubstrate
from .loop import OrganismLoop
from .intent import IntentModel
from .planning import CounterfactualReplayEngine
from .sensory import SensoryAdapterHub
from .memory import ReplayEvent, TraceMemory
from .memory_economy import MemoryPressureGovernor
from .play import IntrinsicPlayDrive
from .moment import MomentLedger
from .motor_experiment import MotorExperimentIntent, MotorExperimenter, MotorProbeStats
from .neural_graph import NeuralGrowthGraph, Neuron, Synapse
from .object_file import ObjectFileCortex
from .priority import PriorityArbitrator
from .route_memory import RouteMemory, RouteStep
from .runtime_shell import RuntimeShellPolicy
from .self_model import SelfBoundaryAssessment, SelfBoundaryModel
from .symbol_goal import ActiveSymbolGoalMemory, SymbolGoalState
from .text_crib import TextCribMemory
from .tutor import TutorSurface
from .workspace import GlobalWorkspace
from .world import MiniEcologyWorld, WorldObject

STATE_VERSION = 1
DEFAULT_STATE_PATH = Path("stores/_demo/persistent_brain_state.json")


def save_loop(loop: OrganismLoop, path: str | Path = DEFAULT_STATE_PATH, *, seed: int | None = None, note: str = "manual save") -> dict[str, object]:
    """Write a replayable organism state file and return storage metadata."""

    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)
    payload = loop_to_state(loop, seed=seed, note=note)
    out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    return {"path": str(out), "tick": loop.tick, "version": STATE_VERSION, "note": note, "seed": seed, "saved": True}


def load_loop(path: str | Path = DEFAULT_STATE_PATH) -> tuple[OrganismLoop, dict[str, object]]:
    """Load an organism loop from an explicit JSON brain-state file."""

    source = Path(path)
    payload = json.loads(source.read_text(encoding="utf-8"))
    if int(payload.get("version", -1)) != STATE_VERSION:
        raise ValueError(f"Unsupported KishSyn brain-state version: {payload.get('version')!r}")
    loop = state_to_loop(payload)
    return loop, {"path": str(source), "tick": loop.tick, "version": STATE_VERSION, "seed": payload.get("seed"), "loaded": True, "note": payload.get("note", "")}


def loop_to_state(loop: OrganismLoop, *, seed: int | None, note: str) -> dict[str, object]:
    return {
        "version": STATE_VERSION,
        "note": note,
        "seed": seed,
        "tick": loop.tick,
        "body": asdict(loop.body),
        "world": world_to_state(loop.world),
        "graph": graph_to_state(loop.graph),
        "memory": memory_to_state(loop.memory),
        "workspace": {"events": list(loop.workspace.events)},
        "self_model": {"samples": [asdict(sample) for sample in loop.self_model.samples]},
        "route_memory": {
            "capacity": loop.route_memory.capacity,
            "steps": [asdict(step) for step in loop.route_memory.steps],
            "best_places": loop.route_memory.best_places,
        },
        "comfort_memory": {
            "capacity": loop.comfort_memory.capacity,
            "basins": [asdict(basin) for basin in loop.comfort_memory.basins.values()],
            "history": loop.comfort_memory.history,
        },
        "body_map": {
            "bindings": [asdict(binding) for binding in loop.body_map.bindings.values()],
            "history": loop.body_map.history,
        },
        "development": {
            "error_history": list(loop.development.error_history),
            "mode_history": list(loop.development.mode_history),
            "progress_history": list(loop.development.progress_history),
            "last_focus": asdict(loop.development.last_focus),
        },
        "focus_gate": loop.focus_gate.state(),
        "moment_ledger": loop.moment_ledger.state(),
        "binding_engine": loop.binding_engine.state(),
        "anatomy_growth": loop.anatomy_growth.state(),
        "intent_model": loop.intent_model.state(),
        "counterfactual_replay": loop.counterfactual_replay.state(),
        "sensory_hub": loop.sensory_hub.state(),
        "expression_surface": loop.expression_surface.state(),
        "emotional_regulation": loop.emotional_regulation.state(),
        "contextual_affordance": loop.contextual_affordance.state(),
        "object_file": loop.object_file.state(),
        "memory_economy": loop.memory_economy.state(),
        "play_drive": loop.play_drive.state(),
        "grounded_language": loop.grounded_language.state(),
        "os_observation": loop.os_observation.state(),
        "interface_affordance": loop.interface_affordance.state(),
        "dummy_bench": loop.dummy_bench.state(),
        "external_registry": loop.external_registry.state(),
        "runtime_shell_policy": loop.runtime_shell_policy.state(),
        "actor_profile": loop.actor_profile.as_dict(),
        "world_context": loop.world_context.as_dict(),
        "motor_experiment": {
            "stats": [asdict(stat) for stat in loop.motor_experimenter.stats.values()],
            "history": loop.motor_experimenter.history,
            "last_intent": asdict(loop.motor_experimenter.last_intent),
        },
        "symbol_goal": {
            "state": None if loop.symbol_goal.state is None else asdict(loop.symbol_goal.state),
            "activation_count": loop.symbol_goal.activation_count,
            "guided_attempts": loop.symbol_goal.guided_attempts,
            "guided_successes": loop.symbol_goal.guided_successes,
            "expired_count": loop.symbol_goal.expired_count,
            "last_evidence": list(loop.symbol_goal.last_evidence),
            "last_guided_score": loop.symbol_goal.last_guided_score,
        },
        "priority": {
            "honor_count": loop.priority.honor_count,
            "defer_count": loop.priority.defer_count,
            "survival_override_count": loop.priority.survival_override_count,
            "resume_count": loop.priority.resume_count,
            "last_mode": loop.priority.last_mode,
            "last_reason": loop.priority.last_reason,
            "last_symbol_bias": loop.priority.last_symbol_bias,
            "last_survival_pressure": loop.priority.last_survival_pressure,
            "last_symbol_strength": loop.priority.last_symbol_strength,
            "was_deferred": loop.priority._was_deferred,
        },
        "text_crib": loop.text_crib.state(),
        "tutor": loop.tutor.state(),
        "autopilot": loop.autopilot.state(),
        "runtime": {
            "replay_interval": loop.replay_interval,
            "current_goal_id": loop.current_goal_id,
            "goal_started_tick": loop.goal_started_tick,
            "last_trace": None if loop.last_trace is None else trace_to_state(loop.last_trace),
        },
    }


def state_to_loop(payload: dict[str, Any]) -> OrganismLoop:
    seed = int(payload.get("seed") or 1)
    world = world_from_state(payload["world"], seed=seed)
    graph = graph_from_state(payload["graph"])
    loop = OrganismLoop(seed=seed, world=world, graph=graph)
    loop.tick = int(payload.get("tick", world.tick))
    loop.body = BodyState(**payload.get("body", {})).clipped()
    loop.memory = memory_from_state(payload.get("memory", {}))
    loop.workspace = workspace_from_state(payload.get("workspace", {}))
    loop.self_model = self_model_from_state(payload.get("self_model", {}))
    loop.route_memory = route_memory_from_state(payload.get("route_memory", {}))
    loop.comfort_memory = comfort_memory_from_state(payload.get("comfort_memory", {}))
    loop.body_map = body_map_from_state(payload.get("body_map", {}))
    loop.development = development_from_state(payload.get("development", {}))
    loop.focus_gate = FocusGate.from_state(payload.get("focus_gate", {}))
    loop.moment_ledger = MomentLedger.from_state(payload.get("moment_ledger", {}))
    loop.binding_engine = BindingEngine.from_state(payload.get("binding_engine", {}))
    loop.anatomy_growth = AnatomyGrowthEngine.from_state(payload.get("anatomy_growth", {}))
    loop.intent_model = IntentModel.from_state(payload.get("intent_model", {}))
    loop.counterfactual_replay = CounterfactualReplayEngine.from_state(payload.get("counterfactual_replay", {}))
    loop.sensory_hub = SensoryAdapterHub.from_state(payload.get("sensory_hub", {}))
    loop.expression_surface = ExpressionSurface.from_state(payload.get("expression_surface", {}))
    loop.emotional_regulation = EmotionalRegulationField.from_state(payload.get("emotional_regulation", {}))
    loop.contextual_affordance = ContextualAffordanceCortex.from_state(payload.get("contextual_affordance", {}))
    loop.object_file = ObjectFileCortex.from_state(payload.get("object_file", {}))
    loop.memory_economy = MemoryPressureGovernor.from_state(payload.get("memory_economy", {}))
    loop.play_drive = IntrinsicPlayDrive.from_state(payload.get("play_drive", {}))
    loop.grounded_language = GroundedLanguageCortex.from_state(payload.get("grounded_language", {}))
    loop.os_observation = OSObservationSubstrate.from_state(payload.get("os_observation", {}))
    loop.interface_affordance = InterfaceAffordanceCortex.from_state(payload.get("interface_affordance", {}))
    loop.dummy_bench = DummyBenchActuator.from_state(payload.get("dummy_bench", {}))
    loop.external_registry = ExternalAdapterRegistry.from_state(payload.get("external_registry", {}))
    loop.runtime_shell_policy = RuntimeShellPolicy.from_state(payload.get("runtime_shell_policy", {}))
    loop.actor_profile = ActorProfile(**payload.get("actor_profile", {}))
    loop.world_context = WorldContext(**payload.get("world_context", {}))
    loop.motor_experimenter = motor_experimenter_from_state(payload.get("motor_experiment", {}))
    loop.symbol_goal = symbol_goal_from_state(payload.get("symbol_goal", {}))
    loop.priority = priority_from_state(payload.get("priority", {}))
    loop.text_crib = text_crib_from_state(payload.get("text_crib", {}))
    loop.tutor = tutor_from_state(payload.get("tutor", {}))
    loop.autopilot = autopilot_from_state(payload.get("autopilot", {}))
    runtime = payload.get("runtime", {})
    loop.replay_interval = int(runtime.get("replay_interval", loop.replay_interval))
    loop.current_goal_id = runtime.get("current_goal_id")
    loop.goal_started_tick = int(runtime.get("goal_started_tick", 0))
    loop.last_trace = None if runtime.get("last_trace") is None else trace_from_state(runtime["last_trace"])
    return loop


def world_to_state(world: MiniEcologyWorld) -> dict[str, object]:
    return {
        "width": world.width,
        "height": world.height,
        "agent_x": world.agent_x,
        "agent_y": world.agent_y,
        "tick": world.tick,
        "rng_state": repr(world.rng.getstate()),
        "objects": [asdict(obj) for obj in world.objects.values()],
        "terrain": [{"x": x, "y": y, "terrain": terrain} for (x, y), terrain in world.terrain.items()],
        "cell_charge": [{"x": x, "y": y, "value": value} for (x, y), value in world.cell_charge.items()],
        "visit_counts": [{"x": x, "y": y, "value": value} for (x, y), value in world.visit_counts.items()],
        "last_visit_tick": [{"x": x, "y": y, "value": value} for (x, y), value in world.last_visit_tick.items()],
        "depletion_count": world.depletion_count,
        "migration_count": world.migration_count,
        "spawn_count": world.spawn_count,
        "last_events": world.last_events,
    }


def world_from_state(data: dict[str, Any], *, seed: int) -> MiniEcologyWorld:
    world = MiniEcologyWorld(seed=seed, width=int(data.get("width", 31)), height=int(data.get("height", 23)))
    world.agent_x = int(data.get("agent_x", world.agent_x))
    world.agent_y = int(data.get("agent_y", world.agent_y))
    world.tick = int(data.get("tick", world.tick))
    world.objects = {item["object_id"]: WorldObject(**_tuple_fix_object(item)) for item in data.get("objects", [])}
    terrain_items = data.get("terrain", [])
    if terrain_items:
        world.terrain = {(int(item["x"]), int(item["y"])): str(item["terrain"]) for item in terrain_items}
    charge_items = data.get("cell_charge", [])
    if charge_items:
        world.cell_charge = {(int(item["x"]), int(item["y"])): float(item["value"]) for item in charge_items}
    world.visit_counts = {(int(item["x"]), int(item["y"])): int(item["value"]) for item in data.get("visit_counts", [])}
    world.last_visit_tick = {(int(item["x"]), int(item["y"])): int(item["value"]) for item in data.get("last_visit_tick", [])}
    world.depletion_count = int(data.get("depletion_count", 0))
    world.migration_count = int(data.get("migration_count", 0))
    world.spawn_count = int(data.get("spawn_count", 0))
    world.last_events = list(data.get("last_events", []))
    if data.get("rng_state"):
        rng = Random(seed)
        rng.setstate(ast.literal_eval(data["rng_state"]))
        world.rng = rng
    return world


def _tuple_fix_object(item: dict[str, Any]) -> dict[str, Any]:
    obj = dict(item)
    if isinstance(obj.get("mobility"), list):
        obj["mobility"] = tuple(obj["mobility"])
    return obj


def graph_to_state(graph: NeuralGrowthGraph) -> dict[str, object]:
    return {
        "concept_updates": graph.concept_updates,
        "symbol_binding_updates": graph.symbol_binding_updates,
        "neurons": [asdict(neuron) for neuron in graph.neurons.values()],
        "synapses": [asdict(synapse) for synapse in graph.synapses.values()],
    }


def graph_from_state(data: dict[str, Any]) -> NeuralGrowthGraph:
    graph = NeuralGrowthGraph()
    graph.concept_updates = int(data.get("concept_updates", 0))
    graph.symbol_binding_updates = int(data.get("symbol_binding_updates", 0))
    graph.neurons = {item["node_id"]: Neuron(**item) for item in data.get("neurons", [])}
    graph.synapses = {(item["source"], item["target"]): Synapse(**item) for item in data.get("synapses", [])}
    return graph


def memory_to_state(memory: TraceMemory) -> dict[str, object]:
    return {
        "capacity": memory.traces.maxlen or 512,
        "traces": [trace_to_state(trace) for trace in memory.traces],
        "replays": [asdict(event) for event in memory.replays],
    }


def memory_from_state(data: dict[str, Any]) -> TraceMemory:
    memory = TraceMemory(capacity=int(data.get("capacity", 512)))
    memory.traces = deque((trace_from_state(item) for item in data.get("traces", [])), maxlen=memory.traces.maxlen)
    memory.replays = [ReplayEvent(**item) for item in data.get("replays", [])]
    return memory


def workspace_from_state(data: dict[str, Any]) -> GlobalWorkspace:
    workspace = GlobalWorkspace()
    workspace.events = deque(data.get("events", []), maxlen=workspace.events.maxlen)
    return workspace


def self_model_from_state(data: dict[str, Any]) -> SelfBoundaryModel:
    model = SelfBoundaryModel()
    model.samples = [SelfBoundaryAssessment(**item) for item in data.get("samples", [])]
    return model


def route_memory_from_state(data: dict[str, Any]) -> RouteMemory:
    memory = RouteMemory(capacity=int(data.get("capacity", 256)))
    memory.steps = [RouteStep(**item) for item in data.get("steps", [])]
    memory.best_places = {str(k): float(v) for k, v in data.get("best_places", {}).items()}
    return memory


def comfort_memory_from_state(data: dict[str, Any]) -> ComfortAttractorMemory:
    memory = ComfortAttractorMemory(capacity=int(data.get("capacity", 96)))
    memory.basins = {item["place_key"]: ComfortBasin(**item) for item in data.get("basins", [])}
    memory.history = list(data.get("history", []))
    return memory


def body_map_from_state(data: dict[str, Any]) -> ProtoBodyMap:
    body_map = ProtoBodyMap()
    body_map.bindings = {item["channel"]: MotorBinding(**item) for item in data.get("bindings", [])}
    body_map.history = list(data.get("history", []))
    return body_map


def development_from_state(data: dict[str, Any]) -> DevelopmentalRegulator:
    regulator = DevelopmentalRegulator()
    regulator.error_history = deque((float(v) for v in data.get("error_history", [])), maxlen=regulator.error_history.maxlen)
    regulator.mode_history = deque((str(v) for v in data.get("mode_history", [])), maxlen=regulator.mode_history.maxlen)
    regulator.progress_history = deque((float(v) for v in data.get("progress_history", [])), maxlen=regulator.progress_history.maxlen)
    if data.get("last_focus"):
        regulator.last_focus = LearningFocus(**data["last_focus"])
    return regulator


def motor_experimenter_from_state(data: dict[str, Any]) -> MotorExperimenter:
    experimenter = MotorExperimenter()
    experimenter.stats = {item["channel"]: MotorProbeStats(**item) for item in data.get("stats", [])}
    experimenter.history = list(data.get("history", []))
    if data.get("last_intent"):
        experimenter.last_intent = MotorExperimentIntent(**data["last_intent"])
    return experimenter


def symbol_goal_from_state(data: dict[str, Any]) -> ActiveSymbolGoalMemory:
    goal = ActiveSymbolGoalMemory()
    goal.state = None if data.get("state") is None else SymbolGoalState(**data["state"])
    goal.activation_count = int(data.get("activation_count", 0))
    goal.guided_attempts = int(data.get("guided_attempts", 0))
    goal.guided_successes = int(data.get("guided_successes", 0))
    goal.expired_count = int(data.get("expired_count", 0))
    goal.last_evidence = tuple(data.get("last_evidence", []))
    goal.last_guided_score = float(data.get("last_guided_score", 0.0))
    return goal


def priority_from_state(data: dict[str, Any]) -> PriorityArbitrator:
    priority = PriorityArbitrator()
    priority.honor_count = int(data.get("honor_count", 0))
    priority.defer_count = int(data.get("defer_count", 0))
    priority.survival_override_count = int(data.get("survival_override_count", 0))
    priority.resume_count = int(data.get("resume_count", 0))
    priority.last_mode = str(data.get("last_mode", "none"))
    priority.last_reason = str(data.get("last_reason", "no arbitration yet"))
    priority.last_symbol_bias = float(data.get("last_symbol_bias", 0.0))
    priority.last_survival_pressure = float(data.get("last_survival_pressure", 0.0))
    priority.last_symbol_strength = float(data.get("last_symbol_strength", 0.0))
    priority._was_deferred = bool(data.get("was_deferred", False))
    return priority


def text_crib_from_state(data: dict[str, Any]) -> TextCribMemory:
    crib = TextCribMemory()
    crib.restore(data)
    return crib




def autopilot_from_state(data: dict[str, Any]) -> AutonomousTutorCurriculum:
    autopilot = AutonomousTutorCurriculum()
    autopilot.restore(data)
    return autopilot


def tutor_from_state(data: dict[str, Any]) -> TutorSurface:
    tutor = TutorSurface()
    tutor.restore(data)
    return tutor

def trace_to_state(trace: TickTrace) -> dict[str, object]:
    return {
        "tick": trace.tick,
        "frame": frame_to_state(trace.frame),
        "body_before": asdict(trace.body_before),
        "action": asdict(trace.action),
        "prediction": {**asdict(trace.prediction), "evidence": list(trace.prediction.evidence)},
        "outcome": asdict(trace.outcome),
        "body_after": asdict(trace.body_after),
        "prediction_error": trace.prediction_error,
        "plasticity": [asdict(event) for event in trace.plasticity],
        "workspace": list(trace.workspace),
        "efference": None if trace.efference is None else efference_to_state(trace.efference),
        "self_causation": trace.self_causation,
        "world_causation": trace.world_causation,
        "causation_label": trace.causation_label,
        "world_events": list(trace.world_events),
    }


def trace_from_state(data: dict[str, Any]) -> TickTrace:
    return TickTrace(
        tick=int(data["tick"]),
        frame=frame_from_state(data["frame"]),
        body_before=BodyState(**data["body_before"]),
        action=Action(**data["action"]),
        prediction=prediction_from_state(data["prediction"]),
        outcome=Outcome(**data["outcome"]),
        body_after=BodyState(**data["body_after"]),
        prediction_error=float(data["prediction_error"]),
        plasticity=tuple(PlasticityEvent(**event) for event in data.get("plasticity", [])),
        workspace=tuple(data.get("workspace", [])),
        efference=None if data.get("efference") is None else efference_from_state(data["efference"]),
        self_causation=float(data.get("self_causation", 0.0)),
        world_causation=float(data.get("world_causation", 0.0)),
        causation_label=str(data.get("causation_label", "unknown")),
        world_events=tuple(data.get("world_events", [])),
    )


def frame_to_state(frame: SensoryFrame) -> dict[str, object]:
    return {"tick": frame.tick, "features": [asdict(feature) for feature in frame.features], "raw": frame.raw}


def frame_from_state(data: dict[str, Any]) -> SensoryFrame:
    return SensoryFrame(
        tick=int(data["tick"]),
        features=tuple(SensoryFeature(**feature) for feature in data.get("features", [])),
        raw=dict(data.get("raw", {})),
    )


def prediction_from_state(data: dict[str, Any]) -> Prediction:
    return Prediction(
        expected_outcome=data.get("expected_outcome", "neutral"),
        confidence=float(data.get("confidence", 0.0)),
        evidence=tuple(data.get("evidence", ())),
    )


def efference_to_state(efference: EfferenceCopy) -> dict[str, object]:
    return {"tick": efference.tick, "action": asdict(efference.action), "prediction": {**asdict(efference.prediction), "evidence": list(efference.prediction.evidence)}}


def efference_from_state(data: dict[str, Any]) -> EfferenceCopy:
    return EfferenceCopy(tick=int(data["tick"]), action=Action(**data["action"]), prediction=prediction_from_state(data["prediction"]))
