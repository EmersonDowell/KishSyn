"""Bounded external tutor surface for KishSyn Core.

The tutor is not KishSyn's mind. It is an environmental teacher that can
present weak, traceable teaching proposals as sensory text and plastic graph
hints. The organism still has to retain, use, and prove those pathways through
its own graph, priority, symbol-goal, and action loops.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
import os
import re

from .contracts import PlasticityEvent
from .neural_graph import NeuralGrowthGraph
from .symbol_goal import ActiveSymbolGoalMemory
from .text_crib import TextCribMemory

_WORD_RE = re.compile(r"[a-zA-Z0-9_]+")

COLOR_TERMS = {
    "red", "blue", "green", "yellow", "purple", "orange", "black", "white", "gray", "brown", "pink",
}
SHAPE_TERMS = {
    "round", "circle", "square", "triangle", "jagged", "soft", "line", "star", "cross", "diamond",
}
NUMBER_WORDS = {
    "zero": "0", "one": "1", "two": "2", "three": "3", "four": "4", "five": "5",
    "six": "6", "seven": "7", "eight": "8", "nine": "9", "ten": "10",
}
TEACH_WORDS = {"teach", "learn", "means", "label", "name", "this", "that", "is", "are"}


@dataclass(frozen=True)
class TutorTerm:
    kind: str
    token: str
    paired_feature: str
    concept_family: str


@dataclass(frozen=True)
class TutorExchange:
    tick: int
    source: str
    user_text: str
    tutor_text: str
    mode: str
    intent: str
    terms: tuple[TutorTerm, ...]
    plasticity_count: int
    note: str


class TutorSurface:
    """External teacher surface with strict boundaries.

    A tutor exchange can introduce terms and weak graph hints. It cannot select
    actions, rewrite memories, claim consciousness, or answer as KishSyn. All
    generated learning evidence is visible and ablatable through the graph.
    """

    def __init__(self, *, history_limit: int = 64) -> None:
        self.history: deque[TutorExchange] = deque(maxlen=history_limit)
        self.input_count = 0
        self.lesson_count = 0
        self.plasticity_count = 0
        self.goal_activation_count = 0
        self.last_mode = "local"
        self.last_intent = "none"
        self.last_note = "no tutor exchanges yet"
        self.api_key_detected = bool(os.environ.get("OPENAI_API_KEY"))
        self.external_api_enabled = False

    def receive(
        self,
        *,
        tick: int,
        message: str,
        text_crib: TextCribMemory,
        graph: NeuralGrowthGraph,
        symbol_goal: ActiveSymbolGoalMemory,
        source: str = "user",
        mode: str = "local",
    ) -> tuple[PlasticityEvent, ...]:
        cleaned = message.strip()[:500]
        words = tuple(_WORD_RE.findall(cleaned.lower()))
        terms = self._extract_terms(words)
        intent = self._intent(words, terms)
        tutor_text = self._lesson_text(terms=terms, intent=intent, original=cleaned)

        self.input_count += 1
        self.lesson_count += 1
        self.last_mode = "local" if mode != "external" else "external-disabled"
        self.last_intent = intent
        self.last_note = "external API disabled; local bounded tutor used" if mode == "external" else "local bounded tutor used"

        # The user's words and the tutor's lesson both enter through the text crib.
        # This preserves the sensory route instead of directly mutating a parser.
        if cleaned:
            text_crib.receive_text(tick=tick, text=cleaned, source=source, ttl=22)
        text_crib.receive_text(tick=tick, text=tutor_text, source="tutor", ttl=42)

        events = list(self._teach_terms(tick=tick, terms=terms, graph=graph))
        best_token = self._best_goal_token(terms=terms, graph=graph)
        if best_token:
            events.extend(symbol_goal.activate_token(
                tick=tick,
                graph=graph,
                token=best_token,
                source_target=None,
                reason=f"tutor surfaced term {best_token}",
                ttl=48,
            ))
            self.goal_activation_count += 1

        self.plasticity_count += len(events)
        self.history.append(TutorExchange(
            tick=tick,
            source=source[:32] or "user",
            user_text=cleaned,
            tutor_text=tutor_text,
            mode=self.last_mode,
            intent=intent,
            terms=terms,
            plasticity_count=len(events),
            note=self.last_note,
        ))
        return tuple(events)

    def snapshot(self) -> dict[str, object]:
        return {
            "input_count": self.input_count,
            "lesson_count": self.lesson_count,
            "plasticity_count": self.plasticity_count,
            "goal_activation_count": self.goal_activation_count,
            "last_mode": self.last_mode,
            "last_intent": self.last_intent,
            "last_note": self.last_note,
            "api_key_detected": self.api_key_detected,
            "external_api_enabled": self.external_api_enabled,
            "history": [self._exchange_view(item) for item in list(self.history)[-8:]],
        }

    def state(self) -> dict[str, object]:
        return {
            "input_count": self.input_count,
            "lesson_count": self.lesson_count,
            "plasticity_count": self.plasticity_count,
            "goal_activation_count": self.goal_activation_count,
            "last_mode": self.last_mode,
            "last_intent": self.last_intent,
            "last_note": self.last_note,
            "history": [self._exchange_state(item) for item in self.history],
        }

    def restore(self, data: dict[str, object]) -> None:
        self.history.clear()
        self.input_count = int(data.get("input_count", 0))
        self.lesson_count = int(data.get("lesson_count", 0))
        self.plasticity_count = int(data.get("plasticity_count", 0))
        self.goal_activation_count = int(data.get("goal_activation_count", 0))
        self.last_mode = str(data.get("last_mode", "local"))
        self.last_intent = str(data.get("last_intent", "restored"))
        self.last_note = str(data.get("last_note", "restored tutor surface"))
        self.api_key_detected = bool(os.environ.get("OPENAI_API_KEY"))
        self.external_api_enabled = False
        for item in data.get("history", []):
            if isinstance(item, dict):
                terms = tuple(
                    TutorTerm(
                        kind=str(term.get("kind", "unknown")),
                        token=str(term.get("token", "")),
                        paired_feature=str(term.get("paired_feature", "")),
                        concept_family=str(term.get("concept_family", "")),
                    )
                    for term in item.get("terms", []) if isinstance(term, dict)
                )
                self.history.append(TutorExchange(
                    tick=int(item.get("tick", 0)),
                    source=str(item.get("source", "user")),
                    user_text=str(item.get("user_text", "")),
                    tutor_text=str(item.get("tutor_text", "")),
                    mode=str(item.get("mode", "local")),
                    intent=str(item.get("intent", "restored")),
                    terms=terms,
                    plasticity_count=int(item.get("plasticity_count", 0)),
                    note=str(item.get("note", "restored")),
                ))

    def _teach_terms(self, *, tick: int, terms: tuple[TutorTerm, ...], graph: NeuralGrowthGraph) -> tuple[PlasticityEvent, ...]:
        events: list[PlasticityEvent] = []
        for term in terms:
            token_node = f"symbol:token={term.token}"
            tutor_node = f"tutor:{term.kind}={term.token}"
            graph.ensure_neuron(tutor_node, kind="tutor", label=f"{term.kind}={term.token}", tick=tick)
            graph.ensure_neuron(token_node, kind="symbol", label=f"token={term.token}", tick=tick)
            graph.activate(tutor_node, amount=0.68, tick=tick)
            graph.activate(token_node, amount=0.58, tick=tick)
            events.append(graph.reinforce(tutor_node, token_node, amount=0.040, tick=tick, reason="external tutor exposed token"))
            events.append(graph.reinforce(token_node, tutor_node, amount=0.018, tick=tick, reason="token recalls tutor exposure"))
            concepts = graph.concepts_for_feature(term.paired_feature)
            for concept in concepts:
                graph.ensure_neuron(concept, kind="concept", label=concept.split(":", 1)[1], tick=tick)
                graph.activate(concept, amount=0.54, tick=tick)
                events.append(graph.reinforce(tutor_node, concept, amount=0.030, tick=tick, reason="external tutor proposed concept"))
                events.append(graph.reinforce(token_node, concept, amount=0.055, tick=tick, reason="weak tutor symbol proposal"))
                events.append(graph.reinforce(concept, token_node, amount=0.026, tick=tick, reason="concept can recall taught word"))
                graph.symbol_binding_updates += 1
        return tuple(events)

    def _extract_terms(self, words: tuple[str, ...]) -> tuple[TutorTerm, ...]:
        terms: list[TutorTerm] = []
        seen: set[tuple[str, str]] = set()
        for word in words[:32]:
            term: TutorTerm | None = None
            if word in COLOR_TERMS:
                term = TutorTerm("color", word, f"vision:paired_color={word}", "color")
            elif word in SHAPE_TERMS:
                normalized = "round" if word == "circle" else word
                term = TutorTerm("shape", word, f"vision:paired_shape={normalized}", "shape")
            elif word in NUMBER_WORDS:
                term = TutorTerm("count", word, f"vision:paired_count={NUMBER_WORDS[word]}", "count")
            elif word.isdigit() and 0 <= int(word) <= 20:
                term = TutorTerm("count", word, f"vision:paired_count={word}", "count")
            elif len(word) == 1 and word.isalpha():
                term = TutorTerm("glyph", word, f"vision:paired_glyph={word.upper()}", "glyph")
            if term is None:
                continue
            key = (term.kind, term.token)
            if key not in seen:
                terms.append(term)
                seen.add(key)
        return tuple(terms[:12])

    def _intent(self, words: tuple[str, ...], terms: tuple[TutorTerm, ...]) -> str:
        if any(word in TEACH_WORDS for word in words):
            return "explicit_teach"
        if "?" in " ".join(words):
            return "question"
        if terms:
            return "implicit_label_exposure"
        return "open_text_exposure"

    def _lesson_text(self, *, terms: tuple[TutorTerm, ...], intent: str, original: str) -> str:
        if not terms:
            return f"tutor observes text {original[:120]}"
        clauses = []
        for term in terms[:8]:
            clauses.append(f"teach {term.concept_family} {term.token}")
        return " ; ".join(clauses)

    def _best_goal_token(self, *, terms: tuple[TutorTerm, ...], graph: NeuralGrowthGraph) -> str:
        best = ""
        best_score = 0.0
        for term in terms:
            token_node = f"symbol:token={term.token}"
            score = 0.0
            for concept in graph.concepts_for_feature(term.paired_feature):
                score = max(score, graph.weight(token_node, concept))
            if score > best_score:
                best = term.token
                best_score = score
        return best if best_score > 0.012 else ""

    def _exchange_view(self, item: TutorExchange) -> dict[str, object]:
        return {
            "tick": item.tick,
            "source": item.source,
            "user_text": item.user_text,
            "tutor_text": item.tutor_text,
            "mode": item.mode,
            "intent": item.intent,
            "terms": [self._term_view(term) for term in item.terms],
            "plasticity_count": item.plasticity_count,
            "note": item.note,
        }

    def _exchange_state(self, item: TutorExchange) -> dict[str, object]:
        return self._exchange_view(item)

    def _term_view(self, term: TutorTerm) -> dict[str, str]:
        return {
            "kind": term.kind,
            "token": term.token,
            "paired_feature": term.paired_feature,
            "concept_family": term.concept_family,
        }
