"""Interface affordance discovery for desktop/program surfaces.

M14 learns that observed UI elements have roles and possible interaction shapes
without performing those interactions. A button may imply a click-like candidate;
a text field may imply type-text; a console may imply read/inspect. Those are
contextual affordance hypotheses only. They may propose and be audited, never
actuate before later dummy/supervised/certified gates.
"""

from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass
from typing import Any, Literal

from .contracts import PlasticityEvent
from .external_interface import ExternalAdapterRegistry
from .neural_graph import NeuralGrowthGraph

InterfaceActionKind = Literal["inspect", "read", "click", "type_text", "scroll", "unknown"]

_WRITE_LIKE = {"click", "type_text", "scroll"}


@dataclass(frozen=True)
class UIElementSignature:
    """Reusable signature for a kind of interface element.

    Pattern: Flyweight Value Object. The signature intentionally ignores tick and
    raw screen coordinates so repeated observations strengthen one UI pattern
    instead of growing per-frame junk anatomy.
    """

    signature_id: str
    role: str
    label: str
    app: str
    surface_kind: str = "window"

    @property
    def node_id(self) -> str:
        return f"ui_element_kind:{self.signature_id}"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class InterfaceAffordanceContract:
    """Governed output for an interface affordance candidate.

    Pattern: Contract Object. M14 may expose proposals for attention, review, and
    future dummy benches, but it cannot actuate the OS or an application.
    """

    element_signature: str
    action_kind: InterfaceActionKind
    surface_id: str
    confidence: float
    risk: float
    write_like: bool
    may_propose: bool = True
    may_actuate: bool = False
    reason: str = "M14 interface affordances are observation-grounded proposals only."

    def as_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["confidence"] = round(float(self.confidence), 4)
        payload["risk"] = round(float(self.risk), 4)
        return payload


@dataclass
class InterfaceAffordanceRecord:
    """Reusable evidence record for a UI element affordance.

    Pattern: Repository Entity + Flyweight. Many observations of the same button,
    field, menu, or console role update one record. Nothing here is a live OS
    handle and nothing here is executable.
    """

    record_id: str
    element_signature: str
    role: str
    label: str
    app: str
    surface_id: str
    action_kind: InterfaceActionKind
    write_like: bool
    first_tick: int
    last_tick: int
    evidence_count: int = 0
    allowed_count: int = 0
    blocked_count: int = 0
    confidence_total: float = 0.0

    def observe(self, *, tick: int, confidence: float, allowed: bool) -> None:
        self.evidence_count += 1
        self.last_tick = int(tick)
        self.confidence_total += max(0.0, min(1.0, float(confidence)))
        if allowed:
            self.allowed_count += 1
        else:
            self.blocked_count += 1

    @property
    def mean_confidence(self) -> float:
        return self.confidence_total / max(1, self.evidence_count)

    def contract(self) -> InterfaceAffordanceContract:
        risk = 0.02 if not self.write_like else 0.12
        return InterfaceAffordanceContract(
            element_signature=self.element_signature,
            action_kind=self.action_kind,
            surface_id=self.surface_id,
            confidence=min(1.0, self.mean_confidence * min(1.0, 0.35 + self.evidence_count / 8.0)),
            risk=risk,
            write_like=self.write_like,
            may_propose=True,
            may_actuate=False,
            reason="interface affordance discovered from observation; actuation remains blocked until later dummy/supervised gates",
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "record_id": self.record_id,
            "element_signature": self.element_signature,
            "role": self.role,
            "label": self.label,
            "app": self.app,
            "surface_id": self.surface_id,
            "action_kind": self.action_kind,
            "write_like": self.write_like,
            "first_tick": self.first_tick,
            "last_tick": self.last_tick,
            "evidence_count": self.evidence_count,
            "allowed_count": self.allowed_count,
            "blocked_count": self.blocked_count,
            "mean_confidence": round(float(self.mean_confidence), 4),
            "contract": self.contract().as_dict(),
        }

    def state(self) -> dict[str, Any]:
        payload = self.as_dict()
        payload["confidence_total"] = self.confidence_total
        return payload

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "InterfaceAffordanceRecord":
        return cls(
            record_id=str(data.get("record_id", "unknown")),
            element_signature=str(data.get("element_signature", "unknown")),
            role=str(data.get("role", "unknown")),
            label=str(data.get("label", "")),
            app=str(data.get("app", "unknown_app")),
            surface_id=str(data.get("surface_id", "unknown_surface")),
            action_kind=str(data.get("action_kind", "unknown")),  # type: ignore[arg-type]
            write_like=bool(data.get("write_like", False)),
            first_tick=int(data.get("first_tick", 0)),
            last_tick=int(data.get("last_tick", 0)),
            evidence_count=int(data.get("evidence_count", 0)),
            allowed_count=int(data.get("allowed_count", 0)),
            blocked_count=int(data.get("blocked_count", 0)),
            confidence_total=float(data.get("confidence_total", float(data.get("mean_confidence", 0.0)) * max(1, int(data.get("evidence_count", 0))))),
        )


class InterfaceAffordanceCortex:
    """Learns UI roles and proposed affordances from observation frames.

    Pattern: Facade + Repository + Strategy. Platform-specific observers feed
    desktop frames into this stable facade; action-shape inference stays small,
    inspectable, and replaceable; stored records are reusable anatomy, not logs.
    """

    def __init__(self, *, capacity: int = 512, history_limit: int = 96) -> None:
        self.capacity = max(32, int(capacity))
        self.records: dict[str, InterfaceAffordanceRecord] = {}
        self.signatures: dict[str, UIElementSignature] = {}
        self.history: deque[dict[str, Any]] = deque(maxlen=max(16, int(history_limit)))
        self.record_updates = 0
        self.contract_count = 0
        self.write_like_blocked_count = 0
        self.actuation_grant_count = 0

    def observe_frame(
        self,
        *,
        tick: int,
        frame: Any,
        registry: ExternalAdapterRegistry,
        graph: NeuralGrowthGraph | None = None,
    ) -> tuple[PlasticityEvent, ...]:
        events: list[PlasticityEvent] = []
        surface_id = str(getattr(frame, "surface_id", "unknown_surface"))
        app = str(getattr(frame, "active_application", "unknown_app"))
        title = str(getattr(frame, "title", ""))
        elements = tuple(getattr(frame, "elements", ()) or ())[:64]
        for element in elements:
            signature = _element_signature(element=element, app=app, surface_id=surface_id)
            self.signatures[signature.signature_id] = signature
            action_kinds = _candidate_actions(element)
            for action_kind in action_kinds:
                record_id = _record_id(surface_id=surface_id, signature=signature, action_kind=action_kind)
                write_like = action_kind in _WRITE_LIKE
                external_id = _external_affordance_id(surface_id=surface_id, element_id=str(getattr(element, "element_id", "element")), action_kind=action_kind)
                external = registry.affordances.get(external_id)
                allowed = external in registry.allowed_affordances() if external is not None else (not write_like)
                confidence = float(getattr(element, "confidence", 0.0) or 0.0)
                if external is not None:
                    confidence = max(confidence, float(external.confidence))
                record = self.records.get(record_id)
                if record is None:
                    record = InterfaceAffordanceRecord(
                        record_id=record_id,
                        element_signature=signature.signature_id,
                        role=signature.role,
                        label=signature.label,
                        app=signature.app,
                        surface_id=surface_id,
                        action_kind=action_kind,
                        write_like=write_like,
                        first_tick=int(tick),
                        last_tick=int(tick),
                    )
                    self.records[record_id] = record
                    self._trim()
                record.observe(tick=tick, confidence=confidence or 0.55, allowed=allowed)
                contract = record.contract()
                self.record_updates += 1
                self.contract_count += 1
                if contract.write_like and not contract.may_actuate:
                    self.write_like_blocked_count += 1
                if contract.may_actuate:
                    self.actuation_grant_count += 1
                self.history.append({
                    "tick": int(tick),
                    "surface_id": surface_id,
                    "title": title[:80],
                    "signature": signature.signature_id,
                    "action_kind": action_kind,
                    "write_like": write_like,
                    "allowed_by_external_contract": bool(allowed),
                    "may_actuate": contract.may_actuate,
                })
                if graph is not None:
                    events.extend(self._write_graph(graph=graph, tick=tick, signature=signature, record=record, contract=contract))
        return tuple(events)

    def contracts_for_surface(self, surface_id: str) -> tuple[InterfaceAffordanceContract, ...]:
        contracts = [record.contract() for record in self.records.values() if record.surface_id == surface_id]
        contracts.sort(key=lambda item: (-item.confidence, item.element_signature, item.action_kind))
        return tuple(contracts)

    def snapshot(self) -> dict[str, Any]:
        records = sorted((record.as_dict() for record in self.records.values()), key=lambda item: (-int(item["evidence_count"]), str(item["record_id"])))
        return {
            "record_count": len(self.records),
            "signature_count": len(self.signatures),
            "record_updates": self.record_updates,
            "contract_count": self.contract_count,
            "write_like_blocked_count": self.write_like_blocked_count,
            "actuation_grant_count": self.actuation_grant_count,
            "top_records": records[:12],
            "recent": list(self.history)[-8:],
            "law": "interface elements may form inspectable affordance proposals; M14 grants no OS actuation.",
        }

    def state(self) -> dict[str, Any]:
        return {
            "capacity": self.capacity,
            "record_updates": self.record_updates,
            "contract_count": self.contract_count,
            "write_like_blocked_count": self.write_like_blocked_count,
            "actuation_grant_count": self.actuation_grant_count,
            "signatures": [signature.as_dict() for signature in sorted(self.signatures.values(), key=lambda item: item.signature_id)],
            "records": [record.state() for record in sorted(self.records.values(), key=lambda item: item.record_id)],
            "history": list(self.history)[-96:],
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "InterfaceAffordanceCortex":
        cortex = cls(capacity=int(data.get("capacity", 512)))
        cortex.record_updates = int(data.get("record_updates", 0))
        cortex.contract_count = int(data.get("contract_count", 0))
        cortex.write_like_blocked_count = int(data.get("write_like_blocked_count", 0))
        cortex.actuation_grant_count = int(data.get("actuation_grant_count", 0))
        for item in data.get("signatures", []):
            if isinstance(item, dict):
                signature = UIElementSignature(
                    signature_id=str(item.get("signature_id", "unknown")),
                    role=str(item.get("role", "unknown")),
                    label=str(item.get("label", "")),
                    app=str(item.get("app", "unknown_app")),
                    surface_kind=str(item.get("surface_kind", "window")),
                )
                cortex.signatures[signature.signature_id] = signature
        for item in data.get("records", []):
            if isinstance(item, dict):
                record = InterfaceAffordanceRecord.from_state(item)
                cortex.records[record.record_id] = record
        for item in data.get("history", [])[-96:]:
            if isinstance(item, dict):
                cortex.history.append(dict(item))
        return cortex

    def _write_graph(self, *, graph: NeuralGrowthGraph, tick: int, signature: UIElementSignature, record: InterfaceAffordanceRecord, contract: InterfaceAffordanceContract) -> tuple[PlasticityEvent, ...]:
        events: list[PlasticityEvent] = []
        element_node = signature.node_id
        role_node = f"ui_role:{_safe(signature.role)}"
        action_node = f"interface_affordance:{record.action_kind}"
        surface_node = f"external_surface:{_safe(record.surface_id)}"
        app_node = f"external_app:{_safe(record.app)}"
        safety_node = "interface_contract:proposal_only" if not contract.may_actuate else "interface_contract:actuation_allowed"
        graph.ensure_neuron(element_node, kind="ui_element_kind", label=f"{signature.role}:{signature.label or signature.signature_id}"[:96], tick=tick)
        graph.ensure_neuron(role_node, kind="ui_role", label=signature.role, tick=tick)
        graph.ensure_neuron(action_node, kind="interface_affordance", label=record.action_kind, tick=tick)
        graph.ensure_neuron(surface_node, kind="external_surface", label=record.surface_id, tick=tick)
        graph.ensure_neuron(app_node, kind="external_app", label=record.app, tick=tick)
        graph.ensure_neuron(safety_node, kind="interface_contract", label="proposal only" if not contract.may_actuate else "actuation allowed", tick=tick)
        for node, amount in ((element_node, 0.56), (role_node, 0.48), (action_node, 0.46), (safety_node, 0.52)):
            graph.activate(node, amount=amount, tick=tick)
        events.append(graph.reinforce(surface_node, element_node, amount=0.025, tick=tick, reason="M14 interface element observed on external surface"))
        events.append(graph.reinforce(element_node, role_node, amount=0.024, tick=tick, reason="M14 UI element role binding"))
        events.append(graph.reinforce(element_node, action_node, amount=0.018 if not record.write_like else 0.012, tick=tick, reason="M14 interface affordance proposal binding"))
        events.append(graph.reinforce(action_node, safety_node, amount=0.026, tick=tick, reason="M14 affordance contract remains proposal-only"))
        events.append(graph.reinforce(app_node, element_node, amount=0.016, tick=tick, reason="M14 app-to-interface-pattern binding"))
        return tuple(events)

    def _trim(self) -> None:
        if len(self.records) <= self.capacity:
            return
        ordered = sorted(self.records.values(), key=lambda item: (item.evidence_count, item.last_tick, item.record_id))
        for record in ordered[: max(0, len(self.records) - self.capacity)]:
            self.records.pop(record.record_id, None)


def _candidate_actions(element: Any) -> tuple[InterfaceActionKind, ...]:
    role = str(getattr(element, "role", "unknown"))
    interactable = bool(getattr(element, "interactable", False))
    actions: list[InterfaceActionKind] = ["inspect"]
    if role in {"console", "file", "webview", "text_field"}:
        actions.append("read")
    if interactable and role in {"button", "menu", "icon", "webview", "file"}:
        actions.append("click")
    if interactable and role in {"text_field", "console"}:
        actions.append("type_text")
    if interactable and role in {"webview", "canvas"}:
        actions.append("scroll")
    return tuple(dict.fromkeys(actions))  # preserves order while de-duplicating


def _element_signature(*, element: Any, app: str, surface_id: str) -> UIElementSignature:
    role = _safe(getattr(element, "role", "unknown"))
    label = str(getattr(element, "label", "") or role)[:120]
    app_slug = _safe(app or "unknown_app")
    label_slug = _safe(label)
    signature_id = f"{app_slug}:{role}:{label_slug}"
    surface_kind = "console" if role == "console" else "window"
    return UIElementSignature(signature_id=signature_id[:160], role=role, label=label, app=app_slug, surface_kind=surface_kind)


def _record_id(*, surface_id: str, signature: UIElementSignature, action_kind: str) -> str:
    return f"{_safe(surface_id)}:{signature.signature_id}:{_safe(action_kind)}"[:220]


def _external_affordance_id(*, surface_id: str, element_id: str, action_kind: str) -> str:
    external_kind = "inspect" if action_kind in {"inspect", "read"} else action_kind
    prefix = "inspect" if external_kind == "inspect" else f"blocked_{external_kind}"
    return f"{prefix}:{_safe(surface_id)}:{_safe(element_id)}"


def _safe(value: object) -> str:
    text = "".join(ch.lower() if ch.isalnum() else "_" for ch in str(value).strip())
    text = "_".join(piece for piece in text.split("_") if piece)
    return (text or "unknown")[:96]
