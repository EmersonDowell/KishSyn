"""Run the formal M6 emotional-regulation-field lock evaluator."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from kishsyn_core.milestone import MilestoneM6LockEvaluator


def _parse_seeds(value: str) -> tuple[int, ...]:
    seeds = tuple(int(piece.strip()) for piece in value.split(",") if piece.strip())
    return seeds or (337,)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Run the KishSyn M6 milestone lock evaluator.")
    parser.add_argument("--seed", type=int, default=337)
    parser.add_argument("--seeds", default="337")
    parser.add_argument("--steps", type=int, default=160)
    parser.add_argument("--ablation-steps", type=int, default=24)
    parser.add_argument("--out", type=Path, default=Path("stores/_demo/milestone_m6_lock_report.json"))
    args = parser.parse_args(argv)
    report = MilestoneM6LockEvaluator().evaluate(seed=args.seed, seeds=_parse_seeds(args.seeds), steps=args.steps, ablation_steps=args.ablation_steps)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report.as_dict(), indent=2, sort_keys=True), encoding="utf-8")
    state = "LOCKED" if report.locked else "CANDIDATE"
    print(f"[KishSyn Core] M6 {state} score={report.summary_score} verdict={report.verdict!r}")
    print(f"[KishSyn Core] wrote {args.out}")
    return 0 if report.locked else 2


if __name__ == "__main__":
    raise SystemExit(main())
