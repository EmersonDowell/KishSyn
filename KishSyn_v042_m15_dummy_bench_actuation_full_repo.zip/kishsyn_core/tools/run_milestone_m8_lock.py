"""Milestone M8 lock probe for contextual affordance cognition."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from kishsyn_core.benchmark import BenchmarkPlaygroundSuite
from kishsyn_core.loop import OrganismLoop


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run KishSyn Core M8 contextual affordance lock probe.")
    parser.add_argument("--steps", type=int, default=180)
    parser.add_argument("--seeds", type=str, default="337,171,23", help="Comma-separated deterministic seeds.")
    parser.add_argument("--out", type=Path, default=Path("stores/_demo/milestone_m8_lock_report.json"))
    return parser


def _parse_seeds(raw: str) -> tuple[int, ...]:
    seeds = tuple(int(piece.strip()) for piece in raw.split(",") if piece.strip())
    return seeds or (337,)


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    seeds = _parse_seeds(args.seeds)
    apple_task = BenchmarkPlaygroundSuite()._apple_across_worlds_contextual_affordance(seeds)

    loop_records: list[float] = []
    loop_updates: list[float] = []
    plan_leaks: list[float] = []
    for seed in seeds:
        loop = OrganismLoop(seed=seed)
        loop.run(steps=max(96, args.steps))
        snap = loop.snapshot().__dict__
        contextual = snap["contextual_affordance"]
        loop_records.append(float(contextual.get("record_count", 0.0)))
        loop_updates.append(float(contextual.get("record_updates", 0.0)))
        plan_leaks.append(float(any(str(node.get("id", "")).startswith("plan:t") for node in snap["graph"].get("nodes", []))))

    mean_records = sum(loop_records) / max(1, len(loop_records))
    mean_updates = sum(loop_updates) / max(1, len(loop_updates))
    leak_count = sum(plan_leaks)
    apple_passed = apple_task.status == "pass"
    loop_passed = mean_records >= 3.0 and mean_updates >= 80.0 and leak_count == 0
    score = (0.58 if apple_passed else 0.0) + (0.42 if loop_passed else 0.0)
    locked = score >= 0.95
    verdict = "M8 locked: contextual affordance cognition is bounded and context-aware" if locked else "M8 not locked: contextual affordance evidence insufficient"
    payload = {
        "milestone": "M8 Contextual Affordance Cognition",
        "verdict": verdict,
        "locked": locked,
        "score": round(score, 4),
        "consciousness_claimed": False,
        "seeds": list(seeds),
        "steps": args.steps,
        "apple_across_worlds": apple_task.as_dict(),
        "loop_contextual_affordance": {
            "mean_record_count": round(mean_records, 4),
            "mean_record_updates": round(mean_updates, 4),
            "plan_tick_node_leaks": int(leak_count),
        },
        "law": "concept + actor/body + world context + action + provenance + outcome = meaning-in-use",
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    print(f"[KishSyn Core] M8 LOCK score={payload['score']} locked={locked} verdict={verdict!r} out={args.out}")
    return 0 if locked else 1


if __name__ == "__main__":
    raise SystemExit(main())
