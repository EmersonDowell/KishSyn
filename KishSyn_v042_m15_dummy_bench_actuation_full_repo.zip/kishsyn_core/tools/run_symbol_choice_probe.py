"""Run a symbol-guided choice probe after embodied learning."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from kishsyn_core.loop import OrganismLoop
from kishsyn_core.symbol_choice import SymbolChoiceProbe


def main() -> int:
    parser = argparse.ArgumentParser(description="Run KishSyn Core symbol-guided choice probe")
    parser.add_argument("--steps", type=int, default=160)
    parser.add_argument("--seed", type=int, default=337)
    parser.add_argument("--out", type=Path, default=Path("stores/_demo/symbol_choice_probe.json"))
    args = parser.parse_args()

    loop = OrganismLoop(seed=args.seed)
    loop.run(steps=args.steps)
    report = SymbolChoiceProbe().evaluate(loop.graph).as_dict()
    payload = {
        "steps": args.steps,
        "seed": args.seed,
        "tick": loop.tick,
        "score": loop.snapshot().score,
        "symbol_choice": report,
        "consciousness_claimed": False,
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    print(
        "[KishSyn Core] symbol choice "
        f"trials={report['trial_count']} passed={report['passed_count']} "
        f"accuracy={report['accuracy']} ablation_delta={report['ablation_delta']} out={args.out}"
    )
    return 0 if int(report["trial_count"]) > 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
