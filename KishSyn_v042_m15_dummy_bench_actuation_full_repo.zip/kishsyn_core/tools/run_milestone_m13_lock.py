"""Milestone M13 lock probe for desktop/OS observation substrate."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from kishsyn_core.desktop_observation import DesktopElement, DesktopObservationFrame
from kishsyn_core.loop import OrganismLoop


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run KishSyn Core M13 desktop/OS observation lock probe.")
    parser.add_argument("--steps", type=int, default=180)
    parser.add_argument("--seeds", type=str, default="337,171,23", help="Comma-separated deterministic seeds.")
    parser.add_argument("--out", type=Path, default=Path("stores/_demo/milestone_m13_lock_report.json"))
    return parser


def _parse_seeds(raw: str) -> tuple[int, ...]:
    seeds = tuple(int(piece.strip()) for piece in raw.split(",") if piece.strip())
    return seeds or (337,)


def _frame(tick: int, seed: int) -> DesktopObservationFrame:
    app = "notepad.exe" if seed % 2 else "terminal.exe"
    title = "Untitled - Notepad" if app == "notepad.exe" else "PowerShell - KishSyn"
    return DesktopObservationFrame(
        tick=tick,
        surface_id=f"desktop:screen0:{app}",
        title=title,
        active_application=app,
        elements=(
            DesktopElement("main_window", "window", title, (0, 0, 1100, 760), interactable=False, confidence=0.94),
            DesktopElement("primary_text", "text_field", "main text field", (18, 90, 960, 560), interactable=True, confidence=0.86),
            DesktopElement("file_menu", "menu", "File", (4, 26, 42, 24), interactable=True, confidence=0.78),
            DesktopElement("status_console", "console", "status output", (0, 714, 1100, 46), interactable=False, confidence=0.72),
        ),
        text_fragments=("apple red round", "KishSyn observation only", "no actuation"),
        source="desktop_read_only_adapter",
        screenshot_digest=f"demo:{seed}",
    )


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    seeds = _parse_seeds(args.seeds)
    observation_counts: list[float] = []
    surface_counts: list[float] = []
    sensory_features: list[float] = []
    allowed_write: list[float] = []
    blocked_write: list[float] = []
    graph_events: list[float] = []
    runtime_desktop: list[float] = []
    tick_leaks: list[float] = []

    for seed in seeds:
        loop = OrganismLoop(seed=seed)
        loop.os_observation.observe(_frame(loop.tick, seed), sensory_hub=loop.sensory_hub, registry=loop.external_registry, graph=loop.graph)
        loop.run(steps=max(96, args.steps))
        snap = loop.snapshot().__dict__
        observation = snap["os_observation"]
        sensory = snap["sensory"]
        registry = snap["external_interface"]
        runtime = snap["runtime_shell"]
        graph = snap["graph"]
        observation_counts.append(float(observation.get("observation_count", 0.0)))
        surface_counts.append(float(observation.get("surface_count", 0.0)))
        sensory_features.append(float(sensory.get("feature_count", 0.0)))
        allowed_write.append(float(registry.get("allowed_write_like_count", 0.0)))
        blocked_write.append(float(registry.get("blocked_write_like_count", 0.0)))
        graph_events.append(float(observation.get("graph_event_count", 0.0)))
        runtime_desktop.append(1.0 if runtime.get("supports_desktop_exe") and not runtime.get("html_locked") else 0.0)
        tick_leaks.append(float(any(str(node.get("id", "")).startswith("os:t") for node in graph.get("nodes", []))))

    mean_observations = sum(observation_counts) / max(1, len(observation_counts))
    mean_surfaces = sum(surface_counts) / max(1, len(surface_counts))
    mean_features = sum(sensory_features) / max(1, len(sensory_features))
    mean_blocked = sum(blocked_write) / max(1, len(blocked_write))
    mean_graph_events = sum(graph_events) / max(1, len(graph_events))
    observation_passed = mean_observations >= 1.0 and mean_surfaces >= 1.0 and mean_features >= 120.0 and mean_graph_events >= 6.0
    safety_passed = sum(allowed_write) == 0.0 and mean_blocked >= 1.0 and sum(tick_leaks) == 0.0
    shell_passed = sum(runtime_desktop) == len(seeds)
    score = (0.42 if observation_passed else 0.0) + (0.36 if safety_passed else 0.0) + (0.22 if shell_passed else 0.0)
    locked = score >= 0.95
    verdict = "M13 locked: desktop/OS observation is read-only, sensory, portable, and non-actuating" if locked else "M13 not locked: observation/safety/portability evidence insufficient"
    payload = {
        "milestone": "M13 Desktop/OS Observation Substrate",
        "verdict": verdict,
        "locked": locked,
        "score": round(score, 4),
        "consciousness_claimed": False,
        "seeds": list(seeds),
        "steps": args.steps,
        "metrics": {
            "mean_observation_count": round(mean_observations, 4),
            "mean_surface_count": round(mean_surfaces, 4),
            "mean_sensory_feature_count": round(mean_features, 4),
            "mean_blocked_write_like_count": round(mean_blocked, 4),
            "mean_graph_event_count": round(mean_graph_events, 4),
            "allowed_write_like_total": round(sum(allowed_write), 4),
            "os_tick_node_leaks": int(sum(tick_leaks)),
            "desktop_shell_safe_count": int(sum(runtime_desktop)),
        },
        "law": "OS/program surfaces enter as read-only observations and governed affordance proposals; HTML/web UI is a shell, not the organism.",
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    print(f"[KishSyn Core] M13 LOCK score={payload['score']} locked={locked} verdict={verdict!r} out={args.out}")
    return 0 if locked else 1


if __name__ == "__main__":
    raise SystemExit(main())
