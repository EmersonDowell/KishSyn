"""Run a living-loop probe for persistent symbol goals."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from kishsyn_core.loop import OrganismLoop


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the KishSyn persistent symbol-goal probe.")
    parser.add_argument("--steps", type=int, default=300)
    parser.add_argument("--seed", type=int, default=337)
    parser.add_argument("--out", default="stores/_demo/symbol_goal_probe.json")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    loop = OrganismLoop(seed=args.seed)
    loop.run(steps=args.steps)
    snapshot = loop.snapshot()
    payload = {
        "tick": snapshot.tick,
        "survival": snapshot.score["survival"],
        "growth": snapshot.score["growth"],
        "symbol_goal": snapshot.symbol_goal,
        "symbol_choice": snapshot.symbol_choice,
        "consciousness_claimed": False,
        "interpretation": "Persistent cue tokens can bias later action only through learned symbol/concept pathways.",
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    sg = snapshot.symbol_goal
    print(
        "[KishSyn Core] symbol goal "
        f"activations={sg['activation_count']} guided_attempts={sg['guided_attempts']} "
        f"guided_success_rate={sg['guided_success_rate']} active={bool(sg['active'])} "
        f"choice_accuracy={snapshot.symbol_choice['accuracy']}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
