"""Development gates for KishSyn Core.

The ship gate is intentionally bounded and process-local. The full pytest
inventory remains available for deeper audits, but the required gate focuses on
living-core proof: one recursive loop, graph growth, persistent brain state,
text/tutor/autopilot surfaces, and scope discipline. This avoids external pytest
plugin or long-lived thread teardown hangs while still testing the organism spine.
"""

from __future__ import annotations

import tempfile
from pathlib import Path

from kishsyn_core.scope import ProjectScopePolicy

ROOT = Path(__file__).resolve().parents[2]


def main() -> int:
    from kishsyn_core.benchmark import BenchmarkPlaygroundSuite
    from kishsyn_core.evidence import IntelligenceEvidenceEvaluator
    from kishsyn_core.loop import OrganismLoop
    from kishsyn_core.milestone import MilestoneM1LockEvaluator, MilestoneM2LockEvaluator, MilestoneM3LockEvaluator, MilestoneM4LockEvaluator, MilestoneM5LockEvaluator, MilestoneM6LockEvaluator, MilestoneM7LockEvaluator
    from kishsyn_core.observatory.server import ObservatorySession
    from kishsyn_core.neural_graph import NeuralGrowthGraph
    from kishsyn_core.state import load_loop, save_loop
    from kishsyn_core.symbol_choice import SymbolChoiceProbe

    checks: list[str] = []

    loop = OrganismLoop(seed=337)
    loop.run(steps=144)
    snap = loop.snapshot()
    _assert(snap.tick == 144, "loop did not advance to requested tick")
    _assert(snap.graph["node_count"] >= 32, "neural graph did not grow")
    _assert(snap.graph["edge_count"] >= 24, "synapse graph did not grow")
    _assert(snap.focus["mean_selectivity"] >= 0.15, "focus gate did not select a bounded active moment")
    _assert(snap.moments["count"] >= 64, "focused moment ledger did not retain active moments")
    _assert(snap.binding["stable_count"] >= 1, "binding engine did not stabilize focused coactivations")
    _assert(snap.anatomy["circuit_count"] >= 1, "anatomy growth did not promote a provisional circuit")
    _assert(snap.binding.get("stable_cross_modal_count", 0) >= 1, "binding engine did not stabilize cross-modal assemblies")
    _assert(snap.intent.get("continued_count", 0) >= 8, "intent model did not persist selected targets across moments")
    _assert(snap.planning.get("report_count", 0) >= 64, "counterfactual replay did not run inside the loop")
    _assert(snap.planning.get("mean_options", 0.0) >= 2.0, "counterfactual replay did not evaluate multiple action candidates")
    _assert(snap.planning.get("plan_template_count", 0) >= 3, "counterfactual replay did not compress plans into reusable templates")
    _assert(not any(str(node.get("id", "")).startswith("plan:t") for node in snap.graph["nodes"]), "tick-specific plan nodes leaked into durable graph anatomy")
    loop.sensory_hub.receive_console(tick=loop.tick, text="red round ?", source="gate_console")
    loop.sensory_hub.receive_math(tick=loop.tick, expression="2+2=4", source="gate_math")
    loop.sensory_hub.receive_screen_probe(tick=loop.tick, description="screen red circle near cursor", source="gate_screen")
    loop.run(steps=20)
    snap = loop.snapshot()
    _assert(snap.sensory["packet_count"] >= 3, "sensory adapter did not retain external packets")
    _assert(snap.sensory["feature_count"] >= 12, "sensory adapter did not normalize external features")
    _assert(snap.expression["output_count"] >= 1, "expression surface did not emit grounded console output")
    _assert("expression" in snap.atlas["surface_counts"], "neural atlas did not mirror expression surface")
    _assert(snap.atlas_inspector["node_count"] >= 32, "neural atlas inspector did not expose inspectable nodes")
    _assert(snap.emotion["sample_count"] >= 32, "emotional regulation field did not retain regulation samples")
    _assert(snap.emotion["trait_count"] >= 3, "emotional regulation field did not accumulate trait tendencies")
    _assert(snap.emotion.get("bias_count", 0) >= 1, "emotional regulation field did not export bounded bias contracts")
    _assert(snap.emotion.get("last_bias") is not None, "emotional regulation bias contract missing from snapshot")
    _assert("emotion" in snap.atlas["surface_counts"], "neural atlas did not mirror emotional regulation surface")
    _assert(snap.contextual_affordance["record_count"] >= 3, "contextual affordance memory did not form reusable records")
    _assert(snap.contextual_affordance["record_updates"] >= 32, "contextual affordance memory did not receive lived updates")
    edge = next((item for item in snap.graph["edges"] if abs(float(item.get("weight", 0.0))) > 0.01), None)
    node_id = snap.graph["nodes"][0]["id"]
    node_report = loop.neural_atlas_inspector.inspect_node(graph=loop.graph, node_id=node_id, tick=loop.tick, last_trace=loop.last_trace).as_dict()
    _assert(node_report["found"] is True, "neural atlas inspector could not inspect a neuron")
    if edge is not None:
        syn_report = loop.neural_atlas_inspector.inspect_synapse(graph=loop.graph, source=edge["source"], target=edge["target"], tick=loop.tick, last_trace=loop.last_trace).as_dict()
        _assert(syn_report["found"] is True, "neural atlas inspector could not inspect a synapse")
    _assert(snap.score["survival"] > 0.45, "metabolism is too punishing for sustained learning")
    _assert(snap.autopilot["lesson_count"] >= 1, "autonomous tutor did not inject any bounded lessons")
    _assert(snap.tutor["lesson_count"] >= snap.autopilot["lesson_count"], "autopilot did not enter through tutor surface")
    _assert(snap.text_crib["input_count"] >= 2, "text crib did not receive sensory text from tutor/autopilot")
    checks.append("living loop / focus / graph / anatomy / intent / planning / adapters / expression / contextual affordance")

    loop.tutor.receive(
        tick=loop.tick,
        message="teach red round A two",
        text_crib=loop.text_crib,
        graph=loop.graph,
        symbol_goal=loop.symbol_goal,
        source="gate",
        mode="local",
    )
    loop.run(steps=12)
    snap = loop.snapshot()
    _assert(snap.tutor["lesson_count"] >= 2, "manual tutor lesson did not register")
    _assert(any(node["kind"] in {"text", "tutor"} for node in snap.graph["nodes"]), "text/tutor neurons missing")
    checks.append("text/tutor surface")

    seeded = NeuralGrowthGraph()
    seeded.ensure_neuron("symbol:token=red", kind="symbol", label="token=red", tick=0)
    seeded.ensure_neuron("concept:color=red", kind="concept", label="color=red", tick=0)
    seeded.ensure_neuron("vision:color=red", kind="feature", label="vision:color=red", tick=0)
    seeded.reinforce("symbol:token=red", "concept:color=red", amount=0.7, tick=0, reason="gate grounding")
    seeded.reinforce("vision:color=red", "concept:color=red", amount=0.4, tick=0, reason="gate abstraction")
    report = SymbolChoiceProbe().evaluate(seeded)
    _assert(report.trial_count >= 1 and report.ablation_delta > 0.01, "symbol-choice ablation proof failed")
    checks.append("symbol choice ablation")

    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "brain.json"
        saved = save_loop(loop, path, seed=337, note="dev gate save")
        restored, meta = load_loop(path)
        restored_snap = restored.snapshot()
        _assert(saved["saved"] is True and meta["loaded"] is True, "brain state did not save/load")
        _assert(restored_snap.tick == loop.tick, "loaded brain tick drifted")
        _assert(restored_snap.graph["node_count"] == loop.snapshot().graph["node_count"], "loaded graph node count drifted")
        _assert(restored_snap.autopilot["lesson_count"] == loop.snapshot().autopilot["lesson_count"], "loaded autopilot state drifted")
        _assert(restored_snap.contextual_affordance["record_count"] == loop.snapshot().contextual_affordance["record_count"], "loaded contextual affordance state drifted")
    checks.append("persistent brain state")

    benchmark = BenchmarkPlaygroundSuite().evaluate(seeds=(337,), steps=144)
    _assert(benchmark.consciousness_claimed is False, "benchmark suite made a forbidden consciousness claim")
    _assert(benchmark.summary_score >= 0.50, "benchmark playground suite fell below watchable threshold")
    _assert(any(task.name == "changed-object surprise" and task.status != "fail" for task in benchmark.tasks), "changed-object benchmark failed")
    _assert(any(task.name == "focused moment substrate" and task.status != "fail" for task in benchmark.tasks), "focused moment benchmark failed")
    _assert(any(task.name == "cross-modal binding" and task.status != "fail" for task in benchmark.tasks), "cross-modal binding benchmark failed")
    _assert(any(task.name == "intent persistence" and task.status != "fail" for task in benchmark.tasks), "intent persistence benchmark failed")
    _assert(any(task.name == "counterfactual replay proto-planning" and task.status != "fail" for task in benchmark.tasks), "counterfactual replay benchmark failed")
    _assert(any(task.name == "sensory adapter and expression surface" and task.status != "fail" for task in benchmark.tasks), "sensory adapter/expression benchmark failed")
    _assert(any(task.name == "neural atlas inspection" and task.status != "fail" for task in benchmark.tasks), "neural atlas inspection benchmark failed")
    _assert(any(task.name == "emotional regulation field" and task.status != "fail" for task in benchmark.tasks), "emotional regulation benchmark failed")
    checks.append("benchmark playground suite")

    evidence = IntelligenceEvidenceEvaluator().evaluate(seed=337, steps=144, ablation_steps=24)
    _assert(evidence.consciousness_claimed is False, "evidence report made a forbidden consciousness claim")
    _assert(evidence.summary_score >= 0.55, "emergence evidence score fell below watchable threshold")
    _assert(any(item.name == "symbol ablation" and item.status != "fail" for item in evidence.criteria), "symbol evidence is not ablation-sensitive enough")
    _assert(any(item.name == "focused moment substrate" and item.status != "fail" for item in evidence.criteria), "focused moment evidence did not enter scorecard")
    _assert(any(item.name == "cross-modal binding" and item.status != "fail" for item in evidence.criteria), "cross-modal evidence did not enter scorecard")
    _assert(any(item.name == "intent persistence" and item.status != "fail" for item in evidence.criteria), "intent evidence did not enter scorecard")
    _assert(any(item.name == "counterfactual replay proto-planning" and item.status != "fail" for item in evidence.criteria), "planning evidence did not enter scorecard")
    _assert(any(item.name == "sensory adapter expression surface" and item.status != "fail" for item in evidence.criteria), "sensory adapter/expression evidence did not enter scorecard")
    _assert(any(item.name == "neural atlas inspection" and item.status != "fail" for item in evidence.criteria), "neural atlas inspection evidence did not enter scorecard")
    _assert(any(item.name == "emotional regulation field" and item.status != "fail" for item in evidence.criteria), "emotional regulation evidence did not enter scorecard")
    _assert(any(item.name == "benchmark playground suite" and item.status != "fail" for item in evidence.criteria), "benchmark evidence did not enter scorecard")
    checks.append("emergence evidence scorecard")

    _assert(MilestoneM1LockEvaluator.milestone_id == "M1", "M1 lock evaluator surface missing")
    _assert(MilestoneM2LockEvaluator.milestone_id == "M2", "M2 lock evaluator surface missing")
    _assert(MilestoneM3LockEvaluator.milestone_id == "M3", "M3 lock evaluator surface missing")
    _assert(MilestoneM4LockEvaluator.milestone_id == "M4", "M4 lock evaluator surface missing")
    _assert(MilestoneM5LockEvaluator.milestone_id == "M5", "M5 lock evaluator surface missing")
    _assert(MilestoneM6LockEvaluator.milestone_id == "M6", "M6 lock evaluator surface missing")
    _assert(MilestoneM7LockEvaluator.milestone_id == "M7", "M7 lock evaluator surface missing")
    checks.append("M1/M2/M3/M4/M5/M6/M7 milestone evaluator surfaces")

    observatory = ObservatorySession(seed=338, autosave_every=0)
    try:
        reports = observatory.reports_snapshot()
        _assert("benchmark" in reports and "evidence" in reports and "history" in reports, "observatory report surface missing")
    finally:
        observatory.stop()
    checks.append("observatory test/evidence/history surface")

    scope_inventory = ProjectScopePolicy(ROOT).validate()
    py_files = scope_inventory.python_files
    md_files = scope_inventory.markdown_files
    checks.append("scope/doc budget")

    for check in checks:
        print(f"[KishSyn Core] gate check OK: {check}")
    print("[KishSyn Core] dev gates OK")
    print(f"[KishSyn Core] active_python_files={len(py_files)} markdown_docs={len(md_files)}")
    print('[KishSyn Core] full inventory PowerShell: $env:PYTEST_DISABLE_PLUGIN_AUTOLOAD="1"; python -m pytest kishsyn_core/tests -q')
    return 0


def _assert(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


if __name__ == "__main__":
    raise SystemExit(main())
