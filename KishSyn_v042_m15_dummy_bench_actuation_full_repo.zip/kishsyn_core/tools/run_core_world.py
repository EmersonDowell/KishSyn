"""Run the clean core organism loop from the command line."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from kishsyn_core.loop import OrganismLoop
from kishsyn_core.state import DEFAULT_STATE_PATH, load_loop, save_loop


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run KishSyn Core mini ecology.")
    parser.add_argument("--steps", type=int, default=144)
    parser.add_argument("--seed", type=int, default=337)
    parser.add_argument("--out", type=Path, default=Path("stores/_demo/core_world_snapshot.json"))
    parser.add_argument("--state-in", type=Path, default=None, help="Optional persistent brain-state JSON to load before running.")
    parser.add_argument("--state-out", type=Path, default=None, help="Optional persistent brain-state JSON to write after running.")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.state_in is not None and args.state_in.exists():
        loop, loaded = load_loop(args.state_in)
        seed = int(loaded.get("seed", args.seed) or args.seed)
    else:
        loop = OrganismLoop(seed=args.seed)
        seed = args.seed
    loop.run(steps=args.steps)
    snapshot = loop.snapshot().__dict__
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(snapshot, indent=2), encoding="utf-8")
    if args.state_out is not None:
        save_loop(loop, args.state_out, seed=seed, note="run_core_world save")
    elif args.state_in is not None:
        save_loop(loop, args.state_in, seed=seed, note="run_core_world continuity save")
    print(
        "[KishSyn Core] "
        f"tick={snapshot['tick']} "
        f"survival={snapshot['score']['survival']} "
        f"growth={snapshot['score']['growth']} "
        f"nodes={snapshot['graph']['node_count']} "
        f"edges={snapshot['graph']['edge_count']} "
        f"out={args.out} "
        f"state={args.state_out or args.state_in or DEFAULT_STATE_PATH}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
