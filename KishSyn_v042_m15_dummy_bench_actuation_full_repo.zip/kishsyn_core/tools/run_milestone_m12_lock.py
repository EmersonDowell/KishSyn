"""Milestone M12 lock probe for grounded language and teaching."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from kishsyn_core.contextual_affordance import ActorProfile, WorldContext
from kishsyn_core.contracts import Action, BodyState, Outcome, Prediction, SensoryFeature, SensoryFrame, TickTrace
from kishsyn_core.grounded_language import GroundedLanguageCortex
from kishsyn_core.loop import OrganismLoop
from kishsyn_core.neural_graph import NeuralGrowthGraph


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run KishSyn Core M12 grounded-language lock probe.")
    parser.add_argument("--steps", type=int, default=180)
    parser.add_argument("--seeds", type=str, default="337,171,23", help="Comma-separated deterministic seeds.")
    parser.add_argument("--out", type=Path, default=Path("stores/_demo/milestone_m12_lock_report.json"))
    return parser


def _parse_seeds(raw: str) -> tuple[int, ...]:
    seeds = tuple(int(piece.strip()) for piece in raw.split(",") if piece.strip())
    return seeds or (337,)


def _direct_language_score() -> tuple[float, dict[str, object]]:
    graph = NeuralGrowthGraph()
    cortex = GroundedLanguageCortex()
    target_features = (
        "vision:object=apple_A",
        "vision:color=red",
        "vision:shape=round",
        "vision:quantity=available",
    )
    trace = TickTrace(
        tick=1,
        frame=SensoryFrame(tick=1, features=(SensoryFeature("word", "apple", "text", 0.82), SensoryFeature("word", "red", "text", 0.76))),
        body_before=BodyState(),
        action=Action("inspect", "apple_A", "direct M12 probe"),
        prediction=Prediction("novelty", 0.2),
        outcome=Outcome("novelty", target_id="apple_A", message="apple-like target inspected"),
        body_after=BodyState(),
        prediction_error=0.33,
        self_causation=0.8,
        causation_label="self",
    )
    cortex.observe(
        tick=1,
        graph=graph,
        trace=trace,
        target_features=target_features,
        actor=ActorProfile(),
        context=WorldContext(),
    )
    contract = cortex.contract_for("apple")
    has_object_kind = any(item.get("anchor_kind") == "object_kind" for item in contract.top_anchors)
    has_object_file = any(item.get("anchor_kind") == "object_file" for item in contract.top_anchors)
    no_tick_leak = not any(node_id.startswith("language:t") for node_id in graph.neurons)
    no_command = contract.may_command_action is False
    score = (0.30 if contract.grounded else 0.0) + (0.24 if has_object_kind else 0.0) + (0.20 if has_object_file else 0.0) + (0.16 if no_command else 0.0) + (0.10 if no_tick_leak else 0.0)
    return score, {
        "contract": contract.as_dict(),
        "has_object_kind_anchor": has_object_kind,
        "has_object_file_anchor": has_object_file,
        "no_language_tick_leak": no_tick_leak,
    }


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    seeds = _parse_seeds(args.seeds)
    direct_score, direct = _direct_language_score()

    record_counts: list[float] = []
    word_counts: list[float] = []
    update_counts: list[float] = []
    no_command_flags: list[float] = []
    tick_leaks: list[float] = []
    for seed in seeds:
        loop = OrganismLoop(seed=seed)
        loop.text_crib.receive_text(tick=loop.tick, text="apple red round remember", source="m12_lock", ttl=max(120, args.steps))
        loop.run(steps=max(120, args.steps))
        snap = loop.snapshot().__dict__
        language = snap["grounded_language"]
        record_counts.append(float(language.get("record_count", 0.0)))
        word_counts.append(float(language.get("word_count", 0.0)))
        update_counts.append(float(language.get("record_updates", 0.0)))
        last_contract = language.get("last_contract") or {}
        no_command_flags.append(1.0 if last_contract.get("may_command_action") is False else 0.0)
        tick_leaks.append(float(any(str(node.get("id", "")).startswith("language:t") for node in snap["graph"].get("nodes", []))))

    mean_records = sum(record_counts) / max(1, len(record_counts))
    mean_words = sum(word_counts) / max(1, len(word_counts))
    mean_updates = sum(update_counts) / max(1, len(update_counts))
    loop_passed = mean_records >= 4.0 and mean_words >= 1.0 and mean_updates >= 12.0 and sum(no_command_flags) == len(seeds) and sum(tick_leaks) == 0
    score = round(direct_score * 0.50 + (0.50 if loop_passed else 0.0), 4)
    locked = score >= 0.95
    verdict = "M12 locked: language is grounded recall over lived anchors" if locked else "M12 not locked: grounded-language evidence insufficient"
    payload = {
        "milestone": "M12 Grounded Language and Teaching",
        "verdict": verdict,
        "locked": locked,
        "score": score,
        "consciousness_claimed": False,
        "seeds": list(seeds),
        "steps": args.steps,
        "direct_grounding": direct,
        "loop_grounding": {
            "mean_record_count": round(mean_records, 4),
            "mean_word_count": round(mean_words, 4),
            "mean_record_updates": round(mean_updates, 4),
            "contracts_non_commanding": int(sum(no_command_flags)),
            "language_tick_node_leaks": int(sum(tick_leaks)),
        },
        "law": "language is a grounded recall surface; words may bind to lived anchors but may not command action or become a persona",
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    print(f"[KishSyn Core] M12 LOCK score={payload['score']} locked={locked} verdict={verdict!r} out={args.out}")
    return 0 if locked else 1


if __name__ == "__main__":
    raise SystemExit(main())
