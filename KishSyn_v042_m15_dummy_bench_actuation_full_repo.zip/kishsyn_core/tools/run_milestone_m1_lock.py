"""Run the formal Milestone M1 lock report."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from kishsyn_core.milestone import MilestoneM1LockEvaluator


def _parse_seeds(value: str) -> tuple[int, ...]:
    seeds = tuple(int(part.strip()) for part in value.split(",") if part.strip())
    if not seeds:
        raise argparse.ArgumentTypeError("at least one seed is required")
    return seeds


def main() -> int:
    parser = argparse.ArgumentParser(description="Run KishSyn Milestone M1 lock evaluation.")
    parser.add_argument("--seed", type=int, default=337)
    parser.add_argument("--seeds", type=_parse_seeds, default=(337, 171, 23))
    parser.add_argument("--steps", type=int, default=240)
    parser.add_argument("--ablation-steps", type=int, default=48)
    parser.add_argument("--out", type=Path, default=Path("stores/_demo/milestone_m1_lock_report.json"))
    args = parser.parse_args()

    report = MilestoneM1LockEvaluator().evaluate(
        seed=args.seed,
        seeds=args.seeds,
        steps=args.steps,
        ablation_steps=args.ablation_steps,
    )
    payload = report.as_dict()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    state = "LOCKED" if report.locked else "CANDIDATE"
    print(
        f"[KishSyn Core] M1 {state} score={report.summary_score} "
        f"verdict='{report.verdict}' out={args.out}"
    )
    return 0 if report.locked else 1


if __name__ == "__main__":
    raise SystemExit(main())
