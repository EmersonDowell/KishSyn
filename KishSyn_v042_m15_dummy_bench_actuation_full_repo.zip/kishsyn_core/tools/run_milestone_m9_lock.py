"""Milestone M9 lock probe for object-file identity cortex."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from kishsyn_core.benchmark import BenchmarkPlaygroundSuite
from kishsyn_core.loop import OrganismLoop


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run KishSyn Core M9 object-file identity lock probe.")
    parser.add_argument("--steps", type=int, default=180)
    parser.add_argument("--seeds", type=str, default="337,171,23", help="Comma-separated deterministic seeds.")
    parser.add_argument("--out", type=Path, default=Path("stores/_demo/milestone_m9_lock_report.json"))
    return parser


def _parse_seeds(raw: str) -> tuple[int, ...]:
    seeds = tuple(int(piece.strip()) for piece in raw.split(",") if piece.strip())
    return seeds or (337,)


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    seeds = _parse_seeds(args.seeds)
    suite = BenchmarkPlaygroundSuite()
    task = suite._object_file_identity_cortex(seeds)

    loop_files: list[float] = []
    loop_kinds: list[float] = []
    loop_updates: list[float] = []
    for seed in seeds:
        loop = OrganismLoop(seed=seed)
        loop.run(steps=max(96, args.steps))
        snap = loop.snapshot().__dict__
        object_file = snap["object_file"]
        loop_files.append(float(object_file.get("file_count", 0.0)))
        loop_kinds.append(float(object_file.get("kind_count", 0.0)))
        loop_updates.append(float(object_file.get("record_updates", 0.0)))

    mean_files = sum(loop_files) / max(1, len(loop_files))
    mean_kinds = sum(loop_kinds) / max(1, len(loop_kinds))
    mean_updates = sum(loop_updates) / max(1, len(loop_updates))
    direct_passed = task.status == "pass"
    loop_passed = mean_files >= 3.0 and mean_kinds >= 2.0 and mean_updates >= 80.0
    score = (0.58 if direct_passed else 0.0) + (0.42 if loop_passed else 0.0)
    locked = score >= 0.95
    verdict = "M9 locked: object identity and shared kind anatomy are separated" if locked else "M9 not locked: object-file evidence insufficient"
    payload = {
        "milestone": "M9 Object-File Cortex",
        "verdict": verdict,
        "locked": locked,
        "score": round(score, 4),
        "consciousness_claimed": False,
        "seeds": list(seeds),
        "steps": args.steps,
        "object_file_identity": task.as_dict(),
        "loop_object_file": {
            "mean_file_count": round(mean_files, 4),
            "mean_kind_count": round(mean_kinds, 4),
            "mean_record_updates": round(mean_updates, 4),
        },
        "law": "same kind does not mean same individual; object files preserve instance identity while sharing category anatomy",
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    print(f"[KishSyn Core] M9 LOCK score={payload['score']} locked={locked} verdict={verdict!r} out={args.out}")
    return 0 if locked else 1


if __name__ == "__main__":
    raise SystemExit(main())
