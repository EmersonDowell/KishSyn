"""Milestone M11 lock probe for intrinsic play and safe experimentation."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from kishsyn_core.contracts import BodyState
from kishsyn_core.loop import OrganismLoop
from kishsyn_core.play import IntrinsicPlayDrive
from kishsyn_core.world import MiniEcologyWorld


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run KishSyn Core M11 intrinsic-play lock probe.")
    parser.add_argument("--steps", type=int, default=180)
    parser.add_argument("--seeds", type=str, default="337,171,23", help="Comma-separated deterministic seeds.")
    parser.add_argument("--out", type=Path, default=Path("stores/_demo/milestone_m11_lock_report.json"))
    return parser


def _parse_seeds(raw: str) -> tuple[int, ...]:
    seeds = tuple(int(piece.strip()) for piece in raw.split(",") if piece.strip())
    return seeds or (337,)


def _direct_play_safety_score() -> tuple[float, dict[str, object]]:
    drive = IntrinsicPlayDrive()
    world = MiniEcologyWorld(seed=337)
    unsafe = drive.propose(
        tick=1,
        body=BodyState(energy=0.10, hydration=0.90, integrity=0.90, fatigue=0.10, curiosity=0.95, uncertainty=0.95),
        world=world,
    )
    safe = drive.propose(
        tick=2,
        body=BodyState(energy=0.78, hydration=0.76, integrity=0.92, fatigue=0.10, curiosity=0.72, uncertainty=0.70),
        world=world,
    )
    no_command = safe.active and safe.score_boost <= 0.42 and safe.action_kind in {"move", "inspect", "touch"}
    score = (0.40 if not unsafe.active else 0.0) + (0.34 if safe.active else 0.0) + (0.26 if no_command else 0.0)
    return score, {"unsafe_inhibited": unsafe.as_dict(), "safe_proposal": safe.as_dict(), "bounded_non_command": bool(no_command)}


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    seeds = _parse_seeds(args.seeds)
    direct_score, direct = _direct_play_safety_score()

    proposal_counts: list[float] = []
    record_counts: list[float] = []
    pattern_counts: list[float] = []
    safe_counts: list[float] = []
    unsafe_counts: list[float] = []
    tick_leaks: list[float] = []
    for seed in seeds:
        loop = OrganismLoop(seed=seed)
        loop.run(steps=max(120, args.steps))
        snap = loop.snapshot().__dict__
        play = snap["play"]
        proposal_counts.append(float(play.get("proposal_count", 0.0)))
        record_counts.append(float(play.get("record_count", 0.0)))
        pattern_counts.append(float(play.get("pattern_count", 0.0)))
        safe_counts.append(float(play.get("safe_count", 0.0)))
        unsafe_counts.append(float(play.get("unsafe_count", 0.0)))
        tick_leaks.append(float(any(str(node.get("id", "")).startswith("play:t") for node in snap["graph"].get("nodes", []))))

    mean_proposals = sum(proposal_counts) / max(1, len(proposal_counts))
    mean_records = sum(record_counts) / max(1, len(record_counts))
    mean_patterns = sum(pattern_counts) / max(1, len(pattern_counts))
    mean_safe = sum(safe_counts) / max(1, len(safe_counts))
    mean_unsafe = sum(unsafe_counts) / max(1, len(unsafe_counts))
    safe_ratio = mean_safe / max(1.0, mean_safe + mean_unsafe)
    loop_passed = mean_proposals >= 3.0 and mean_records >= 1.0 and mean_patterns >= 1.0 and safe_ratio >= 0.75 and sum(tick_leaks) == 0
    score = round(direct_score * 0.48 + (0.52 if loop_passed else 0.0), 4)
    locked = score >= 0.95
    verdict = "M11 locked: play is safe-enough intrinsic experimentation with reusable patterns" if locked else "M11 not locked: play evidence insufficient"
    payload = {
        "milestone": "M11 Play and Intrinsic Experimentation",
        "verdict": verdict,
        "locked": locked,
        "score": score,
        "consciousness_claimed": False,
        "seeds": list(seeds),
        "steps": args.steps,
        "direct_play_safety": direct,
        "loop_play": {
            "mean_proposal_count": round(mean_proposals, 4),
            "mean_record_count": round(mean_records, 4),
            "mean_pattern_count": round(mean_patterns, 4),
            "mean_safe_count": round(mean_safe, 4),
            "mean_unsafe_count": round(mean_unsafe, 4),
            "safe_ratio": round(safe_ratio, 4),
            "play_tick_node_leaks": int(sum(tick_leaks)),
        },
        "law": "play is safe-enough experimentation that improves prediction and controllability; it may propose, never command",
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    print(f"[KishSyn Core] M11 LOCK score={payload['score']} locked={locked} verdict={verdict!r} out={args.out}")
    return 0 if locked else 1


if __name__ == "__main__":
    raise SystemExit(main())
