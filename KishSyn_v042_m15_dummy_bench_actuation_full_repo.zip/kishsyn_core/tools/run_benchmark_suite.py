"""Run the controlled KishSyn benchmark playground suite."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from kishsyn_core.benchmark import BenchmarkPlaygroundSuite


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run KishSyn Core controlled benchmark playgrounds.")
    parser.add_argument("--steps", type=int, default=240)
    parser.add_argument("--seeds", type=str, default="337,171,23", help="Comma-separated deterministic seeds.")
    parser.add_argument("--out", type=Path, default=Path("stores/_demo/benchmark_suite_report.json"))
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    seeds = tuple(int(piece.strip()) for piece in args.seeds.split(",") if piece.strip())
    report = BenchmarkPlaygroundSuite().evaluate(seeds=seeds, steps=args.steps)
    payload = report.as_dict()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    passed = sum(1 for task in report.tasks if task.status == "pass")
    watched = sum(1 for task in report.tasks if task.status == "watch")
    failed = sum(1 for task in report.tasks if task.status == "fail")
    print(
        "[KishSyn Core] benchmark suite "
        f"verdict={report.verdict!r} score={report.summary_score} "
        f"tasks=pass:{passed}/watch:{watched}/fail:{failed} "
        f"consciousness_claimed={report.consciousness_claimed} out={args.out}"
    )
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
