"""Run KishSyn's bounded emergent-intelligence evidence report."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from kishsyn_core.evidence import IntelligenceEvidenceEvaluator


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run KishSyn Core intelligence-evidence scorecard.")
    parser.add_argument("--steps", type=int, default=420)
    parser.add_argument("--seed", type=int, default=337)
    parser.add_argument("--ablation-steps", type=int, default=72)
    parser.add_argument("--out", type=Path, default=Path("stores/_demo/intelligence_evidence_report.json"))
    parser.add_argument("--benchmark-seeds", type=str, default="337,171,23", help="Comma-separated seeds for embedded benchmark playground suite.")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    benchmark_seeds = tuple(int(piece.strip()) for piece in args.benchmark_seeds.split(",") if piece.strip())
    report = IntelligenceEvidenceEvaluator().evaluate(seed=args.seed, steps=args.steps, ablation_steps=args.ablation_steps, benchmark_seeds=benchmark_seeds)
    payload = report.as_dict()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    passed = sum(1 for item in report.criteria if item.status == "pass")
    watched = sum(1 for item in report.criteria if item.status == "watch")
    failed = sum(1 for item in report.criteria if item.status == "fail")
    print(
        "[KishSyn Core] "
        f"verdict={report.verdict!r} "
        f"score={report.summary_score} "
        f"criteria=pass:{passed}/watch:{watched}/fail:{failed} "
        f"consciousness_claimed={report.consciousness_claimed} "
        f"out={args.out}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
