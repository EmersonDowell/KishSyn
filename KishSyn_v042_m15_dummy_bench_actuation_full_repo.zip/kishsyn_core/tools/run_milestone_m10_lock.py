"""Milestone M10 lock probe for retention pressure and memory economy."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from kishsyn_core.loop import OrganismLoop
from kishsyn_core.memory_economy import MemoryPressureGovernor
from kishsyn_core.contracts import Action, BodyState, Outcome, Prediction, SensoryFeature, SensoryFrame, TickTrace
from kishsyn_core.neural_graph import NeuralGrowthGraph


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run KishSyn Core M10 retention-pressure memory-economy lock probe.")
    parser.add_argument("--steps", type=int, default=180)
    parser.add_argument("--seeds", type=str, default="337,171,23", help="Comma-separated deterministic seeds.")
    parser.add_argument("--out", type=Path, default=Path("stores/_demo/milestone_m10_lock_report.json"))
    return parser


def _parse_seeds(raw: str) -> tuple[int, ...]:
    seeds = tuple(int(piece.strip()) for piece in raw.split(",") if piece.strip())
    return seeds or (337,)


def _instruction_trace(tick: int) -> TickTrace:
    features = tuple(SensoryFeature(key="word", value=word, kind="text", intensity=1.0) for word in ("remember", "red", "round", "page"))
    return TickTrace(
        tick=tick,
        frame=SensoryFrame(tick=tick, features=features, raw={}),
        body_before=BodyState(energy=0.18, hydration=0.72, integrity=0.88, fatigue=0.12, curiosity=0.46, uncertainty=0.60),
        action=Action("inspect", "apple_A", "m10 lock trace"),
        prediction=Prediction("neutral", confidence=0.1),
        outcome=Outcome("novelty", target_id="apple_A", message="m10 lock outcome"),
        body_after=BodyState(energy=0.20, hydration=0.72, integrity=0.88, fatigue=0.12, curiosity=0.40, uncertainty=0.50),
        prediction_error=0.92,
        self_causation=0.9,
        world_causation=0.1,
        causation_label="self_caused",
        world_events=("apple changed",),
    )


def _direct_memory_pressure_score() -> tuple[float, dict[str, object]]:
    graph = NeuralGrowthGraph()
    governor = MemoryPressureGovernor()
    for tick in range(18):
        governor.observe(tick=tick, graph=graph, trace=_instruction_trace(tick))
    snap = governor.snapshot()
    top = snap["top_summaries"][0] if snap["top_summaries"] else {}
    no_tick_nodes = not any(node_id.startswith("memory:t") for node_id in graph.neurons)
    reused_summary = snap["summary_count"] == 1 and top.get("evidence_count", 0) == 18
    preserved = snap["last_pressure"] and snap["last_pressure"].get("decision") in {"preserve", "consolidate"}
    score = (0.38 if no_tick_nodes else 0.0) + (0.34 if reused_summary else 0.0) + (0.28 if preserved else 0.0)
    return score, {"snapshot": snap, "no_tick_nodes": no_tick_nodes, "reused_summary": reused_summary, "preserved_instruction": bool(preserved)}


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    seeds = _parse_seeds(args.seeds)
    direct_score, direct = _direct_memory_pressure_score()

    observed_counts: list[float] = []
    summary_counts: list[float] = []
    summary_updates: list[float] = []
    compression_ratios: list[float] = []
    plan_leaks: list[float] = []
    memory_tick_leaks: list[float] = []
    for seed in seeds:
        loop = OrganismLoop(seed=seed)
        loop.sensory_hub.receive_console(tick=loop.tick, text="remember red round page", source="m10_lock", ttl=args.steps + 24)
        loop.run(steps=max(120, args.steps))
        snap = loop.snapshot().__dict__
        memory = snap["memory_economy"]
        observed = float(memory.get("observed_count", 0.0))
        summaries = float(memory.get("summary_count", 0.0))
        updates = float(memory.get("summary_updates", 0.0))
        observed_counts.append(observed)
        summary_counts.append(summaries)
        summary_updates.append(updates)
        compression_ratios.append(summaries / max(1.0, observed))
        plan_leaks.append(float(any(str(node.get("id", "")).startswith("plan:t") for node in snap["graph"].get("nodes", []))))
        memory_tick_leaks.append(float(any(str(node.get("id", "")).startswith("memory:t") for node in snap["graph"].get("nodes", []))))

    mean_observed = sum(observed_counts) / max(1, len(observed_counts))
    mean_summaries = sum(summary_counts) / max(1, len(summary_counts))
    mean_updates = sum(summary_updates) / max(1, len(summary_updates))
    mean_compression = sum(compression_ratios) / max(1, len(compression_ratios))
    loop_passed = mean_observed >= 120.0 and mean_updates >= 80.0 and mean_summaries >= 3.0 and mean_compression <= 0.70 and sum(plan_leaks) == 0 and sum(memory_tick_leaks) == 0
    score = round(direct_score * 0.50 + (0.50 if loop_passed else 0.0), 4)
    locked = score >= 0.95
    verdict = "M10 locked: retention pressure compresses experience into reusable memory economy" if locked else "M10 not locked: retention pressure evidence insufficient"
    payload = {
        "milestone": "M10 Retention Pressure and Memory Economy",
        "verdict": verdict,
        "locked": locked,
        "score": score,
        "consciousness_claimed": False,
        "seeds": list(seeds),
        "steps": args.steps,
        "direct_memory_pressure": direct,
        "loop_memory_economy": {
            "mean_observed_count": round(mean_observed, 4),
            "mean_summary_count": round(mean_summaries, 4),
            "mean_summary_updates": round(mean_updates, 4),
            "mean_summary_per_trace_ratio": round(mean_compression, 4),
            "plan_tick_node_leaks": int(sum(plan_leaks)),
            "memory_tick_node_leaks": int(sum(memory_tick_leaks)),
        },
        "law": "the graph stores reusable anatomy; the ledger stores events; retention pressure decides what earns durable memory",
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    print(f"[KishSyn Core] M10 LOCK score={payload['score']} locked={locked} verdict={verdict!r} out={args.out}")
    return 0 if locked else 1


if __name__ == "__main__":
    raise SystemExit(main())
