"""Per-patch gate manifest for KishSyn Core.

This tool does not replace the full dev gate. It gives the patch author a small,
explicit gate set for the surfaces touched by the current patch so unchanged,
expensive historical locks do not need to be rerun every time.
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from dataclasses import dataclass


@dataclass(frozen=True)
class PatchGate:
    name: str
    command: tuple[str, ...]
    reason: str


GATES: dict[str, tuple[PatchGate, ...]] = {
    "always": (
        PatchGate("core import", (sys.executable, "-c", "import kishsyn_core"), "package must import from repo root"),
        PatchGate("M7 bias contract smoke", (sys.executable, "-m", "pytest", "kishsyn_core/tests/test_milestone_m7_emotion_bias.py::test_emotion_bias_contract_reaches_focus_and_expression", "-q"), "emotion bias must reach focus and expression as evidence"),
        PatchGate("M7 plan-template smoke", (sys.executable, "-m", "pytest", "kishsyn_core/tests/test_milestone_m7_emotion_bias.py::test_plan_instances_compress_into_reusable_templates", "-q"), "planning must compress repeated instances into reusable templates"),
        PatchGate("M7 persistence smoke", (sys.executable, "-m", "pytest", "kishsyn_core/tests/test_milestone_m7_emotion_bias.py::test_plan_templates_and_emotion_bias_persist", "-q"), "new planning/emotion state must roundtrip through JSON persistence"),
        PatchGate("M8 contextual affordance smoke", (sys.executable, "-m", "pytest", "kishsyn_core/tests/test_contextual_affordance.py", "-q"), "object use must stay actor/context/world-bound instead of universal"),
        PatchGate("M9 object-file smoke", (sys.executable, "-m", "pytest", "kishsyn_core/tests/test_object_file_cortex.py", "-q"), "object identity must stay distinct while sharing object-kind anatomy"),
        PatchGate("M10 memory-economy smoke", (sys.executable, "-m", "pytest", "kishsyn_core/tests/test_memory_economy.py", "-q"), "retention pressure must compress repeated experience into reusable summaries"),
        PatchGate("M11 intrinsic-play smoke", (sys.executable, "-m", "pytest", "kishsyn_core/tests/test_intrinsic_play.py", "-q"), "play must remain safe-enough experimentation and reuse patterns"),
        PatchGate("M12 grounded-language smoke", (sys.executable, "-m", "pytest", "kishsyn_core/tests/test_grounded_language.py", "-q"), "language must bind to lived anchors without becoming a command or persona"),
        PatchGate("M13 desktop observation smoke", (sys.executable, "-m", "pytest", "kishsyn_core/tests/test_milestone_m13_os_observation.py", "-q"), "OS/program surfaces must enter as read-only sensory observations and preserve desktop-exe portability"),
        PatchGate("M14 interface affordance smoke", (sys.executable, "-m", "pytest", "kishsyn_core/tests/test_milestone_m14_interface_affordance.py", "-q"), "observed UI elements must become proposal-only reusable affordance records"),
        PatchGate("M15 dummy-bench smoke", (sys.executable, "-m", "pytest", "kishsyn_core/tests/test_milestone_m15_dummy_bench.py", "-q"), "dummy-bench actuation must execute only inside the sealed sandbox and never touch real OS authority"),
        PatchGate("graph viewport performance smoke", (sys.executable, "-m", "pytest", "kishsyn_core/tests/test_graph_viewport_performance.py", "-q"), "synaptic viewport must stay budgeted instead of rendering full graph anatomy by default"),
        PatchGate("external interface contract smoke", (sys.executable, "-m", "pytest", "kishsyn_core/tests/test_external_interface.py", "-q"), "future OS/program adapters must remain governed and non-actuating by default"),
    ),
    "planning": (
        PatchGate("M3 planning smoke", (sys.executable, "-m", "pytest", "kishsyn_core/tests/test_milestone_m3_planning.py::test_counterfactual_replay_surface_runs_inside_loop", "kishsyn_core/tests/test_milestone_m3_planning.py::test_counterfactual_replay_persists_in_brain_state", "-q"), "planning changes must preserve counterfactual replay and persistence"),
    ),
    "emotion": (
        PatchGate("emotion field smoke", (sys.executable, "-m", "pytest", "kishsyn_core/tests/test_emotional_regulation_field.py", "-q"), "emotion changes must preserve regulation samples and state roundtrip"),
    ),
    "scope": (
        PatchGate("scope inventory", (sys.executable, "-m", "pytest", "kishsyn_core/tests/test_dev_gates_inventory.py", "-q"), "file/doc budget must ignore archives and generated stores"),
    ),
    "full": (
        PatchGate("full dev gates", (sys.executable, "-m", "kishsyn_core.tools.dev_gates"), "run before major locks, release candidates, and broad surface changes"),
    ),
}


def _selected(profile: str) -> tuple[PatchGate, ...]:
    if profile == "quick":
        keys = ("always", "scope")
    elif profile == "current":
        keys = ("always", "planning", "emotion", "scope")
    elif profile == "full":
        keys = ("always", "planning", "emotion", "scope", "full")
    else:
        raise ValueError(f"unknown patch gate profile: {profile}")
    seen: set[tuple[str, ...]] = set()
    gates: list[PatchGate] = []
    for key in keys:
        for gate in GATES[key]:
            if gate.command in seen:
                continue
            seen.add(gate.command)
            gates.append(gate)
    return tuple(gates)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="List or run KishSyn per-patch gates.")
    parser.add_argument("--profile", choices=("quick", "current", "full"), default="current")
    parser.add_argument("--run", action="store_true", help="execute the selected gates instead of listing them")
    args = parser.parse_args(argv)
    gates = _selected(args.profile)
    if not args.run:
        print(f"[KishSyn Core] patch gate profile={args.profile}")
        for gate in gates:
            print(f"- {gate.name}: {' '.join(gate.command)}")
            print(f"  reason: {gate.reason}")
        return 0
    if args.profile in {"quick", "current"}:
        _run_inline_patch_smoke()
        print(f"[KishSyn Core] patch gates OK profile={args.profile}")
        return 0
    for gate in gates:
        print(f"[KishSyn Core] running patch gate: {gate.name}")
        result = subprocess.run(gate.command, check=False)
        if result.returncode != 0:
            print(f"[KishSyn Core] patch gate failed: {gate.name}", file=sys.stderr)
            return result.returncode
    print(f"[KishSyn Core] patch gates OK profile={args.profile}")
    return 0


def _run_inline_patch_smoke() -> None:
    from pathlib import Path

    from kishsyn_core.desktop_observation import DesktopElement, DesktopObservationFrame
    from kishsyn_core.loop import OrganismLoop
    from kishsyn_core.graph_viewport import GraphViewportBudget, GraphViewportProjector
    from kishsyn_core.scope import ProjectScopePolicy
    from kishsyn_core.state import load_loop, save_loop

    loop = OrganismLoop(seed=337)
    loop.text_crib.receive_text(tick=loop.tick, text="apple red round remember", source="patch_gate", ttl=120)
    loop.sensory_hub.receive_console(tick=loop.tick, text="red round ?", source="patch_gate", ttl=84)
    loop.os_observation.observe(
        DesktopObservationFrame(
            tick=loop.tick,
            surface_id="desktop:screen0:patch_gate",
            title="Patch Gate Desktop",
            active_application="patch_gate.exe",
            elements=(
                DesktopElement("main_window", "window", "Patch Gate Desktop", (0, 0, 900, 700), False, 0.92),
                DesktopElement("text_box", "text_field", "input area", (20, 80, 760, 420), True, 0.84),
                DesktopElement("run_button", "button", "Run", (790, 80, 80, 36), True, 0.80),
            ),
            text_fragments=("apple red round", "read only observation"),
            source="patch_gate_desktop_observer",
        ),
        sensory_hub=loop.sensory_hub,
        registry=loop.external_registry,
        graph=loop.graph,
        interface_affordance=loop.interface_affordance,
    )
    loop.os_observation.observe(
        loop.dummy_bench.observe_frame(tick=loop.tick),
        sensory_hub=loop.sensory_hub,
        registry=loop.external_registry,
        graph=loop.graph,
        interface_affordance=loop.interface_affordance,
    )
    loop.dummy_bench.execute_script(tick=loop.tick, graph=loop.graph, sensory_hub=loop.sensory_hub)
    loop.run(steps=96)
    snap = loop.snapshot().__dict__
    planning = snap["planning"]
    emotion = snap["emotion"]
    if planning.get("plan_template_count", 0) < 3:
        raise AssertionError("patch gate failed: plan templates did not form")
    if planning.get("plan_template_updates", 0) < 80:
        raise AssertionError("patch gate failed: plan template updates too low")
    if any(str(node.get("id", "")).startswith("plan:t") for node in snap["graph"]["nodes"]):
        raise AssertionError("patch gate failed: tick-specific plan node leaked")
    contextual = snap["contextual_affordance"]
    object_file = snap["object_file"]
    if emotion.get("bias_count", 0) < 80 or emotion.get("last_bias") is None:
        raise AssertionError("patch gate failed: emotion bias contract missing")
    if contextual.get("record_count", 0) < 3 or contextual.get("record_updates", 0) < 40:
        raise AssertionError("patch gate failed: contextual affordance records did not form")
    if object_file.get("file_count", 0) < 3 or object_file.get("record_updates", 0) < 40:
        raise AssertionError("patch gate failed: object files did not form")
    memory_economy = snap["memory_economy"]
    if memory_economy.get("observed_count", 0) < 90 or memory_economy.get("summary_updates", 0) < 40:
        raise AssertionError("patch gate failed: memory economy did not observe and summarize traces")
    if any(str(node.get("id", "")).startswith("memory:t") for node in snap["graph"]["nodes"]):
        raise AssertionError("patch gate failed: tick-specific memory node leaked")
    play = snap["play"]
    if play.get("proposal_count", 0) < 1 or play.get("record_count", 0) < 1 or play.get("pattern_count", 0) < 1:
        raise AssertionError("patch gate failed: intrinsic play did not form safe reusable patterns")
    if play.get("unsafe_count", 0) > play.get("safe_count", 0):
        raise AssertionError("patch gate failed: intrinsic play safety ratio collapsed")
    if any(str(node.get("id", "")).startswith("play:t") for node in snap["graph"]["nodes"]):
        raise AssertionError("patch gate failed: tick-specific play node leaked")
    grounded_language = snap["grounded_language"]
    if grounded_language.get("record_count", 0) < 1 or grounded_language.get("record_updates", 0) < 1:
        raise AssertionError("patch gate failed: grounded language did not bind text to lived anchors")
    if (grounded_language.get("last_contract") or {}).get("may_command_action") is not False:
        raise AssertionError("patch gate failed: grounded language contract may command action")
    if any(str(node.get("id", "")).startswith("language:t") for node in snap["graph"]["nodes"]):
        raise AssertionError("patch gate failed: tick-specific language node leaked")
    os_observation = snap["os_observation"]
    external_interface = snap["external_interface"]
    runtime_shell = snap["runtime_shell"]
    if os_observation.get("observation_count", 0) < 1 or os_observation.get("graph_event_count", 0) < 3:
        raise AssertionError("patch gate failed: OS observation substrate did not ingest desktop frame")
    if external_interface.get("allowed_write_like_count", 1) != 0 or external_interface.get("blocked_write_like_count", 0) < 1:
        raise AssertionError("patch gate failed: external interface allowed write-like desktop action before certification")
    if not runtime_shell.get("supports_desktop_exe") or runtime_shell.get("html_locked"):
        raise AssertionError("patch gate failed: runtime shell policy is locked to HTML or lacks desktop .exe path")
    if any(str(node.get("id", "")).startswith("os:t") for node in snap["graph"]["nodes"]):
        raise AssertionError("patch gate failed: tick-specific OS observation node leaked")
    interface_affordance = snap["interface_affordance"]
    if interface_affordance.get("record_count", 0) < 4 or interface_affordance.get("signature_count", 0) < 3:
        raise AssertionError("patch gate failed: interface affordance records did not form from desktop observation")
    if interface_affordance.get("write_like_blocked_count", 0) < 1 or interface_affordance.get("actuation_grant_count", 1) != 0:
        raise AssertionError("patch gate failed: interface affordance cortex granted actuation or failed to block write-like candidates")
    if any(str(node.get("id", "")).startswith("ui:t") for node in snap["graph"]["nodes"]):
        raise AssertionError("patch gate failed: tick-specific UI affordance node leaked")
    dummy_bench = snap["dummy_bench"]
    if dummy_bench.get("executed_count", 0) < 4 or dummy_bench.get("changed_count", 0) < 2:
        raise AssertionError("patch gate failed: dummy bench did not execute consequence-bearing practice")
    if dummy_bench.get("real_os_touch_count", 1) != 0:
        raise AssertionError("patch gate failed: dummy bench touched real OS authority")
    if any(str(node.get("id", "")).startswith("dummy:t") for node in snap["graph"]["nodes"]):
        raise AssertionError("patch gate failed: tick-specific dummy bench node leaked")
    viewport_graph = GraphViewportProjector().project(
        graph=loop.graph,
        tick=loop.tick,
        budget=GraphViewportBudget(node_limit=96, edge_limit=160),
    )
    if len(viewport_graph.get("nodes", [])) > 96 or len(viewport_graph.get("edges", [])) > 160:
        raise AssertionError("patch gate failed: graph viewport exceeded explicit render budget")
    if "viewport" not in viewport_graph or viewport_graph["viewport"].get("mode") != "budgeted":
        raise AssertionError("patch gate failed: graph viewport budget metadata missing")
    with __import__("tempfile").TemporaryDirectory() as tmp:
        path = Path(tmp) / "brain.json"
        save_loop(loop, path, seed=337, note="patch gate")
        restored, _ = load_loop(path)
        restored_snap = restored.snapshot().__dict__
        if restored_snap["planning"].get("plan_template_count") != planning.get("plan_template_count"):
            raise AssertionError("patch gate failed: plan templates did not persist")
        if restored_snap["emotion"].get("last_bias") is None:
            raise AssertionError("patch gate failed: emotion bias did not persist")
        if restored_snap["contextual_affordance"].get("record_count") != contextual.get("record_count"):
            raise AssertionError("patch gate failed: contextual affordance memory did not persist")
        if restored_snap["object_file"].get("file_count") != object_file.get("file_count"):
            raise AssertionError("patch gate failed: object-file memory did not persist")
        if restored_snap["memory_economy"].get("summary_count") != memory_economy.get("summary_count"):
            raise AssertionError("patch gate failed: memory-economy summaries did not persist")
        if restored_snap["play"].get("pattern_count") != play.get("pattern_count"):
            raise AssertionError("patch gate failed: intrinsic play patterns did not persist")
        if restored_snap["grounded_language"].get("record_count") != grounded_language.get("record_count"):
            raise AssertionError("patch gate failed: grounded language records did not persist")
        if restored_snap["os_observation"].get("observation_count") != os_observation.get("observation_count"):
            raise AssertionError("patch gate failed: OS observations did not persist")
        if restored_snap["external_interface"].get("surface_count") != external_interface.get("surface_count"):
            raise AssertionError("patch gate failed: external interface registry did not persist")
        if restored_snap["interface_affordance"].get("record_count") != interface_affordance.get("record_count"):
            raise AssertionError("patch gate failed: interface affordance records did not persist")
        if restored_snap["dummy_bench"].get("executed_count") != dummy_bench.get("executed_count"):
            raise AssertionError("patch gate failed: dummy bench practice did not persist")
        if not restored_snap["runtime_shell"].get("supports_desktop_exe"):
            raise AssertionError("patch gate failed: runtime shell policy did not persist")
    ProjectScopePolicy(Path(__file__).resolve().parents[2]).validate()


if __name__ == "__main__":
    raise SystemExit(main())
