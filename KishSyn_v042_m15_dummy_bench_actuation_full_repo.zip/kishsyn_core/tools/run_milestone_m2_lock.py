"""Run the governed M2 cross-modal binding / intent persistence lock report."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from kishsyn_core.milestone import MilestoneM2LockEvaluator


def main() -> int:
    parser = argparse.ArgumentParser(description="Run KishSyn M2 lock report")
    parser.add_argument("--seed", type=int, default=337)
    parser.add_argument("--seeds", type=str, default="337,171,23")
    parser.add_argument("--steps", type=int, default=160)
    parser.add_argument("--ablation-steps", type=int, default=32)
    parser.add_argument("--out", type=str, default="stores/_demo/milestone_m2_lock_report.json")
    args = parser.parse_args()
    seeds = tuple(int(part.strip()) for part in args.seeds.split(",") if part.strip())
    report = MilestoneM2LockEvaluator().evaluate(seed=args.seed, seeds=seeds, steps=args.steps, ablation_steps=args.ablation_steps)
    payload = report.as_dict()
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
    status = "LOCKED" if report.locked else "CANDIDATE"
    print(f"[KishSyn Core] M2 {status} score={report.summary_score} verdict={report.verdict!r}")
    print(f"[KishSyn Core] wrote {out}")
    return 0 if report.locked else 2


if __name__ == "__main__":
    raise SystemExit(main())
