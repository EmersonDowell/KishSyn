"""Emergent comfort-attractor memory.

This module does not define a home base. It tracks whether places repeatedly
reduce body pressure, remain predictable, stay safe, and become familiar. If a
region becomes useful, action selection may bias toward it as a learned comfort
basin.
"""

from __future__ import annotations

from dataclasses import dataclass

from .contracts import BodyState, Outcome, PlasticityEvent
from .neural_graph import NeuralGrowthGraph


@dataclass
class ComfortBasin:
    place_key: str
    terrain: str
    familiarity: float = 0.0
    recovery: float = 0.0
    safety: float = 0.0
    predictability: float = 0.0
    visits: int = 0
    last_tick: int = 0

    @property
    def score(self) -> float:
        return max(
            -1.0,
            min(
                1.0,
                self.familiarity * 0.22
                + self.recovery * 0.34
                + self.safety * 0.24
                + self.predictability * 0.20,
            ),
        )


class ComfortAttractorMemory:
    """Learns place comfort from pressure relief, safety, and predictability."""

    def __init__(self, *, capacity: int = 96) -> None:
        self.capacity = capacity
        self.basins: dict[str, ComfortBasin] = {}
        self.history: list[dict[str, object]] = []

    def record(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph,
        place_key: str,
        terrain: str,
        body_before: BodyState,
        body_after: BodyState,
        outcome: Outcome,
        prediction_error: float,
        world_events: tuple[str, ...] = (),
    ) -> tuple[PlasticityEvent, ...]:
        basin = self.basins.get(place_key)
        if basin is None:
            basin = ComfortBasin(place_key=place_key, terrain=terrain)
            self.basins[place_key] = basin
        basin.visits += 1
        basin.last_tick = tick
        basin.terrain = terrain

        pressure_before = self._pressure(body_before)
        pressure_after = self._pressure(body_after)
        relief = max(-1.0, min(1.0, pressure_before - pressure_after))
        hazard = 1.0 if outcome.kind == "pain" or any("hazard" in event for event in world_events) else 0.0
        predictable = max(-1.0, min(1.0, 1.0 - prediction_error * 1.4))
        familiarity_gain = 1.0 / max(4.0, float(basin.visits))

        basin.familiarity = self._ema(basin.familiarity, familiarity_gain, 0.08)
        basin.recovery = self._ema(basin.recovery, relief, 0.16)
        basin.safety = self._ema(basin.safety, 1.0 - hazard * 2.0, 0.12)
        basin.predictability = self._ema(basin.predictability, predictable, 0.12)

        self.history.append(
            {
                "tick": tick,
                "place": place_key,
                "terrain": terrain,
                "outcome": outcome.kind,
                "relief": round(relief, 4),
                "score": round(basin.score, 4),
            }
        )
        if len(self.history) > self.capacity:
            self.history = self.history[-self.capacity :]

        events: list[PlasticityEvent] = []
        place_node = f"comfort:place={place_key}"
        terrain_node = f"comfort:terrain={terrain}"
        basin_node = "comfort:basin"
        outcome_node = f"outcome:{outcome.kind}"
        for node_id, kind, label in (
            (place_node, "comfort", place_key),
            (terrain_node, "comfort", terrain),
            (basin_node, "comfort", "comfort basin"),
            (outcome_node, "outcome", outcome.kind),
        ):
            graph.ensure_neuron(node_id, kind=kind, label=label, tick=tick)
        graph.activate(place_node, amount=max(0.15, abs(basin.score)), tick=tick)
        graph.activate(terrain_node, amount=0.42, tick=tick)
        graph.activate(basin_node, amount=max(0.10, basin.score), tick=tick)
        if abs(basin.score) > 0.02:
            events.append(graph.reinforce(place_node, basin_node, amount=basin.score * 0.035, tick=tick, reason="learned comfort basin"))
            events.append(graph.reinforce(terrain_node, basin_node, amount=basin.score * 0.020, tick=tick, reason="terrain comfort context"))
            events.append(graph.reinforce(place_node, outcome_node, amount=max(-0.04, min(0.05, relief * 0.08)), tick=tick, reason="comfort consequence"))
        return tuple(events)

    def score_place(self, *, place_key: str, body: BodyState, terrain: str = "plain") -> float:
        basin = self.basins.get(place_key)
        if basin is None:
            return 0.0
        stress = max(body.needs().values())
        terrain_match = 0.04 if basin.terrain == terrain else 0.0
        return max(-0.38, min(0.38, basin.score * (0.30 + stress * 0.65) + terrain_match))

    def heat_for(self, place_key: str) -> float:
        basin = self.basins.get(place_key)
        return 0.0 if basin is None else round(basin.score, 4)

    def snapshot(self) -> dict[str, object]:
        ranked = sorted(self.basins.values(), key=lambda item: item.score, reverse=True)[:10]
        return {
            "basin_count": len(self.basins),
            "top_basins": [
                {
                    "place": basin.place_key,
                    "terrain": basin.terrain,
                    "score": round(basin.score, 4),
                    "familiarity": round(basin.familiarity, 4),
                    "recovery": round(basin.recovery, 4),
                    "safety": round(basin.safety, 4),
                    "predictability": round(basin.predictability, 4),
                    "visits": basin.visits,
                }
                for basin in ranked
            ],
            "recent": self.history[-12:],
        }

    def _pressure(self, body: BodyState) -> float:
        needs = body.needs()
        return max(0.0, min(1.0, sum(needs.values()) / len(needs)))

    def _ema(self, old: float, value: float, rate: float) -> float:
        return max(-1.0, min(1.0, old * (1.0 - rate) + value * rate))
