"""Context-bound affordance memory for KishSyn Core.

This module begins the M8 direction: concepts are not commands. A perceived
object kind may carry different learned uses depending on actor/body, world
rules, action, provenance, and lived outcome. The layer observes completed
experience and stores reusable evidence; it does not choose actions yet.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Literal

from .contracts import Action, Outcome, PlasticityEvent
from .neural_graph import NeuralGrowthGraph

ContextKind = Literal["simulation", "game", "robot_world", "language", "unknown"]
ActorKind = Literal["kishsyn_sim_body", "game_avatar", "robot_body", "human", "animal", "unknown"]
ProvenanceSource = Literal["self_action", "human_instruction", "simulation_rule", "language", "observation", "unknown"]


@dataclass(frozen=True)
class ActorProfile:
    """The acting body whose abilities make an affordance local, not universal.

    Pattern: Value Object. A robot body, a game avatar, and a human may perceive
    the same object kind but learn different valid actions and consequences.
    """

    actor_id: str = "kishsyn:self"
    kind: ActorKind = "kishsyn_sim_body"
    body_schema: str = "simulated_ecology_body"
    can_metabolize_organic_food: bool = False
    can_receive_game_hp: bool = False

    def node_id(self) -> str:
        return f"actor:{_safe(self.actor_id)}:{self.kind}"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class WorldContext:
    """A local rule field around learned meaning-in-use.

    Pattern: Context Object. Game A, Game B, a toy ecology, and a robot field are
    allowed to disagree about what the same object can do.
    """

    context_id: str = "mini_ecology"
    kind: ContextKind = "simulation"
    rule_surface: str = "deterministic_toy_ecology"
    confidence: float = 1.0

    def node_id(self) -> str:
        return f"context:{_safe(self.context_id)}:{self.kind}"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class RealityProvenance:
    """Where a learned affordance claim came from.

    Pattern: Provenance Stamp. Later transfer can treat self-action, language,
    and game-rule evidence differently instead of blending them into one truth.
    """

    source: ProvenanceSource = "self_action"
    confidence: float = 1.0
    note: str = "lived action outcome"

    def node_id(self) -> str:
        return f"provenance:{self.source}"

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class ObjectKindSignature:
    """Reusable object-kind signature derived from sensory tokens, not object ids."""

    signature_id: str
    features: tuple[str, ...]

    def node_id(self) -> str:
        return f"object_kind:{self.signature_id}"

    def as_dict(self) -> dict[str, Any]:
        return {"signature_id": self.signature_id, "features": list(self.features)}


@dataclass
class AffordanceRecord:
    """Reusable conditional action-outcome memory.

    Pattern: Flyweight. Many tick events update one record keyed by actor,
    context, object kind, action, and outcome instead of creating one durable
    node per event.
    """

    record_id: str
    actor_id: str
    actor_kind: ActorKind
    context_id: str
    context_kind: ContextKind
    object_signature: str
    action_kind: str
    outcome_kind: str
    provenance_source: ProvenanceSource
    evidence_count: int = 0
    positive_count: int = 0
    mismatch_count: int = 0
    total_prediction_error: float = 0.0
    last_tick: int = 0

    def observe(self, *, tick: int, prediction_error: float) -> None:
        self.evidence_count += 1
        self.positive_count += 1 if prediction_error <= 0.72 else 0
        self.mismatch_count += 0 if prediction_error <= 0.72 else 1
        self.total_prediction_error += float(prediction_error)
        self.last_tick = int(tick)

    @property
    def confidence(self) -> float:
        evidence = min(1.0, self.evidence_count / 8.0)
        alignment = self.positive_count / max(1, self.evidence_count)
        return max(0.0, min(1.0, evidence * 0.45 + alignment * 0.55))

    def as_dict(self) -> dict[str, Any]:
        return {
            "record_id": self.record_id,
            "actor_id": self.actor_id,
            "actor_kind": self.actor_kind,
            "context_id": self.context_id,
            "context_kind": self.context_kind,
            "object_signature": self.object_signature,
            "action_kind": self.action_kind,
            "outcome_kind": self.outcome_kind,
            "provenance_source": self.provenance_source,
            "evidence_count": self.evidence_count,
            "positive_count": self.positive_count,
            "mismatch_count": self.mismatch_count,
            "confidence": round(self.confidence, 4),
            "mean_prediction_error": round(self.total_prediction_error / max(1, self.evidence_count), 4),
            "last_tick": self.last_tick,
        }


@dataclass(frozen=True)
class TransferHypothesis:
    """Weak cross-context reuse proposal, not a hard belief."""

    source_record_id: str
    target_context_id: str
    object_signature: str
    action_kind: str
    hypothesized_outcome: str
    strength: float
    reason: str

    def as_dict(self) -> dict[str, Any]:
        return {**asdict(self), "strength": round(float(self.strength), 4)}


@dataclass(frozen=True)
class AffordanceBiasContract:
    """Governed action-bias evidence exported from contextual affordances.

    Pattern: Contract Object. M8 may report whether a local context makes an
    action look useful or risky, but this contract is not an action command and
    cross-context evidence is intentionally inhibited until local evidence is
    recorded in the target world/body.
    """

    actor_id: str
    actor_kind: ActorKind
    context_id: str
    context_kind: ContextKind
    object_signature: str
    action_kind: str
    local_record_id: str | None
    local_confidence: float
    transfer_strength: float
    bias: float
    inhibited: bool
    may_command_action: bool
    reason: str

    def as_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["local_confidence"] = round(float(self.local_confidence), 4)
        payload["transfer_strength"] = round(float(self.transfer_strength), 4)
        payload["bias"] = round(float(self.bias), 4)
        return payload


class ContextualAffordanceCortex:
    """Stores meaning-in-use as actor + context + object + action + outcome.

    Pattern: Repository + Strategy. The Repository stores reusable records; the
    transfer Strategy produces weak hypotheses across contexts without promoting
    them to truth until local evidence arrives.
    """

    def __init__(self, *, capacity: int = 256) -> None:
        self.capacity = max(16, int(capacity))
        self.records: dict[str, AffordanceRecord] = {}
        self.history: list[dict[str, Any]] = []
        self.transfer_hypotheses: list[TransferHypothesis] = []
        self.record_updates = 0
        self.object_kind_count = 0
        self.context_count = 0
        self.actor_count = 0

    def record(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph,
        actor: ActorProfile,
        context: WorldContext,
        target_features: tuple[str, ...],
        action: Action,
        outcome: Outcome,
        prediction_error: float,
        provenance: RealityProvenance | None = None,
    ) -> tuple[PlasticityEvent, ...]:
        """Record completed contextual affordance evidence after a lived tick."""

        if action.target_id is None:
            return ()
        provenance = provenance or RealityProvenance()
        object_kind = object_kind_from_features(target_features)
        record_id = _record_id(actor=actor, context=context, object_kind=object_kind, action_kind=action.kind, outcome_kind=outcome.kind, provenance=provenance)
        record = self.records.get(record_id)
        if record is None:
            record = AffordanceRecord(
                record_id=record_id,
                actor_id=actor.actor_id,
                actor_kind=actor.kind,
                context_id=context.context_id,
                context_kind=context.kind,
                object_signature=object_kind.signature_id,
                action_kind=action.kind,
                outcome_kind=outcome.kind,
                provenance_source=provenance.source,
            )
            self.records[record_id] = record
            self._trim_records()
        record.observe(tick=tick, prediction_error=prediction_error)
        self.record_updates += 1

        actor_node = actor.node_id()
        context_node = context.node_id()
        object_node = object_kind.node_id()
        provenance_node = provenance.node_id()
        affordance_node = f"affordance:{record_id}"
        outcome_node = f"outcome:{outcome.kind}"
        graph.ensure_neuron(actor_node, kind="actor", label=f"{actor.kind}:{actor.actor_id}", tick=tick)
        graph.ensure_neuron(context_node, kind="world_context", label=f"{context.kind}:{context.context_id}", tick=tick)
        graph.ensure_neuron(object_node, kind="object_kind", label=object_kind.signature_id, tick=tick)
        graph.ensure_neuron(provenance_node, kind="provenance", label=provenance.source, tick=tick)
        graph.ensure_neuron(affordance_node, kind="affordance", label=f"{object_kind.signature_id}:{action.kind}->{outcome.kind}", tick=tick)
        graph.ensure_neuron(outcome_node, kind="outcome", label=outcome.kind, tick=tick)
        graph.activate(affordance_node, amount=max(0.20, min(1.0, record.confidence)), tick=tick)
        amount = 0.020 if prediction_error <= 0.72 else -0.008
        events = (
            graph.reinforce(actor_node, affordance_node, amount=0.012, tick=tick, reason="contextual affordance actor evidence"),
            graph.reinforce(context_node, affordance_node, amount=0.014, tick=tick, reason="contextual affordance world-rule evidence"),
            graph.reinforce(object_node, affordance_node, amount=0.018, tick=tick, reason="contextual affordance object-kind evidence"),
            graph.reinforce(provenance_node, affordance_node, amount=0.010, tick=tick, reason="contextual affordance provenance evidence"),
            graph.reinforce(affordance_node, outcome_node, amount=amount, tick=tick, reason="contextual affordance outcome evidence"),
        )
        self.history.append(record.as_dict())
        self.history = self.history[-64:]
        self._refresh_counts()
        return events

    def propose_transfer(
        self,
        *,
        object_kind: ObjectKindSignature,
        action_kind: str,
        target_context: WorldContext,
        target_actor: ActorProfile,
    ) -> tuple[TransferHypothesis, ...]:
        """Return weak transfer hypotheses from matching object/action records.

        Cross-context evidence is intentionally inhibited. It can become a local
        belief only after `record()` receives lived target-context evidence.
        """

        hypotheses: list[TransferHypothesis] = []
        for record in self.records.values():
            if record.object_signature != object_kind.signature_id or record.action_kind != action_kind:
                continue
            same_context = record.context_id == target_context.context_id and record.context_kind == target_context.kind
            same_actor = record.actor_id == target_actor.actor_id and record.actor_kind == target_actor.kind
            if same_context and same_actor:
                strength = record.confidence
                reason = "same actor and context; local evidence may be reused"
            else:
                context_penalty = 0.35 if not same_context else 1.0
                actor_penalty = 0.55 if not same_actor else 1.0
                strength = record.confidence * context_penalty * actor_penalty
                reason = "cross-context transfer inhibited until local confirmation"
            if strength <= 0.01:
                continue
            hypotheses.append(
                TransferHypothesis(
                    source_record_id=record.record_id,
                    target_context_id=target_context.context_id,
                    object_signature=object_kind.signature_id,
                    action_kind=action_kind,
                    hypothesized_outcome=record.outcome_kind,
                    strength=strength,
                    reason=reason,
                )
            )
        hypotheses.sort(key=lambda item: (-item.strength, item.source_record_id))
        self.transfer_hypotheses = hypotheses[:12]
        return tuple(self.transfer_hypotheses)

    def bias_contract(
        self,
        *,
        object_kind: ObjectKindSignature,
        action_kind: str,
        target_context: WorldContext,
        target_actor: ActorProfile,
    ) -> AffordanceBiasContract:
        """Return an inspectable, non-command bias contract for one action.

        Local target-world evidence may create a small positive or negative bias.
        Cross-context evidence may only create a weak hypothesis and must remain
        inhibited. This keeps Game-A apple healing from becoming a robot-body
        assumption that the apple is self-edible.
        """

        local_records = [
            record
            for record in self.records.values()
            if record.object_signature == object_kind.signature_id
            and record.action_kind == action_kind
            and record.context_id == target_context.context_id
            and record.context_kind == target_context.kind
            and record.actor_id == target_actor.actor_id
            and record.actor_kind == target_actor.kind
        ]
        local_records.sort(key=lambda record: (-record.confidence, -record.evidence_count, record.record_id))
        if local_records:
            record = local_records[0]
            valence = _outcome_valence(record.outcome_kind)
            bias = max(-0.35, min(0.35, valence * record.confidence * 0.35))
            return AffordanceBiasContract(
                actor_id=target_actor.actor_id,
                actor_kind=target_actor.kind,
                context_id=target_context.context_id,
                context_kind=target_context.kind,
                object_signature=object_kind.signature_id,
                action_kind=action_kind,
                local_record_id=record.record_id,
                local_confidence=record.confidence,
                transfer_strength=0.0,
                bias=bias,
                inhibited=False,
                may_command_action=False,
                reason="local contextual evidence may gently bias ranking, never command action",
            )
        transfers = self.propose_transfer(
            object_kind=object_kind,
            action_kind=action_kind,
            target_context=target_context,
            target_actor=target_actor,
        )
        transfer_strength = transfers[0].strength if transfers else 0.0
        weak_bias = min(0.08, transfer_strength * 0.18)
        return AffordanceBiasContract(
            actor_id=target_actor.actor_id,
            actor_kind=target_actor.kind,
            context_id=target_context.context_id,
            context_kind=target_context.kind,
            object_signature=object_kind.signature_id,
            action_kind=action_kind,
            local_record_id=None,
            local_confidence=0.0,
            transfer_strength=transfer_strength,
            bias=weak_bias,
            inhibited=True,
            may_command_action=False,
            reason="cross-context affordance transfer is a weak hypothesis until target-world evidence exists",
        )

    def snapshot(self) -> dict[str, Any]:
        records = sorted((record.as_dict() for record in self.records.values()), key=lambda item: (-int(item["evidence_count"]), str(item["record_id"])))
        return {
            "record_count": len(self.records),
            "record_updates": self.record_updates,
            "object_kind_count": self.object_kind_count,
            "context_count": self.context_count,
            "actor_count": self.actor_count,
            "top_records": records[:12],
            "last_records": self.history[-8:],
            "transfer_hypotheses": [item.as_dict() for item in self.transfer_hypotheses[-8:]],
        }

    def state(self) -> dict[str, Any]:
        return {
            "capacity": self.capacity,
            "record_updates": self.record_updates,
            "records": [record.as_dict() for record in self.records.values()],
            "history": self.history[-64:],
            "transfer_hypotheses": [item.as_dict() for item in self.transfer_hypotheses[-12:]],
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "ContextualAffordanceCortex":
        cortex = cls(capacity=int(data.get("capacity", 256)))
        cortex.record_updates = int(data.get("record_updates", 0))
        for item in data.get("records", []):
            record = AffordanceRecord(
                record_id=str(item["record_id"]),
                actor_id=str(item.get("actor_id", "kishsyn:self")),
                actor_kind=item.get("actor_kind", "unknown"),
                context_id=str(item.get("context_id", "unknown")),
                context_kind=item.get("context_kind", "unknown"),
                object_signature=str(item.get("object_signature", "object=unknown")),
                action_kind=str(item.get("action_kind", "wait")),
                outcome_kind=str(item.get("outcome_kind", "neutral")),
                provenance_source=item.get("provenance_source", "unknown"),
                evidence_count=int(item.get("evidence_count", 0)),
                positive_count=int(item.get("positive_count", 0)),
                mismatch_count=int(item.get("mismatch_count", 0)),
                total_prediction_error=float(item.get("mean_prediction_error", 0.0)) * max(1, int(item.get("evidence_count", 0))),
                last_tick=int(item.get("last_tick", 0)),
            )
            cortex.records[record.record_id] = record
        cortex.history = [dict(item) for item in data.get("history", [])][-64:]
        cortex.transfer_hypotheses = [
            TransferHypothesis(
                source_record_id=str(item.get("source_record_id", "")),
                target_context_id=str(item.get("target_context_id", "")),
                object_signature=str(item.get("object_signature", "")),
                action_kind=str(item.get("action_kind", "")),
                hypothesized_outcome=str(item.get("hypothesized_outcome", "neutral")),
                strength=float(item.get("strength", 0.0)),
                reason=str(item.get("reason", "restored")),
            )
            for item in data.get("transfer_hypotheses", [])
        ][-12:]
        cortex._refresh_counts()
        return cortex

    def _trim_records(self) -> None:
        if len(self.records) <= self.capacity:
            return
        ordered = sorted(self.records.values(), key=lambda record: (record.evidence_count, record.last_tick, record.record_id))
        for record in ordered[: max(0, len(self.records) - self.capacity)]:
            self.records.pop(record.record_id, None)

    def _refresh_counts(self) -> None:
        self.object_kind_count = len({record.object_signature for record in self.records.values()})
        self.context_count = len({(record.context_id, record.context_kind) for record in self.records.values()})
        self.actor_count = len({(record.actor_id, record.actor_kind) for record in self.records.values()})


def object_kind_from_features(features: tuple[str, ...]) -> ObjectKindSignature:
    """Build a reusable sensory object signature while ignoring instance spam."""

    keep_prefixes = (
        "vision:color=",
        "vision:shape=",
        "vision:glyph=",
        "vision:paired_color=",
        "vision:paired_shape=",
        "vision:paired_glyph=",
        "vision:symbol_token=",
        "screen:descriptor=",
        "image:descriptor=",
    )
    kept_raw: list[str] = []
    kept_safe: list[str] = []
    for feature in features:
        if feature.startswith(keep_prefixes):
            kept_raw.append(feature)
            kept_safe.append(_safe_feature(feature))
    if not kept_safe:
        return ObjectKindSignature(signature_id="object=unknown", features=())
    unique_pairs = sorted({safe: raw for safe, raw in zip(kept_safe, kept_raw)}.items())
    signature_id = "|".join(safe for safe, _raw in unique_pairs)
    raw_features = tuple(raw for _safe_name, raw in unique_pairs)
    return ObjectKindSignature(signature_id=signature_id, features=raw_features)


def _record_id(
    *,
    actor: ActorProfile,
    context: WorldContext,
    object_kind: ObjectKindSignature,
    action_kind: str,
    outcome_kind: str,
    provenance: RealityProvenance,
) -> str:
    return ":".join(
        _safe(part)
        for part in (
            context.kind,
            context.context_id,
            actor.kind,
            actor.actor_id,
            object_kind.signature_id,
            action_kind,
            outcome_kind,
            provenance.source,
        )
    )


def _outcome_valence(outcome_kind: str) -> float:
    """Small local valence map for governed affordance bias.

    The values are intentionally conservative. They are used for ranking
    pressure only, not command selection.
    """

    if outcome_kind in {"relief", "novelty", "communication"}:
        return 1.0
    if outcome_kind in {"pain", "blocked", "depleted"}:
        return -1.0
    return 0.0


def _safe_feature(value: str) -> str:
    return _safe(value.replace(":", "_"))


def _safe(value: object) -> str:
    text = str(value).strip().lower().replace(" ", "_")
    allowed = []
    for char in text:
        if char.isalnum() or char in {"_", "-", "=", "|", "."}:
            allowed.append(char)
        else:
            allowed.append("_")
    compact = "".join(allowed)
    while "__" in compact:
        compact = compact.replace("__", "_")
    return compact.strip("_") or "unknown"
