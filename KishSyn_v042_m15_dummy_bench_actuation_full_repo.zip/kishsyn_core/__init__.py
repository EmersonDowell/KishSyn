"""KishSyn Core Rebase v036.

A deliberately small reflex-first substrate. The package exposes one living loop,
one living ecology, developmental regulation, focus-gated MomentFrames,
cross-modal binding, provisional anatomy growth, motor experimentation,
trace-grounded sensory abstraction, embodied symbol teaching, symbol-guided choice,
persistent brain-state save/load, trace-grounded text crib, bounded autonomous tutor pulses, controlled benchmark playgrounds, observatory test/evidence visualization, persistent report history, live action-reasoning mementos, Milestone M1/M2/M3 lock reports, counterfactual replay/proto-planning, context-bound affordance memory, contextual affordance bias contracts, Apple Across Worlds lock evidence, object-file identity, retention-pressure memory economy, external embodiment contracts, one neural growth graph, and one observatory surface.
"""

from .loop import OrganismLoop, OrganismSnapshot
from .state import DEFAULT_STATE_PATH, load_loop, save_loop
from .world import MiniEcologyWorld

__version__ = "0.36.0"

__all__ = ["OrganismLoop", "OrganismSnapshot", "MiniEcologyWorld", "DEFAULT_STATE_PATH", "load_loop", "save_loop"]
