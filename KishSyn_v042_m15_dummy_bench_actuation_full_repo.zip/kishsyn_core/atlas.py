"""Standard neural atlas projection for KishSyn Core.

The atlas is the GUI-facing mirror of the growing brain. It does not compute
cognition. It standardizes how every sensory, motor, memory, planning,
expression, and anatomy surface appears as inspectable neural activity.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from typing import Any

from .contracts import TickTrace
from .neural_graph import NeuralGrowthGraph


@dataclass(frozen=True)
class NeuralAtlasFrame:
    tick: int
    node_count: int
    edge_count: int
    surface_counts: dict[str, int]
    active_nodes: tuple[dict[str, object], ...]
    active_edges: tuple[dict[str, object], ...]
    recent_plasticity: tuple[dict[str, object], ...]
    doctrine: str

    def as_dict(self) -> dict[str, object]:
        return {
            "tick": self.tick,
            "node_count": self.node_count,
            "edge_count": self.edge_count,
            "surface_counts": dict(self.surface_counts),
            "active_nodes": list(self.active_nodes),
            "active_edges": list(self.active_edges),
            "recent_plasticity": list(self.recent_plasticity),
            "doctrine": self.doctrine,
        }


class NeuralAtlasProjector:
    """Projects graph state into a standardized live atlas surface.

    Pattern: Facade + Read Model. The GUI reads this projection so visual code
    never needs private knowledge of how individual modules store neurons.
    """

    doctrine = "Every surface touched by KishSyn must become inspectable graph activity: sensory, focus, moment, binding, anatomy, intent, planning, emotional regulation, expression, and motor consequence."

    def project(self, *, tick: int, graph: NeuralGrowthGraph, last_trace: TickTrace | None = None) -> NeuralAtlasFrame:
        nodes = list(graph.neurons.values())
        edges = [syn for syn in graph.synapses.values() if abs(syn.weight) > 0.01]
        surface_counts = Counter(self._surface_for_node(node.node_id, node.kind) for node in nodes)
        active_nodes = sorted(
            (
                {
                    "id": node.node_id,
                    "kind": node.kind,
                    "surface": self._surface_for_node(node.node_id, node.kind),
                    "label": node.label,
                    "activation": round(node.activation, 4),
                    "created_at": node.created_at,
                    "last_active": node.last_active,
                }
                for node in nodes
                if node.activation > 0.04 or tick - node.last_active <= 4
            ),
            key=lambda item: (-float(item["activation"]), -int(item["last_active"]), str(item["id"])),
        )[:80]
        active_edges = sorted(
            (
                {
                    "source": syn.source,
                    "target": syn.target,
                    "source_surface": self._surface_for_id(syn.source),
                    "target_surface": self._surface_for_id(syn.target),
                    "weight": round(syn.weight, 4),
                    "updates": syn.updates,
                    "last_updated": syn.last_updated,
                }
                for syn in edges
                if tick - syn.last_updated <= 12 or abs(syn.weight) >= 0.35
            ),
            key=lambda item: (-int(item["last_updated"]), -abs(float(item["weight"])), str(item["source"])),
        )[:120]
        plasticity = ()
        if last_trace is not None:
            plasticity = tuple(
                {
                    "source": event.source,
                    "target": event.target,
                    "source_surface": self._surface_for_id(event.source),
                    "target_surface": self._surface_for_id(event.target),
                    "before": round(event.before, 4),
                    "after": round(event.after, 4),
                    "delta": round(event.after - event.before, 4),
                    "reason": event.reason,
                }
                for event in last_trace.plasticity[-24:]
            )
        return NeuralAtlasFrame(
            tick=tick,
            node_count=len(nodes),
            edge_count=len(edges),
            surface_counts=dict(sorted(surface_counts.items())),
            active_nodes=tuple(active_nodes),
            active_edges=tuple(active_edges),
            recent_plasticity=plasticity,
            doctrine=self.doctrine,
        )

    def _surface_for_node(self, node_id: str, kind: str) -> str:
        if kind in {"concept", "symbol", "text", "tutor", "expression", "emotion", "circuit", "binding"}:
            return kind
        return self._surface_for_id(node_id)

    def _surface_for_id(self, node_id: str) -> str:
        prefix = node_id.split(":", 1)[0]
        if prefix in {"vision", "screen", "image", "audio", "math", "text", "body", "action", "outcome", "need", "self", "place", "terrain", "symbol", "symbol_goal", "concept", "binding", "circuit", "intent", "plan", "predicted", "expression", "motor", "route", "comfort", "development", "priority", "tutor", "emotion"}:
            return prefix
        return "unknown"
