"""Intent persistence for the M2 substrate.

An intent is not a thought label. It is a short-lived action commitment that
survives across moments while the target remains useful, reachable, and safe.
The model gives KishSyn a governed way to keep pursuing what she selected
instead of jittering between every newly salient signal.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from .action import ActionCandidate
from .contracts import Action, BodyState, Outcome, PlasticityEvent
from .neural_graph import NeuralGrowthGraph
from .world import MiniEcologyWorld


@dataclass
class IntentState:
    """One active action commitment.

    Pattern: Memento. The state is explicit and serializable so persistence,
    tests, and the Observatory can inspect intent without hidden policy.
    """

    intent_id: str
    target_id: str
    action_kind: str
    dominant_need: str
    expected_outcome: str
    started_tick: int
    last_tick: int
    reason: str
    strength: float = 0.0
    continuation_ticks: int = 0
    status: str = "active"
    active_symbols: tuple[str, ...] = ()

    def as_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["active_symbols"] = list(self.active_symbols)
        payload["strength"] = round(float(self.strength), 4)
        return payload


class IntentModel:
    """Maintains and audits short-lived target commitments.

    Pattern: State Machine. Intents start, continue, complete, abandon, or expire
    through explicit conditions. The model may stabilize target pursuit, but it
    cannot create a goal from nowhere and cannot override survival pressure.
    """

    def __init__(self, *, max_age: int = 24) -> None:
        self.max_age = max(4, int(max_age))
        self.current: IntentState | None = None
        self.last: IntentState | None = None
        self.started_count = 0
        self.continued_count = 0
        self.completed_count = 0
        self.abandoned_count = 0
        self.expired_count = 0
        self.override_count = 0
        self.update_count = 0
        self.history: list[dict[str, Any]] = []

    def stabilize(
        self,
        *,
        tick: int,
        candidate: ActionCandidate,
        world: MiniEcologyWorld,
        body: BodyState,
        active_symbol_tokens: tuple[str, ...] = (),
    ) -> ActionCandidate:
        """Return a continuity-adjusted candidate when an active intent is valid."""

        pressure = max(body.needs().values())
        if self.current is not None:
            age = tick - self.current.started_tick
            target = world.objects.get(self.current.target_id)
            if target is None or target.quantity <= 0:
                self._end(tick=tick, status="completed", reason="target unavailable or depleted")
            elif target.affordance == "hazard" or body.integrity < 0.18:
                self._end(tick=tick, status="abandoned", reason="unsafe target or survival pressure")
            elif age > self.max_age:
                self._end(tick=tick, status="expired", reason="intent aged out")
            elif pressure < 0.92:
                self.current.last_tick = tick
                self.current.continuation_ticks += 1
                self.current.strength = min(1.0, self.current.strength + 0.055)
                self.continued_count += 1
                distance = world.distance_to(target.object_id)
                if distance > 0:
                    reason = f"intent continuity toward {target.color}/{target.shape}; {candidate.action.reason}"
                    return ActionCandidate(Action("move", target.object_id, reason), candidate.score + 0.16 + self.current.strength * 0.12, reason)
                reason = f"intent reached {target.color}/{target.shape}; {candidate.action.reason}"
                return ActionCandidate(Action("touch", target.object_id, reason), candidate.score + 0.24 + self.current.strength * 0.12, reason)
            else:
                self.override_count += 1

        self._maybe_start(tick=tick, candidate=candidate, world=world, body=body, active_symbol_tokens=active_symbol_tokens)
        return candidate

    def record_outcome(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph,
        action: Action,
        outcome: Outcome,
        prediction_error: float,
    ) -> tuple[PlasticityEvent, ...]:
        """Update intent state from actual consequence and write graph traces."""

        self.update_count += 1
        if self.current is None:
            return ()
        current = self.current
        events: list[PlasticityEvent] = []
        intent_node = current.intent_id
        graph.ensure_neuron(intent_node, kind="intent", label=f"{current.dominant_need}:{current.target_id}", tick=tick)
        graph.activate(intent_node, amount=max(0.25, current.strength), tick=tick)
        action_node = f"action:{action.kind}"
        outcome_node = f"outcome:{outcome.kind}"
        need_node = f"need:{current.dominant_need}"
        target_node = f"target:{current.target_id}"
        for node, kind, label in ((action_node, "action", action.kind), (outcome_node, "outcome", outcome.kind), (need_node, "need", current.dominant_need), (target_node, "target", current.target_id)):
            graph.ensure_neuron(node, kind=kind, label=label, tick=tick)
        events.append(graph.reinforce(need_node, intent_node, amount=0.014, tick=tick, reason="need recruits persistent intent"))
        events.append(graph.reinforce(intent_node, action_node, amount=0.014, tick=tick, reason="intent commits motor action"))
        events.append(graph.reinforce(intent_node, target_node, amount=0.018, tick=tick, reason="intent binds target"))
        events.append(graph.reinforce(intent_node, outcome_node, amount=0.016 if outcome.kind in {"relief", "novelty"} else -0.010 if outcome.kind == "pain" else 0.006, tick=tick, reason="intent consequence trace"))
        if outcome.kind in {"relief", "novelty", "depleted"} and action.target_id == current.target_id:
            self._end(tick=tick, status="completed", reason=f"intent resolved by {outcome.kind}")
        elif outcome.kind == "pain" or prediction_error >= 0.90:
            self._end(tick=tick, status="abandoned", reason=f"intent disrupted by {outcome.kind} / error {prediction_error:.2f}")
        return tuple(events)

    def snapshot(self) -> dict[str, Any]:
        total_terminal = self.completed_count + self.abandoned_count + self.expired_count
        continuity_ratio = self.continued_count / max(1, self.started_count + self.continued_count)
        return {
            "current": None if self.current is None else self.current.as_dict(),
            "last": None if self.last is None else self.last.as_dict(),
            "started_count": self.started_count,
            "continued_count": self.continued_count,
            "completed_count": self.completed_count,
            "abandoned_count": self.abandoned_count,
            "expired_count": self.expired_count,
            "override_count": self.override_count,
            "update_count": self.update_count,
            "terminal_count": total_terminal,
            "continuity_ratio": round(float(continuity_ratio), 4),
            "history": self.history[-12:],
        }

    def state(self) -> dict[str, Any]:
        return {
            "max_age": self.max_age,
            "current": None if self.current is None else self.current.as_dict(),
            "last": None if self.last is None else self.last.as_dict(),
            "started_count": self.started_count,
            "continued_count": self.continued_count,
            "completed_count": self.completed_count,
            "abandoned_count": self.abandoned_count,
            "expired_count": self.expired_count,
            "override_count": self.override_count,
            "update_count": self.update_count,
            "history": self.history[-96:],
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "IntentModel":
        model = cls(max_age=int(data.get("max_age", 24)))
        model.current = _intent_from_dict(data.get("current"))
        model.last = _intent_from_dict(data.get("last"))
        model.started_count = int(data.get("started_count", 0))
        model.continued_count = int(data.get("continued_count", 0))
        model.completed_count = int(data.get("completed_count", 0))
        model.abandoned_count = int(data.get("abandoned_count", 0))
        model.expired_count = int(data.get("expired_count", 0))
        model.override_count = int(data.get("override_count", 0))
        model.update_count = int(data.get("update_count", 0))
        model.history = [dict(item) for item in data.get("history", [])][-96:]
        return model

    def _maybe_start(
        self,
        *,
        tick: int,
        candidate: ActionCandidate,
        world: MiniEcologyWorld,
        body: BodyState,
        active_symbol_tokens: tuple[str, ...],
    ) -> None:
        target_id = candidate.action.target_id
        if target_id not in world.objects:
            return
        target = world.objects[target_id]
        if target.quantity <= 0 or target.affordance == "hazard" or candidate.action.kind not in {"move", "inspect", "touch", "eat", "drink", "rest"}:
            return
        need = body.dominant_need()
        self.current = IntentState(
            intent_id=f"intent:{need}:{target_id}:{tick}",
            target_id=target_id,
            action_kind=candidate.action.kind,
            dominant_need=need,
            expected_outcome="unknown",
            started_tick=tick,
            last_tick=tick,
            reason=candidate.action.reason,
            strength=max(0.18, min(0.72, float(candidate.score) * 0.08 + 0.28)),
            active_symbols=tuple(active_symbol_tokens),
        )
        self.started_count += 1
        self.history.append({"tick": tick, "event": "start", "target": target_id, "need": need, "reason": candidate.action.reason[:144]})
        self.history = self.history[-96:]

    def _end(self, *, tick: int, status: str, reason: str) -> None:
        if self.current is None:
            return
        self.current.status = status
        self.current.last_tick = tick
        self.last = self.current
        if status == "completed":
            self.completed_count += 1
        elif status == "expired":
            self.expired_count += 1
        else:
            self.abandoned_count += 1
        self.history.append({"tick": tick, "event": status, "target": self.current.target_id, "need": self.current.dominant_need, "reason": reason[:144]})
        self.history = self.history[-96:]
        self.current = None


def _intent_from_dict(data: dict[str, Any] | None) -> IntentState | None:
    if not data:
        return None
    return IntentState(
        intent_id=str(data.get("intent_id", "")),
        target_id=str(data.get("target_id", "")),
        action_kind=str(data.get("action_kind", "move")),
        dominant_need=str(data.get("dominant_need", "unknown")),
        expected_outcome=str(data.get("expected_outcome", "unknown")),
        started_tick=int(data.get("started_tick", 0)),
        last_tick=int(data.get("last_tick", 0)),
        reason=str(data.get("reason", "")),
        strength=float(data.get("strength", 0.0)),
        continuation_ticks=int(data.get("continuation_ticks", 0)),
        status=str(data.get("status", "active")),
        active_symbols=tuple(str(item) for item in data.get("active_symbols", [])),
    )
