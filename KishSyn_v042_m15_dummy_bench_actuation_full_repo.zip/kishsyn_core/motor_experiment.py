"""Prediction-driven motor experimentation.

This is not a hardcoded body map. It is a small probe regulator that proposes
safe motor experiments when the organism is stable enough to learn. The normal
action selector may accept or ignore the proposal, and only consequences update
body ownership, prediction, and graph pathways.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from .body_map import ProtoBodyMap
from .contracts import Action, ActionKind, BodyState, Outcome, PlasticityEvent
from .development import LearningFocus
from .neural_graph import NeuralGrowthGraph
from .world import MiniEcologyWorld, WorldObject

ExperimentLabel = Literal["inactive", "probe", "protect"]


@dataclass(frozen=True)
class MotorExperimentIntent:
    """Bounded proposal to test one motor channel.

    The intent is a proposal, not a command. It carries enough information for
    the action selector and observatory to expose why a probe was considered.
    """

    label: ExperimentLabel = "inactive"
    action_kind: ActionKind = "wait"
    target_id: str | None = None
    confidence_before: float = 0.0
    score_boost: float = 0.0
    reason: str = "no probe"

    @property
    def active(self) -> bool:
        return self.label == "probe"


@dataclass
class MotorProbeStats:
    channel: str
    attempts: int = 0
    self_caused: float = 0.0
    reliability: float = 0.0
    useful: float = 0.0
    harmful: float = 0.0
    last_tick: int = 0

    @property
    def controllability(self) -> float:
        return max(0.0, min(1.0, self.self_caused * 0.42 + self.reliability * 0.28 + self.useful * 0.22 - self.harmful * 0.18))


class MotorExperimenter:
    """Chooses occasional safe probes to discover controllable action channels."""

    CHANNELS: tuple[ActionKind, ...] = ("move", "inspect", "touch", "wait")

    def __init__(self) -> None:
        self.stats: dict[str, MotorProbeStats] = {}
        self.history: list[dict[str, object]] = []
        self.last_intent = MotorExperimentIntent()

    def propose(
        self,
        *,
        tick: int,
        body: BodyState,
        focus: LearningFocus,
        body_map: ProtoBodyMap,
        world: MiniEcologyWorld,
    ) -> MotorExperimentIntent:
        survival_pressure = max(1.0 - body.energy, 1.0 - body.hydration, 1.0 - body.integrity, body.fatigue)
        if survival_pressure > 0.66 or focus.mode == "stabilize":
            intent = MotorExperimentIntent("protect", reason="survival pressure too high for motor probe")
            self.last_intent = intent
            return intent
        if focus.mode not in {"explore", "verify"} and tick % 29 != 7:
            intent = MotorExperimentIntent(reason="developmental focus not probing motor channels")
            self.last_intent = intent
            return intent

        ranked = sorted(
            self.CHANNELS,
            key=lambda kind: (self._known_confidence(kind, body_map), self._attempts(kind), kind),
        )
        for channel in ranked:
            target_id = self._target_for(channel, world)
            if channel != "wait" and target_id is None:
                continue
            known = self._known_confidence(channel, body_map)
            # Early life probes are frequent; as controllability rises they thin out.
            cadence = 5 if known < 0.18 else 11 if known < 0.42 else 23
            if tick % cadence not in {1, 3, 5} and focus.mode != "verify":
                continue
            boost = 0.36 + (1.0 - known) * 0.34 + max(0.0, focus.novelty_bias) * 0.22
            reason = f"motor probe {channel}; confidence {known:.2f}; focus {focus.mode}"
            intent = MotorExperimentIntent("probe", channel, target_id, round(known, 4), round(boost, 4), reason)
            self.last_intent = intent
            return intent

        intent = MotorExperimentIntent(reason="no safe motor probe target")
        self.last_intent = intent
        return intent

    def record(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph,
        intent: MotorExperimentIntent,
        action: Action,
        outcome: Outcome,
        prediction_error: float,
        self_causation: float,
        body_before: BodyState,
        body_after: BodyState,
    ) -> tuple[PlasticityEvent, ...]:
        if not intent.active:
            return ()
        channel = f"motor:{action.kind}"
        stats = self.stats.get(channel)
        if stats is None:
            stats = MotorProbeStats(channel=channel)
            self.stats[channel] = stats
        stats.attempts += 1
        stats.last_tick = tick
        reliability = max(0.0, min(1.0, 1.0 - prediction_error))
        useful = 1.0 if outcome.kind in {"relief", "novelty"} else 0.35 if self._body_delta(body_before, body_after) > 0.012 else 0.0
        harmful = 1.0 if outcome.kind == "pain" else 0.0
        stats.self_caused = self._ema(stats.self_caused, self_causation, 0.18)
        stats.reliability = self._ema(stats.reliability, reliability, 0.15)
        stats.useful = self._ema(stats.useful, useful, 0.13)
        stats.harmful = self._ema(stats.harmful, harmful, 0.18)

        result = "harmful" if harmful else "useful" if useful > 0 else "neutral"
        self.history.append(
            {
                "tick": tick,
                "channel": channel,
                "target": action.target_id,
                "outcome": outcome.kind,
                "result": result,
                "self": round(self_causation, 4),
                "reliability": round(reliability, 4),
                "controllability": round(stats.controllability, 4),
            }
        )
        self.history = self.history[-64:]

        experiment_node = f"experiment:channel={action.kind}"
        result_node = f"experiment:result={result}"
        self_node = "self:caused"
        outcome_node = f"outcome:{outcome.kind}"
        for node_id, kind, label in (
            (experiment_node, "experiment", f"probe {action.kind}"),
            (result_node, "experiment", result),
            (self_node, "self", "self caused"),
            (outcome_node, "outcome", outcome.kind),
        ):
            graph.ensure_neuron(node_id, kind=kind, label=label, tick=tick)
        graph.activate(experiment_node, amount=max(0.24, stats.controllability), tick=tick)
        graph.activate(result_node, amount=0.70 if result != "neutral" else 0.38, tick=tick)
        events = [
            graph.reinforce(experiment_node, self_node, amount=self_causation * 0.032, tick=tick, reason="motor probe self-causation evidence"),
            graph.reinforce(experiment_node, outcome_node, amount=(0.024 if outcome.kind != "pain" else -0.030), tick=tick, reason="motor probe outcome evidence"),
            graph.reinforce(experiment_node, result_node, amount=(0.030 if result != "harmful" else -0.024), tick=tick, reason="motor probe result evidence"),
        ]
        return tuple(events)

    def snapshot(self) -> dict[str, object]:
        ranked = sorted(self.stats.values(), key=lambda stat: stat.controllability, reverse=True)
        return {
            "last_intent": self.last_intent.__dict__,
            "channel_count": len(self.stats),
            "probe_count": sum(stat.attempts for stat in self.stats.values()),
            "channels": [
                {
                    "channel": stat.channel,
                    "attempts": stat.attempts,
                    "controllability": round(stat.controllability, 4),
                    "self_caused": round(stat.self_caused, 4),
                    "reliability": round(stat.reliability, 4),
                    "useful": round(stat.useful, 4),
                    "harmful": round(stat.harmful, 4),
                }
                for stat in ranked
            ],
            "recent": self.history[-10:],
        }

    def _target_for(self, channel: ActionKind, world: MiniEcologyWorld) -> str | None:
        if channel == "wait":
            return None
        objects = [obj for obj in world.living_objects() if obj.quantity > 0 and not self._obvious_hazard(obj)]
        if not objects:
            return None
        if channel == "inspect":
            undiscovered = [obj for obj in objects if not obj.discovered]
            if undiscovered:
                return min(undiscovered, key=lambda obj: (world.distance_to(obj.object_id), obj.object_id)).object_id
        if channel == "touch":
            adjacent = [obj for obj in objects if world.distance_to(obj.object_id) <= 1 and obj.discovered]
            if adjacent:
                return min(adjacent, key=lambda obj: obj.object_id).object_id
        return min(objects, key=lambda obj: (world.distance_to(obj.object_id), obj.object_id)).object_id

    def _obvious_hazard(self, obj: WorldObject) -> bool:
        return obj.shape in {"spike", "jagged"} or obj.color in {"black", "dark", "crimson"}

    def _known_confidence(self, channel: ActionKind, body_map: ProtoBodyMap) -> float:
        learned = body_map.confidence(channel)
        probe = self.stats.get(f"motor:{channel}")
        probe_score = 0.0 if probe is None else probe.controllability
        return max(learned, probe_score)

    def _attempts(self, channel: ActionKind) -> int:
        probe = self.stats.get(f"motor:{channel}")
        return 0 if probe is None else probe.attempts

    def _body_delta(self, before: BodyState, after: BodyState) -> float:
        return (
            abs(after.energy - before.energy)
            + abs(after.hydration - before.hydration)
            + abs(after.integrity - before.integrity)
            + abs(after.fatigue - before.fatigue)
            + abs(after.curiosity - before.curiosity)
            + abs(after.uncertainty - before.uncertainty)
        ) / 6.0

    def _ema(self, old: float, value: float, rate: float) -> float:
        return max(0.0, min(1.0, old * (1.0 - rate) + value * rate))
