"""Persistent symbol-goal working memory.

A cue is not a command and not a lookup table. When the organism physically
encounters a cue surface, the token can remain active as a short-lived internal
pressure. The action selector may use that token only through learned
symbol->concept pathways already grown in the neural graph.
"""

from __future__ import annotations

from dataclasses import dataclass

from .contracts import Action, Outcome, PlasticityEvent
from .neural_graph import NeuralGrowthGraph


@dataclass(frozen=True)
class SymbolGoalState:
    token: str
    source_target: str | None
    activated_tick: int
    expires_tick: int
    strength: float
    reason: str


class ActiveSymbolGoalMemory:
    """Short-lived symbolic intention produced by experienced cue surfaces."""

    def __init__(self) -> None:
        self.state: SymbolGoalState | None = None
        self.activation_count = 0
        self.guided_attempts = 0
        self.guided_successes = 0
        self.expired_count = 0
        self.last_evidence: tuple[str, ...] = ()
        self.last_guided_score = 0.0

    def active_tokens(self, tick: int) -> tuple[str, ...]:
        self._expire_if_needed(tick)
        if self.state is None:
            return ()
        return (self.state.token,)


    def active_state(self, tick: int) -> SymbolGoalState | None:
        """Return the active goal state after applying expiry."""

        self._expire_if_needed(tick)
        return self.state

    def defer(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph,
        reason: str,
        ttl_extension: int = 6,
    ) -> tuple[PlasticityEvent, ...]:
        """Preserve an active goal briefly when survival must take priority."""

        self._expire_if_needed(tick)
        if self.state is None:
            return ()
        self.state = SymbolGoalState(
            token=self.state.token,
            source_target=self.state.source_target,
            activated_tick=self.state.activated_tick,
            expires_tick=max(self.state.expires_tick, tick + max(2, ttl_extension)),
            strength=max(0.18, self.state.strength * 0.94),
            reason=f"deferred: {reason}",
        )
        goal_node = self._goal_node(self.state.token)
        defer_node = f"symbol_goal:deferred={self.state.token}"
        graph.ensure_neuron(goal_node, kind="symbol_goal", label=f"goal={self.state.token}", tick=tick)
        graph.ensure_neuron(defer_node, kind="symbol_goal", label=f"defer={self.state.token}", tick=tick)
        graph.activate(defer_node, amount=0.46, tick=tick)
        return (
            graph.reinforce(defer_node, goal_node, amount=0.026, tick=tick, reason="symbol goal deferred but preserved"),
        )

    def activate_token(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph,
        token: str,
        source_target: str | None,
        reason: str,
        ttl: int = 42,
    ) -> tuple[PlasticityEvent, ...]:
        token = token.strip()
        if not token:
            return ()
        strength = 0.72
        if self.state is not None and self.state.token == token:
            strength = min(1.0, self.state.strength + 0.12)
        self.state = SymbolGoalState(
            token=token,
            source_target=source_target,
            activated_tick=tick,
            expires_tick=tick + max(6, ttl),
            strength=strength,
            reason=reason,
        )
        self.activation_count += 1
        goal_node = self._goal_node(token)
        token_node = f"symbol:token={token}"
        graph.ensure_neuron(goal_node, kind="symbol_goal", label=f"goal={token}", tick=tick)
        graph.ensure_neuron(token_node, kind="symbol", label=f"token={token}", tick=tick)
        graph.activate(goal_node, amount=strength, tick=tick)
        graph.activate(token_node, amount=max(0.62, strength * 0.72), tick=tick)
        return (
            graph.reinforce(goal_node, token_node, amount=0.060, tick=tick, reason="cue activated persistent symbol goal"),
            graph.reinforce(token_node, goal_node, amount=0.030, tick=tick, reason="symbol recalled as active goal"),
        )

    def record_cue_experience(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph,
        target_features: tuple[str, ...],
        outcome: Outcome,
    ) -> tuple[PlasticityEvent, ...]:
        """Activate a goal only after interacting with a cue surface."""

        if outcome.kind != "novelty" or "mapped symbol token" not in outcome.message:
            return ()
        if "vision:teaches=cue" not in target_features:
            return ()
        tokens = self._feature_values(target_features, "vision:symbol_token")
        if not tokens:
            return ()
        return self.activate_token(
            tick=tick,
            graph=graph,
            token=tokens[0],
            source_target=outcome.target_id,
            reason=f"experienced cue token {tokens[0]}",
        )

    def record_guided_choice(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph,
        action: Action,
        target_features: tuple[str, ...],
        outcome: Outcome,
    ) -> tuple[PlasticityEvent, ...]:
        self._expire_if_needed(tick)
        if self.state is None or not target_features or action.target_id is None:
            return ()
        scene = (f"vision:symbol_token={self.state.token}",)
        score, evidence = graph.symbol_cue_score(scene, target_features)
        self.last_guided_score = round(score, 4)
        self.last_evidence = evidence
        if score <= 0.012:
            return ()
        self.guided_attempts += 1
        success = outcome.kind in {"relief", "novelty"}
        if success:
            self.guided_successes += 1
        goal_node = self._goal_node(self.state.token)
        outcome_node = f"outcome:{outcome.kind}"
        action_node = f"action:{action.kind}"
        graph.ensure_neuron(goal_node, kind="symbol_goal", label=f"goal={self.state.token}", tick=tick)
        graph.ensure_neuron(outcome_node, kind="outcome", label=outcome.kind, tick=tick)
        graph.ensure_neuron(action_node, kind="action", label=action.kind, tick=tick)
        amount = 0.050 if success else -0.025 if outcome.kind == "pain" else 0.012
        events = [
            graph.reinforce(goal_node, action_node, amount=0.020, tick=tick, reason="symbol goal biased action"),
            graph.reinforce(goal_node, outcome_node, amount=amount, tick=tick, reason="symbol goal consequence"),
        ]
        # Keep the goal alive briefly when it actually found a relevant target.
        if success:
            self.state = SymbolGoalState(
                token=self.state.token,
                source_target=self.state.source_target,
                activated_tick=self.state.activated_tick,
                expires_tick=max(self.state.expires_tick, tick + 8),
                strength=min(1.0, self.state.strength + 0.04),
                reason=self.state.reason,
            )
        return tuple(events)

    def snapshot(self, *, tick: int) -> dict[str, object]:
        self._expire_if_needed(tick)
        active = None
        if self.state is not None:
            active = {
                "token": self.state.token,
                "source_target": self.state.source_target,
                "strength": round(self.state.strength, 4),
                "ttl": max(0, self.state.expires_tick - tick),
                "reason": self.state.reason,
            }
        return {
            "active": active,
            "activation_count": self.activation_count,
            "guided_attempts": self.guided_attempts,
            "guided_successes": self.guided_successes,
            "guided_success_rate": round(0.0 if self.guided_attempts == 0 else self.guided_successes / self.guided_attempts, 4),
            "expired_count": self.expired_count,
            "last_guided_score": self.last_guided_score,
            "last_evidence": list(self.last_evidence),
        }

    def _expire_if_needed(self, tick: int) -> None:
        if self.state is not None and tick > self.state.expires_tick:
            self.state = None
            self.expired_count += 1

    def _feature_values(self, features: tuple[str, ...], prefix: str) -> tuple[str, ...]:
        needle = prefix + "="
        return tuple(feature.split("=", 1)[1] for feature in features if feature.startswith(needle))

    def _goal_node(self, token: str) -> str:
        return f"symbol_goal:token={token}"
