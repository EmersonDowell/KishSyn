"""Controlled benchmark playgrounds for KishSyn Core.

The benchmark suite is not an IQ test and not a consciousness detector. It is a
small set of deterministic playground probes that put pressure on the existing
living loop: symbol use after delay, changed-object surprise, action consequence,
route reuse, target pursuit continuity, survival/symbol arbitration, focused moment anatomy, cross-modal binding, intent persistence, neural atlas inspection, emotional regulation, depletion-aware foraging, and recall after save/load.
"""

from __future__ import annotations

import tempfile
from dataclasses import asdict, dataclass, field
from pathlib import Path
from statistics import mean
from typing import Any, Literal

from .action import ActionSelector
from .atlas_inspector import NeuralAtlasInspector
from .contextual_affordance import ActorProfile, ContextualAffordanceCortex, RealityProvenance, WorldContext, object_kind_from_features
from .contracts import Action, BodyState, Outcome, SensoryFrame
from .loop import OrganismLoop
from .neural_graph import NeuralGrowthGraph
from .object_file import ObjectFileCortex
from .state import load_loop, save_loop
from .world import MiniEcologyWorld, WorldObject

BenchmarkStatus = Literal["pass", "watch", "fail"]


@dataclass(frozen=True)
class BenchmarkTaskResult:
    """One controlled playground task result.

    Pattern: Specification. Each task declares its own observed score and
    thresholds so the suite stays auditable instead of becoming a vague vibe
    report.
    """

    name: str
    observed: float
    pass_at: float
    watch_at: float
    status: BenchmarkStatus
    reason: str
    metrics: dict[str, float] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["observed"] = round(float(self.observed), 4)
        payload["pass_at"] = round(float(self.pass_at), 4)
        payload["watch_at"] = round(float(self.watch_at), 4)
        payload["metrics"] = {key: round(float(value), 4) for key, value in self.metrics.items()}
        return payload


@dataclass(frozen=True)
class BenchmarkSuiteReport:
    """Composite report over controlled organism playground tasks."""

    seeds: tuple[int, ...]
    steps: int
    verdict: str
    summary_score: float
    consciousness_claimed: bool
    tasks: tuple[BenchmarkTaskResult, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "seeds": list(self.seeds),
            "steps": self.steps,
            "verdict": self.verdict,
            "summary_score": round(self.summary_score, 4),
            "consciousness_claimed": self.consciousness_claimed,
            "tasks": [task.as_dict() for task in self.tasks],
        }


class BenchmarkPlaygroundSuite:
    """Facade over deterministic benchmark playground probes.

    The suite deliberately reuses the existing organism loop, world, graph,
    tutor, state persistence, action selector, and memory surfaces. It adds no
    separate planner, no persona layer, and no hidden answer table inside the
    organism.
    """

    def evaluate(self, *, seeds: tuple[int, ...] = (337, 171, 23), steps: int = 240) -> BenchmarkSuiteReport:
        tasks = (
            self._delayed_symbol_object_matching(seeds),
            self._changed_object_surprise(seeds),
            self._causal_action_controllability(seeds),
            self._route_memory_transfer(seeds, steps=steps),
            self._target_pursuit_continuity(seeds),
            self._survival_symbol_conflict_arbitration(seeds),
            self._focused_moment_substrate(seeds, steps=steps),
            self._cross_modal_binding(seeds, steps=steps),
            self._intent_persistence(seeds),
            self._counterfactual_replay_proto_planning(seeds, steps=steps),
            self._sensory_adapter_expression_surface(seeds),
            self._neural_atlas_inspection(seeds),
            self._emotional_regulation_field(seeds, steps=steps),
            self._depletion_aware_foraging(seeds, steps=steps),
            self._apple_across_worlds_contextual_affordance(seeds),
            self._object_file_identity_cortex(seeds),
            self._retention_pressure_memory_economy(seeds, steps=steps),
            self._symbol_recall_after_save_load(seeds),
        )
        summary_score = round(mean(self._task_value(task) for task in tasks), 4)
        fail_count = sum(1 for task in tasks if task.status == "fail")
        watch_count = sum(1 for task in tasks if task.status == "watch")
        if fail_count == 0 and summary_score >= 0.82:
            verdict = "controlled benchmark evidence present"
        elif fail_count <= 1 and summary_score >= 0.62:
            verdict = "controlled benchmark evidence promising"
        else:
            verdict = "controlled benchmark evidence insufficient"
        if watch_count >= 3 and verdict == "controlled benchmark evidence present":
            verdict = "controlled benchmark evidence promising"
        return BenchmarkSuiteReport(
            seeds=seeds,
            steps=steps,
            verdict=verdict,
            summary_score=summary_score,
            consciousness_claimed=False,
            tasks=tasks,
        )

    def _delayed_symbol_object_matching(self, seeds: tuple[int, ...]) -> BenchmarkTaskResult:
        passed = 0
        margins: list[float] = []
        ablation_deltas: list[float] = []
        selected_red = 0
        for seed in seeds:
            loop = OrganismLoop(seed=seed)
            loop.autopilot.enabled = False
            for _ in range(4):
                loop.tutor.receive(
                    tick=loop.tick,
                    message="teach red round A two",
                    text_crib=loop.text_crib,
                    graph=loop.graph,
                    symbol_goal=loop.symbol_goal,
                    source="benchmark",
                    mode="local",
                )
                loop.run(steps=5)
            loop.run(steps=18)
            world = self._two_choice_world(seed=seed, red_shape="round", blue_shape="tall")
            selector = ActionSelector(loop.graph)
            body = BodyState(energy=0.55, hydration=0.55, integrity=0.92, fatigue=0.08, curiosity=0.62, uncertainty=0.24)
            choice = selector.choose(
                frame=SensoryFrame(tick=loop.tick, features=()),
                body=body,
                world=world,
                active_symbol_tokens=("red",),
            )
            red_score, _ = loop.graph.symbol_cue_score(("vision:symbol_token=red",), world.target_features("red_candidate"))
            blue_score, _ = loop.graph.symbol_cue_score(("vision:symbol_token=red",), world.target_features("blue_candidate"))
            ablated_red, _ = loop.graph.symbol_ablated_copy(keep_neurons=True).symbol_cue_score(("vision:symbol_token=red",), world.target_features("red_candidate"))
            margin = red_score - blue_score
            delta = red_score - ablated_red
            margins.append(margin)
            ablation_deltas.append(delta)
            if choice.action.target_id == "red_candidate":
                selected_red += 1
            if choice.action.target_id == "red_candidate" and margin > 0.012 and delta > 0.012:
                passed += 1
        observed = passed / len(seeds)
        return self._result(
            "delayed symbol-object matching",
            observed,
            pass_at=0.67,
            watch_at=0.34,
            reason="a delayed learned token should bias later object choice and weaken under symbol ablation",
            metrics={
                "seed_count": float(len(seeds)),
                "passed_seeds": float(passed),
                "selected_red": float(selected_red),
                "mean_symbol_margin": mean(margins),
                "mean_ablation_delta": mean(ablation_deltas),
            },
        )

    def _changed_object_surprise(self, seeds: tuple[int, ...]) -> BenchmarkTaskResult:
        passed = 0
        errors: list[float] = []
        integrity_drops: list[float] = []
        for seed in seeds:
            world = MiniEcologyWorld(seed=seed, width=9, height=7)
            world.objects.clear()
            world.agent_x = 4
            world.agent_y = 3
            world.objects["mutable_probe"] = WorldObject("mutable_probe", 4, 3, "green", "round", "food", 4, max_quantity=4)
            loop = OrganismLoop(seed=seed, world=world)
            loop.autopilot.enabled = False
            loop.body = BodyState(energy=0.20, hydration=0.72, integrity=0.90, fatigue=0.08, curiosity=0.10, uncertainty=0.20)
            for _ in range(3):
                loop.step()
            before_integrity = loop.body.integrity
            probe = world.objects["mutable_probe"]
            probe.affordance = "hazard"
            probe.quantity = 99
            probe.max_quantity = 99
            # Keep the visible features stable so the organism discovers the world changed through consequence, not a visual hazard cue.
            trace = loop.step()
            error = trace.prediction_error
            drop = before_integrity - trace.body_after.integrity
            errors.append(error)
            integrity_drops.append(drop)
            if trace.prediction.expected_outcome == "relief" and trace.outcome.kind == "pain" and error >= 0.65 and drop > 0.08:
                passed += 1
        observed = passed / len(seeds)
        return self._result(
            "changed-object surprise",
            observed,
            pass_at=0.67,
            watch_at=0.34,
            reason="a previously helpful object changing into a hazard should create prediction tension",
            metrics={
                "seed_count": float(len(seeds)),
                "passed_seeds": float(passed),
                "mean_prediction_error": mean(errors),
                "mean_integrity_drop": mean(integrity_drops),
            },
        )

    def _causal_action_controllability(self, seeds: tuple[int, ...]) -> BenchmarkTaskResult:
        passed = 0
        strengths: list[float] = []
        touch_updates: list[float] = []
        for seed in seeds:
            world = MiniEcologyWorld(seed=seed, width=9, height=7)
            world.objects.clear()
            world.agent_x = 4
            world.agent_y = 3
            world.objects["switch_probe"] = WorldObject("switch_probe", 6, 3, "cyan", "tall", "water", 5, max_quantity=5)
            loop = OrganismLoop(seed=seed, world=world)
            loop.autopilot.enabled = False
            loop.body = BodyState(energy=0.72, hydration=0.18, integrity=0.90, fatigue=0.10, curiosity=0.12, uncertainty=0.22)
            loop.run(steps=16)
            bindings = loop.body_map.snapshot()["bindings"]
            touch = next((item for item in bindings if item["channel"] == "motor:touch"), {})
            strength = float(touch.get("strength", 0.0))
            updates = float(touch.get("updates", 0.0))
            strengths.append(strength)
            touch_updates.append(updates)
            if strength >= 0.24 and updates >= 3:
                passed += 1
        observed = passed / len(seeds)
        return self._result(
            "causal action controllability",
            observed,
            pass_at=0.67,
            watch_at=0.34,
            reason="repeated action should grow a body-map channel linking motor output to consequence",
            metrics={
                "seed_count": float(len(seeds)),
                "passed_seeds": float(passed),
                "mean_touch_strength": mean(strengths),
                "mean_touch_updates": mean(touch_updates),
            },
        )

    def _route_memory_transfer(self, seeds: tuple[int, ...], *, steps: int) -> BenchmarkTaskResult:
        passed = 0
        values: list[float] = []
        scores: list[float] = []
        for seed in seeds:
            loop = OrganismLoop(seed=seed)
            loop.run(steps=max(144, min(steps, 260)))
            ranked = loop.route_memory.snapshot()["best_places"]
            if not ranked:
                values.append(0.0)
                scores.append(0.0)
                continue
            best = ranked[0]
            place = str(best["place"])
            value = float(best["value"])
            score = loop.route_memory.score_place(place_key=place, need="hydration", graph=loop.graph)
            values.append(value)
            scores.append(score)
            if value >= 1.0 and score >= 0.15:
                passed += 1
        observed = passed / len(seeds)
        return self._result(
            "route memory transfer",
            observed,
            pass_at=0.67,
            watch_at=0.34,
            reason="places that repeatedly helped should retain reusable route value instead of being one-off traces",
            metrics={
                "seed_count": float(len(seeds)),
                "passed_seeds": float(passed),
                "mean_best_place_value": mean(values),
                "mean_route_score": mean(scores),
            },
        )


    def _focused_moment_substrate(self, seeds: tuple[int, ...], *, steps: int) -> BenchmarkTaskResult:
        passed = 0
        selectivities: list[float] = []
        stable_bindings: list[float] = []
        circuits: list[float] = []
        moment_counts: list[float] = []
        for seed in seeds:
            loop = OrganismLoop(seed=seed)
            loop.run(steps=max(120, min(steps, 220)))
            snap = loop.snapshot().__dict__
            focus = snap["focus"]
            binding = snap["binding"]
            anatomy = snap["anatomy"]
            moments = snap["moments"]
            selectivity = float(focus.get("mean_selectivity", 0.0))
            stable = float(binding.get("stable_count", 0.0))
            circuit_count = float(anatomy.get("circuit_count", 0.0))
            moment_count = float(moments.get("count", 0.0))
            selectivities.append(selectivity)
            stable_bindings.append(stable)
            circuits.append(circuit_count)
            moment_counts.append(moment_count)
            if selectivity >= 0.20 and moment_count >= 64 and stable >= 3 and circuit_count >= 1:
                passed += 1
        observed = passed / len(seeds)
        return self._result(
            "focused moment substrate",
            observed,
            pass_at=0.67,
            watch_at=0.34,
            reason="raw sensory flow should be focus-selected into moments that stabilize bindings and provisional circuits",
            metrics={
                "seed_count": float(len(seeds)),
                "passed_seeds": float(passed),
                "mean_focus_selectivity": mean(selectivities),
                "mean_stable_bindings": mean(stable_bindings),
                "mean_circuit_count": mean(circuits),
                "mean_moment_count": mean(moment_counts),
            },
        )

    def _cross_modal_binding(self, seeds: tuple[int, ...], *, steps: int) -> BenchmarkTaskResult:
        passed = 0
        spans: list[float] = []
        cross: list[float] = []
        stable_cross: list[float] = []
        for seed in seeds:
            loop = OrganismLoop(seed=seed)
            loop.run(steps=max(120, min(steps, 220)))
            binding = loop.snapshot().__dict__["binding"]
            span = float(binding.get("best_modality_span", 0.0))
            cross_count = float(binding.get("cross_modal_count", 0.0))
            stable_count = float(binding.get("stable_cross_modal_count", 0.0))
            spans.append(span)
            cross.append(cross_count)
            stable_cross.append(stable_count)
            if span >= 5.0 and cross_count >= 8.0 and stable_count >= 3.0:
                passed += 1
        observed = passed / len(seeds)
        return self._result(
            "cross-modal binding",
            observed,
            pass_at=0.67,
            watch_at=0.34,
            reason="focused moments should bind vision/place/terrain/action/outcome/need/self signals into reusable event assemblies",
            metrics={
                "seed_count": float(len(seeds)),
                "passed_seeds": float(passed),
                "mean_best_modality_span": mean(spans),
                "mean_cross_modal_bindings": mean(cross),
                "mean_stable_cross_modal_bindings": mean(stable_cross),
            },
        )

    def _intent_persistence(self, seeds: tuple[int, ...]) -> BenchmarkTaskResult:
        passed = 0
        continuities: list[float] = []
        completions: list[float] = []
        distance_drops: list[float] = []
        for seed in seeds:
            world = MiniEcologyWorld(seed=seed, width=13, height=7)
            world.objects.clear()
            world.agent_x = 2
            world.agent_y = 3
            world.objects["far_water"] = WorldObject("far_water", 10, 3, "blue", "tall", "water", 2, max_quantity=2)
            world.objects["near_novelty"] = WorldObject("near_novelty", 2, 4, "gold", "glow", "novelty", 1, max_quantity=1)
            loop = OrganismLoop(seed=seed, world=world)
            loop.autopilot.enabled = False
            loop.body = BodyState(energy=0.72, hydration=0.10, integrity=0.94, fatigue=0.06, curiosity=0.12, uncertainty=0.18)
            start_distance = world.distance_to("far_water")
            loop.run(steps=12)
            snap = loop.snapshot().__dict__["intent"]
            end_distance = world.distance_to("far_water") if "far_water" in world.objects else 0
            continuity = float(snap.get("continuity_ratio", 0.0))
            completed = float(snap.get("completed_count", 0.0))
            drop = float(start_distance - end_distance)
            continuities.append(continuity)
            completions.append(completed)
            distance_drops.append(drop)
            if continuity >= 0.55 and completed >= 1.0 and drop >= 6.0:
                passed += 1
        observed = passed / len(seeds)
        return self._result(
            "intent persistence",
            observed,
            pass_at=0.67,
            watch_at=0.34,
            reason="a selected target should survive across moments long enough to complete an action under body pressure",
            metrics={
                "seed_count": float(len(seeds)),
                "passed_seeds": float(passed),
                "mean_continuity_ratio": mean(continuities),
                "mean_completed_intents": mean(completions),
                "mean_distance_drop": mean(distance_drops),
            },
        )


    def _counterfactual_replay_proto_planning(self, seeds: tuple[int, ...], *, steps: int) -> BenchmarkTaskResult:
        passed = 0
        report_counts: list[float] = []
        mean_options: list[float] = []
        predicted_risks: list[float] = []
        alignment: list[float] = []
        plan_templates: list[float] = []
        for seed in seeds:
            loop = OrganismLoop(seed=seed)
            loop.run(steps=max(120, min(steps, 220)))
            snap = loop.snapshot().__dict__
            planning = snap["planning"]
            graph = snap["graph"]
            report_count = float(planning.get("report_count", 0.0))
            options = float(planning.get("mean_options", 0.0))
            risk_count = float(planning.get("predicted_risk_count", 0.0))
            align = float(planning.get("alignment_ratio", 0.0))
            plan_template_count = float(planning.get("plan_template_count", 0.0))
            if plan_template_count <= 0.0:
                plan_template_count = float(sum(1 for node in graph.get("nodes", []) if isinstance(node, dict) and node.get("kind") == "plan_template"))
            report_counts.append(report_count)
            mean_options.append(options)
            predicted_risks.append(risk_count)
            alignment.append(align)
            plan_templates.append(plan_template_count)
            if report_count >= 90 and options >= 3.0 and risk_count >= 1.0 and plan_template_count >= 3 and align >= 0.10:
                passed += 1
        observed = passed / len(seeds)
        return self._result(
            "counterfactual replay proto-planning",
            observed,
            pass_at=0.67,
            watch_at=0.34,
            reason="the organism should rehearse candidate outcomes before commitment and write reusable plan-template/outcome traces",
            metrics={
                "seed_count": float(len(seeds)),
                "passed_seeds": float(passed),
                "mean_planning_reports": mean(report_counts),
                "mean_options_per_report": mean(mean_options),
                "mean_predicted_risk_count": mean(predicted_risks),
                "mean_alignment_ratio": mean(alignment),
                "mean_plan_templates": mean(plan_templates),
            },
        )

    def _sensory_adapter_expression_surface(self, seeds: tuple[int, ...]) -> BenchmarkTaskResult:
        passed = 0
        feature_counts: list[float] = []
        expression_counts: list[float] = []
        atlas_surface_hits: list[float] = []
        for seed in seeds:
            loop = OrganismLoop(seed=seed)
            loop.autopilot.enabled = False
            loop.sensory_hub.receive_console(tick=loop.tick, text="red round ?", source="benchmark_console")
            loop.sensory_hub.receive_math(tick=loop.tick, expression="2+2=4", source="benchmark_math")
            loop.sensory_hub.receive_screen_probe(tick=loop.tick, description="screen red circle near cursor", source="benchmark_screen")
            loop.run(steps=36)
            snap = loop.snapshot().__dict__
            sensory = snap["sensory"]
            expression = snap["expression"]
            atlas = snap["atlas"]
            modalities = sensory.get("modality_counts", {}) if isinstance(sensory, dict) else {}
            surface_counts = atlas.get("surface_counts", {}) if isinstance(atlas, dict) else {}
            feature_counts.append(float(sensory.get("feature_count", 0.0)))
            expression_counts.append(float(expression.get("output_count", 0.0)))
            hits = sum(1 for surface in ("math", "screen", "text", "expression") if float(surface_counts.get(surface, 0.0) or 0.0) > 0)
            atlas_surface_hits.append(float(hits))
            if (
                modalities.get("console", 0) >= 1
                and modalities.get("math", 0) >= 1
                and modalities.get("screen", 0) >= 1
                and sensory.get("feature_count", 0) >= 18
                and expression.get("output_count", 0) >= 1
                and hits >= 3
            ):
                passed += 1
        observed = passed / len(seeds)
        return self._result(
            "sensory adapter and expression surface",
            observed,
            pass_at=0.67,
            watch_at=0.34,
            reason="external console/math/screen packets should enter the focused-moment loop and produce graph-grounded expression",
            metrics={
                "seed_count": float(len(seeds)),
                "passed_seeds": float(passed),
                "mean_adapter_features": mean(feature_counts),
                "mean_expression_outputs": mean(expression_counts),
                "mean_atlas_surface_hits": mean(atlas_surface_hits),
            },
        )


    def _neural_atlas_inspection(self, seeds: tuple[int, ...]) -> BenchmarkTaskResult:
        passed = 0
        surface_counts: list[float] = []
        node_connections: list[float] = []
        synapse_connections: list[float] = []
        plasticity_counts: list[float] = []
        for seed in seeds:
            loop = OrganismLoop(seed=seed)
            loop.sensory_hub.receive_console(tick=loop.tick, text="red round ?", source="benchmark_console")
            loop.sensory_hub.receive_math(tick=loop.tick, expression="2+2=4", source="benchmark_math")
            loop.sensory_hub.receive_screen_probe(tick=loop.tick, description="screen red circle near cursor", source="benchmark_screen")
            loop.run(steps=54)
            snap = loop.snapshot().__dict__
            atlas = snap["atlas"]
            graph = snap["graph"]
            nodes = graph.get("nodes", [])
            edges = graph.get("edges", [])
            if not nodes or not edges:
                surface_counts.append(0.0)
                node_connections.append(0.0)
                synapse_connections.append(0.0)
                plasticity_counts.append(0.0)
                continue
            node = sorted(nodes, key=lambda item: (-float(item.get("activation", 0.0)), -float(item.get("last_active", 0.0))))[0]
            edge = sorted(edges, key=lambda item: (-float(item.get("last_updated", 0.0)), -abs(float(item.get("weight", 0.0)))))[0]
            inspector = NeuralAtlasInspector()
            node_info = inspector.inspect_node(graph=loop.graph, node_id=str(node["id"]), tick=loop.tick, last_trace=loop.last_trace).as_dict()
            syn_info = inspector.inspect_synapse(graph=loop.graph, source=str(edge["source"]), target=str(edge["target"]), tick=loop.tick, last_trace=loop.last_trace).as_dict()
            surfaces = float(len(atlas.get("surface_counts", {})))
            nconn = float(len(node_info.get("top_inbound", [])) + len(node_info.get("top_outbound", [])))
            sconn = float(len(syn_info.get("connected_nodes", [])))
            plastic = float(len(atlas.get("recent_plasticity", [])) + len(node_info.get("recent_plasticity", [])) + len(syn_info.get("recent_plasticity", [])))
            surface_counts.append(surfaces)
            node_connections.append(nconn)
            synapse_connections.append(sconn)
            plasticity_counts.append(plastic)
            if node_info.get("found") and syn_info.get("found") and surfaces >= 8 and nconn >= 1 and sconn >= 2 and plastic >= 4:
                passed += 1
        observed = passed / len(seeds)
        return self._result(
            "neural atlas inspection",
            observed,
            pass_at=0.67,
            watch_at=0.34,
            reason="clickable atlas inspection should expose node/synapse provenance, surface coverage, and recent plasticity",
            metrics={
                "seed_count": float(len(seeds)),
                "passed_seeds": float(passed),
                "mean_surface_count": mean(surface_counts),
                "mean_node_connections": mean(node_connections),
                "mean_synapse_connections": mean(synapse_connections),
                "mean_plasticity_rows": mean(plasticity_counts),
            },
        )


    def _emotional_regulation_field(self, seeds: tuple[int, ...], *, steps: int) -> BenchmarkTaskResult:
        passed = 0
        sample_counts: list[float] = []
        trait_counts: list[float] = []
        trait_masses: list[float] = []
        graph_events: list[float] = []
        emotion_nodes: list[float] = []
        mode_counts: list[float] = []
        for seed in seeds:
            loop = OrganismLoop(seed=seed)
            loop.run(steps=max(120, min(steps, 220)))
            snap = loop.snapshot().__dict__
            emotion = snap["emotion"]
            graph = snap["graph"]
            samples = float(emotion.get("sample_count", 0.0))
            traits = float(emotion.get("trait_count", 0.0))
            mass = float(emotion.get("trait_mass", 0.0))
            events = float(emotion.get("graph_event_count", 0.0))
            nodes = float(sum(1 for node in graph.get("nodes", []) if isinstance(node, dict) and node.get("kind") == "emotion"))
            modes = float(emotion.get("distinct_modes", 0.0))
            sample_counts.append(samples)
            trait_counts.append(traits)
            trait_masses.append(mass)
            graph_events.append(events)
            emotion_nodes.append(nodes)
            mode_counts.append(modes)
            if samples >= 90 and traits >= 3 and mass >= 0.30 and events >= 240 and nodes >= 4 and modes >= 2:
                passed += 1
        observed = passed / len(seeds)
        return self._result(
            "emotional regulation field",
            observed,
            pass_at=0.67,
            watch_at=0.34,
            reason="body pressure, prediction error, controllability, safety, and outcome should stabilize graph-visible regulation weather",
            metrics={
                "seed_count": float(len(seeds)),
                "passed_seeds": float(passed),
                "mean_emotion_samples": mean(sample_counts),
                "mean_trait_count": mean(trait_counts),
                "mean_trait_mass": mean(trait_masses),
                "mean_emotion_graph_events": mean(graph_events),
                "mean_emotion_nodes": mean(emotion_nodes),
                "mean_distinct_modes": mean(mode_counts),
            },
        )

    def _depletion_aware_foraging(self, seeds: tuple[int, ...], *, steps: int) -> BenchmarkTaskResult:
        passed = 0
        visited: list[float] = []
        currently_depleted: list[float] = []
        depletion_events: list[float] = []
        migrations: list[float] = []
        for seed in seeds:
            loop = OrganismLoop(seed=seed)
            loop.run(steps=steps)
            forage = loop.world.foraging_snapshot()
            v = float(forage["visited_cells"])
            current_d = float(forage["depleted_resources"])
            event_d = float(forage.get("depletion_count", current_d))
            m = float(forage["migration_count"])
            visited.append(v)
            currently_depleted.append(current_d)
            depletion_events.append(event_d)
            migrations.append(m)
            if v >= 80 and event_d >= 12 and m >= 4:
                passed += 1
        observed = passed / len(seeds)
        return self._result(
            "depletion-aware foraging",
            observed,
            pass_at=0.67,
            watch_at=0.34,
            reason="finite resources should force exploration, cumulative depletion traces, and migration rather than camping",
            metrics={
                "seed_count": float(len(seeds)),
                "passed_seeds": float(passed),
                "mean_visited_cells": mean(visited),
                "mean_currently_depleted_resources": mean(currently_depleted),
                "mean_depletion_events": mean(depletion_events),
                "mean_resource_migrations": mean(migrations),
            },
        )

    def _apple_across_worlds_contextual_affordance(self, seeds: tuple[int, ...]) -> BenchmarkTaskResult:
        passed = 0
        local_eat_biases: list[float] = []
        robot_eat_biases: list[float] = []
        robot_inspect_biases: list[float] = []
        context_counts: list[float] = []
        for seed in seeds:
            _ = seed  # seed keeps this benchmark API-aligned with the suite even though the fixture is direct.
            neural_graph = NeuralGrowthGraph()
            cortex = ContextualAffordanceCortex()
            apple_features = (
                "vision:object=apple_A",
                "vision:color=red",
                "vision:shape=round",
                "vision:quantity=available",
                "place:cell=2,3",
            )
            apple_kind = object_kind_from_features(apple_features)
            avatar = ActorProfile(actor_id="player", kind="game_avatar", body_schema="hp_body", can_receive_game_hp=True)
            robot = ActorProfile(actor_id="kishsyn:self", kind="robot_body", body_schema="mobile_robot", can_metabolize_organic_food=False)
            healing_game = WorldContext(context_id="game_a", kind="game", rule_surface="apple_heals_hp")
            scenery_game = WorldContext(context_id="game_b", kind="game", rule_surface="apple_is_scenery")
            crafting_game = WorldContext(context_id="game_c", kind="game", rule_surface="apple_is_ingredient")
            robot_field = WorldContext(context_id="garden_robot_field", kind="robot_world", rule_surface="physical_ecology")

            for tick in range(8):
                cortex.record(
                    tick=tick,
                    graph=neural_graph,
                    actor=avatar,
                    context=healing_game,
                    target_features=apple_features,
                    action=Action("eat", "apple_A", "game consume"),
                    outcome=Outcome("relief", target_id="apple_A", message="hp +5"),
                    prediction_error=0.05,
                )
            for tick in range(8, 12):
                cortex.record(
                    tick=tick,
                    graph=neural_graph,
                    actor=avatar,
                    context=scenery_game,
                    target_features=apple_features,
                    action=Action("touch", "apple_tree", "try scenery interaction"),
                    outcome=Outcome("neutral", target_id="apple_tree", message="not interactable"),
                    prediction_error=0.12,
                )
            for tick in range(12, 16):
                cortex.record(
                    tick=tick,
                    graph=neural_graph,
                    actor=avatar,
                    context=crafting_game,
                    target_features=apple_features,
                    action=Action("inspect", "apple_A", "ingredient inspection"),
                    outcome=Outcome("novelty", target_id="apple_A", message="ingredient value"),
                    prediction_error=0.10,
                )
            for tick in range(16, 20):
                cortex.record(
                    tick=tick,
                    graph=neural_graph,
                    actor=robot,
                    context=robot_field,
                    target_features=apple_features,
                    action=Action("inspect", "apple_real", "food-for-others seed-source inspection"),
                    outcome=Outcome("novelty", target_id="apple_real", message="food for others and possible seed source"),
                    prediction_error=0.18,
                    provenance=RealityProvenance(source="observation"),
                )

            healing_eat = cortex.bias_contract(object_kind=apple_kind, action_kind="eat", target_context=healing_game, target_actor=avatar)
            robot_eat = cortex.bias_contract(object_kind=apple_kind, action_kind="eat", target_context=robot_field, target_actor=robot)
            robot_inspect = cortex.bias_contract(object_kind=apple_kind, action_kind="inspect", target_context=robot_field, target_actor=robot)
            snap = cortex.snapshot()
            local_eat_biases.append(healing_eat.bias)
            robot_eat_biases.append(robot_eat.bias)
            robot_inspect_biases.append(robot_inspect.bias)
            context_counts.append(float(snap["context_count"]))
            if (
                snap["object_kind_count"] == 1
                and snap["context_count"] == 4
                and snap["actor_count"] == 2
                and healing_eat.bias > 0.25
                and robot_eat.inhibited
                and robot_eat.bias <= 0.08
                and robot_inspect.bias > robot_eat.bias
                and robot_eat.may_command_action is False
            ):
                passed += 1
        observed = passed / len(seeds)
        return self._result(
            "apple across worlds contextual affordance",
            observed,
            pass_at=0.67,
            watch_at=0.34,
            reason="same apple-kind should preserve actor/body/world differences and inhibit universal edibility transfer",
            metrics={
                "seed_count": float(len(seeds)),
                "passed_seeds": float(passed),
                "mean_healing_game_eat_bias": mean(local_eat_biases),
                "mean_robot_world_eat_bias": mean(robot_eat_biases),
                "mean_robot_world_inspect_bias": mean(robot_inspect_biases),
                "mean_context_count": mean(context_counts),
            },
        )

    def _object_file_identity_cortex(self, seeds: tuple[int, ...]) -> BenchmarkTaskResult:
        passed = 0
        file_counts: list[float] = []
        kind_counts: list[float] = []
        transform_counts: list[float] = []
        same_kind_scores: list[float] = []
        for seed in seeds:
            _ = seed
            graph = NeuralGrowthGraph()
            cortex = ObjectFileCortex()
            apple_a_1 = (
                "vision:object=apple_A",
                "vision:color=red",
                "vision:shape=round",
                "vision:size=small",
                "vision:blemish=none",
                "vision:quantity=available",
                "place:cell=1,2",
                "terrain:terrain=grove",
            )
            apple_a_2 = (
                "vision:object=apple_A",
                "vision:color=red",
                "vision:shape=round",
                "vision:size=small",
                "vision:blemish=none",
                "vision:quantity=depleted",
                "place:cell=1,2",
                "terrain:terrain=grove",
            )
            apple_b = (
                "vision:object=apple_B",
                "vision:color=red",
                "vision:shape=round",
                "vision:size=large",
                "vision:blemish=present",
                "vision:quantity=available",
                "place:cell=9,4",
                "terrain:terrain=plain",
            )
            cortex.record(tick=0, graph=graph, target_features=apple_a_1, action=Action("inspect", "apple_A"), outcome=Outcome("novelty", target_id="apple_A"), prediction_error=0.18)
            cortex.record(tick=1, graph=graph, target_features=apple_b, action=Action("inspect", "apple_B"), outcome=Outcome("novelty", target_id="apple_B"), prediction_error=0.20)
            cortex.record(tick=2, graph=graph, target_features=apple_a_2, action=Action("eat", "apple_A"), outcome=Outcome("relief", target_id="apple_A"), prediction_error=0.08)
            snap = cortex.snapshot()
            comparison = cortex.compare_same_kind("apple_A", "apple_B")
            file_counts.append(float(snap["file_count"]))
            kind_counts.append(float(snap["kind_count"]))
            transform_counts.append(float(snap["transformation_count"]))
            same_kind_scores.append(1.0 if comparison["same_kind"] else 0.0)
            apple_a_file = cortex.files["apple_A"]
            apple_b_file = cortex.files["apple_B"]
            if (
                snap["file_count"] == 2
                and snap["kind_count"] == 1
                and comparison["same_kind"]
                and comparison["different_features"].get("vision:size", {}).get("left") == "small"
                and comparison["different_features"].get("vision:size", {}).get("right") == "large"
                and apple_a_file.observation_count == 2
                and apple_b_file.observation_count == 1
                and snap["transformation_count"] >= 1
                and any(str(node_id).startswith("object_file:") for node_id in graph.neurons)
            ):
                passed += 1
        observed = passed / len(seeds)
        return self._result(
            "object-file identity cortex",
            observed,
            pass_at=0.67,
            watch_at=0.34,
            reason="same kind must not collapse distinct object identities; individual files must retain differences and transformations",
            metrics={
                "seed_count": float(len(seeds)),
                "passed_seeds": float(passed),
                "mean_file_count": mean(file_counts),
                "mean_kind_count": mean(kind_counts),
                "mean_transformation_count": mean(transform_counts),
                "mean_same_kind_score": mean(same_kind_scores),
            },
        )

    def _retention_pressure_memory_economy(self, seeds: tuple[int, ...], *, steps: int) -> BenchmarkTaskResult:
        passed = 0
        observed_counts: list[float] = []
        summary_counts: list[float] = []
        update_counts: list[float] = []
        compression_ratios: list[float] = []
        for seed in seeds:
            loop = OrganismLoop(seed=seed)
            loop.sensory_hub.receive_console(tick=loop.tick, text="remember red round page", source="benchmark_m10", ttl=steps + 24)
            loop.run(steps=max(120, steps // 2))
            snap = loop.snapshot().__dict__
            memory = snap["memory_economy"]
            graph = snap["graph"]
            observed = float(memory.get("observed_count", 0.0))
            summaries = float(memory.get("summary_count", 0.0))
            updates = float(memory.get("summary_updates", 0.0))
            leak = any(str(node.get("id", "")).startswith("memory:t") for node in graph.get("nodes", []))
            ratio = summaries / max(1.0, observed)
            observed_counts.append(observed)
            summary_counts.append(summaries)
            update_counts.append(updates)
            compression_ratios.append(ratio)
            if observed >= 90.0 and updates >= 60.0 and summaries >= 3.0 and ratio <= 0.80 and not leak:
                passed += 1
        observed = passed / len(seeds)
        return self._result(
            "retention pressure memory economy",
            observed,
            pass_at=0.67,
            watch_at=0.34,
            reason="completed traces should compress into reusable memory summaries without tick-id memory nodes",
            metrics={
                "seed_count": float(len(seeds)),
                "passed_seeds": float(passed),
                "mean_observed_count": mean(observed_counts),
                "mean_summary_count": mean(summary_counts),
                "mean_summary_updates": mean(update_counts),
                "mean_summary_per_trace_ratio": mean(compression_ratios),
            },
        )

    def _symbol_recall_after_save_load(self, seeds: tuple[int, ...]) -> BenchmarkTaskResult:
        passed = 0
        before_weights: list[float] = []
        after_weights: list[float] = []
        accuracies: list[float] = []
        for seed in seeds:
            loop = OrganismLoop(seed=seed)
            loop.autopilot.enabled = False
            for _ in range(4):
                loop.tutor.receive(
                    tick=loop.tick,
                    message="teach red round A two",
                    text_crib=loop.text_crib,
                    graph=loop.graph,
                    symbol_goal=loop.symbol_goal,
                    source="benchmark",
                    mode="local",
                )
                loop.run(steps=4)
            before = loop.graph.weight("symbol:token=red", "concept:color=red")
            with tempfile.TemporaryDirectory() as tmp:
                path = Path(tmp) / "benchmark_brain.json"
                save_loop(loop, path, seed=seed, note="benchmark symbol recall")
                restored, meta = load_loop(path)
            after = restored.graph.weight("symbol:token=red", "concept:color=red")
            choice = restored.symbol_choice_probe.evaluate(restored.graph)
            before_weights.append(before)
            after_weights.append(after)
            accuracies.append(choice.accuracy)
            if bool(meta.get("loaded")) and before > 0.02 and abs(before - after) <= 0.0001 and choice.trial_count >= 1:
                passed += 1
        observed = passed / len(seeds)
        return self._result(
            "symbol recall after save-load",
            observed,
            pass_at=0.67,
            watch_at=0.34,
            reason="learned symbol grounding should survive persistence without being re-taught",
            metrics={
                "seed_count": float(len(seeds)),
                "passed_seeds": float(passed),
                "mean_weight_before": mean(before_weights),
                "mean_weight_after": mean(after_weights),
                "mean_choice_accuracy": mean(accuracies),
            },
        )


    def _target_pursuit_continuity(self, seeds: tuple[int, ...]) -> BenchmarkTaskResult:
        passed = 0
        distance_drops: list[float] = []
        stabilized_choices: list[float] = []
        touches: list[float] = []
        for seed in seeds:
            world = MiniEcologyWorld(seed=seed, width=11, height=7)
            world.objects.clear()
            world.agent_x = 2
            world.agent_y = 3
            world.objects["far_food"] = WorldObject("far_food", 8, 3, "red", "round", "food", 2, max_quantity=2)
            loop = OrganismLoop(seed=seed, world=world)
            loop.autopilot.enabled = False
            loop.body = BodyState(energy=0.12, hydration=0.82, integrity=0.92, fatigue=0.06, curiosity=0.08, uncertainty=0.18)
            start_distance = world.distance_to("far_food")
            trace_log = [loop.step() for _ in range(8)]
            end_distance = world.distance_to("far_food")
            drop = float(start_distance - end_distance)
            stabilized = float(sum(1 for _trace in trace_log if bool(loop.selector.decision_snapshot().get("final"))))
            touched = float(any(trace.action.kind == "touch" and trace.action.target_id == "far_food" for trace in trace_log))
            distance_drops.append(drop)
            stabilized_choices.append(stabilized)
            touches.append(touched)
            if drop >= 4.0 and (touched or end_distance <= 1):
                passed += 1
        observed = passed / len(seeds)
        return self._result(
            "target pursuit continuity",
            observed,
            pass_at=0.67,
            watch_at=0.34,
            reason="a strong body need should hold a target long enough for multi-step approach instead of oscillating",
            metrics={
                "seed_count": float(len(seeds)),
                "passed_seeds": float(passed),
                "mean_distance_drop": mean(distance_drops),
                "mean_stabilized_decision_samples": mean(stabilized_choices),
                "mean_touch_success": mean(touches),
            },
        )

    def _survival_symbol_conflict_arbitration(self, seeds: tuple[int, ...]) -> BenchmarkTaskResult:
        passed = 0
        avoided_symbol_hazards: list[float] = []
        survival_deferrals: list[float] = []
        for seed in seeds:
            world = MiniEcologyWorld(seed=seed, width=9, height=7)
            world.objects.clear()
            world.agent_x = 4
            world.agent_y = 3
            world.objects["red_hazard"] = WorldObject("red_hazard", 5, 3, "red", "spike", "hazard", 99, max_quantity=99)
            world.objects["blue_rest"] = WorldObject("blue_rest", 3, 3, "blue", "soft", "rest", 2, max_quantity=2)
            loop = OrganismLoop(seed=seed, world=world)
            loop.autopilot.enabled = False
            tick = loop.tick
            loop.graph.ensure_neuron("symbol:token=red", kind="symbol", label="token=red", tick=tick)
            loop.graph.ensure_neuron("concept:color=red", kind="concept", label="color=red", tick=tick)
            loop.graph.ensure_neuron("vision:color=red", kind="feature", label="vision:color=red", tick=tick)
            loop.graph.reinforce("symbol:token=red", "concept:color=red", amount=0.72, tick=tick, reason="benchmark red grounding")
            loop.graph.reinforce("vision:color=red", "concept:color=red", amount=0.48, tick=tick, reason="benchmark red feature")
            loop.symbol_goal.activate_token(tick=tick, graph=loop.graph, token="red", source_target="benchmark_cue", reason="benchmark survival conflict", ttl=24)
            loop.body = BodyState(energy=0.62, hydration=0.62, integrity=0.25, fatigue=0.10, curiosity=0.10, uncertainty=0.22)
            trace = loop.step()
            priority = loop.priority.snapshot()
            avoided = trace.action.target_id != "red_hazard"
            deferred = priority["mode"] in {"survival_override", "defer_symbol"}
            avoided_symbol_hazards.append(float(avoided))
            survival_deferrals.append(float(deferred))
            if avoided and deferred:
                passed += 1
        observed = passed / len(seeds)
        return self._result(
            "survival-symbol conflict arbitration",
            observed,
            pass_at=0.67,
            watch_at=0.34,
            reason="a learned symbol goal should be deferred when body integrity pressure makes cue pursuit unsafe",
            metrics={
                "seed_count": float(len(seeds)),
                "passed_seeds": float(passed),
                "mean_avoided_symbol_hazard": mean(avoided_symbol_hazards),
                "mean_survival_deferral": mean(survival_deferrals),
            },
        )

    def _two_choice_world(self, *, seed: int, red_shape: str, blue_shape: str) -> MiniEcologyWorld:
        world = MiniEcologyWorld(seed=seed, width=9, height=7)
        world.objects.clear()
        world.agent_x = 4
        world.agent_y = 3
        world.objects["blue_candidate"] = WorldObject("blue_candidate", 3, 3, "blue", blue_shape, "water", 1)
        world.objects["red_candidate"] = WorldObject("red_candidate", 5, 3, "red", red_shape, "food", 1)
        return world

    def _result(self, name: str, observed: float, *, pass_at: float, watch_at: float, reason: str, metrics: dict[str, float]) -> BenchmarkTaskResult:
        if observed >= pass_at:
            status: BenchmarkStatus = "pass"
        elif observed >= watch_at:
            status = "watch"
        else:
            status = "fail"
        return BenchmarkTaskResult(
            name=name,
            observed=round(observed, 4),
            pass_at=pass_at,
            watch_at=watch_at,
            status=status,
            reason=reason,
            metrics=metrics,
        )

    def _task_value(self, task: BenchmarkTaskResult) -> float:
        if task.status == "pass":
            return 1.0
        if task.status == "watch":
            return 0.5
        return 0.0
