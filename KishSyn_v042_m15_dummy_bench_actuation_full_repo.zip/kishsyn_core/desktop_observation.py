"""Desktop/OS observation substrate for future embodiment.

M13 begins with observation only. Windows, buttons, consoles, files, and game UI
surfaces become replayable sensory features plus external-interface affordance
proposals. No mouse, keyboard, file, network, or process action is performed by
this module.
"""

from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass, field
from typing import Any, Literal

from .contracts import PlasticityEvent
from .external_interface import AdapterSafetyContract, ExternalAdapterRegistry, ExternalAffordance, ExternalSurface
from .neural_graph import NeuralGrowthGraph
from .sensory import SensoryAdapterHub

DesktopRole = Literal["window", "button", "text_field", "console", "menu", "icon", "canvas", "webview", "file", "unknown"]


@dataclass(frozen=True)
class DesktopElement:
    """A read-only UI element observation.

    Pattern: Value Object. The element describes what appears on a surface; it is
    not an action and not an automation handle.
    """

    element_id: str
    role: DesktopRole
    label: str = ""
    bounds: tuple[int, int, int, int] = (0, 0, 0, 0)
    interactable: bool = False
    confidence: float = 0.0

    def as_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["bounds"] = list(self.bounds)
        payload["confidence"] = round(float(self.confidence), 4)
        return payload


@dataclass(frozen=True)
class DesktopObservationFrame:
    """One replayable desktop observation frame.

    Pattern: Memento. It stores a compact symbolic view of the desktop without
    retaining raw screenshots or live operating-system handles.
    """

    tick: int
    surface_id: str
    title: str
    active_application: str
    elements: tuple[DesktopElement, ...] = ()
    text_fragments: tuple[str, ...] = ()
    source: str = "desktop_observer"
    screenshot_digest: str = ""
    metadata: dict[str, str] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "tick": self.tick,
            "surface_id": self.surface_id,
            "title": self.title,
            "active_application": self.active_application,
            "elements": [element.as_dict() for element in self.elements],
            "text_fragments": list(self.text_fragments),
            "source": self.source,
            "screenshot_digest": self.screenshot_digest,
            "metadata": dict(self.metadata),
        }


@dataclass(frozen=True)
class DesktopObservationReport:
    """Audit report for one desktop observation ingestion."""

    tick: int
    surface_id: str
    element_count: int
    sensory_packet_created: bool
    inspect_affordances: int
    blocked_write_like_affordances: int
    graph_events: int
    features: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "tick": self.tick,
            "surface_id": self.surface_id,
            "element_count": self.element_count,
            "sensory_packet_created": self.sensory_packet_created,
            "inspect_affordances": self.inspect_affordances,
            "blocked_write_like_affordances": self.blocked_write_like_affordances,
            "graph_events": self.graph_events,
            "features": list(self.features),
        }


class OSObservationSubstrate:
    """Read-only bridge from OS/program observations into KishSyn.

    Pattern: Adapter + Facade + Memento. Future platform-specific capture code
    should terminate here, producing replayable observation frames and governed
    affordance proposals before any signal enters FocusGate.
    """

    def __init__(self, *, history_limit: int = 64) -> None:
        self.frames: deque[DesktopObservationFrame] = deque(maxlen=max(8, int(history_limit)))
        self.reports: deque[DesktopObservationReport] = deque(maxlen=max(8, int(history_limit)))
        self.observation_count = 0
        self.graph_event_count = 0
        self.blocked_write_like_count = 0
        self.surface_counts: dict[str, int] = {}
        self.role_counts: dict[str, int] = {}

    def observe(
        self,
        frame: DesktopObservationFrame,
        *,
        sensory_hub: SensoryAdapterHub,
        registry: ExternalAdapterRegistry,
        graph: NeuralGrowthGraph | None = None,
        interface_affordance: Any | None = None,
    ) -> DesktopObservationReport:
        safe_frame = _normalize_frame(frame)
        self.frames.append(safe_frame)
        self.observation_count += 1
        self.surface_counts[safe_frame.surface_id] = self.surface_counts.get(safe_frame.surface_id, 0) + 1
        surface_kind = "console" if any(element.role == "console" for element in safe_frame.elements) else "window"
        registry.register_surface(
            ExternalSurface(
                surface_id=safe_frame.surface_id,
                kind=surface_kind,
                title=safe_frame.title,
                adapter_id=safe_frame.source,
                read_only=True,
                metadata={"active_application": safe_frame.active_application, **safe_frame.metadata},
            ),
            AdapterSafetyContract(adapter_id=safe_frame.source, stage="read_only_telemetry", permission="observe_only", max_risk=0.05),
        )

        inspect_count = 0
        blocked_write = 0
        descriptors: list[str] = [safe_frame.title, safe_frame.active_application]
        for element in safe_frame.elements[:18]:
            self.role_counts[element.role] = self.role_counts.get(element.role, 0) + 1
            label = element.label or element.role
            descriptors.extend((element.role, label))
            registry.propose_affordance(
                ExternalAffordance(
                    affordance_id=f"inspect:{safe_frame.surface_id}:{element.element_id}",
                    surface_id=safe_frame.surface_id,
                    kind="inspect",
                    description=f"inspect {element.role} {label}"[:160],
                    confidence=max(0.0, min(1.0, element.confidence or 0.55)),
                    risk=0.01,
                    evidence=(f"role:{element.role}", f"label:{_slug(label)}"),
                )
            )
            inspect_count += 1
            if element.interactable:
                affordance = ExternalAffordance(
                    affordance_id=f"blocked_click:{safe_frame.surface_id}:{element.element_id}",
                    surface_id=safe_frame.surface_id,
                    kind="click",
                    description=f"blocked click proposal for {element.role} {label}"[:160],
                    confidence=max(0.0, min(1.0, element.confidence or 0.42)),
                    risk=0.04,
                    evidence=("blocked_by:read_only_telemetry", f"role:{element.role}"),
                )
                registry.propose_affordance(affordance)
                if affordance not in registry.allowed_affordances():
                    blocked_write += 1
        descriptors.extend(safe_frame.text_fragments[:8])
        metadata = {
            "surface_id": safe_frame.surface_id,
            "active_application": safe_frame.active_application,
            "element_count": str(len(safe_frame.elements)),
            "observer_stage": "read_only_telemetry",
        }
        sensory_hub.receive_screen_probe(
            tick=safe_frame.tick,
            description=" ".join(str(part) for part in descriptors if str(part).strip())[:700],
            source=safe_frame.source,
            ttl=24,
            intensity=0.76,
        )
        # Add a second compact packet with machine-stable metadata so focus can
        # bind the surface identity without OCR or live OS handles.
        sensory_hub.receive(
            tick=safe_frame.tick,
            source=f"{safe_frame.source}:metadata",
            modality="screen",
            payload=f"surface {safe_frame.surface_id} app {safe_frame.active_application} roles {' '.join(sorted(self.role_counts))}",
            ttl=24,
            intensity=0.66,
            metadata=metadata,
        )
        events: tuple[PlasticityEvent, ...] = ()
        if graph is not None:
            graph_events = list(self._write_graph_anatomy(tick=safe_frame.tick, frame=safe_frame, graph=graph))
            if interface_affordance is not None:
                graph_events.extend(interface_affordance.observe_frame(tick=safe_frame.tick, frame=safe_frame, registry=registry, graph=graph))
            events = tuple(graph_events)
            self.graph_event_count += len(events)
        elif interface_affordance is not None:
            interface_affordance.observe_frame(tick=safe_frame.tick, frame=safe_frame, registry=registry, graph=None)
        self.blocked_write_like_count += blocked_write
        report = DesktopObservationReport(
            tick=safe_frame.tick,
            surface_id=safe_frame.surface_id,
            element_count=len(safe_frame.elements),
            sensory_packet_created=True,
            inspect_affordances=inspect_count,
            blocked_write_like_affordances=blocked_write,
            graph_events=len(events),
            features=self._feature_tokens(safe_frame),
        )
        self.reports.append(report)
        return report

    def snapshot(self) -> dict[str, Any]:
        return {
            "observation_count": self.observation_count,
            "surface_count": len(self.surface_counts),
            "graph_event_count": self.graph_event_count,
            "blocked_write_like_count": self.blocked_write_like_count,
            "surface_counts": dict(sorted(self.surface_counts.items())),
            "role_counts": dict(sorted(self.role_counts.items())),
            "last": self.reports[-1].as_dict() if self.reports else None,
            "recent": [report.as_dict() for report in list(self.reports)[-8:]],
            "law": "desktop/OS surfaces are read-only observations first; actuation remains gated elsewhere.",
        }

    def state(self) -> dict[str, Any]:
        return {
            "observation_count": self.observation_count,
            "graph_event_count": self.graph_event_count,
            "blocked_write_like_count": self.blocked_write_like_count,
            "surface_counts": dict(self.surface_counts),
            "role_counts": dict(self.role_counts),
            "frames": [frame.as_dict() for frame in self.frames],
            "reports": [report.as_dict() for report in self.reports],
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "OSObservationSubstrate":
        substrate = cls()
        substrate.observation_count = int(data.get("observation_count", 0))
        substrate.graph_event_count = int(data.get("graph_event_count", 0))
        substrate.blocked_write_like_count = int(data.get("blocked_write_like_count", 0))
        substrate.surface_counts = {str(key): int(value) for key, value in dict(data.get("surface_counts", {})).items()}
        substrate.role_counts = {str(key): int(value) for key, value in dict(data.get("role_counts", {})).items()}
        for item in data.get("frames", [])[-substrate.frames.maxlen :]:
            if isinstance(item, dict):
                substrate.frames.append(_frame_from_dict(item))
        for item in data.get("reports", [])[-substrate.reports.maxlen :]:
            if isinstance(item, dict):
                substrate.reports.append(_report_from_dict(item))
        return substrate

    def _feature_tokens(self, frame: DesktopObservationFrame) -> tuple[str, ...]:
        tokens = [
            f"screen:surface_id={_slug(frame.surface_id)}",
            f"screen:active_application={_slug(frame.active_application)}",
            f"screen:title={_slug(frame.title)}",
        ]
        for element in frame.elements[:12]:
            tokens.append(f"screen:ui_role={element.role}")
            if element.label:
                tokens.append(f"screen:ui_label={_slug(element.label)}")
        return tuple(tokens)

    def _write_graph_anatomy(self, *, tick: int, frame: DesktopObservationFrame, graph: NeuralGrowthGraph) -> tuple[PlasticityEvent, ...]:
        events: list[PlasticityEvent] = []
        surface_node = f"external_surface:{_slug(frame.surface_id)}"
        app_node = f"external_app:{_slug(frame.active_application)}"
        title_node = f"external_title:{_slug(frame.title)}"
        graph.ensure_neuron(surface_node, kind="external_surface", label=frame.surface_id, tick=tick)
        graph.ensure_neuron(app_node, kind="external_app", label=frame.active_application, tick=tick)
        graph.ensure_neuron(title_node, kind="external_title", label=frame.title, tick=tick)
        graph.activate(surface_node, amount=0.64, tick=tick)
        graph.activate(app_node, amount=0.58, tick=tick)
        graph.activate(title_node, amount=0.52, tick=tick)
        events.append(graph.reinforce(surface_node, app_node, amount=0.035, tick=tick, reason="desktop observation app binding"))
        events.append(graph.reinforce(surface_node, title_node, amount=0.030, tick=tick, reason="desktop observation title binding"))
        for element in frame.elements[:18]:
            role_node = f"ui_role:{element.role}"
            graph.ensure_neuron(role_node, kind="ui_role", label=element.role, tick=tick)
            graph.activate(role_node, amount=0.50, tick=tick)
            events.append(graph.reinforce(surface_node, role_node, amount=0.022, tick=tick, reason="desktop observation role binding"))
            if element.label:
                label_node = f"ui_label:{_slug(element.label)}"
                graph.ensure_neuron(label_node, kind="ui_label", label=element.label[:72], tick=tick)
                graph.activate(label_node, amount=0.48, tick=tick)
                events.append(graph.reinforce(role_node, label_node, amount=0.018, tick=tick, reason="desktop observation label binding"))
        return tuple(events)


def _normalize_frame(frame: DesktopObservationFrame) -> DesktopObservationFrame:
    return DesktopObservationFrame(
        tick=int(frame.tick),
        surface_id=_slug(frame.surface_id or "desktop_surface"),
        title=str(frame.title or "Untitled")[:120],
        active_application=str(frame.active_application or "unknown_app")[:80],
        elements=tuple(_normalize_element(element) for element in frame.elements[:64]),
        text_fragments=tuple(str(text)[:160] for text in frame.text_fragments[:24]),
        source=_slug(frame.source or "desktop_observer"),
        screenshot_digest=str(frame.screenshot_digest or "")[:80],
        metadata={str(k)[:48]: str(v)[:120] for k, v in dict(frame.metadata).items()},
    )


def _normalize_element(element: DesktopElement) -> DesktopElement:
    return DesktopElement(
        element_id=_slug(element.element_id or element.label or element.role),
        role=element.role,
        label=str(element.label or "")[:120],
        bounds=tuple(int(value) for value in tuple(element.bounds)[:4]) if len(tuple(element.bounds)) >= 4 else (0, 0, 0, 0),
        interactable=bool(element.interactable),
        confidence=max(0.0, min(1.0, float(element.confidence))),
    )


def _frame_from_dict(item: dict[str, Any]) -> DesktopObservationFrame:
    elements = tuple(_element_from_dict(element) for element in item.get("elements", []) if isinstance(element, dict))
    return DesktopObservationFrame(
        tick=int(item.get("tick", 0)),
        surface_id=str(item.get("surface_id", "desktop_surface")),
        title=str(item.get("title", "")),
        active_application=str(item.get("active_application", "")),
        elements=elements,
        text_fragments=tuple(str(text) for text in item.get("text_fragments", [])),
        source=str(item.get("source", "desktop_observer")),
        screenshot_digest=str(item.get("screenshot_digest", "")),
        metadata={str(k): str(v) for k, v in dict(item.get("metadata", {})).items()},
    )


def _element_from_dict(item: dict[str, Any]) -> DesktopElement:
    bounds = item.get("bounds", (0, 0, 0, 0))
    if isinstance(bounds, list):
        bounds = tuple(bounds)
    return DesktopElement(
        element_id=str(item.get("element_id", "element")),
        role=str(item.get("role", "unknown")),  # type: ignore[arg-type]
        label=str(item.get("label", "")),
        bounds=tuple(int(value) for value in bounds[:4]),
        interactable=bool(item.get("interactable", False)),
        confidence=float(item.get("confidence", 0.0)),
    )


def _report_from_dict(item: dict[str, Any]) -> DesktopObservationReport:
    return DesktopObservationReport(
        tick=int(item.get("tick", 0)),
        surface_id=str(item.get("surface_id", "")),
        element_count=int(item.get("element_count", 0)),
        sensory_packet_created=bool(item.get("sensory_packet_created", False)),
        inspect_affordances=int(item.get("inspect_affordances", 0)),
        blocked_write_like_affordances=int(item.get("blocked_write_like_affordances", 0)),
        graph_events=int(item.get("graph_events", 0)),
        features=tuple(str(feature) for feature in item.get("features", [])),
    )


def _slug(value: str) -> str:
    text = "".join(ch.lower() if ch.isalnum() else "_" for ch in str(value).strip())
    text = "_".join(piece for piece in text.split("_") if piece)
    return (text or "unknown")[:80]
