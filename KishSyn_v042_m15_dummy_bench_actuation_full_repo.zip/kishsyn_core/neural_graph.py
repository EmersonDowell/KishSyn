"""Experience-grown neural association graph.

This is not a biological simulation. It is a compact plastic graph that obeys
the same core discipline: repeated co-activation strengthens pathways; harmful
outcomes inhibit action paths; decay prevents unlimited growth. v010 added
embodied symbol teaching and v012 adds persistent cue-goal support: symbols bind to grounded concept hubs only after
inspection/contact traces expose token-paired sensory evidence.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import tanh

from .contracts import PlasticityEvent


@dataclass
class Neuron:
    node_id: str
    kind: str
    label: str
    activation: float = 0.0
    created_at: int = 0
    last_active: int = 0


@dataclass
class Synapse:
    source: str
    target: str
    weight: float = 0.0
    last_updated: int = 0
    updates: int = 0


class NeuralGrowthGraph:
    """A tiny directed weighted graph that grows from traces."""

    CONCEPT_DIMENSIONS = {
        "vision:color": "color",
        "vision:shape": "shape",
        "vision:glyph": "glyph",
        "vision:count": "count",
        "vision:symbol_token": "symbol_token",
        "vision:paired_color": "color",
        "vision:paired_shape": "shape",
        "vision:paired_glyph": "glyph",
        "vision:paired_count": "count",
        "vision:teaches": "teaching_relation",
        "terrain:terrain": "terrain",
        "place:zone": "zone",
        "text:word": "word",
        "text:char": "char",
        "text:glyph": "glyph",
        "text:number": "count",
        "text:word_count": "quantity",
        "text:char_count": "quantity",
        "text:punctuation": "utterance",
        "screen:descriptor": "screen_descriptor",
        "screen:surface": "surface",
        "image:descriptor": "image_descriptor",
        "image:surface": "surface",
        "audio:descriptor": "audio_descriptor",
        "audio:surface": "surface",
        "math:operator": "operator",
        "math:left": "quantity",
        "math:right": "quantity",
        "math:result": "quantity",
        "math:truth": "truth",
        "math:result_parity": "parity",
        "math:equation_form": "equation_form",
        "console:surface": "surface",
        "sensor:surface": "surface",
        "expression:channel": "channel",
        "expression:phrase": "utterance",
        "emotion:mode": "emotion_mode",
        "emotion:arousal": "arousal_band",
        "emotion:valence": "valence_band",
        "emotion:control": "control_band",
        "emotion:trait": "trait",
    }

    def __init__(self) -> None:
        self.neurons: dict[str, Neuron] = {}
        self.synapses: dict[tuple[str, str], Synapse] = {}
        self.concept_updates = 0
        self.symbol_binding_updates = 0

    def ensure_neuron(self, node_id: str, *, kind: str, label: str, tick: int) -> Neuron:
        if node_id not in self.neurons:
            self.neurons[node_id] = Neuron(node_id=node_id, kind=kind, label=label, created_at=tick)
        return self.neurons[node_id]

    def activate(self, node_id: str, *, amount: float, tick: int) -> None:
        neuron = self.neurons.get(node_id)
        if neuron is None:
            return
        neuron.activation = max(neuron.activation, min(1.0, amount))
        neuron.last_active = tick

    def reinforce(self, source: str, target: str, *, amount: float, tick: int, reason: str) -> PlasticityEvent:
        key = (source, target)
        synapse = self.synapses.get(key)
        if synapse is None:
            synapse = Synapse(source=source, target=target)
            self.synapses[key] = synapse
        before = synapse.weight
        synapse.weight = max(-1.0, min(1.0, synapse.weight + amount))
        synapse.updates += 1
        synapse.last_updated = tick
        return PlasticityEvent(source=source, target=target, before=before, after=synapse.weight, reason=reason)

    def decay(self, *, rate: float = 0.002) -> None:
        for synapse in self.synapses.values():
            edge_rate = rate
            if synapse.source.startswith(("symbol:", "symbol_goal:", "concept:")) or synapse.target.startswith(("symbol:", "symbol_goal:", "concept:")):
                edge_rate = rate * 0.18
            if synapse.weight > 0:
                synapse.weight = max(0.0, synapse.weight - edge_rate)
            elif synapse.weight < 0:
                synapse.weight = min(0.0, synapse.weight + edge_rate)
        for neuron in self.neurons.values():
            neuron.activation *= 0.88

    def score_target_for_need(self, target_features: tuple[str, ...], need: str) -> float:
        if not target_features:
            return 0.0
        score = 0.0
        need_node = f"need:{need}"
        relief_node = "outcome:relief"
        pain_node = "outcome:pain"
        novelty_node = "outcome:novelty"
        for feature in target_features:
            exact_relief = self.weight(feature, relief_node)
            exact_pain = self.weight(feature, pain_node)
            exact_novelty = self.weight(feature, novelty_node)
            concept_relief = self._concept_generalization(feature, relief_node)
            concept_pain = self._concept_generalization(feature, pain_node)
            concept_novelty = self._concept_generalization(feature, novelty_node)
            symbol_relief = self._symbol_generalization(feature, relief_node)
            symbol_pain = self._symbol_generalization(feature, pain_node)
            symbol_novelty = self._symbol_generalization(feature, novelty_node)
            score += (exact_relief + concept_relief * 0.55 + symbol_relief * 0.45) * 1.2
            score -= (exact_pain + concept_pain * 0.65 + symbol_pain * 0.55) * 1.6
            score += (exact_novelty + concept_novelty * 0.50 + symbol_novelty * 0.40) * 0.35
            score += self.weight(need_node, feature) * 0.7
            for concept in self.concepts_for_feature(feature):
                score += self.weight(need_node, concept) * 0.28
        return tanh(score)

    def predicted_outcome(self, target_features: tuple[str, ...]) -> tuple[str, float, tuple[str, ...]]:
        totals = {"relief": 0.0, "pain": 0.0, "novelty": 0.0, "neutral": 0.05}
        evidence: list[str] = []
        for feature in target_features:
            for outcome in ("relief", "pain", "novelty"):
                direct = self.weight(feature, f"outcome:{outcome}")
                concept = self._concept_generalization(feature, f"outcome:{outcome}")
                symbol = self._symbol_generalization(feature, f"outcome:{outcome}")
                weight = direct + concept * 0.5 + symbol * 0.4
                if weight > 0:
                    totals[outcome] += weight
                    if direct > 0:
                        evidence.append(f"{feature}->{outcome}:{direct:.2f}")
                    elif concept > 0:
                        evidence.append(f"{feature}~concept->{outcome}:{concept:.2f}")
                    elif symbol > 0:
                        evidence.append(f"{feature}~symbol->{outcome}:{symbol:.2f}")
                elif outcome == "pain" and weight < 0:
                    totals["relief"] += abs(weight) * 0.2
        best, value = max(totals.items(), key=lambda item: item[1])
        confidence = max(0.0, min(1.0, value / max(1.0, sum(abs(v) for v in totals.values()))))
        return best, confidence, tuple(evidence[:6])

    def concepts_for_feature(self, feature: str) -> tuple[str, ...]:
        """Return abstract concept hubs a feature may join.

        These are not semantic labels handed to the organism. They are sparse
        sensory dimensions that become useful only if plasticity strengthens
        them through consequence.
        """

        if "=" not in feature:
            return ()
        prefix, value = feature.split("=", 1)
        concepts: list[str] = []
        dimension = self.CONCEPT_DIMENSIONS.get(prefix)
        if dimension is not None:
            concepts.append(f"concept:dimension={dimension}")
            concepts.append(f"concept:{dimension}={value}")
        if prefix in {"vision:glyph", "vision:paired_glyph", "text:glyph"} and value:
            concepts.append("concept:alphabetic_mark")
        if prefix in {"vision:count", "vision:paired_count", "text:number"} and value.isdigit():
            concepts.append("concept:numerosity")
            parity = "even" if int(value) % 2 == 0 else "odd"
            concepts.append(f"concept:parity={parity}")
        return tuple(concepts)

    def abstract_from_features(
        self,
        *,
        tick: int,
        features: tuple[str, ...],
        outcome_node: str,
        need_node: str,
        reason: str,
    ) -> tuple[PlasticityEvent, ...]:
        """Grow sparse concept hubs from experienced features.

        Concept formation is deliberately downstream of action/outcome traces.
        A color, shape, glyph, or count becomes meaningful only when repeated
        experience links it to need pressure and consequence.
        """

        events: list[PlasticityEvent] = []
        for feature in features:
            concepts = self.concepts_for_feature(feature)
            if not concepts:
                continue
            for concept in concepts:
                label = concept.split(":", 1)[1]
                self.ensure_neuron(concept, kind="concept", label=label, tick=tick)
                self.activate(concept, amount=0.58, tick=tick)
                events.append(self.reinforce(feature, concept, amount=0.035, tick=tick, reason=f"{reason} abstraction"))
                events.append(self.reinforce(concept, outcome_node, amount=0.025, tick=tick, reason=f"{reason} concept consequence"))
                events.append(self.reinforce(need_node, concept, amount=0.018, tick=tick, reason=f"{reason} need concept"))
                self.concept_updates += 1
        return tuple(events)

    def bind_symbols_from_features(
        self,
        *,
        tick: int,
        features: tuple[str, ...],
        outcome_node: str,
        need_node: str,
        reason: str,
    ) -> tuple[PlasticityEvent, ...]:
        """Bind teacher tokens to grounded concept hubs only after experience.

        The world may expose a teaching surface, but the organism does not get
        a direct parser table. A token becomes useful only when the token, its
        paired sensory evidence, need pressure, and consequence are coactive
        during an inspected/touched trace.
        """

        token_values = self._feature_values(features, "vision:symbol_token")
        if not token_values:
            return ()
        paired_features = [
            feature for feature in features
            if feature.startswith(("vision:paired_color=", "vision:paired_shape=", "vision:paired_glyph=", "vision:paired_count="))
        ]
        if not paired_features:
            return ()
        events: list[PlasticityEvent] = []
        for token_value in token_values:
            token_node = f"symbol:token={token_value}"
            self.ensure_neuron(token_node, kind="symbol", label=f"token={token_value}", tick=tick)
            self.activate(token_node, amount=0.74, tick=tick)
            events.append(self.reinforce(need_node, token_node, amount=0.020, tick=tick, reason=f"{reason} token pressure"))
            events.append(self.reinforce(token_node, outcome_node, amount=0.030, tick=tick, reason=f"{reason} token consequence"))
            for paired in paired_features:
                for concept in self.concepts_for_feature(paired):
                    self.ensure_neuron(concept, kind="concept", label=concept.split(":", 1)[1], tick=tick)
                    self.activate(concept, amount=0.62, tick=tick)
                    events.append(self.reinforce(token_node, concept, amount=0.140, tick=tick, reason=f"{reason} symbol grounding"))
                    events.append(self.reinforce(concept, token_node, amount=0.060, tick=tick, reason=f"{reason} symbol recall"))
                    events.append(self.reinforce(concept, outcome_node, amount=0.022, tick=tick, reason=f"{reason} grounded symbol consequence"))
                    self.symbol_binding_updates += 1
        return tuple(events)

    def _feature_values(self, features: tuple[str, ...], prefix: str) -> tuple[str, ...]:
        values: list[str] = []
        needle = prefix + "="
        for feature in features:
            if feature.startswith(needle):
                values.append(feature.split("=", 1)[1])
        return tuple(values)

    def _concept_generalization(self, feature: str, outcome_node: str) -> float:
        score = 0.0
        for concept in self.concepts_for_feature(feature):
            score += self.weight(feature, concept) * self.weight(concept, outcome_node)
        return score

    def _symbol_generalization(self, feature: str, outcome_node: str) -> float:
        if not feature.startswith("vision:symbol_token="):
            return 0.0
        token = feature.split("=", 1)[1]
        token_node = f"symbol:token={token}"
        score = self.weight(token_node, outcome_node)
        for (source, target), synapse in self.synapses.items():
            if source == token_node and target.startswith("concept:"):
                score += synapse.weight * self.weight(target, outcome_node)
        return score


    def symbol_cue_score(self, scene_features: tuple[str, ...], target_features: tuple[str, ...]) -> tuple[float, tuple[str, ...]]:
        """Score whether active symbol cues support a candidate target.

        This is not a parser. It uses only learned symbol->concept pathways and
        target feature->concept pathways grown by plasticity. The built-in
        concept dimensions provide a sensory axis, but a cue cannot help until
        the symbol itself has been grounded by traces.
        """

        tokens = self._feature_values(scene_features, "vision:symbol_token")
        if not tokens or not target_features:
            return 0.0, ()
        target_concepts: dict[str, list[str]] = {}
        for feature in target_features:
            for concept in self.concepts_for_feature(feature):
                target_concepts.setdefault(concept, []).append(feature)
        if not target_concepts:
            return 0.0, ()
        score = 0.0
        evidence: list[str] = []
        for token in tokens:
            token_node = f"symbol:token={token}"
            if token_node not in self.neurons:
                continue
            for concept, matching_features in target_concepts.items():
                token_to_concept = self.weight(token_node, concept)
                if token_to_concept <= 0.0:
                    continue
                membership = max((self.weight(feature, concept) for feature in matching_features), default=0.0)
                if concept in self.neurons:
                    membership = max(membership, 0.12)
                cue_value = token_to_concept * membership
                score += cue_value
                if cue_value > 0.01:
                    evidence.append(f"{token_node}->{concept}:{cue_value:.3f}")
            for (source, concept), synapse in self.synapses.items():
                if source != token_node or not concept.startswith("concept:") or synapse.weight <= 0.0:
                    continue
                family = self._concept_family(concept)
                if not family:
                    continue
                has_conflict = any(self._concept_family(candidate) == family and candidate != concept for candidate in target_concepts)
                if has_conflict:
                    score -= synapse.weight * 0.10
        return max(-1.0, min(1.0, score)), tuple(evidence[:8])

    def _concept_family(self, concept: str) -> str:
        if not concept.startswith("concept:"):
            return ""
        payload = concept.split(":", 1)[1]
        return payload.split("=", 1)[0]

    def symbol_ablated_copy(self, *, keep_neurons: bool = True) -> "NeuralGrowthGraph":
        """Copy graph while removing symbol pathways for ablation proof."""

        clone = NeuralGrowthGraph()
        clone.concept_updates = self.concept_updates
        clone.symbol_binding_updates = 0
        if keep_neurons:
            clone.neurons = {
                node_id: Neuron(
                    node_id=n.node_id,
                    kind=n.kind,
                    label=n.label,
                    activation=n.activation,
                    created_at=n.created_at,
                    last_active=n.last_active,
                )
                for node_id, n in self.neurons.items()
            }
        for key, synapse in self.synapses.items():
            source, target = key
            if source.startswith(("symbol:", "symbol_goal:", "text:")) or target.startswith(("symbol:", "symbol_goal:", "text:")):
                continue
            clone.synapses[key] = Synapse(
                source=synapse.source,
                target=synapse.target,
                weight=synapse.weight,
                last_updated=synapse.last_updated,
                updates=synapse.updates,
            )
        return clone

    def weight(self, source: str, target: str) -> float:
        synapse = self.synapses.get((source, target))
        return 0.0 if synapse is None else synapse.weight

    def ablated_copy(self, *, keep_neurons: bool = True) -> "NeuralGrowthGraph":
        clone = NeuralGrowthGraph()
        clone.concept_updates = self.concept_updates
        clone.symbol_binding_updates = self.symbol_binding_updates
        if keep_neurons:
            clone.neurons = {
                node_id: Neuron(
                    node_id=n.node_id,
                    kind=n.kind,
                    label=n.label,
                    activation=n.activation,
                    created_at=n.created_at,
                    last_active=n.last_active,
                )
                for node_id, n in self.neurons.items()
            }
        return clone

    def concept_snapshot(self) -> dict[str, object]:
        concept_nodes = [n for n in self.neurons.values() if n.kind == "concept"]
        by_family: dict[str, int] = {}
        for node in concept_nodes:
            family = node.node_id.split("=", 1)[0].replace("concept:", "")
            by_family[family] = by_family.get(family, 0) + 1
        prototypes: list[dict[str, object]] = []
        for node in concept_nodes:
            outcome_weights = {
                outcome: round(self.weight(node.node_id, f"outcome:{outcome}"), 4)
                for outcome in ("relief", "pain", "novelty", "depleted", "neutral")
            }
            best = max(outcome_weights.items(), key=lambda item: item[1])
            if best[1] <= 0.01:
                continue
            prototypes.append(
                {
                    "id": node.node_id,
                    "label": node.label,
                    "activation": round(node.activation, 4),
                    "best_outcome": best[0],
                    "best_weight": best[1],
                    "weights": outcome_weights,
                }
            )
        prototypes.sort(key=lambda item: (-float(item["best_weight"]), str(item["id"])))
        return {
            "concept_count": len(concept_nodes),
            "concept_updates": self.concept_updates,
            "families": by_family,
            "top_prototypes": prototypes[:14],
        }

    def symbol_snapshot(self) -> dict[str, object]:
        symbol_nodes = [n for n in self.neurons.values() if n.kind == "symbol"]
        bindings: list[dict[str, object]] = []
        for node in symbol_nodes:
            links = []
            for (source, target), synapse in self.synapses.items():
                if source == node.node_id and target.startswith("concept:") and synapse.weight > 0.01:
                    links.append({"concept": target, "weight": round(synapse.weight, 4), "updates": synapse.updates})
            links.sort(key=lambda item: (-float(item["weight"]), str(item["concept"])))
            if links:
                bindings.append({"token": node.node_id, "label": node.label, "activation": round(node.activation, 4), "links": links[:6]})
        bindings.sort(key=lambda item: (-max(float(link["weight"]) for link in item["links"]), str(item["token"])))
        return {
            "symbol_count": len(symbol_nodes),
            "symbol_binding_updates": self.symbol_binding_updates,
            "bindings": bindings[:14],
        }

    def snapshot(self) -> dict[str, object]:
        nodes = [
            {
                "id": n.node_id,
                "kind": n.kind,
                "label": n.label,
                "activation": round(n.activation, 4),
                "created_at": n.created_at,
                "last_active": n.last_active,
            }
            for n in sorted(self.neurons.values(), key=lambda item: item.node_id)
        ]
        edges = [
            {
                "source": s.source,
                "target": s.target,
                "weight": round(s.weight, 4),
                "updates": s.updates,
                "last_updated": s.last_updated,
            }
            for s in sorted(self.synapses.values(), key=lambda item: (item.source, item.target))
            if abs(s.weight) > 0.01
        ]
        return {
            "nodes": nodes,
            "edges": edges,
            "node_count": len(nodes),
            "edge_count": len(edges),
            "concepts": self.concept_snapshot(),
            "symbols": self.symbol_snapshot(),
        }
