"""A living sensory-motor ecology for the clean core.

The world is deterministic and replayable, but it is not a static feeding dish.
Resources are finite, restorative terrain has local charge, depleted resources
migrate/regrow elsewhere, hazards move, and new affordance carriers enter the
ecology. The organism receives sensory features, not affordance labels.
"""

from __future__ import annotations

from dataclasses import dataclass
from random import Random
from typing import Iterable

from .contracts import Action, BodyState, Outcome, SensoryFeature, SensoryFrame


@dataclass
class WorldObject:
    object_id: str
    x: int
    y: int
    color: str
    shape: str
    affordance: str
    quantity: int = 1
    discovered: bool = False
    max_quantity: int = 1
    regrow_interval: int = 0
    mobility: tuple[int, int] = (0, 0)
    mobile_phase: int = 0
    depleted_at: int | None = None
    spawn_tick: int = 0
    glyph: str = ""
    count: int = 1
    symbol_token: str = ""
    paired_color: str = ""
    paired_shape: str = ""
    paired_glyph: str = ""
    paired_count: int = 0
    teaching_relation: str = ""

    def visible_features(self, distance: int, *, zone: str) -> tuple[SensoryFeature, ...]:
        intensity = 1.0 / max(1, distance)
        features = [
            SensoryFeature("object", self.object_id, "vision", intensity),
            SensoryFeature("color", self.color, "vision", intensity),
            SensoryFeature("shape", self.shape, "vision", intensity),
            SensoryFeature("distance", str(distance), "vision", intensity),
            SensoryFeature("zone", zone, "place", intensity * 0.8),
            SensoryFeature("quantity", "depleted" if self.quantity <= 0 else "available", "vision", intensity * 0.6),
        ]
        if self.glyph:
            features.append(SensoryFeature("glyph", self.glyph, "vision", intensity * 0.95))
            features.append(SensoryFeature("count", str(max(1, self.count)), "vision", intensity * 0.70))
        if self.symbol_token:
            features.append(SensoryFeature("symbol_token", self.symbol_token, "vision", intensity * 0.95))
        if self.teaching_relation:
            features.append(SensoryFeature("teaches", self.teaching_relation, "vision", intensity * 0.70))
        if self.paired_color:
            features.append(SensoryFeature("paired_color", self.paired_color, "vision", intensity * 0.76))
        if self.paired_shape:
            features.append(SensoryFeature("paired_shape", self.paired_shape, "vision", intensity * 0.76))
        if self.paired_glyph:
            features.append(SensoryFeature("paired_glyph", self.paired_glyph, "vision", intensity * 0.76))
        if self.paired_count:
            features.append(SensoryFeature("paired_count", str(max(1, self.paired_count)), "vision", intensity * 0.72))
        return tuple(features)


class MiniEcologyWorld:
    """A deterministic living toy ecology.

    The organism receives feature observations. It is not handed the affordance;
    it has to learn affordances by acting on objects and surviving consequences.
    v008 intentionally removes infinite camping value: resources deplete,
    comfort terrain has finite local charge, and resource patches relocate to
    underexplored regions after depletion.
    """

    def __init__(self, *, seed: int = 1, width: int = 31, height: int = 23) -> None:
        self.rng = Random(seed)
        self.width = width
        self.height = height
        self.agent_x = width // 2
        self.agent_y = height // 2
        self.tick = 0
        self.objects: dict[str, WorldObject] = {}
        self.last_events: list[str] = []
        self.terrain = self._build_terrain()
        self.cell_charge = self._initial_cell_charge()
        self.visit_counts: dict[tuple[int, int], int] = {}
        self.last_visit_tick: dict[tuple[int, int], int] = {}
        self.depletion_count = 0
        self.migration_count = 0
        self.spawn_count = 0
        self._spawn_initial_objects()
        self._record_visit()

    def _build_terrain(self) -> dict[tuple[int, int], str]:
        terrain: dict[tuple[int, int], str] = {}
        cx, cy = self.width // 2, self.height // 2
        for y in range(self.height):
            for x in range(self.width):
                if x in {0, self.width - 1} or y in {0, self.height - 1}:
                    kind = "edge"
                elif (x - cx) ** 2 + (y - cy) ** 2 <= 8:
                    kind = "meadow"
                elif 3 <= x <= 7 and 3 <= y <= self.height - 5:
                    kind = "grove"
                elif self.width - 9 <= x <= self.width - 4 and 2 <= y <= 7:
                    kind = "spring"
                elif self.width - 11 <= x <= self.width - 5 and self.height - 7 <= y <= self.height - 3:
                    kind = "shelter"
                elif (x * 5 + y * 7) % 29 == 0 or (x + y * 3) % 23 == 0:
                    kind = "rough"
                else:
                    kind = "plain"
                terrain[(x, y)] = kind
        return terrain

    def _initial_cell_charge(self) -> dict[tuple[int, int], float]:
        charge: dict[tuple[int, int], float] = {}
        for cell, terrain in self.terrain.items():
            charge[cell] = self._terrain_max_charge(terrain)
        return charge

    def _terrain_max_charge(self, terrain: str) -> float:
        if terrain in {"spring", "shelter"}:
            return 1.0
        if terrain == "grove":
            return 0.75
        if terrain == "meadow":
            return 0.45
        return 0.20

    def _spawn_initial_objects(self) -> None:
        fixed = (
            WorldObject("round_red_0", 3, 3, "red", "round", "food", 2, max_quantity=2, regrow_interval=42),
            WorldObject("round_green_0", 6, 15, "green", "round", "food", 1, max_quantity=2, regrow_interval=48),
            WorldObject("round_violet_0", 4, 19, "violet", "round", "food", 1, max_quantity=2, regrow_interval=53),
            WorldObject("tall_blue_0", 27, 3, "blue", "tall", "water", 2, max_quantity=2, regrow_interval=39),
            WorldObject("tall_cyan_0", 23, 7, "cyan", "tall", "water", 1, max_quantity=2, regrow_interval=46),
            WorldObject("tall_silver_0", 28, 12, "silver", "tall", "water", 1, max_quantity=2, regrow_interval=57),
            WorldObject("dark_spike_0", 2, 16, "dark", "spike", "hazard", 99, max_quantity=99, mobility=(1, 0)),
            WorldObject("jagged_orange_0", 18, 19, "orange", "jagged", "hazard", 99, max_quantity=99, mobility=(-1, 0), mobile_phase=2),
            WorldObject("black_spike_0", 13, 3, "black", "spike", "hazard", 99, max_quantity=99, mobility=(0, 1), mobile_phase=1),
            WorldObject("soft_gray_0", 27, 19, "gray", "soft", "rest", 2, max_quantity=2, regrow_interval=55),
            WorldObject("soft_white_0", 21, 16, "white", "soft", "rest", 1, max_quantity=2, regrow_interval=60),
            WorldObject("glow_gold_0", 15, 5, "gold", "glow", "novelty", 1, max_quantity=1, regrow_interval=64),
            WorldObject("glow_teal_0", 12, 13, "teal", "glow", "novelty", 1, max_quantity=1, regrow_interval=58),
            WorldObject("glyph_A_red_0", 9, 4, "red", "glyph", "symbol", 1, max_quantity=1, regrow_interval=70, glyph="A", count=1),
            WorldObject("glyph_B_blue_0", 24, 14, "blue", "glyph", "symbol", 1, max_quantity=1, regrow_interval=74, glyph="B", count=2),
            WorldObject("glyph_C_green_0", 7, 20, "green", "glyph", "symbol", 1, max_quantity=1, regrow_interval=78, glyph="C", count=3),
            WorldObject("teacher_color_red_0", 10, 6, "white", "glyph", "symbol", 1, max_quantity=1, regrow_interval=82, glyph="R", count=1, symbol_token="red", paired_color="red", teaching_relation="color"),
            WorldObject("teacher_shape_round_0", 5, 10, "white", "glyph", "symbol", 1, max_quantity=1, regrow_interval=84, glyph="O", count=1, symbol_token="round", paired_shape="round", teaching_relation="shape"),
            WorldObject("teacher_glyph_A_0", 18, 8, "white", "glyph", "symbol", 1, max_quantity=1, regrow_interval=86, glyph="A", count=1, symbol_token="A", paired_glyph="A", teaching_relation="glyph"),
            WorldObject("teacher_count_two_0", 21, 11, "white", "glyph", "symbol", 1, max_quantity=1, regrow_interval=88, glyph="2", count=2, symbol_token="two", paired_count=2, teaching_relation="count"),
            WorldObject("cue_color_red_0", 15, 11, "white", "glyph", "symbol", 1, max_quantity=1, regrow_interval=90, glyph="R", count=1, symbol_token="red", teaching_relation="cue"),
            WorldObject("cue_shape_round_0", 16, 11, "white", "glyph", "symbol", 1, max_quantity=1, regrow_interval=92, glyph="O", count=1, symbol_token="round", teaching_relation="cue"),
            WorldObject("cue_glyph_A_0", 15, 12, "white", "glyph", "symbol", 1, max_quantity=1, regrow_interval=94, glyph="A", count=1, symbol_token="A", teaching_relation="cue"),
            WorldObject("cue_count_two_0", 16, 12, "white", "glyph", "symbol", 1, max_quantity=1, regrow_interval=96, glyph="2", count=2, symbol_token="two", teaching_relation="cue"),
        )
        for obj in fixed:
            self.objects[obj.object_id] = obj
        for idx, affordance in enumerate(("food", "water", "rest", "novelty", "symbol", "food", "water", "symbol")):
            self._spawn_procedural_object(affordance=affordance, reason=f"initial:{idx}")

    def living_dynamics(self) -> list[str]:
        """Advance ecology processes that are not direct agent actions."""

        events: list[str] = []
        events.extend(self._scheduled_spawns())
        events.extend(self._recharge_cells())
        events.extend(self._relocate_or_regrow_objects())
        events.extend(self._move_mobile_objects())
        return events

    def _scheduled_spawns(self) -> list[str]:
        events: list[str] = []
        schedule = {
            36: ("food", "amber"),
            54: ("novelty", "lime"),
            72: ("rest", "lavender"),
            96: ("water", "indigo"),
            112: ("symbol", "white"),
            120: ("hazard", "crimson"),
            150: ("food", "pearl"),
            168: ("symbol", "amber"),
        }
        if self.tick in schedule:
            affordance, color = schedule[self.tick]
            obj = self._spawn_procedural_object(affordance=affordance, color=color, reason=f"scheduled:{self.tick}")
            events.append(f"spawn:{obj.object_id}")
        if self.tick > 0 and self.tick % 80 == 0 and len(self.objects) < 44:
            affordance = self.rng.choice(["food", "water", "rest", "novelty", "symbol"])
            obj = self._spawn_procedural_object(affordance=affordance, reason=f"pulse:{self.tick}")
            events.append(f"spawn:{obj.object_id}")
        return events

    def _spawn_procedural_object(self, *, affordance: str, reason: str, color: str | None = None) -> WorldObject:
        shape_for = {"food": "round", "water": "tall", "rest": "soft", "novelty": "glow", "hazard": "jagged", "symbol": "glyph"}
        palettes = {
            "food": ["red", "green", "violet", "amber", "pearl"],
            "water": ["blue", "cyan", "silver", "indigo"],
            "rest": ["gray", "white", "lavender"],
            "novelty": ["gold", "teal", "lime"],
            "hazard": ["dark", "orange", "black", "crimson"],
            "symbol": ["red", "blue", "green", "white", "amber", "violet"],
        }
        cell = self._underexplored_cell(prefer_far=True)
        color = color or self.rng.choice(palettes[affordance])
        shape = shape_for[affordance]
        idx = self.spawn_count
        self.spawn_count += 1
        quantity = 99 if affordance == "hazard" else 1
        max_quantity = 99 if affordance == "hazard" else (2 if affordance in {"food", "water", "rest"} else 1)
        glyph = ""
        count = 1
        symbol_token = ""
        paired_color = ""
        paired_shape = ""
        paired_glyph = ""
        paired_count = 0
        teaching_relation = ""
        if affordance == "symbol":
            glyph = self.rng.choice(["A", "B", "C", "D", "E", "F"])
            count = self.rng.randint(1, 4)
            roll = self.rng.random()
            if roll < 0.50:
                teaching_relation = self.rng.choice(["color", "shape", "glyph", "count"])
                if teaching_relation == "color":
                    paired_color = self.rng.choice(["red", "blue", "green", "violet", "amber", "cyan"])
                    symbol_token = paired_color
                elif teaching_relation == "shape":
                    paired_shape = self.rng.choice(["round", "tall", "soft", "glow", "glyph"])
                    symbol_token = paired_shape
                elif teaching_relation == "glyph":
                    paired_glyph = glyph
                    symbol_token = glyph
                else:
                    paired_count = count
                    symbol_token = {1: "one", 2: "two", 3: "three", 4: "four"}.get(count, str(count))
            elif roll < 0.78:
                teaching_relation = "cue"
                symbol_token = self.rng.choice(["red", "blue", "green", "round", "tall", "soft", "A", "B", "two", "three"])
        interval = 0 if affordance == "hazard" else self.rng.randint(42, 68)
        mobility = (0, 0)
        if affordance == "hazard":
            mobility = self.rng.choice([(1, 0), (-1, 0), (0, 1), (0, -1)])
        obj = WorldObject(
            f"{shape}_{color}_{idx}",
            cell[0],
            cell[1],
            color,
            shape,
            affordance,
            quantity,
            max_quantity=max_quantity,
            regrow_interval=interval,
            mobility=mobility,
            mobile_phase=self.rng.randint(0, 4),
            spawn_tick=self.tick,
            glyph=glyph,
            count=count,
            symbol_token=symbol_token,
            paired_color=paired_color,
            paired_shape=paired_shape,
            paired_glyph=paired_glyph,
            paired_count=paired_count,
            teaching_relation=teaching_relation,
        )
        self.objects[obj.object_id] = obj
        return obj

    def _underexplored_cell(self, *, prefer_far: bool) -> tuple[int, int]:
        best_cell = (self.width // 2, self.height // 2)
        best_score = -10**9
        for y in range(1, self.height - 1):
            for x in range(1, self.width - 1):
                terrain = self.terrain_at(x, y)
                if terrain == "edge":
                    continue
                visits = self.visit_counts.get((x, y), 0)
                distance = abs(x - self.agent_x) + abs(y - self.agent_y)
                occupied = any(obj.x == x and obj.y == y for obj in self.objects.values() if obj.quantity > 0)
                if occupied:
                    continue
                terrain_bonus = {"spring": 1.0, "grove": 0.7, "shelter": 0.7, "meadow": 0.4, "plain": 0.2, "rough": -0.3}.get(terrain, 0.0)
                score = -visits * 1.8 + terrain_bonus + self.rng.random() * 0.25
                score += min(10, distance) * (0.12 if prefer_far else 0.02)
                if score > best_score:
                    best_score = score
                    best_cell = (x, y)
        return best_cell

    def _recharge_cells(self) -> list[str]:
        events: list[str] = []
        for cell, terrain in self.terrain.items():
            if cell == (self.agent_x, self.agent_y):
                continue
            max_charge = self._terrain_max_charge(terrain)
            current = self.cell_charge.get(cell, max_charge)
            if current >= max_charge:
                continue
            self.cell_charge[cell] = min(max_charge, current + 0.018)
        return events

    def _relocate_or_regrow_objects(self) -> list[str]:
        events: list[str] = []
        for obj in self.objects.values():
            if obj.regrow_interval <= 0 or obj.quantity >= obj.max_quantity or obj.affordance == "hazard":
                continue
            if obj.depleted_at is None:
                continue
            if self.tick - obj.depleted_at < obj.regrow_interval:
                continue
            old = (obj.x, obj.y)
            obj.x, obj.y = self._underexplored_cell(prefer_far=True)
            obj.quantity = 1
            obj.discovered = False
            obj.depleted_at = None
            self.migration_count += 1
            events.append(f"migrate:{obj.object_id}:{old[0]},{old[1]}->{obj.x},{obj.y}")
        return events

    def _move_mobile_objects(self) -> list[str]:
        events: list[str] = []
        for obj in self.objects.values():
            if obj.mobility == (0, 0) or (self.tick + obj.mobile_phase) % 5 != 0:
                continue
            dx, dy = obj.mobility
            nx, ny = obj.x + dx, obj.y + dy
            if nx <= 0 or nx >= self.width - 1:
                obj.mobility = (-dx, dy)
                nx = obj.x + obj.mobility[0]
            if ny <= 0 or ny >= self.height - 1:
                obj.mobility = (dx, -dy)
                ny = obj.y + obj.mobility[1]
            if self.terrain_at(nx, ny) == "edge":
                continue
            obj.x = max(1, min(self.width - 2, nx))
            obj.y = max(1, min(self.height - 2, ny))
            events.append(f"move:{obj.object_id}")
        return events

    def maybe_spawn(self) -> list[str]:
        """Compatibility alias retained for older callers."""

        return self.living_dynamics()

    def observe(self, body: BodyState) -> SensoryFrame:
        local_terrain = self.terrain_at(self.agent_x, self.agent_y)
        cell = (self.agent_x, self.agent_y)
        features: list[SensoryFeature] = [
            SensoryFeature("need", body.dominant_need(), "body", max(body.needs().values())),
            SensoryFeature("agent_x", str(self.agent_x), "vision", 0.25),
            SensoryFeature("agent_y", str(self.agent_y), "vision", 0.25),
            SensoryFeature("cell", self.place_key(self.agent_x, self.agent_y), "place", 0.75),
            SensoryFeature("zone", self.zone_for(self.agent_x, self.agent_y), "place", 0.55),
            SensoryFeature("terrain", local_terrain, "terrain", 0.55),
            SensoryFeature("cell_charge", self._charge_band(cell), "terrain", 0.36),
            SensoryFeature("visit_count", self._visit_band(cell), "place", 0.34),
            SensoryFeature("nearby_density", str(min(5, len(self.nearest_objects(limit=5)))), "vision", 0.2),
            SensoryFeature("available_resources", str(self.available_resource_count()), "vision", 0.2),
        ]
        for obj in self.nearest_objects(limit=10):
            distance = self.distance_to(obj.object_id)
            features.extend(obj.visible_features(distance, zone=self.zone_for(obj.x, obj.y)))
        return SensoryFrame(
            tick=self.tick,
            features=tuple(features),
            raw={
                "agent": {"x": self.agent_x, "y": self.agent_y},
                "terrain": local_terrain,
                "zone": self.zone_for(self.agent_x, self.agent_y),
                "objects": [self.object_view(obj) for obj in self.objects.values()],
                "terrain_map": self.terrain_view(),
                "foraging": self.foraging_snapshot(),
            },
        )

    def nearest_objects(self, *, limit: int) -> list[WorldObject]:
        return sorted(self.objects.values(), key=lambda obj: (self.distance_to(obj.object_id), obj.object_id))[:limit]

    def foraging_candidates(self, *, limit: int) -> list[WorldObject]:
        """Return targets exposed to the selector by local perception plus gradients.

        This is not a god-view of affordances. It is an intentionally small
        sensory/memory proxy: nearby objects, visible novel objects, and distant
        objects in underexplored cells can enter competition as environmental
        gradients when the organism has exhausted local value.
        """

        candidates: dict[str, WorldObject] = {obj.object_id: obj for obj in self.nearest_objects(limit=14)}
        available = [obj for obj in self.objects.values() if obj.quantity > 0 and obj.affordance != "hazard"]
        underexplored = sorted(
            available,
            key=lambda obj: (
                self.visit_counts.get((obj.x, obj.y), 0),
                -self.distance_to(obj.object_id),
                obj.object_id,
            ),
        )[:8]
        for obj in underexplored:
            candidates[obj.object_id] = obj
        novel = sorted([obj for obj in available if not obj.discovered], key=lambda obj: (self.distance_to(obj.object_id), obj.object_id))[:6]
        for obj in novel:
            candidates[obj.object_id] = obj
        return sorted(candidates.values(), key=lambda obj: (self.distance_to(obj.object_id), obj.object_id))[:limit]

    def available_resource_count(self) -> int:
        return sum(1 for obj in self.objects.values() if obj.quantity > 0 and obj.affordance in {"food", "water", "rest", "novelty", "symbol"})

    def distance_to(self, object_id: str) -> int:
        obj = self.objects[object_id]
        return abs(obj.x - self.agent_x) + abs(obj.y - self.agent_y)

    def terrain_at(self, x: int, y: int) -> str:
        return self.terrain.get((x, y), "plain")

    def zone_for(self, x: int, y: int) -> str:
        column = "west" if x < self.width / 3 else "east" if x >= (self.width * 2) / 3 else "center"
        row = "north" if y < self.height / 3 else "south" if y >= (self.height * 2) / 3 else "middle"
        return f"{row}_{column}"

    def place_key(self, x: int, y: int) -> str:
        return f"{self.zone_for(x, y)}:{x//3},{y//3}"

    def terrain_view(self) -> list[dict[str, object]]:
        cells: list[dict[str, object]] = []
        for (x, y), terrain in sorted(self.terrain.items()):
            cells.append(
                {
                    "x": x,
                    "y": y,
                    "terrain": terrain,
                    "charge": round(self.cell_charge.get((x, y), 0.0), 3),
                    "visits": self.visit_counts.get((x, y), 0),
                }
            )
        return cells

    def object_view(self, obj: WorldObject) -> dict[str, object]:
        return {
            "id": obj.object_id,
            "x": obj.x,
            "y": obj.y,
            "color": obj.color,
            "shape": obj.shape,
            "quantity": obj.quantity,
            "max_quantity": obj.max_quantity,
            "discovered": obj.discovered,
            "mobile": obj.mobility != (0, 0),
            "zone": self.zone_for(obj.x, obj.y),
            "terrain": self.terrain_at(obj.x, obj.y),
            "affordance_witness": obj.affordance,
            "glyph": obj.glyph,
            "count": obj.count,
            "symbol_token": obj.symbol_token,
            "paired_color": obj.paired_color,
            "paired_shape": obj.paired_shape,
            "paired_glyph": obj.paired_glyph,
            "paired_count": obj.paired_count,
            "teaching_relation": obj.teaching_relation,
            "depleted": obj.quantity <= 0,
        }

    def step(self, action: Action) -> Outcome:
        self.tick += 1
        self.last_events = self.living_dynamics()
        if action.kind == "wait":
            outcome = self._ambient_outcome(Outcome("neutral", {"fatigue": -0.002}, message="waited"))
        elif action.kind == "move":
            outcome = self._ambient_outcome(self._move_toward(action.target_id))
        elif action.kind == "inspect":
            outcome = self._ambient_outcome(self._inspect(action.target_id))
        elif action.kind in {"touch", "eat", "drink", "rest", "avoid"}:
            outcome = self._ambient_outcome(self._interact(action))
        else:
            outcome = self._ambient_outcome(Outcome("neutral", message="unknown action ignored"))
        self._record_visit()
        return outcome

    def _ambient_outcome(self, outcome: Outcome) -> Outcome:
        deltas = dict(outcome.delta_body)
        cell = (self.agent_x, self.agent_y)
        terrain = self.terrain_at(self.agent_x, self.agent_y)
        charge = self.cell_charge.get(cell, 0.0)
        visits = self.visit_counts.get(cell, 0)
        if terrain == "rough":
            deltas["fatigue"] = deltas.get("fatigue", 0.0) + 0.008
        elif terrain == "grove" and charge > 0.05:
            used = min(charge, 0.055)
            deltas["curiosity"] = deltas.get("curiosity", 0.0) - used * 0.22
            self.cell_charge[cell] = max(0.0, charge - used)
        elif terrain == "spring" and charge > 0.05:
            used = min(charge, 0.070)
            deltas["hydration"] = deltas.get("hydration", 0.0) + used * 0.16
            self.cell_charge[cell] = max(0.0, charge - used)
        elif terrain == "shelter" and charge > 0.05:
            used = min(charge, 0.065)
            deltas["fatigue"] = deltas.get("fatigue", 0.0) - used * 0.15
            deltas["integrity"] = deltas.get("integrity", 0.0) + used * 0.04
            self.cell_charge[cell] = max(0.0, charge - used)
        elif terrain == "meadow" and charge > 0.05:
            used = min(charge, 0.025)
            deltas["curiosity"] = deltas.get("curiosity", 0.0) + used * 0.05
            self.cell_charge[cell] = max(0.0, charge - used)

        if visits > 4:
            pressure = min(0.035, (visits - 4) * 0.003)
            deltas["fatigue"] = deltas.get("fatigue", 0.0) + pressure
            deltas["uncertainty"] = deltas.get("uncertainty", 0.0) + pressure * 0.7
        if charge <= 0.03 and terrain in {"spring", "shelter", "grove"}:
            deltas["uncertainty"] = deltas.get("uncertainty", 0.0) + 0.012
        if any(self.distance_to(obj.object_id) <= 1 and obj.affordance == "hazard" for obj in self.objects.values()):
            deltas["uncertainty"] = deltas.get("uncertainty", 0.0) + 0.006
        return Outcome(outcome.kind, deltas, outcome.target_id, outcome.message)

    def _move_toward(self, target_id: str | None) -> Outcome:
        if target_id not in self.objects:
            return Outcome("blocked", {"fatigue": 0.005}, target_id=target_id, message="target missing")
        obj = self.objects[target_id]
        if obj.x > self.agent_x:
            self.agent_x += 1
        elif obj.x < self.agent_x:
            self.agent_x -= 1
        elif obj.y > self.agent_y:
            self.agent_y += 1
        elif obj.y < self.agent_y:
            self.agent_y -= 1
        return Outcome("neutral", {"fatigue": 0.004}, target_id=target_id, message=f"moved through {self.terrain_at(self.agent_x, self.agent_y)}")

    def _inspect(self, target_id: str | None) -> Outcome:
        if target_id not in self.objects:
            return Outcome("blocked", {"uncertainty": 0.02}, target_id=target_id, message="nothing to inspect")
        obj = self.objects[target_id]
        obj.discovered = True
        return Outcome("novelty", {"uncertainty": -0.04, "curiosity": -0.08}, target_id=target_id, message="inspected unknown pattern")

    def _interact(self, action: Action) -> Outcome:
        target_id = action.target_id
        if target_id not in self.objects:
            return Outcome("blocked", {"uncertainty": 0.04}, target_id=target_id, message="missing interaction target")
        obj = self.objects[target_id]
        if self.distance_to(target_id) > 0:
            return self._move_toward(target_id)
        obj.discovered = True
        if obj.quantity <= 0:
            return Outcome("depleted", {"uncertainty": 0.04, "fatigue": 0.006}, target_id=target_id, message="object depleted")
        if obj.affordance == "food":
            obj.quantity -= 1
            self._mark_depleted_if_empty(obj)
            return Outcome("relief", {"energy": 0.20, "fatigue": -0.02}, target_id=target_id, message="gathered energy resource")
        if obj.affordance == "water":
            obj.quantity -= 1
            self._mark_depleted_if_empty(obj)
            return Outcome("relief", {"hydration": 0.24, "fatigue": -0.01}, target_id=target_id, message="gathered hydration resource")
        if obj.affordance == "rest":
            obj.quantity -= 1
            self._mark_depleted_if_empty(obj)
            return Outcome("relief", {"fatigue": -0.22, "integrity": 0.04}, target_id=target_id, message="used finite shelter resource")
        if obj.affordance == "novelty":
            obj.quantity -= 1
            self._mark_depleted_if_empty(obj)
            return Outcome("novelty", {"curiosity": -0.18, "uncertainty": -0.10}, target_id=target_id, message="mapped finite novelty resource")
        if obj.affordance == "symbol":
            obj.quantity -= 1
            self._mark_depleted_if_empty(obj)
            if obj.symbol_token:
                message = f"mapped symbol token {obj.symbol_token} via {obj.teaching_relation or 'association'}"
                delta = {"curiosity": -0.16, "uncertainty": -0.16}
            else:
                message = f"mapped glyph {obj.glyph} with count {obj.count}"
                delta = {"curiosity": -0.14, "uncertainty": -0.12}
            return Outcome("novelty", delta, target_id=target_id, message=message)
        if obj.affordance == "hazard":
            return Outcome("pain", {"integrity": -0.18, "fatigue": 0.03}, target_id=target_id, message="damage from hazard")
        return Outcome("neutral", target_id=target_id, message="ambiguous contact")

    def _mark_depleted_if_empty(self, obj: WorldObject) -> None:
        if obj.quantity <= 0 and obj.depleted_at is None:
            obj.depleted_at = self.tick
            self.depletion_count += 1

    def _record_visit(self) -> None:
        cell = (self.agent_x, self.agent_y)
        self.visit_counts[cell] = self.visit_counts.get(cell, 0) + 1
        self.last_visit_tick[cell] = self.tick

    def _charge_band(self, cell: tuple[int, int]) -> str:
        value = self.cell_charge.get(cell, 0.0)
        if value > 0.66:
            return "high"
        if value > 0.25:
            return "medium"
        if value > 0.04:
            return "low"
        return "empty"

    def _visit_band(self, cell: tuple[int, int]) -> str:
        visits = self.visit_counts.get(cell, 0)
        if visits <= 1:
            return "new"
        if visits <= 4:
            return "known"
        if visits <= 9:
            return "familiar"
        return "overused"

    def target_features(self, target_id: str | None) -> tuple[str, ...]:
        if target_id not in self.objects:
            return ()
        obj = self.objects[target_id]
        return (
            f"vision:color={obj.color}",
            f"vision:shape={obj.shape}",
            f"vision:object={obj.object_id}",
            f"vision:quantity={'depleted' if obj.quantity <= 0 else 'available'}",
            *(() if not obj.glyph else (f"vision:glyph={obj.glyph}", f"vision:count={max(1, obj.count)}")),
            *(() if not obj.symbol_token else (f"vision:symbol_token={obj.symbol_token}",)),
            *(() if not obj.teaching_relation else (f"vision:teaches={obj.teaching_relation}",)),
            *(() if not obj.paired_color else (f"vision:paired_color={obj.paired_color}",)),
            *(() if not obj.paired_shape else (f"vision:paired_shape={obj.paired_shape}",)),
            *(() if not obj.paired_glyph else (f"vision:paired_glyph={obj.paired_glyph}",)),
            *(() if not obj.paired_count else (f"vision:paired_count={max(1, obj.paired_count)}",)),
            f"place:zone={self.zone_for(obj.x, obj.y)}",
            f"place:cell={self.place_key(obj.x, obj.y)}",
            f"terrain:terrain={self.terrain_at(obj.x, obj.y)}",
            f"terrain:charge={self._charge_band((obj.x, obj.y))}",
            f"place:visit={self._visit_band((obj.x, obj.y))}",
        )

    def living_objects(self) -> Iterable[WorldObject]:
        return self.objects.values()

    def foraging_snapshot(self) -> dict[str, object]:
        return {
            "visited_cells": len(self.visit_counts),
            "total_visits": sum(self.visit_counts.values()),
            "available_resources": self.available_resource_count(),
            "available_symbols": sum(1 for obj in self.objects.values() if obj.quantity > 0 and obj.affordance == "symbol"),
            "available_teaching_symbols": sum(1 for obj in self.objects.values() if obj.quantity > 0 and obj.affordance == "symbol" and obj.symbol_token and obj.teaching_relation != "cue"),
            "available_symbol_cues": sum(1 for obj in self.objects.values() if obj.quantity > 0 and obj.affordance == "symbol" and obj.symbol_token and obj.teaching_relation == "cue"),
            "depleted_resources": sum(1 for obj in self.objects.values() if obj.quantity <= 0 and obj.affordance != "hazard"),
            "depletion_count": self.depletion_count,
            "migration_count": self.migration_count,
            "spawn_count": self.spawn_count,
            "current_cell_visits": self.visit_counts.get((self.agent_x, self.agent_y), 0),
            "current_cell_charge": round(self.cell_charge.get((self.agent_x, self.agent_y), 0.0), 3),
        }
