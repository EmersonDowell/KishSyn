"""Developmental regulation for the reflex-first organism.

This is not a mind, mood, or personality module. It is a small state regulator
that watches body pressure and recent prediction error, then biases the same
single loop toward stabilizing, exploring, verifying, or consolidating.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Literal

from .contracts import BodyState, PlasticityEvent, TickTrace
from .memory import TraceMemory
from .neural_graph import NeuralGrowthGraph

DevelopmentMode = Literal["stabilize", "explore", "verify", "consolidate"]


@dataclass(frozen=True)
class LearningFocus:
    """Current developmental bias surface.

    The focus is an action-bias contract, not a command. The organism still
    selects actions through the normal action selector.
    """

    mode: DevelopmentMode
    pressure: float
    recent_error: float
    learning_progress: float
    safety_bias: float
    novelty_bias: float
    comfort_bias: float
    route_bias: float
    replay_bias: float
    reason: str


class DevelopmentalRegulator:
    """Small developmental state machine grounded in loop evidence."""

    def __init__(self, *, history: int = 96) -> None:
        self.error_history: deque[float] = deque(maxlen=history)
        self.mode_history: deque[str] = deque(maxlen=history)
        self.progress_history: deque[float] = deque(maxlen=history)
        self.last_focus = LearningFocus(
            mode="explore",
            pressure=0.0,
            recent_error=0.0,
            learning_progress=0.0,
            safety_bias=0.0,
            novelty_bias=0.18,
            comfort_bias=0.0,
            route_bias=0.0,
            replay_bias=0.0,
            reason="initial exploration",
        )

    def sense(self, *, tick: int, body: BodyState, memory: TraceMemory, graph: NeuralGrowthGraph) -> LearningFocus:
        pressure = self._body_pressure(body)
        recent_error, older_error = self._error_windows(memory)
        learning_progress = max(-1.0, min(1.0, older_error - recent_error))
        traces = len(memory.traces)
        graph_size = len(graph.neurons) + len(graph.synapses)

        if pressure >= 0.62 or body.integrity < 0.46:
            focus = LearningFocus(
                mode="stabilize",
                pressure=pressure,
                recent_error=recent_error,
                learning_progress=learning_progress,
                safety_bias=0.32,
                novelty_bias=-0.14,
                comfort_bias=0.24,
                route_bias=0.18,
                replay_bias=0.08,
                reason="body pressure high; stabilize before novelty",
            )
        elif traces >= 12 and recent_error > 0.58:
            focus = LearningFocus(
                mode="verify",
                pressure=pressure,
                recent_error=recent_error,
                learning_progress=learning_progress,
                safety_bias=0.10,
                novelty_bias=0.06,
                comfort_bias=0.04,
                route_bias=0.12,
                replay_bias=0.18,
                reason="prediction mismatch high; verify uncertain associations",
            )
        elif traces >= 24 and tick % 17 == 0 and recent_error < 0.36:
            focus = LearningFocus(
                mode="consolidate",
                pressure=pressure,
                recent_error=recent_error,
                learning_progress=learning_progress,
                safety_bias=0.12,
                novelty_bias=-0.08,
                comfort_bias=0.18,
                route_bias=0.10,
                replay_bias=0.30,
                reason="stable enough to consolidate recent learning",
            )
        else:
            novelty_bias = 0.22 if graph_size < 80 else 0.14
            focus = LearningFocus(
                mode="explore",
                pressure=pressure,
                recent_error=recent_error,
                learning_progress=learning_progress,
                safety_bias=0.04,
                novelty_bias=novelty_bias,
                comfort_bias=0.02,
                route_bias=0.04,
                replay_bias=0.02,
                reason="pressure manageable; seek learnable novelty",
            )
        self.last_focus = focus
        self.mode_history.append(focus.mode)
        self.progress_history.append(focus.learning_progress)
        return focus

    def record(self, *, tick: int, graph: NeuralGrowthGraph, trace: TickTrace, focus: LearningFocus) -> tuple[PlasticityEvent, ...]:
        """Make developmental state visible and plastic in the neural graph."""

        self.error_history.append(trace.prediction_error)
        mode_node = f"development:mode={focus.mode}"
        pressure_node = f"development:pressure={self._bucket(focus.pressure)}"
        progress_node = f"development:progress={self._progress_bucket(focus.learning_progress)}"
        action_node = f"action:{trace.action.kind}"
        outcome_node = f"outcome:{trace.outcome.kind}"
        need_node = f"need:{trace.body_before.dominant_need()}"
        for node_id, kind, label in (
            (mode_node, "development", focus.mode),
            (pressure_node, "development", f"pressure {self._bucket(focus.pressure)}"),
            (progress_node, "development", f"progress {self._progress_bucket(focus.learning_progress)}"),
        ):
            graph.ensure_neuron(node_id, kind=kind, label=label, tick=tick)
            graph.activate(node_id, amount=0.72, tick=tick)
        events = [
            graph.reinforce(pressure_node, mode_node, amount=0.018 + focus.pressure * 0.018, tick=tick, reason="developmental pressure selected focus"),
            graph.reinforce(mode_node, action_node, amount=0.020 if trace.outcome.kind != "pain" else -0.012, tick=tick, reason="developmental focus biased action"),
            graph.reinforce(mode_node, outcome_node, amount=0.018 if trace.outcome.kind in {"relief", "novelty"} else -0.010 if trace.outcome.kind == "pain" else 0.004, tick=tick, reason="developmental focus outcome evidence"),
            graph.reinforce(need_node, mode_node, amount=0.012, tick=tick, reason="need recruited developmental focus"),
            graph.reinforce(progress_node, mode_node, amount=0.012 + max(0.0, focus.learning_progress) * 0.016, tick=tick, reason="learning progress shaped focus"),
        ]
        return tuple(events)

    def should_replay_now(self, *, tick: int, focus: LearningFocus) -> bool:
        if focus.mode == "consolidate":
            return tick > 0 and tick % 4 == 0
        if focus.mode == "verify":
            return tick > 0 and tick % 6 == 0
        return False

    def snapshot(self) -> dict[str, object]:
        focus = self.last_focus
        counts = {mode: list(self.mode_history).count(mode) for mode in ("stabilize", "explore", "verify", "consolidate")}
        return {
            "mode": focus.mode,
            "reason": focus.reason,
            "pressure": round(focus.pressure, 4),
            "recent_error": round(focus.recent_error, 4),
            "learning_progress": round(focus.learning_progress, 4),
            "biases": {
                "safety": round(focus.safety_bias, 4),
                "novelty": round(focus.novelty_bias, 4),
                "comfort": round(focus.comfort_bias, 4),
                "route": round(focus.route_bias, 4),
                "replay": round(focus.replay_bias, 4),
            },
            "mode_counts": counts,
            "progress_samples": [round(value, 4) for value in list(self.progress_history)[-12:]],
        }

    def _body_pressure(self, body: BodyState) -> float:
        needs = body.needs()
        survival_pressure = max(needs["energy"], needs["hydration"], needs["integrity"], needs["fatigue"])
        cognitive_pressure = max(needs["uncertainty"] * 0.75, needs["curiosity"] * 0.45)
        return round(max(survival_pressure, cognitive_pressure), 4)

    def _error_windows(self, memory: TraceMemory) -> tuple[float, float]:
        traces = list(memory.traces)
        if not traces:
            return 0.0, 0.0
        recent = traces[-8:]
        older = traces[-24:-8] or recent
        recent_error = sum(trace.prediction_error for trace in recent) / len(recent)
        older_error = sum(trace.prediction_error for trace in older) / len(older)
        return round(recent_error, 4), round(older_error, 4)

    def _bucket(self, value: float) -> str:
        if value >= 0.72:
            return "high"
        if value >= 0.42:
            return "medium"
        return "low"

    def _progress_bucket(self, value: float) -> str:
        if value > 0.08:
            return "improving"
        if value < -0.08:
            return "worsening"
        return "flat"
