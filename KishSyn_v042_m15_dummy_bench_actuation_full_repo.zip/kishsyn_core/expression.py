"""Grounded expression motor surface for KishSyn Core.

Expression is a motor channel, not a chatbot mask. It may emit compact console
utterances only from current organism state, graph evidence, and recent sensory
pressure. Later speech/audio output can use the same surface.
"""

from __future__ import annotations

from collections import deque
from dataclasses import asdict, dataclass
from typing import Any

from .contracts import Action, BodyState, Outcome, PlasticityEvent, Prediction
from .focus import FocusReport
from .neural_graph import NeuralGrowthGraph


@dataclass(frozen=True)
class ExpressionAct:
    tick: int
    channel: str
    text: str
    reason: str
    evidence: tuple[str, ...]

    def as_dict(self) -> dict[str, object]:
        return {
            "tick": self.tick,
            "channel": self.channel,
            "text": self.text,
            "reason": self.reason,
            "evidence": list(self.evidence),
        }


class ExpressionSurface:
    """Produces bounded graph-grounded motor expression.

    Pattern: Command + Adapter + Memento. Expression commands are inspectable,
    stored, and linked back into the graph. They never replace perception,
    planning, or language grounding.
    """

    def __init__(self, *, cadence: int = 12, history_limit: int = 64) -> None:
        self.cadence = max(4, int(cadence))
        self.outputs: deque[ExpressionAct] = deque(maxlen=max(8, int(history_limit)))
        self.output_count = 0
        self.last_reason = "no expression yet"
        self.last_evidence: tuple[str, ...] = ()

    def maybe_express(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph,
        body: BodyState,
        action: Action,
        prediction: Prediction,
        outcome: Outcome,
        prediction_error: float,
        focus_report: FocusReport,
        emotion_bias: object | None = None,
    ) -> tuple[PlasticityEvent, ...]:
        external_attention = any(signal.kind in {"text", "math"} for signal in focus_report.selected_signals)
        bias_expression = float(getattr(emotion_bias, "expression_bias", 0.0) or 0.0)
        should_emit = tick % self.cadence == 0 or prediction_error >= 0.70 or outcome.kind in {"pain", "communication"}
        should_emit = should_emit or (external_attention and tick % max(4, self.cadence // 2) == 0)
        should_emit = should_emit or (bias_expression >= 0.18 and tick % max(4, self.cadence // 3) == 0)
        if not should_emit:
            return ()
        need = body.dominant_need()
        concept = self._top_active_concept(graph)
        focus_token = focus_report.selected_signals[0].token if focus_report.selected_signals else "focus:none"
        words = [f"need:{need}", f"act:{action.kind}", f"out:{outcome.kind}"]
        bias_mode = str(getattr(emotion_bias, "mode", "") or "")
        if bias_mode and bias_expression >= 0.12:
            words.append(f"reg:{bias_mode}")
        if prediction_error >= 0.55:
            words.append("surprise")
        if concept:
            words.append(concept.replace("concept:", "concept:"))
        text = " ".join(words[:6])
        evidence = tuple(item for item in (focus_token, f"prediction:{prediction.expected_outcome}", f"error:{prediction_error:.3f}", f"emotion_bias:{bias_mode}:{bias_expression:.3f}" if bias_mode else "", concept) if item)
        act = ExpressionAct(tick=tick, channel="console", text=text[:220], reason="grounded expression motor", evidence=evidence[:8])
        self.outputs.append(act)
        self.output_count += 1
        self.last_reason = act.reason
        self.last_evidence = act.evidence
        return self._bind_expression(tick=tick, graph=graph, act=act, need=need, action=action, outcome=outcome)

    def snapshot(self) -> dict[str, object]:
        return {
            "output_count": self.output_count,
            "cadence": self.cadence,
            "last_reason": self.last_reason,
            "last_evidence": list(self.last_evidence),
            "last": self.outputs[-1].as_dict() if self.outputs else None,
            "outputs": [item.as_dict() for item in list(self.outputs)[-8:]],
        }

    def state(self) -> dict[str, object]:
        return {
            "output_count": self.output_count,
            "cadence": self.cadence,
            "last_reason": self.last_reason,
            "last_evidence": list(self.last_evidence),
            "outputs": [item.as_dict() for item in self.outputs],
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "ExpressionSurface":
        surface = cls(cadence=int(data.get("cadence", 12)))
        surface.output_count = int(data.get("output_count", 0))
        surface.last_reason = str(data.get("last_reason", "restored expression"))
        surface.last_evidence = tuple(str(v) for v in data.get("last_evidence", []))
        for item in data.get("outputs", [])[-surface.outputs.maxlen :]:
            if isinstance(item, dict):
                surface.outputs.append(_act_from_dict(item))
        return surface

    def _bind_expression(self, *, tick: int, graph: NeuralGrowthGraph, act: ExpressionAct, need: str, action: Action, outcome: Outcome) -> tuple[PlasticityEvent, ...]:
        events: list[PlasticityEvent] = []
        channel_node = f"expression:channel={act.channel}"
        phrase_node = f"expression:phrase={_slug(act.text)}"
        need_node = f"need:{need}"
        action_node = f"action:{action.kind}"
        outcome_node = f"outcome:{outcome.kind}"
        for node, kind, label in (
            (channel_node, "expression", f"channel={act.channel}"),
            (phrase_node, "expression", act.text),
            (need_node, "need", need),
            (action_node, "action", action.kind),
            (outcome_node, "outcome", outcome.kind),
        ):
            graph.ensure_neuron(node, kind=kind, label=label, tick=tick)
            graph.activate(node, amount=0.62 if kind == "expression" else 0.50, tick=tick)
        events.append(graph.reinforce(need_node, phrase_node, amount=0.026, tick=tick, reason="expression grounded in need pressure"))
        events.append(graph.reinforce(action_node, phrase_node, amount=0.020, tick=tick, reason="expression grounded in action"))
        events.append(graph.reinforce(outcome_node, phrase_node, amount=0.024, tick=tick, reason="expression grounded in outcome"))
        events.append(graph.reinforce(phrase_node, channel_node, amount=0.035, tick=tick, reason="expression emitted on console channel"))
        return tuple(events)

    def _top_active_concept(self, graph: NeuralGrowthGraph) -> str:
        concepts = [node for node in graph.neurons.values() if node.kind == "concept" and node.activation > 0.05]
        if not concepts:
            return ""
        concepts.sort(key=lambda node: (-node.activation, -node.last_active, node.node_id))
        return concepts[0].node_id


def _slug(text: str) -> str:
    return "_".join(piece for piece in text.lower().replace(":", "_").split() if piece)[:80] or "blank"


def _act_from_dict(data: dict[str, Any]) -> ExpressionAct:
    return ExpressionAct(
        tick=int(data.get("tick", 0)),
        channel=str(data.get("channel", "console")),
        text=str(data.get("text", "")),
        reason=str(data.get("reason", "restored")),
        evidence=tuple(str(v) for v in data.get("evidence", [])),
    )
