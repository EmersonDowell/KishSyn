"""Causal evidence scoring for the living KishSyn core.

This module is not a consciousness detector. It is a small scorecard that asks
whether the organism is producing measurable, ablation-sensitive adaptive
organization from the single living loop.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from statistics import mean
from typing import Any, Literal

from .benchmark import BenchmarkPlaygroundSuite
from .atlas_inspector import NeuralAtlasInspector
from .loop import OrganismLoop

EvidenceStatus = Literal["pass", "watch", "fail"]


@dataclass(frozen=True)
class EvidenceCriterion:
    """One measurable organism capability.

    Pattern: Specification. Each criterion keeps its own threshold and observed
    value so the report remains auditable instead of becoming a vague composite
    intelligence score.
    """

    name: str
    observed: float
    pass_at: float
    watch_at: float
    status: EvidenceStatus
    reason: str


@dataclass(frozen=True)
class IntelligenceEvidenceReport:
    """Bounded report for emergent-intelligence evidence.

    The verdict is deliberately conservative. A pass means the current run shows
    primitive evidence worth studying, not consciousness, sentience, or AGI.
    """

    seed: int
    steps: int
    verdict: str
    summary_score: float
    consciousness_claimed: bool
    criteria: tuple[EvidenceCriterion, ...]
    metrics: dict[str, float]
    benchmarks: dict[str, Any]

    def as_dict(self) -> dict[str, Any]:
        return {
            "seed": self.seed,
            "steps": self.steps,
            "verdict": self.verdict,
            "summary_score": self.summary_score,
            "consciousness_claimed": self.consciousness_claimed,
            "criteria": [asdict(item) for item in self.criteria],
            "metrics": dict(self.metrics),
            "benchmarks": dict(self.benchmarks),
        }


class IntelligenceEvidenceEvaluator:
    """Runs a deterministic evidence pass over the single organism loop.

    Pattern: Facade + Composite Scorecard. This class coordinates the existing
    loop, graph, symbol ablation, memory ablation, motor, body, route, tutor,
    and persistence-facing metrics without adding a second mind stack.
    """

    def evaluate(self, *, seed: int = 337, steps: int = 420, ablation_steps: int = 72, benchmark_seeds: tuple[int, ...] | None = None) -> IntelligenceEvidenceReport:
        loop = OrganismLoop(seed=seed)
        loop.run(steps=steps)
        snapshot = loop.snapshot().__dict__
        score = snapshot["score"]
        symbol_choice = snapshot["symbol_choice"]
        symbol_goal = snapshot["symbol_goal"]
        motor = snapshot["motor_experiment"]
        body_map = snapshot["body_map"]
        self_model = snapshot["self_model"]
        memory = snapshot["memory"]
        world = snapshot["world"]
        graph = snapshot["graph"]
        focus = snapshot["focus"]
        moments = snapshot["moments"]
        binding = snapshot["binding"]
        anatomy = snapshot["anatomy"]
        intent = snapshot["intent"]
        planning = snapshot["planning"]
        sensory = snapshot["sensory"]
        expression = snapshot["expression"]
        atlas = snapshot["atlas"]
        emotion = snapshot["emotion"]

        # Give M4 a small deterministic sensory challenge during the evidence run.
        # It enters through the same adapter contract, then the loop continues.
        m4_probe = OrganismLoop(seed=seed)
        m4_probe.sensory_hub.receive_console(tick=m4_probe.tick, text="red round ?", source="evidence_console")
        m4_probe.sensory_hub.receive_math(tick=m4_probe.tick, expression="2+2=4", source="evidence_math")
        m4_probe.sensory_hub.receive_screen_probe(tick=m4_probe.tick, description="screen red circle near cursor", source="evidence_screen")
        m4_probe.run(steps=40)
        m4_snapshot = m4_probe.snapshot().__dict__
        m4_sensory = m4_snapshot["sensory"]
        m4_expression = m4_snapshot["expression"]
        m4_atlas = m4_snapshot["atlas"]

        m5_probe = OrganismLoop(seed=seed)
        m5_probe.sensory_hub.receive_console(tick=m5_probe.tick, text="red round ?", source="evidence_console")
        m5_probe.sensory_hub.receive_math(tick=m5_probe.tick, expression="2+2=4", source="evidence_math")
        m5_probe.sensory_hub.receive_screen_probe(tick=m5_probe.tick, description="screen red circle near cursor", source="evidence_screen")
        m5_probe.run(steps=54)
        m5_snapshot = m5_probe.snapshot().__dict__
        m5_atlas = m5_snapshot["atlas"]
        m5_index = m5_snapshot["atlas_inspector"]
        m5_nodes = m5_snapshot["graph"].get("nodes", [])
        m5_edges = m5_snapshot["graph"].get("edges", [])
        inspector = NeuralAtlasInspector()
        m5_node_found = 0.0
        m5_synapse_found = 0.0
        m5_node_connections = 0.0
        m5_synapse_connections = 0.0
        m5_inspection_plasticity = 0.0
        if m5_nodes and m5_edges:
            node = sorted(m5_nodes, key=lambda item: (-float(item.get("activation", 0.0)), -float(item.get("last_active", 0.0))))[0]
            edge = sorted(m5_edges, key=lambda item: (-float(item.get("last_updated", 0.0)), -abs(float(item.get("weight", 0.0)))))[0]
            node_info = inspector.inspect_node(graph=m5_probe.graph, node_id=str(node["id"]), tick=m5_probe.tick, last_trace=m5_probe.last_trace).as_dict()
            syn_info = inspector.inspect_synapse(graph=m5_probe.graph, source=str(edge["source"]), target=str(edge["target"]), tick=m5_probe.tick, last_trace=m5_probe.last_trace).as_dict()
            m5_node_found = 1.0 if node_info.get("found") else 0.0
            m5_synapse_found = 1.0 if syn_info.get("found") else 0.0
            m5_node_connections = float(len(node_info.get("top_inbound", [])) + len(node_info.get("top_outbound", [])))
            m5_synapse_connections = float(len(syn_info.get("connected_nodes", [])))
            m5_inspection_plasticity = float(len(m5_atlas.get("recent_plasticity", [])) + len(node_info.get("recent_plasticity", [])) + len(syn_info.get("recent_plasticity", [])))

        ablated_survival = loop.ablated_memory_score(steps=ablation_steps, seed=seed)
        survival_delta = abs(loop.survival_score() - ablated_survival)
        suite_seeds = benchmark_seeds if benchmark_seeds is not None else (seed,)
        benchmark_report = BenchmarkPlaygroundSuite().evaluate(seeds=suite_seeds, steps=max(160, min(steps, 220)))
        motor_controllability = max((float(channel.get("controllability", 0.0)) for channel in motor.get("channels", [])), default=0.0)
        body_binding_strength = max((float(binding.get("strength", 0.0)) for binding in body_map.get("bindings", [])), default=0.0)
        foraging = world.get("foraging", {})
        depletion_events = float(foraging.get("depletion_count", foraging.get("depleted_resources", 0.0)))
        useful_activity = float(foraging.get("visited_cells", 0.0)) + depletion_events * 2.0
        replay_count = float(len(memory.get("replays", [])))

        metrics = {
            "survival": float(score["survival"]),
            "growth": float(score["growth"]),
            "node_count": float(graph["node_count"]),
            "edge_count": float(graph["edge_count"]),
            "trace_count": float(memory["trace_count"]),
            "replay_count": replay_count,
            "visited_cells": float(foraging.get("visited_cells", 0.0)),
            "depleted_resources": float(foraging.get("depleted_resources", 0.0)),
            "depletion_events": depletion_events,
            "useful_activity": useful_activity,
            "comfort_basins": float(score["comfort_basins"]),
            "route_steps": float(score["route_steps"]),
            "mean_self_causation": float(self_model.get("mean_self_causation", 0.0)),
            "motor_probes": float(score["motor_probes"]),
            "motor_controllability": motor_controllability,
            "body_binding_strength": body_binding_strength,
            "concept_count": float(score["concept_count"]),
            "symbol_count": float(score["symbol_count"]),
            "symbol_binding_updates": float(score["symbol_binding_updates"]),
            "symbol_choice_accuracy": float(symbol_choice.get("accuracy", 0.0)),
            "symbol_choice_ablation_delta": float(symbol_choice.get("ablation_delta", 0.0)),
            "symbol_choice_passed": float(symbol_choice.get("passed_count", 0.0)),
            "symbol_goal_activations": float(symbol_goal.get("activation_count", 0.0)),
            "symbol_goal_guided_attempts": float(symbol_goal.get("guided_attempts", 0.0)),
            "text_inputs": float(score["text_inputs"]),
            "text_outputs": float(score["text_outputs"]),
            "tutor_lessons": float(score["tutor_lessons"]),
            "autopilot_lessons": float(score["autopilot_lessons"]),
            "memory_ablation_survival_delta": round(survival_delta, 4),
            "benchmark_summary_score": float(benchmark_report.summary_score),
            "benchmark_passed_tasks": float(sum(1 for task in benchmark_report.tasks if task.status == "pass")),
            "benchmark_watch_tasks": float(sum(1 for task in benchmark_report.tasks if task.status == "watch")),
            "benchmark_failed_tasks": float(sum(1 for task in benchmark_report.tasks if task.status == "fail")),
            "focus_selectivity": float(focus.get("mean_selectivity", 0.0)),
            "moment_count": float(moments.get("count", 0.0)),
            "stable_bindings": float(binding.get("stable_count", 0.0)),
            "binding_candidates": float(binding.get("candidate_count", 0.0)),
            "circuit_count": float(anatomy.get("circuit_count", 0.0)),
            "circuit_promotions": float(anatomy.get("promotion_count", 0.0)),
            "cross_modal_bindings": float(binding.get("stable_cross_modal_count", 0.0)),
            "best_modality_span": float(binding.get("best_modality_span", 0.0)),
            "intent_continuity": float(intent.get("continuity_ratio", 0.0)),
            "intent_completed": float(intent.get("completed_count", 0.0)),
            "intent_terminal": float(intent.get("terminal_count", 0.0)),
            "planning_report_count": float(planning.get("report_count", 0.0)),
            "planning_mean_options": float(planning.get("mean_options", 0.0)),
            "planning_alignment": float(planning.get("alignment_ratio", 0.0)),
            "planning_predicted_risks": float(planning.get("predicted_risk_count", 0.0)),
            "planning_switches": float(planning.get("plan_switches", 0.0)),
            "sensory_packets": float(sensory.get("packet_count", 0.0)),
            "sensory_features": float(sensory.get("feature_count", 0.0)),
            "expression_outputs": float(expression.get("output_count", 0.0)),
            "atlas_surface_count": float(len(atlas.get("surface_counts", {}) if isinstance(atlas, dict) else {})),
            "m4_sensory_packets": float(m4_sensory.get("packet_count", 0.0)),
            "m4_sensory_features": float(m4_sensory.get("feature_count", 0.0)),
            "m4_expression_outputs": float(m4_expression.get("output_count", 0.0)),
            "m4_atlas_surface_count": float(len(m4_atlas.get("surface_counts", {}) if isinstance(m4_atlas, dict) else {})),
            "m5_atlas_surface_count": float(len(m5_atlas.get("surface_counts", {}) if isinstance(m5_atlas, dict) else {})),
            "m5_inspectable_nodes": float(m5_index.get("node_count", 0.0) if isinstance(m5_index, dict) else 0.0),
            "m5_inspectable_synapses": float(m5_index.get("edge_count", 0.0) if isinstance(m5_index, dict) else 0.0),
            "m5_node_found": m5_node_found,
            "m5_synapse_found": m5_synapse_found,
            "m5_node_connections": m5_node_connections,
            "m5_synapse_connections": m5_synapse_connections,
            "m5_inspection_plasticity": m5_inspection_plasticity,
            "emotion_samples": float(emotion.get("sample_count", 0.0)),
            "emotion_trait_count": float(emotion.get("trait_count", 0.0)),
            "emotion_trait_mass": float(emotion.get("trait_mass", 0.0)),
            "emotion_distinct_modes": float(emotion.get("distinct_modes", 0.0)),
            "emotion_graph_events": float(emotion.get("graph_event_count", 0.0)),
            "emotion_mean_control": float(emotion.get("mean_control", 0.0)),
            "emotion_stability": float(emotion.get("emotional_stability", 0.0)),
        }
        for task in benchmark_report.tasks:
            metrics[f"benchmark_{task.name.replace(' ', '_').replace('-', '_')}"] = float(task.observed)

        criteria = (
            self._criterion("body continuity", metrics["survival"], pass_at=0.55, watch_at=0.45, reason="organism remains viable long enough to learn"),
            self._criterion("trace and replay", metrics["trace_count"] + replay_count * 6.0, pass_at=max(96.0, steps * 0.7), watch_at=max(48.0, steps * 0.35), reason="experience is retained and replayed, not discarded"),
            self._criterion("graph growth", metrics["node_count"] + metrics["edge_count"], pass_at=120.0, watch_at=64.0, reason="plastic substrate grows structured nodes and synapses"),
            self._criterion("foraging adaptation", metrics["useful_activity"], pass_at=96.0, watch_at=42.0, reason="agent explores, accumulates depletion traces, and avoids pure camping"),
            self._criterion("self-causation boundary", metrics["mean_self_causation"], pass_at=0.45, watch_at=0.25, reason="efference/outcome loop separates own action from world drift"),
            self._criterion("motor controllability", metrics["motor_controllability"] + metrics["body_binding_strength"], pass_at=0.75, watch_at=0.35, reason="motor channels gain controllability and proto-body binding"),
            self._criterion("concept compression", metrics["concept_count"], pass_at=18.0, watch_at=8.0, reason="recurring sensory regularities compress into concept hubs"),
            self._criterion("focused moment substrate", metrics["focus_selectivity"] + metrics["moment_count"] * 0.004 + metrics["stable_bindings"] * 0.035 + metrics["circuit_count"] * 0.020, pass_at=0.82, watch_at=0.42, reason="raw sensory flow is selected into moments that stabilize bindings and provisional circuits"),
            self._criterion("cross-modal binding", metrics["cross_modal_bindings"] * 0.035 + metrics["best_modality_span"] * 0.08, pass_at=0.90, watch_at=0.42, reason="focused moments bind multiple signal kinds into stable event assemblies"),
            self._criterion("intent persistence", metrics["intent_continuity"] + metrics["intent_completed"] * 0.08, pass_at=0.70, watch_at=0.35, reason="selected targets persist across moments and resolve through action consequence"),
            self._criterion("counterfactual replay proto-planning", metrics["planning_report_count"] * 0.004 + metrics["planning_mean_options"] * 0.08 + metrics["planning_alignment"] * 0.30 + min(0.30, metrics["planning_predicted_risks"] * 0.01), pass_at=1.02, watch_at=0.48, reason="candidate actions are rehearsed as imagined consequences before commitment"),
            self._criterion("sensory adapter expression surface", metrics["m4_sensory_packets"] * 0.16 + metrics["m4_sensory_features"] * 0.012 + metrics["m4_expression_outputs"] * 0.18 + metrics["m4_atlas_surface_count"] * 0.04, pass_at=0.86, watch_at=0.42, reason="console/math/screen packets enter the same focused loop and produce graph-grounded expression/atlas activity"),
            self._criterion("neural atlas inspection", metrics["m5_node_found"] * 0.35 + metrics["m5_synapse_found"] * 0.35 + metrics["m5_atlas_surface_count"] * 0.035 + metrics["m5_node_connections"] * 0.04 + metrics["m5_synapse_connections"] * 0.08 + metrics["m5_inspection_plasticity"] * 0.035, pass_at=1.16, watch_at=0.55, reason="clickable atlas inspection exposes node/synapse provenance, surface coverage, and recent plasticity"),
            self._criterion("emotional regulation field", metrics["emotion_samples"] * 0.003 + metrics["emotion_trait_count"] * 0.08 + metrics["emotion_trait_mass"] * 0.30 + metrics["emotion_distinct_modes"] * 0.07 + metrics["emotion_graph_events"] * 0.001 + metrics["emotion_mean_control"] * 0.12, pass_at=0.96, watch_at=0.45, reason="body pressure, outcome, prediction error, controllability, and safety stabilize graph-visible regulation weather"),
            self._criterion("symbol ablation", metrics["symbol_choice_ablation_delta"] + metrics["symbol_choice_passed"] * 0.02, pass_at=0.08, watch_at=0.02, reason="learned symbols change choice scores and weaken under ablation"),
            self._criterion("goal pressure", metrics["symbol_goal_activations"] + metrics["symbol_goal_guided_attempts"] * 0.4, pass_at=12.0, watch_at=4.0, reason="symbolic pressure persists as bias, not command"),
            self._criterion("bounded teaching surface", metrics["tutor_lessons"] + metrics["autopilot_lessons"] + metrics["text_outputs"], pass_at=4.0, watch_at=1.0, reason="lessons enter through replayable text/tutor pressure"),
            self._criterion("ablation sensitivity", metrics["memory_ablation_survival_delta"] + metrics["symbol_choice_ablation_delta"], pass_at=0.04, watch_at=0.01, reason="removing learned structure measurably changes behavior or scores"),
            self._criterion("benchmark playground suite", metrics["benchmark_summary_score"], pass_at=0.72, watch_at=0.50, reason="controlled tasks pressure-test generalization, persistence, change sensitivity, and foraging"),
        )
        summary_score = round(mean(1.0 if c.status == "pass" else 0.5 if c.status == "watch" else 0.0 for c in criteria), 4)
        fail_count = sum(1 for c in criteria if c.status == "fail")
        watch_count = sum(1 for c in criteria if c.status == "watch")
        if fail_count == 0 and summary_score >= 0.82:
            verdict = "primitive adaptive intelligence evidence"
        elif fail_count <= 2 and summary_score >= 0.55:
            verdict = "promising but incomplete emergence evidence"
        else:
            verdict = "insufficient emergence evidence"
        if watch_count >= 4 and verdict == "primitive adaptive intelligence evidence":
            verdict = "promising but incomplete emergence evidence"
        return IntelligenceEvidenceReport(
            seed=seed,
            steps=steps,
            verdict=verdict,
            summary_score=summary_score,
            consciousness_claimed=False,
            criteria=criteria,
            metrics=metrics,
            benchmarks=benchmark_report.as_dict(),
        )

    def _criterion(self, name: str, observed: float, *, pass_at: float, watch_at: float, reason: str) -> EvidenceCriterion:
        if observed >= pass_at:
            status: EvidenceStatus = "pass"
        elif observed >= watch_at:
            status = "watch"
        else:
            status = "fail"
        return EvidenceCriterion(
            name=name,
            observed=round(observed, 4),
            pass_at=round(pass_at, 4),
            watch_at=round(watch_at, 4),
            status=status,
            reason=reason,
        )
