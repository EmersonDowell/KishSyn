"""Proto body-binding map.

This is not a hardcoded body schema. It learns which motor signals appear to be
self-caused by comparing efference copies, consequences, and body-state change.
"""

from __future__ import annotations

from dataclasses import dataclass

from .contracts import Action, BodyState, Outcome, PlasticityEvent
from .neural_graph import NeuralGrowthGraph


@dataclass
class MotorBinding:
    channel: str
    self_confidence: float = 0.0
    body_effect: float = 0.0
    sensory_effect: float = 0.0
    reliability: float = 0.0
    updates: int = 0
    last_tick: int = 0

    @property
    def binding_strength(self) -> float:
        return max(
            0.0,
            min(
                1.0,
                self.self_confidence * 0.42
                + self.body_effect * 0.22
                + self.sensory_effect * 0.18
                + self.reliability * 0.18,
            ),
        )


class ProtoBodyMap:
    """Learns motor-channel ownership from self-caused effects."""

    def __init__(self) -> None:
        self.bindings: dict[str, MotorBinding] = {}
        self.history: list[dict[str, object]] = []

    def record(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph,
        action: Action,
        body_before: BodyState,
        body_after: BodyState,
        from_place: str,
        to_place: str,
        outcome: Outcome,
        prediction_error: float,
        self_causation: float,
    ) -> tuple[PlasticityEvent, ...]:
        channel = f"motor:{action.kind}"
        binding = self.bindings.get(channel)
        if binding is None:
            binding = MotorBinding(channel=channel)
            self.bindings[channel] = binding
        binding.updates += 1
        binding.last_tick = tick

        body_delta = self._body_delta_magnitude(body_before, body_after)
        sensory_delta = 1.0 if from_place != to_place or outcome.target_id is not None else 0.0
        reliability = max(0.0, min(1.0, 1.0 - prediction_error))

        binding.self_confidence = self._ema(binding.self_confidence, self_causation, 0.12)
        binding.body_effect = self._ema(binding.body_effect, min(1.0, body_delta * 5.0), 0.10)
        binding.sensory_effect = self._ema(binding.sensory_effect, sensory_delta, 0.08)
        binding.reliability = self._ema(binding.reliability, reliability, 0.10)

        self.history.append(
            {
                "tick": tick,
                "channel": channel,
                "action": action.kind,
                "outcome": outcome.kind,
                "strength": round(binding.binding_strength, 4),
                "self": round(binding.self_confidence, 4),
                "body_effect": round(binding.body_effect, 4),
                "sensory_effect": round(binding.sensory_effect, 4),
            }
        )
        self.history = self.history[-48:]

        events: list[PlasticityEvent] = []
        self_node = "self:caused"
        channel_node = channel
        body_node = "self:body_effect"
        sensory_node = "self:sensory_effect"
        outcome_node = f"outcome:{outcome.kind}"
        for node_id, kind, label in (
            (self_node, "self", "self caused"),
            (channel_node, "motor", action.kind),
            (body_node, "self", "body effect"),
            (sensory_node, "self", "sensory effect"),
            (outcome_node, "outcome", outcome.kind),
        ):
            graph.ensure_neuron(node_id, kind=kind, label=label, tick=tick)
        graph.activate(channel_node, amount=max(0.20, binding.binding_strength), tick=tick)
        graph.activate(self_node, amount=self_causation, tick=tick)
        if self_causation > 0.15:
            events.append(graph.reinforce(channel_node, self_node, amount=self_causation * 0.045, tick=tick, reason="proto body ownership"))
        if body_delta > 0.001:
            events.append(graph.reinforce(channel_node, body_node, amount=min(0.045, body_delta * 0.55), tick=tick, reason="motor changed body pressure"))
        if sensory_delta > 0.0:
            events.append(graph.reinforce(channel_node, sensory_node, amount=0.025, tick=tick, reason="motor changed sensory place"))
        if prediction_error < 0.28:
            events.append(graph.reinforce(channel_node, outcome_node, amount=0.018, tick=tick, reason="reliable motor consequence"))
        return tuple(events)

    def confidence(self, action_kind: str) -> float:
        binding = self.bindings.get(f"motor:{action_kind}")
        return 0.0 if binding is None else binding.binding_strength

    def snapshot(self) -> dict[str, object]:
        ranked = sorted(self.bindings.values(), key=lambda item: item.binding_strength, reverse=True)
        return {
            "channel_count": len(self.bindings),
            "bindings": [
                {
                    "channel": binding.channel,
                    "strength": round(binding.binding_strength, 4),
                    "self_confidence": round(binding.self_confidence, 4),
                    "body_effect": round(binding.body_effect, 4),
                    "sensory_effect": round(binding.sensory_effect, 4),
                    "reliability": round(binding.reliability, 4),
                    "updates": binding.updates,
                }
                for binding in ranked
            ],
            "recent": self.history[-10:],
        }

    def _body_delta_magnitude(self, before: BodyState, after: BodyState) -> float:
        return (
            abs(after.energy - before.energy)
            + abs(after.hydration - before.hydration)
            + abs(after.integrity - before.integrity)
            + abs(after.fatigue - before.fatigue)
            + abs(after.curiosity - before.curiosity)
            + abs(after.uncertainty - before.uncertainty)
        ) / 6.0

    def _ema(self, old: float, value: float, rate: float) -> float:
        return max(0.0, min(1.0, old * (1.0 - rate) + value * rate))
