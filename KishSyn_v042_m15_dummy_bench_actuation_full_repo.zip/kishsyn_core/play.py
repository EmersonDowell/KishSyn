"""Intrinsic play and safe-enough experimentation for KishSyn Core.

M11 treats play as developmental experimentation, not random behavior. The drive
may propose bounded, inspectable low-risk probes when survival pressure is stable
enough and uncertainty/curiosity can be reduced through action. It cannot bypass
priority arbitration, external-interface quarantine, or the action selector.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from .contextual_affordance import object_kind_from_features
from .contracts import Action, BodyState, Outcome, PlasticityEvent, Prediction
from .neural_graph import NeuralGrowthGraph
from .world import MiniEcologyWorld


@dataclass(frozen=True)
class PlayIntent:
    """A bounded exploration proposal, never a command.

    Pattern: Contract Object. The action selector may rank this proposal against
    all other candidates, but the proposal cannot force behavior and cannot
    access external adapters.
    """

    active: bool
    action_kind: str = "wait"
    target_id: str | None = None
    score_boost: float = 0.0
    safety_margin: float = 0.0
    novelty_pressure: float = 0.0
    uncertainty_pressure: float = 0.0
    controllability_pressure: float = 0.0
    reason: str = "play inactive"

    def as_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        for key in ("score_boost", "safety_margin", "novelty_pressure", "uncertainty_pressure", "controllability_pressure"):
            payload[key] = round(float(payload[key]), 4)
        return payload


@dataclass(frozen=True)
class PlayRecord:
    """Completed play experiment audit record."""

    tick: int
    target_id: str | None
    action_kind: str
    outcome_kind: str
    prediction_error: float
    learning_delta: float
    safe: bool
    reason: str

    def as_dict(self) -> dict[str, Any]:
        payload = asdict(self)
        payload["prediction_error"] = round(float(payload["prediction_error"]), 4)
        payload["learning_delta"] = round(float(payload["learning_delta"]), 4)
        return payload


@dataclass
class PlayPattern:
    """Reusable developmental experiment pattern.

    Pattern: Flyweight. Repeated playful experiments strengthen this one pattern
    instead of creating tick-specific play nodes.
    """

    pattern_id: str
    action_kind: str
    object_signature: str
    evidence_count: int = 0
    safe_count: int = 0
    unsafe_count: int = 0
    total_learning_delta: float = 0.0
    total_prediction_error: float = 0.0
    last_tick: int = 0
    outcome_counts: dict[str, int] = field(default_factory=dict)

    def observe(self, *, tick: int, record: PlayRecord) -> None:
        self.evidence_count += 1
        self.safe_count += 1 if record.safe else 0
        self.unsafe_count += 0 if record.safe else 1
        self.total_learning_delta += float(record.learning_delta)
        self.total_prediction_error += float(record.prediction_error)
        self.last_tick = int(tick)
        self.outcome_counts[record.outcome_kind] = self.outcome_counts.get(record.outcome_kind, 0) + 1

    @property
    def mean_learning_delta(self) -> float:
        return self.total_learning_delta / max(1, self.evidence_count)

    @property
    def safety_ratio(self) -> float:
        return self.safe_count / max(1, self.evidence_count)

    def as_dict(self) -> dict[str, Any]:
        return {
            "pattern_id": self.pattern_id,
            "action_kind": self.action_kind,
            "object_signature": self.object_signature,
            "evidence_count": self.evidence_count,
            "safe_count": self.safe_count,
            "unsafe_count": self.unsafe_count,
            "safety_ratio": round(float(self.safety_ratio), 4),
            "mean_learning_delta": round(float(self.mean_learning_delta), 4),
            "mean_prediction_error": round(float(self.total_prediction_error / max(1, self.evidence_count)), 4),
            "last_tick": self.last_tick,
            "outcome_counts": dict(sorted(self.outcome_counts.items())),
        }

    def state(self) -> dict[str, Any]:
        return {
            "pattern_id": self.pattern_id,
            "action_kind": self.action_kind,
            "object_signature": self.object_signature,
            "evidence_count": self.evidence_count,
            "safe_count": self.safe_count,
            "unsafe_count": self.unsafe_count,
            "total_learning_delta": self.total_learning_delta,
            "total_prediction_error": self.total_prediction_error,
            "last_tick": self.last_tick,
            "outcome_counts": dict(self.outcome_counts),
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "PlayPattern":
        return cls(
            pattern_id=str(data.get("pattern_id", "unknown")),
            action_kind=str(data.get("action_kind", "inspect")),
            object_signature=str(data.get("object_signature", "object=unknown")),
            evidence_count=int(data.get("evidence_count", 0)),
            safe_count=int(data.get("safe_count", 0)),
            unsafe_count=int(data.get("unsafe_count", 0)),
            total_learning_delta=float(data.get("total_learning_delta", 0.0)),
            total_prediction_error=float(data.get("total_prediction_error", 0.0)),
            last_tick=int(data.get("last_tick", 0)),
            outcome_counts={str(k): int(v) for k, v in dict(data.get("outcome_counts", {})).items()},
        )


class IntrinsicPlayDrive:
    """Safe-enough curiosity-driven experimentation.

    Pattern: Strategy + Repository. The Strategy chooses whether play pressure is
    allowed to propose a bounded experiment. The Repository compresses completed
    play into reusable patterns. The drive does not own motor output.
    """

    def __init__(self, *, capacity: int = 128, history_capacity: int = 96) -> None:
        self.capacity = max(16, int(capacity))
        self.history_capacity = max(16, int(history_capacity))
        self.patterns: dict[str, PlayPattern] = {}
        self.history: list[PlayRecord] = []
        self.proposal_count = 0
        self.accepted_count = 0
        self.record_count = 0
        self.safe_count = 0
        self.unsafe_count = 0
        self.inhibited_count = 0
        self.last_intent: PlayIntent = PlayIntent(active=False)
        self.last_record: PlayRecord | None = None

    def propose(self, *, tick: int, body: BodyState, world: MiniEcologyWorld) -> PlayIntent:
        safety_margin = min(float(body.energy), float(body.hydration), float(body.integrity), 1.0 - float(body.fatigue))
        novelty_pressure = max(0.0, min(1.0, (float(body.curiosity) + float(body.uncertainty)) / 2.0))
        if safety_margin < 0.34:
            self.inhibited_count += 1
            self.last_intent = PlayIntent(active=False, safety_margin=safety_margin, novelty_pressure=novelty_pressure, uncertainty_pressure=body.uncertainty, reason="play inhibited by survival/body pressure")
            return self.last_intent
        if novelty_pressure < 0.28:
            self.inhibited_count += 1
            self.last_intent = PlayIntent(active=False, safety_margin=safety_margin, novelty_pressure=novelty_pressure, uncertainty_pressure=body.uncertainty, reason="play inactive: novelty pressure too low")
            return self.last_intent

        candidate = self._best_safe_object(world=world)
        if candidate is None:
            self.inhibited_count += 1
            self.last_intent = PlayIntent(active=False, safety_margin=safety_margin, novelty_pressure=novelty_pressure, uncertainty_pressure=body.uncertainty, reason="play inhibited: no safe object candidate")
            return self.last_intent

        obj, controllability = candidate
        distance = world.distance_to(obj.object_id)
        action_kind = "move" if distance > 0 else ("inspect" if not obj.discovered else "touch")
        novelty_bonus = 0.10 if not obj.discovered else 0.03
        score = min(0.42, 0.06 + novelty_pressure * 0.20 + controllability * 0.12 + novelty_bonus)
        self.proposal_count += 1
        self.last_intent = PlayIntent(
            active=True,
            action_kind=action_kind,
            target_id=obj.object_id,
            score_boost=score,
            safety_margin=safety_margin,
            novelty_pressure=novelty_pressure,
            uncertainty_pressure=body.uncertainty,
            controllability_pressure=controllability,
            reason=f"safe-enough play probe toward {obj.color}/{obj.shape}",
        )
        return self.last_intent

    def record(
        self,
        *,
        tick: int,
        graph: NeuralGrowthGraph,
        intent: PlayIntent,
        action: Action,
        target_features: tuple[str, ...],
        prediction: Prediction,
        outcome: Outcome,
        prediction_error: float,
    ) -> tuple[PlasticityEvent, ...]:
        if not intent.active or action.target_id != intent.target_id:
            return ()
        self.accepted_count += 1
        safe = outcome.kind != "pain"
        learning_delta = self._learning_delta(prediction=prediction, outcome=outcome, prediction_error=prediction_error)
        record = PlayRecord(
            tick=int(tick),
            target_id=action.target_id,
            action_kind=action.kind,
            outcome_kind=outcome.kind,
            prediction_error=float(prediction_error),
            learning_delta=learning_delta,
            safe=safe,
            reason=intent.reason,
        )
        self.last_record = record
        self.history.append(record)
        self.history = self.history[-self.history_capacity:]
        self.record_count += 1
        self.safe_count += 1 if safe else 0
        self.unsafe_count += 0 if safe else 1

        object_kind = object_kind_from_features(target_features)
        pattern_id = ":".join((_safe(action.kind), _safe(object_kind.signature_id)))
        pattern = self.patterns.get(pattern_id)
        if pattern is None:
            pattern = PlayPattern(pattern_id=pattern_id, action_kind=action.kind, object_signature=object_kind.signature_id)
            self.patterns[pattern_id] = pattern
            self._trim_patterns()
        pattern.observe(tick=tick, record=record)
        return self._write_graph(graph=graph, tick=tick, pattern=pattern, record=record)

    def snapshot(self) -> dict[str, Any]:
        patterns = sorted((pattern.as_dict() for pattern in self.patterns.values()), key=lambda item: (-int(item["evidence_count"]), str(item["pattern_id"])))
        return {
            "proposal_count": self.proposal_count,
            "accepted_count": self.accepted_count,
            "record_count": self.record_count,
            "safe_count": self.safe_count,
            "unsafe_count": self.unsafe_count,
            "inhibited_count": self.inhibited_count,
            "pattern_count": len(self.patterns),
            "last_intent": self.last_intent.as_dict(),
            "last_record": None if self.last_record is None else self.last_record.as_dict(),
            "top_patterns": patterns[:12],
            "recent_records": [record.as_dict() for record in self.history[-12:]],
        }

    def state(self) -> dict[str, Any]:
        return {
            "capacity": self.capacity,
            "history_capacity": self.history_capacity,
            "proposal_count": self.proposal_count,
            "accepted_count": self.accepted_count,
            "record_count": self.record_count,
            "safe_count": self.safe_count,
            "unsafe_count": self.unsafe_count,
            "inhibited_count": self.inhibited_count,
            "last_intent": self.last_intent.as_dict(),
            "last_record": None if self.last_record is None else self.last_record.as_dict(),
            "patterns": [pattern.state() for pattern in self.patterns.values()],
            "history": [record.as_dict() for record in self.history[-self.history_capacity:]],
        }

    @classmethod
    def from_state(cls, data: dict[str, Any]) -> "IntrinsicPlayDrive":
        drive = cls(capacity=int(data.get("capacity", 128)), history_capacity=int(data.get("history_capacity", 96)))
        drive.proposal_count = int(data.get("proposal_count", 0))
        drive.accepted_count = int(data.get("accepted_count", 0))
        drive.record_count = int(data.get("record_count", 0))
        drive.safe_count = int(data.get("safe_count", 0))
        drive.unsafe_count = int(data.get("unsafe_count", 0))
        drive.inhibited_count = int(data.get("inhibited_count", 0))
        drive.last_intent = _intent_from_state(dict(data.get("last_intent", {})))
        drive.last_record = None if data.get("last_record") is None else _record_from_state(dict(data["last_record"]))
        drive.patterns = {str(item.get("pattern_id", "unknown")): PlayPattern.from_state(dict(item)) for item in data.get("patterns", [])}
        drive.history = [_record_from_state(dict(item)) for item in data.get("history", [])][-drive.history_capacity:]
        return drive

    def _best_safe_object(self, *, world: MiniEcologyWorld):
        best = None
        best_score = -999.0
        for obj in world.foraging_candidates(limit=18):
            if obj.quantity <= 0:
                continue
            if obj.affordance == "hazard" or obj.shape in {"spike", "jagged"}:
                continue
            distance = world.distance_to(obj.object_id)
            novelty = 1.0 if not obj.discovered else 0.25
            controllability = max(0.0, 1.0 - distance / 14.0)
            terrain_bonus = 0.10 if world.terrain_at(obj.x, obj.y) in {"meadow", "grove", "spring", "shelter"} else 0.0
            score = novelty * 0.55 + controllability * 0.35 + terrain_bonus - distance * 0.01
            if score > best_score:
                best_score = score
                best = (obj, controllability)
        return best

    def _learning_delta(self, *, prediction: Prediction, outcome: Outcome, prediction_error: float) -> float:
        mismatch = 1.0 if prediction.expected_outcome != outcome.kind else 0.35
        confidence_gap = 1.0 - max(0.0, min(1.0, prediction.confidence))
        return max(0.0, min(1.0, float(prediction_error) * 0.55 + mismatch * 0.25 + confidence_gap * 0.20))

    def _write_graph(self, *, graph: NeuralGrowthGraph, tick: int, pattern: PlayPattern, record: PlayRecord) -> tuple[PlasticityEvent, ...]:
        play_node = f"play_pattern:{pattern.pattern_id}"
        action_node = f"action:{pattern.action_kind}"
        outcome_node = f"outcome:{record.outcome_kind}"
        safety_node = "play:safe" if record.safe else "play:unsafe"
        graph.ensure_neuron(play_node, kind="play_pattern", label=pattern.pattern_id, tick=tick)
        graph.ensure_neuron(action_node, kind="action", label=pattern.action_kind, tick=tick)
        graph.ensure_neuron(outcome_node, kind="outcome", label=record.outcome_kind, tick=tick)
        graph.ensure_neuron(safety_node, kind="play", label="safe" if record.safe else "unsafe", tick=tick)
        graph.activate(play_node, amount=max(0.20, min(1.0, record.learning_delta)), tick=tick)
        amount = 0.010 + min(0.030, record.learning_delta * 0.020)
        safety_amount = 0.018 if record.safe else -0.024
        return (
            graph.reinforce(play_node, action_node, amount=amount, tick=tick, reason="intrinsic play action pattern evidence"),
            graph.reinforce(play_node, outcome_node, amount=amount, tick=tick, reason="intrinsic play outcome evidence"),
            graph.reinforce(play_node, safety_node, amount=safety_amount, tick=tick, reason="intrinsic play safety evidence"),
        )

    def _trim_patterns(self) -> None:
        if len(self.patterns) <= self.capacity:
            return
        ranked = sorted(self.patterns.values(), key=lambda item: (item.safety_ratio, item.mean_learning_delta, item.evidence_count, item.last_tick), reverse=True)
        keep = {item.pattern_id for item in ranked[: self.capacity]}
        self.patterns = {key: value for key, value in self.patterns.items() if key in keep}


def _intent_from_state(data: dict[str, Any]) -> PlayIntent:
    return PlayIntent(
        active=bool(data.get("active", False)),
        action_kind=str(data.get("action_kind", "wait")),
        target_id=data.get("target_id"),
        score_boost=float(data.get("score_boost", 0.0)),
        safety_margin=float(data.get("safety_margin", 0.0)),
        novelty_pressure=float(data.get("novelty_pressure", 0.0)),
        uncertainty_pressure=float(data.get("uncertainty_pressure", 0.0)),
        controllability_pressure=float(data.get("controllability_pressure", 0.0)),
        reason=str(data.get("reason", "restored play intent")),
    )


def _record_from_state(data: dict[str, Any]) -> PlayRecord:
    return PlayRecord(
        tick=int(data.get("tick", 0)),
        target_id=data.get("target_id"),
        action_kind=str(data.get("action_kind", "wait")),
        outcome_kind=str(data.get("outcome_kind", "neutral")),
        prediction_error=float(data.get("prediction_error", 0.0)),
        learning_delta=float(data.get("learning_delta", 0.0)),
        safe=bool(data.get("safe", True)),
        reason=str(data.get("reason", "restored play record")),
    )


def _safe(value: object) -> str:
    text = str(value).strip().lower().replace(" ", "_").replace("/", "_").replace("\\", "_")
    return "".join(ch for ch in text if ch.isalnum() or ch in {"_", "-", ":", "=", "|", "."})[:128] or "unknown"
