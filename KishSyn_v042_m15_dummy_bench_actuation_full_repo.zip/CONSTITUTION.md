# KishSyn Core Constitution

This repo is the clean living line. The v108-style experimental archive may be referenced, but the living core must remain small, reflex-first, and test-gated.

## Prime directive

We do not hardcode a finished mind. We grow lawful conditions where adaptive organization can emerge through sensory input, body pressure, prediction, action, consequence, plasticity, memory, and replay.

## Entry test for every living-core feature

A feature may enter the living core only if it clearly answers:

1. What does it sense?
2. What does it predict?
3. What action can it bias?
4. What plastic change happens after the result?

If it cannot answer those, it belongs outside the living core.

## Scope locks

- One active organism loop.
- One active observatory GUI.
- One active ecology until the base loop is stable.
- Maximum 56 Python files under `kishsyn_core/` unless the constitution is explicitly revised with a matching gate update.
- Maximum 12 markdown files in the repo.
- No fake consciousness, emotion, belief, home, or selfhood engines.
- External AI may tutor, label, or evaluate, but may not be the organism's intelligence.
- Real sensory feeds must enter through replayable sensory-frame quarantine.

## Brain-building order

Reflex before language. Prediction before planning. Efference before motor identity. Place memory before navigation intelligence. Replay before reflection. Global workspace before self-narrative.

## v005 emergent-attractor rule

Do not code `home`. Do not code `body_part`. Do not code `I am alive`. Code lawful pressures and plastic consequences. A place may become home-like only if experience makes it safe, restorative, familiar, and predictable. A motor channel may become body-like only if repeated action creates self-caused sensory/body change.


## v006 developmental regulation rule

Do not code personality or consciousness. Code developmental conditions. A growth mode may bias action only from body pressure, prediction error, learning progress, and stability. Stabilization, exploration, verification, and consolidation are regulatory modes, not emotions or identities.


## v007 motor experimentation rule

Do not pre-label a body map. Motor ownership must emerge from repeated action, efference, prediction, self-causation, sensory change, and body-state consequence. Motor probes may be proposed only when survival pressure is low enough; protection beats curiosity.


## v008 finite foraging rule

Do not create infinite comfort loops. Restorative terrain may reduce pressure only through finite local charge, and gatherable objects must deplete. Regrowth must prefer underexplored regions so the organism is pressured to forage, route-learn, and adapt. Short-lived goal continuity is allowed because biological motor behavior requires persistence long enough to complete an action, but it must decay and may not become a scripted task policy.


## v010 symbol teaching rule

Do not teach symbols through lookup tables. A word, letter, color name, shape name, or number token may enter only as a sensory pattern that becomes linked to grounded concepts through interaction, consequence, plasticity, and replay. Symbol surfaces may scaffold learning, but they may not bypass the loop.


## v011 symbol-guided choice rule

Do not let symbols remain decorative. A learned token may bias action only through graph-grown symbol-to-concept pathways, and that influence must be ablation-sensitive. If removing symbol pathways does not change the cue advantage, the symbol is not yet useful knowledge.

The scope cap is raised from 32 to 48 active Python files because proof modules and CLI probes are now allowed when they directly test causal learning. The cap is still a gate, not a suggestion.


## Symbol goal rule

Symbol goals are working-memory pressures, not commands. A cue token may bias action only through learned symbol/concept pathways grown from embodied traces. Direct parser dictionaries remain forbidden in the living core.


## v013 priority arbitration rule

Symbolic goals are never commands. Any active token pressure must pass through priority arbitration against body pressure, uncertainty, and developmental mode. Under crisis, survival suppresses symbol pursuit; under moderate pressure, the symbol may be deferred and preserved; under stable conditions, it may bias action only through learned symbol/concept pathways.

Metabolic constants are part of the learning substrate. If decay keeps the organism permanently exhausted, the world is invalid because it prevents exploration and consolidation.


## v014 persistence and metabolic substrate rule

A learned brain that resets every launch is not a developmental organism. The neural graph, ecology, body state, route memory, comfort basins, proto-body map, symbol goals, priority state, trace memory, and workspace broadcasts must be saveable and reloadable through explicit JSON state files. Future migration of the state format must be versioned.

Metabolic decay is substrate physics. It must be slow enough to permit exploration, consolidation, and symbol-guided behavior. If the body spends most of its life at zero energy or capped fatigue, the world is invalid because crisis pressure suppresses learning. v014 sets metabolic drift to one-eighth of the v013 rate.


## v015 text crib rule

Text is sensory input before it is language. Typed words, characters, and symbols may enter only as replayable sensory features and may influence action only through learned graph pathways, symbol goals, and priority arbitration. The console may produce primitive graph-derived typed output, but it may not use GPT or any external model as the organism's voice. External AI remains a tutor/evaluator layer only.


## Tutor boundary rule

External tutors may teach. They may not become the organism. A tutor can offer weak, transparent lessons and corrections, but KishSyn must store, test, and use those signals through its own graph, motor loop, memory, and priority system. No API or external model may speak as KishSyn unless a future gate proves the output is graph-grounded and clearly separated from the tutor.


## Autonomous tutor rule

Automation may reduce operator babysitting, but it may not become the organism's mind. A tutor, scripted or external, may only inject replayable sensory/text pressure and weak visible graph hints. It may not select actions directly, rewrite memories secretly, claim consciousness, or generate a persona as KishSyn.


## v018 evidence rule

Do not argue that KishSyn is becoming intelligent from appearance, language, or operator feeling alone. Intelligence claims must be routed through measurable evidence: trace continuity, replay, prediction/error, graph growth, self-causation, controllability, concept compression, symbol ablation, body continuity, adaptive foraging, and ablation sensitivity.

The evidence report is a witness surface, not a new mind module. It may score the organism, but it may not steer actions, rewrite memories, claim consciousness, or become a reward oracle hidden inside the living loop.

## v020 living-line scope policy

All source/doc budget checks must use `kishsyn_core.scope.ProjectScopePolicy`. No test or gate may recursively inventory the entire repository root for governed docs, because old patch archives, generated stores, and cloud placeholder folders are not part of the living organism line.



## v021 Benchmark Pressure Doctrine

KishSyn must not advance by appearance alone. New organism capabilities should be accompanied by controlled benchmark pressure whenever possible. Benchmarks must reuse the living substrate surfaces: sensorium, trace, prediction, consequence, plasticity, persistence, and action selection. They must not introduce a hidden planner, answer table, persona layer, or consciousness claim.

The benchmark playground suite is now part of the governed evidence path. It tests delayed symbol use, changed-object prediction tension, causal action controllability, route-memory reuse, depletion-aware foraging, and save/load symbol recall.


## v025 Milestone Law: Focused Moment Substrate

The active locked milestone is M1: Focused Moment Substrate.

KishSyn must not treat all incoming signal as equal. Raw sensory flow must pass through a focus gate before it becomes the active moment. The active moment must be replayable. Repeated focused moments must be eligible for binding. Stable bindings must be eligible for provisional circuit anatomy.

The lawful developmental chain is:

```text
signal -> focus -> moment -> binding -> circuit -> action bias -> consequence -> memory -> reflection
```

No feature may bypass this chain by adding a hidden planner, hidden language mind, hidden answer table, or fake emotional persona.

Storage rule for M1: explicit JSON state remains the source of truth. Do not restore the older database layer until the M1 contracts are stable and a separate storage milestone is declared.

## v026 M1 Lock Law

M1 cannot be called locked because the code looks plausible. It is locked only by `python -m kishsyn_core.tools.run_milestone_m1_lock` returning success.

The M1 lock criteria are: focus selectivity, MomentFrame retention, binding stability, provisional circuit growth, synapse graph support, live finite-resource interaction, benchmark lock, and focused substrate score.

A benchmark task with `watch` status means the milestone is still a candidate, not a lock. All benchmark tasks must pass for the formal lock.

Foraging pressure must be measured by cumulative lived depletion events plus exploration, not by endpoint currently-depleted resources. Endpoint resource counts can change through migration/regrowth and are not a stable developmental criterion.

Storage remains explicit JSON state and JSONL reports for M1. Do not restore the old database layer until a separate storage milestone declares stable contracts, scale pressure, and migration rules.



## M2 Doctrine: Cross-Modal Binding and Intent Persistence

M2 does not authorize a parallel planner, persona layer, or hidden language mind. It authorizes only governed cross-modal binding and explicit target-intent persistence. An intent is selected pressure over predicted affordances, not a scripted desire. A binding is repeated focused coactivation across modalities, not semantic truth.

The old database layer remains out of scope until a dedicated storage milestone proves that indexed storage is needed by locked anatomy contracts.

## M3 Doctrine: Counterfactual Replay and Proto-Planning

M3 authorizes bounded imagination, not a hidden planner. The organism may rehearse currently available action candidates before committing, but those candidates must originate from the living selector and the rehearsal must use existing contracts: body pressure, graph prediction, target features, distance, risk hints, and lived outcome correction.

A plan is not a command. It is an imagined consequence trace. It may bias action only when its projected value is meaningfully better than the reflex candidate and only through an explicit planning report. The lived outcome must then correct the plan by strengthening or weakening plan/prediction/outcome graph traces.

M3 is locked only by `python -m kishsyn_core.tools.run_milestone_m3_lock` returning success. The lock requires M2 to remain locked, repeated planning reports, multi-option rehearsal, risk imagination, graph plan traces, replay/outcome alignment, preserved intent continuity, and a clean benchmark suite.

## Sensory Adapter Forward Rule

Future screen, image, audio, keyboard, console, math, file, robot, or API feeds must enter as sensory adapters. They may not directly become beliefs, goals, emotions, or language knowledge. Every adapter must emit replayable sensory features that pass through focus, MomentFrame capture, binding, intent, prediction, consequence, graph plasticity, and evidence gates.

External AI services may be used as tutors, labelers, curriculum generators, evaluators, or translation surfaces. They may not be KishSyn's mind or voice unless a later milestone proves the output is grounded in KishSyn's own graph, body state, memory, and intent surfaces.


## M4 Adapter and Atlas Law

Every external sensory or motor surface must enter the organism through a governed adapter or expression surface. No screen, image, audio, math, console, hardware, file, API, tutor, or future robotics pathway may bypass FocusGate, MomentFrame, binding/anatomy growth, graph plasticity, persistence, and NeuralAtlas inspection.

The GUI graph is not decorative. It is the required read-model mirror of the growing associative anatomy. Every surface KishSyn touches must be inspectable as neurons, synapses, activations, or plasticity events.


## M5 Atlas Inspection Law

The neural atlas is a governed read-only witness surface. It may display neurons, synapses, activations, surface provenance, connected pathways, and recent plasticity, but it may not mutate the organism or become a hidden steering layer.

Every future sensory or motor surface must remain inspectable through the atlas contract. If KishSyn touches screen, image, audio, math, console, files, API tutors, or hardware, that activity must eventually be visible as standardized graph nodes, synapses, activations, and plasticity events.

M5 is locked only by `python -m kishsyn_core.tools.run_milestone_m5_lock` returning success.


## M6 Emotional Regulation Law

Emotion is regulation weather, not roleplay. The emotional field may observe body pressure, prediction error, controllability, safety, novelty, fatigue, blocked intent, and consequence. It may create replayable regulation samples, graph-visible emotion modes, and slow trait tendencies.

It may not become a fake personality, hidden reward oracle, direct action commander, or chatbot mood mask. Any future emotional expression must be grounded in the organism's own regulation samples, graph traces, memory, body state, and recent context.

M6 is locked only by `python -m kishsyn_core.tools.run_milestone_m6_lock` returning success.

## M7 Emotion-Bias Law

Emotion may bias attention and expression only through a bounded, inspectable contract derived from prior regulation samples. It may not select actions, invent goals, rewrite memory, or become a personality engine.

FocusGate must expose the emotion contribution as a normal score component. Expression may carry emotion only as grounded evidence from the organism's own regulation surface.

## Memory Economy Law

Durable graph anatomy must represent reusable structure, not every event. Tick-specific plans, object encounters, and sensory moments are audit traces unless retention pressure or repeated usefulness promotes them.

The graph stores reusable anatomy. The ledger stores events. Consolidation decides what becomes structure.

Repeated plan instances must strengthen reusable `plan_template:*` nodes. They must not flood the graph with durable `plan:t...` tick-id nodes.

## Contextual Affordance Forward Law

Concepts are anchors, not universal commands. Object meaning must be resolved through actor, body, world context, action, provenance, and outcome. An apple may heal a game avatar in one world, be decorative in another, be an ingredient in another, and be food-for-others or seed-source in a robot-world context.

Future object cognition must separate object files, categories, affordances, actor profiles, world-rule contexts, and reality provenance before claiming common-sense behavior.

## Patch Gate Law

Every patch must run the relevant gate profile for the surfaces it touched. Full `dev_gates` remains the release-grade spine check, but unchanged expensive historical gates may be skipped for a local patch when their contract surfaces and dependencies were not modified.

Use `python -m kishsyn_core.tools.patch_gates --profile current --run` for the active patch surface and reserve full gates for milestone locks, release candidates, broad architecture changes, or when touched surfaces are uncertain.

## v033 M8 Course Law: Contextual Affordance Cognition

Concepts are anchors, not commands. A concept may not directly imply a universal action. Meaning-in-use must be represented through actor/body, world context, object kind, action, provenance, and lived outcome.

The approved M8 formula is:

```text
concept + actor/body + world context + action + provenance + outcome = meaning-in-use
```

An apple-like object may heal a game avatar in one game, be scenery in another, serve as an ingredient in another, or become food-for-others / seed-source in a robot-body context. These are not contradictions. They are context-bound affordances.

Any future action bias from contextual affordance memory must enter through a governed contract. M8 starts as an observer and memory surface only. It may write reusable evidence and graph-visible affordance anatomy, but it may not command behavior.

Cross-context transfer must be inhibited until local evidence confirms it. Game evidence, language evidence, self-action evidence, and real-world sensor evidence must keep provenance tags.

The active source budget is governed by `ProjectScopePolicy`, currently 88 active Python files and 20 active markdown files. Constitution text must not contain stale older caps as operational truth; the policy module and its tests are the gate source.

## v034 M8 Bias Contract Law

Contextual affordance memory may only influence action ranking through an explicit `AffordanceBiasContract`. The contract must expose actor, actor kind, world context, object signature, action kind, local confidence, cross-context transfer strength, inhibition state, and the fact that it may not command action.

Local evidence may create small bounded pressure. Cross-context evidence may only create a weak hypothesis until local target-world evidence exists. A game-avatar apple healing record must never become a robot-body self-edibility command.


## v035 M9 Object-File Law

Same kind does not mean same individual. Object-kind signatures may share category anatomy across similar things, but persistent object identity must live in object files.

An object file may track stable features, recent state, location history, action history, outcome history, and transformations. A sighting is an observation event. It must update the relevant file when identity is known; it must not become a new durable identity unless a new object identity is actually present.

M8 answers meaning-in-use across actor/body/world/action/provenance/outcome. M9 answers individual continuity. These surfaces must not be collapsed into one universal concept or one command pathway.

The active source budget is governed by `ProjectScopePolicy`, current active-source caps are governed by kishsyn_core/scope.py. The policy module is the gate source for active caps.

## M10 Retention Pressure Law

A lived tick is not automatically durable memory. The organism must score completed traces through retention pressure and decide whether the experience is transient, summarized, preserved, or consolidated.

The graph stores reusable anatomy. The ledger stores bounded event history. Retention pressure decides what earns durable memory.

Repeated memories must strengthen reusable `memory_summary:*` nodes. They must not flood the graph with durable `memory:t...` tick-id nodes.

Instruction-like pressure, surprise, pain, relief, utility, self-causation, and dominant body need may raise retention. Low-pressure repetition may compress or decay.

## External Embodiment Law

Future OS, program, game, browser, console, API, file, or robot interaction must enter through governed adapters. External programs are environments, not hidden control channels.

Adapters may expose observations and affordance proposals. Write-like actions such as mouse movement, clicking, typing, file writing, API calls, or physical actuation require graduated certification, explicit session grants, bounded risk, logs, and inspectable consequences.

No future adapter may bypass focus, MomentFrame capture, contextual affordance memory, object files, prediction, consequence, retention pressure, atlas inspection, persistence, or patch gates.


## M11 Play Doctrine

Play is not random action and not a fake personality engine. Play is safe-enough developmental experimentation under body-pressure governance. It may propose bounded probes that the normal action selector can rank, but it may never command behavior, bypass survival pressure, bypass external-interface quarantine, or create tick-specific durable anatomy. Repeated playful experiments must compress into reusable patterns.


## M11 Play Law

Play is safe-enough experimentation, not random action and not hidden goal control. It may propose bounded probes when survival pressure is low enough and novelty/uncertainty are developmentally useful. It may not bypass action selection, priority arbitration, memory economy, or external-interface safety gates. Repeated play must compress into reusable `play_pattern:*` anatomy, not tick-specific play nodes.

## M12 Grounded Language Law

Language is a grounded recall and teaching surface. A word may bind to lived anchors such as concepts, object kinds, object files, contextual affordances, outcomes, actions, retention pressure, and memory summaries. A word may not become a direct command, fake persona, hidden goal, or universal semantic shortcut.

The approved M12 formula is:

```text
word + lived anchor + actor/body + world context + provenance + outcome = grounded recall route
```

External API tutors may help label or teach, but their output must enter through sensory/text/tutor surfaces and then earn retention through organism traces. The language surface must expose `may_command_action=False` in its grounding contract.


## M13 Desktop/OS Observation Law

Operating-system, desktop, browser, console, game, and program surfaces must enter as read-only observations before they can become affordances. A window, button, text field, console line, or game HUD element is an environment object, not a command channel.

M13 authorizes observation frames, sensory packets, inspect affordance proposals, reusable UI graph anatomy, and persistence. It does not authorize mouse movement, clicking, typing, scrolling, file writes, shell commands, API calls, or physical actuation. Write-like affordances must remain blocked until later dummy-bench, supervised, certified, and explicitly granted milestones exist.

## Runtime Shell Portability Law

The web Observatory is a shell, not the organism. The future desktop `.exe`, the CLI runner, and the web Observatory must all wrap the same organism loop, adapter contracts, patch gates, and `stores/` brain-state path. No UI shell may own cognition, own brain state, or create a hidden parallel mind stack.


## M14 Interface Affordance Discovery Law

Interface elements are environment objects before they are controls. A visible button, text field, menu, console, file, webview, canvas, icon, or window may become a reusable `ui_element_kind:*` signature and a proposal-only `interface_affordance:*` record. It may not become a live OS handle or hidden automation shortcut.

M14 authorizes inspectable affordance contracts with `may_propose=true` and `may_actuate=false`. Write-like candidates such as click, type, and scroll must remain blocked until later dummy-bench, supervised, certified, and explicitly granted milestones exist. Repeated observations must strengthen reusable records; tick-specific `ui:t*` durable nodes are forbidden.


## Synaptic Viewport Camera Law

The synaptic viewport is not the brain. It is a bounded visual camera over reusable graph anatomy. Full graph memory belongs to the runtime and `stores/`; visual shells must use budgeted read-models by default and preserve honest total/omitted counts. No web UI or future `.exe` shell may require drawing all nodes and synapses every frame to prove that cognition exists.


## M15 Dummy Bench Actuation Law

Interface-like execution may begin only inside sealed dummy benches. Dummy actions may create sensory feedback and reusable graph anatomy, but they must never touch the real operating system, real files, real network/API surfaces, real mouse/keyboard input, or physical devices. Real desktop/program surfaces remain observation/proposal-only until a later supervised grant milestone explicitly changes that boundary.
