# Patch Ledger

## v028 M3 Counterfactual Replay and Proto-Planning Lock

- Added `kishsyn_core/planning.py` with `CounterfactualReplayEngine`, `CounterfactualOption`, and `PlanningReport`.
- Integrated counterfactual replay into the living loop between action candidate selection and intent stabilization.
- Added plan/prediction/outcome graph traces after lived consequence.
- Added planning persistence to explicit JSON brain state.
- Added planning telemetry to the Observatory Focus / Action / Moment panel.
- Added benchmark task: `counterfactual replay proto-planning`.
- Added evidence criterion: `counterfactual replay proto-planning`.
- Added M3 lock evaluator and CLI: `python -m kishsyn_core.tools.run_milestone_m3_lock`.
- Updated README, COMMANDS, CONSTITUTION, docs, tests, and scope budget.

Validated:

```text
[KishSyn Core] M3 LOCKED score=1.0 verdict='M3 locked: counterfactual replay and proto-planning are controlled and repeatable'
[KishSyn Core] dev gates OK
```

---

# v020 Windows full-test scope policy hotfix

- Moved active source/doc inventory into `kishsyn_core/scope.py` as the single ScopePolicy surface shared by `dev_gates` and pytest.
- Updated `test_contracts_and_scope.py` so the full pytest inventory no longer calls raw `ROOT.rglob("*.md")` and no longer traverses archived patch folders, generated stores, or broken OneDrive placeholder paths.
- Updated the dev-gate inventory regression to test the shared policy instead of a private gate helper.
- Added a fixture-level regression proving archive/store markdown files are ignored by the governed living-line budget.

Design patterns: Policy Object + Facade for governed repo inventory; Anti Ping-Pong regression gate for archive traversal.

Validation:

```text
62 passed
[KishSyn Core] dev gates OK
active_python_files=53 markdown_docs=11
```

# v019 Windows gate traversal hotfix

- Fixed `dev_gates` markdown inventory so it only counts governed active root/docs markdown files instead of recursively walking archive folders, generated stores, or OneDrive/cloud placeholder paths.
- Added `test_dev_gates_inventory.py` so archive/generated traversal cannot quietly return.
- Updated README and COMMANDS with the correct PowerShell pytest command syntax.

Design patterns: Boundary/Facade for the gate inventory surface; Constitutional Scope Gate remains the governing pattern.

# Patch Ledger

## v018 - Intelligence Evidence Scorecard

- Added `kishsyn_core/evidence.py`, a conservative Facade + Composite Scorecard for measuring primitive adaptive-intelligence evidence without adding a second mind stack.
- Added `python -m kishsyn_core.tools.run_evidence_report` to emit a JSON report covering body continuity, trace/replay, graph growth, foraging adaptation, self-causation, motor controllability, concept compression, symbol ablation, symbol-goal pressure, bounded teaching, and ablation sensitivity.
- Added tests proving the scorecard remains bounded, conservative, and does not claim consciousness.
- Tightened `dev_gates` so the emergence-evidence scorecard must remain above the watch threshold and symbol evidence must stay ablation-sensitive.
- Updated README, COMMANDS, and the Constitution with the new evidence rule.

Validation:

```text
60 passed
[KishSyn Core] dev gates OK
active_python_files=51 markdown_docs=12
```

# KishSyn Core Patch Ledger

## v017 - Autonomous Tutor Curriculum + Synapse Observatory Navigation

- Added `kishsyn_core/autopilot.py` with `AutonomousTutorCurriculum`, a bounded environmental tutor that periodically injects weak lessons through the existing tutor/text sensory pathway.
- Integrated autopilot into the single organism loop before text sensory collapse so autonomous lessons are sensed, plastic, persistent, and ablatable instead of hidden instructions.
- Persisted autopilot state inside brain-state JSON.
- Added `/api/autopilot/config` plus observatory controls for auto-tutor on/off and interval changes.
- Changed observatory startup so existing brain state loads by default unless `--fresh-state` is used.
- Expanded neural/synaptic graph zoom from 0.15x to 8x with +/- buttons, fit, mouse-wheel zoom, and drag-to-pan.
- Added autopilot tests and gate coverage.

Validation:

```text
Focused pytest: 15 passed
[KishSyn Core] dev gates OK
[KishSyn Core] active_python_files=48 markdown_docs=12
```


## v013 - Priority Arbitration + Metabolic Stabilization

- Added `kishsyn_core/priority.py` with survival/body/symbol arbitration.
- Active symbol goals can now be honored, deferred, or overridden by survival pressure.
- Added symbol-goal deferral so cue pressure can be preserved through crisis instead of becoming a command.
- Slowed metabolic decay to avoid permanent fatigue cap / zero-energy crisis mode.
- Added priority telemetry to the observatory and snapshot contract.
- Added priority tests and decay-regression coverage.

Validation:

```text
20 passed
[KishSyn Core] dev gates OK
[KishSyn Core] active_python_files=40 markdown_docs=12
[KishSyn Core] full inventory: python -m pytest kishsyn_core/tests -q
```

# Patch Ledger

## v011 - Symbol-Guided Choice + Symbol Ablation Proof

- Added `SymbolChoiceProbe`, a causal test that asks whether learned tokens bias candidate choice through grounded concept pathways.
- Added `NeuralGrowthGraph.symbol_cue_score`, which scores active sensory tokens against candidate target features only through graph-grown `symbol:* -> concept:*` and feature-to-concept pathways.
- Added `NeuralGrowthGraph.symbol_ablated_copy` so symbol influence can be removed without deleting the rest of the learned concept graph.
- Added cue-only symbol surfaces to the ecology, distinct from teacher surfaces. Teacher surfaces bind symbols; cue surfaces can later test whether those symbols influence choice.
- Added a CLI proof command: `python -m kishsyn_core.tools.run_symbol_choice_probe --steps 420 --seed 337 --out stores/_demo/symbol_choice_probe.json`.
- Updated the observatory to show symbol-choice accuracy, trial examples, and symbol ablation delta.
- Raised the active Python file scope gate from 32 to 40 because proof modules are now allowed when they test causal learning directly.
- Added tests proving symbol cues prefer matching grounded candidates over distractors and fail under symbol ablation.

Validation:

```text
37 passed
[KishSyn Core] dev gates OK
```

## v010 - Embodied Symbol Teaching + Symbol-to-Concept Binding

- Added teacher-symbol surfaces to the ecology without adding a parser table or hardcoded definitions.
- Symbol objects can now expose `vision:symbol_token=*` plus paired grounded evidence such as color, shape, glyph, or count.
- Added `symbol:*` neurons and plastic symbol-to-concept binding inside the existing neural growth graph, without adding new Python files.
- Symbol bindings only form downstream of inspected/touched traces; symbols do not become useful unless sensory/action/outcome experience strengthens them.
- Prediction and action scoring can weakly use learned symbol pathways, but only through the same graph pathways as other learned associations.
- Updated the observatory to show symbol counts, symbol-binding updates, and visible token-to-concept links beside the existing concept formation surface.
- Kept the active scope budget locked at 32 Python files and 10 markdown docs.
- Added tests inside existing test files proving teacher symbols expose sensory evidence without affordance labels and that symbol tokens bind to grounded concept hubs after experience.

Validation:

```text
34 passed
[KishSyn Core] dev gates OK
```

## v009 - Trace-Grounded Sensory Abstraction + Symbol/Glyph Encounters

- Added finite symbol/glyph objects to the ecology without exposing affordance labels in sensory features.
- Added glyph and count sensory features so alphabet-like marks and numerosity can become learnable patterns later.
- Extended neural growth with trace-grounded concept hubs for color, shape, glyph, count, terrain, zone, alphabetic marks, numerosity, and parity.
- Concept hubs are downstream of action/outcome traces; they do not mean anything unless consequence plasticity makes them useful.
- Prediction and action scoring can now use weak concept generalization, allowing future transfer from exact object memory toward category-like behavior.
- Updated the observatory to show glyph objects, concept counts, concept families, and top outcome-linked prototypes.
- Added tests proving symbol features expose glyph/count without affordance labels and that concept nodes form from experience.

Validation:

```text
32 passed
[KishSyn Core] dev gates OK
```

## v008 - Finite Foraging Ecology + Anti-Camping Pressure

- Enlarged the default ecology to 31x23 and made terrain/resource pressure less static.
- Added finite local terrain charge so spring/shelter/grove tiles can be exhausted by camping and recharge only while not occupied.
- Made resources gatherable and finite; depleted resources now migrate/regrow into underexplored regions rather than restoring infinite value at the same tile.
- Added procedural resource pulses, resource migration counters, visited-cell tracking, depletion tracking, and foraging telemetry.
- Added foraging candidate exposure so local perception plus underexplored environmental gradients can compete without hardcoding a destination.
- Added short-lived goal continuity to stop selector dithering and let the organism complete a route to a chosen target.
- Updated the observatory to show finite-foraging evidence: visited cells, depleted resources, migrations, local terrain charge, and depleted object state.
- Added tests proving resources deplete/migrate and the loop forages across many cells instead of camping.

Validation:

```text
30 passed
[KishSyn Core] dev gates OK
```


## v007 - Prediction-Driven Motor Experimentation

- Added `MotorExperimenter`, a bounded probe regulator that proposes safe motor-channel tests only when survival pressure allows.
- Action selection now receives optional motor-probe proposals without turning them into commands.
- Motor probes update neural `experiment:*` pathways from self-causation, prediction reliability, usefulness, harm, and outcome evidence.
- The organism snapshot and observatory now expose motor-probe intent, channel controllability, probe count, and experiment neurons.
- Kept the hard scope budget intact at exactly 32 Python files under `kishsyn_core/` and 10 markdown docs.
- Added tests for safe probe proposal, controllability recording, and loop/observatory surface exposure.

Validation:

```text
28 passed
[KishSyn Core] dev gates OK
```

## v006 - Developmental Regulation + Learning Focus

- Added `DevelopmentalRegulator`, a small regulatory state machine that senses body pressure, recent prediction error, and learning progress.
- Added four developmental focus modes: `stabilize`, `explore`, `verify`, and `consolidate`.
- Action selection now receives bounded focus bias without direct commands, personality labels, or consciousness claims.
- Developmental focus now becomes plastic evidence in the neural graph through `development:*` neurons and pathways to action, outcome, pressure, progress, and need nodes.
- Replay can occur more often during verification/consolidation phases, making self-recursive review part of the same loop.
- The observatory now exposes developmental mode, learning progress, pressure, recent error, and focus biases.
- Added tests for developmental focus selection, plasticity, action-bias influence, and snapshot exposure.

Validation:

```text
25 passed
[KishSyn Core] dev gates OK
```

## v005 - Emergent Comfort Basins + Proto-Body Binding

- Added `ComfortAttractorMemory`, which lets places become comfort-like only through repeated recovery, safety, familiarity, and predictability.
- Added `ProtoBodyMap`, which lets motor channels become body-like only when efference, sensory change, body-state change, and self-causation agree.
- Action selection now receives bounded comfort-basin and motor-confidence bias, but no place is hardcoded as home and no body parts are pre-labeled.
- The observatory now overlays comfort heat on the living world and lists comfort basins plus body-binding strengths beside route memory and replay.
- The neural graph now grows `comfort:*`, `motor:*`, and `self:*` pathways from real tick traces.
- Added tests proving comfort basins can emerge positively or negatively and motor channels can gain self-caused binding strength.

Validation:

```text
21 passed
[KishSyn Core] dev gates OK
```

## v004 - Route Memory + Full-Screen Zoomable Observatory

- Added `RouteMemory`, a small hippocampal-style route trace scaffold.
- Added route and target neurons/synapses grown from actual tick traces.
- Action selection now receives bounded route bias from learned place/action/outcome history.
- Enlarged the ecology to 23x17 with more resources, hazards, terrain zones, scheduled spawns, and living dynamics.
- Added terrain-map export so the witness GUI can show the world directly instead of guessing empty-cell terrain.
- Rebuilt the observatory layout so the living world and neural/synaptic graph sit side by side, fill the main screen, and expose zoom controls.
- Added route-memory tests and doctrine while staying inside active scope gates.

## v003 - Larger Living Ecology + Place Memory

- Enlarged the mini ecology from a tiny static grid into a 15x11 living environment.
- Added terrain, zones, renewable resources, moving hazards, scheduled spawns, and regrowth.
- Added `place` and `terrain` sensory feature kinds.
- Bound place/terrain features into the neural graph through the existing plasticity engine.

## v002 - Autonomous Recursive Runtime + Self-Boundary

- Added autonomous server-side ticking.
- Added pause/resume/reset/Hz control.
- Added efference copy and self/world causation estimation.

## v001 - Core Rebase Foundation

- Created clean `kishsyn_core/` package.
- Added reflex-first loop, deterministic mini ecology, neural growth graph, memory, workspace, CLI, observatory, and constitution.


## v012 Persistent Symbol Goals

- Added `kishsyn_core/symbol_goal.py` for cue-activated short-lived symbolic intention.
- Integrated active cue tokens into action selection through existing learned symbol/concept pathways.
- Added `run_symbol_goal_probe` command and tests for cue activation, selector bias, and observatory exposure.
- Updated observatory to show active symbol goal state, guided attempts, and evidence.
- No consciousness claim. No direct token lookup table added.


## v014 - Persistent Brain State + Slower Metabolic Drift

- Added explicit JSON brain-state persistence through `kishsyn_core/state.py`.
- Persisted and restored neural graph, synapses, world ecology, body state, memory traces, workspace events, self-boundary samples, route memory, comfort basins, proto-body map, developmental regulator, motor experiments, symbol goals, priority state, and current motor goal continuity.
- Added observatory Save brain / Load brain controls and server endpoints `/api/state/save` and `/api/state/load`.
- Added `--state`, `--load-state`, and `--autosave-every` server flags.
- Added `--state-in` and `--state-out` to `run_core_world` for headless continuity.
- Reduced metabolic drift to one-eighth of v013 values so energy/fatigue no longer force permanent crisis behavior.
- Raised the active Python file cap to 45, still gated.
- Disabled pytest plugin autoload inside dev gates to prevent external plugin shutdown hangs while keeping the same proof spine.

Validation:

```text
24 passed
[KishSyn Core] dev gates OK
```


## v015 - Trace-Grounded Text Crib Console

- Added `kishsyn_core/text_crib.py`, a sensory-motor text surface for the living loop.
- Added observatory text console endpoints `/api/text/input` and `/api/text/history`.
- Text messages now inject replayable features such as `text:word=*`, `text:char=*`, `text:glyph=*`, and `text:number=*`.
- Known text words may activate learned symbol goals only when graph-grown symbol/concept evidence exists.
- Added primitive typed output derived from the organism's current graph state, not from GPT or a persona layer.
- Persisted text crib input/output history, binding counts, last features, and last graph-derived response in brain-state JSON.
- Added text node visualization in the synaptic graph and a Text Crib Console panel in the observatory.
- Raised the active Python file cap to 48 to permit the text crib and its tests while keeping the scope gate active.

Validation:

```text
27 passed
[KishSyn Core] dev gates OK
```


## v016 - Bounded Tutor Surface

- Added `kishsyn_core/tutor.py`, an external tutor surface for weak, visible label/lesson pressure.
- Added observatory endpoints `/api/tutor/input` and `/api/tutor/history`.
- Tutor lessons enter through the text crib and weak graph plasticity; they do not become a chatbot persona or direct action policy.
- Persisted tutor lesson history and counts in brain-state JSON.
- Added tutor nodes/synapses to the neural graph witness and tutor controls in the Text / Tutor Console.
- Raised the active Python file cap to 56 while keeping the scope gate active.

Validation:

```text
31 passed through bounded dev gate
```


## v021 - Controlled Benchmark Playground Suite

- Added `kishsyn_core/benchmark.py` as the controlled benchmark playground suite.
- Added six deterministic proof-pressure tasks: delayed symbol-object matching, changed-object surprise, causal action controllability, route memory transfer, depletion-aware foraging, and symbol recall after save/load.
- Added `python -m kishsyn_core.tools.run_benchmark_suite` for standalone benchmark reports.
- Embedded benchmark-suite summary into the intelligence evidence report and exposed `--benchmark-seeds` on `run_evidence_report`.
- Tightened `dev_gates` so benchmark playground evidence is now checked before shipping.
- Added benchmark tests and evidence integration tests.
- Kept the active Python file budget at 56 and the markdown budget at 12.

Validation:

```text
64 tests passed in chunked full-inventory validation
[KishSyn Core] dev gates OK
[KishSyn Core] benchmark suite verdict='controlled benchmark evidence present' score=1.0 tasks=pass:6/watch:0/fail:0 consciousness_claimed=False
[KishSyn Core] verdict='primitive adaptive intelligence evidence' score=1.0 criteria=pass:12/watch:0/fail:0 consciousness_claimed=False
```


## v022 - Observatory Tests / Evidence Panel

- Added observatory report endpoints for latest report loading, controlled benchmark execution, and evidence-scorecard execution.
- Added a Tests / Evidence panel to the browser observatory with Run benchmark, Run evidence, Load latest, and Clear view controls.
- Rendered benchmark tasks and evidence criteria as visual pass / watch / fail cards with scores and thresholds.
- Stored latest generated report payloads in the observatory session and wrote report JSON to `stores/_demo`.
- Added observatory report-surface tests and a dev-gate check that the report facade is present.
- Kept the active Python file budget at 56 and the markdown budget at 12.

Validation:

```text
65 passed
[KishSyn Core] dev gates OK
```


## v023 - Observatory Report History / Trend Surface

- Added compact append-only report history to the observatory server using a Repository + Memento pattern inside the existing report facade.
- Benchmark/evidence UI runs now append score, verdict, pass/watch/fail counts, observed task values, run parameters, and timestamp to `stores/_demo/report_history.jsonl`.
- Added `/api/reports/history?reload=true` and included history snapshots in `/api/snapshot` and `/api/reports/latest`.
- Upgraded the Tests / Evidence panel with a trend strip, latest same-kind delta, best benchmark/evidence scores, and recent run rows.
- Added regression tests proving report history is persisted and restored without adding a new mind stack or increasing the active Python file budget.
- Kept the active Python file budget at 56 and the markdown budget at 12.

Validation:

```text
66 passed
[KishSyn Core] dev gates OK
```


## v024 - Action Reasoning and Harder Navigation Pressure

- Added selector-level action-decision mementos without adding a parallel policy or second mind stack.
- `OrganismSnapshot` now exposes `action_reasoning` with dominant need, developmental mode, priority mode, active symbol tokens, selected candidate, final stabilized choice, and top scored candidates.
- Upgraded the Observatory's middle telemetry panel into **Action Reasoning / Last Loop** with candidate score rows, final-choice highlighting, prediction/outcome/causation evidence, and workspace events.
- Expanded the benchmark playground suite from six to eight tasks by adding target pursuit continuity and survival-symbol conflict arbitration.
- Added regression tests for action-reasoning snapshots and the expanded benchmark task inventory.
- Kept the active Python file budget at 56 and the markdown budget at 12.

Validation:

```text
67 passed
[KishSyn Core] dev gates OK
```


## v025 Focused Moment Substrate milestone

- Added `kishsyn_core/focus.py` with FocusGate, FocusSignal, and FocusReport.
- Added `kishsyn_core/moment.py` with MomentFrame and MomentLedger.
- Added `kishsyn_core/binding.py` with BindingEngine and focused event binding candidates.
- Added `kishsyn_core/anatomy.py` with AnatomyGrowthEngine and provisional circuit promotion.
- Integrated focus selection into the living loop before action selection.
- Integrated MomentFrame capture, binding growth, and provisional circuit promotion after action consequence.
- Persisted focus, moment, binding, and anatomy state in JSON brain-state storage.
- Added benchmark task `focused moment substrate`.
- Added evidence criterion `focused moment substrate`.
- Updated dev gates to require focus selectivity, retained moments, stable bindings, and circuit growth.
- Updated Observatory telemetry to show Focus / Action / Moment state.
- Raised active Python scope budget from 56 to 64 because M1 adds four locked substrate modules and one test module.
- Added `docs/MILESTONE_M1_FOCUSED_MOMENT_SUBSTRATE.md`.

Validation:

```text
70 passed
[KishSyn Core] dev gates OK
[KishSyn Core] benchmark suite verdict='controlled benchmark evidence present' score=0.9444 tasks=pass:8/watch:1/fail:0 consciousness_claimed=False
[KishSyn Core] verdict='primitive adaptive intelligence evidence' score=1.0 criteria=pass:13/watch:0/fail:0 consciousness_claimed=False
```


## v026 - M1 Lock Hardening

- Promoted Milestone M1 from candidate surface to formal lock surface with `kishsyn_core/milestone.py`.
- Added `python -m kishsyn_core.tools.run_milestone_m1_lock` as the governed command for declaring M1 locked.
- Corrected depletion-aware foraging measurement to use cumulative depletion events instead of endpoint currently-depleted resources, since resources can migrate/regrow before the final snapshot.
- Corrected evidence foraging metrics to use cumulative depletion pressure plus exploration.
- Added milestone lock tests proving the report contains focus, moment, binding, circuit, benchmark, and focused-substrate criteria.
- Preserved the M1 storage decision: explicit JSON brain-state and JSONL reports remain the source of truth; the old database layer does not return until a separate storage milestone is declared.
- Raised the active line to v026 while staying inside the 64 Python file / 12 markdown document budget.

Validation:

```text
71 passed
[KishSyn Core] dev gates OK
[KishSyn Core] benchmark suite verdict='controlled benchmark evidence present' score=1.0 tasks=pass:9/watch:0/fail:0 consciousness_claimed=False
[KishSyn Core] M1 LOCKED score=1.0 verdict='M1 locked: Focused Moment Substrate is controlled and repeatable'
```

## v027 - M2 Cross-Modal Binding and Intent Persistence

- Added `kishsyn_core/intent.py` with an explicit State Machine for active target commitments.
- Integrated intent persistence into the living loop after candidate selection and before action consequence.
- Added intent graph traces linking need, intent, target, action, and outcome.
- Extended focused binding candidates with modality span, cross-modal count, and stable cross-modal binding metrics.
- Persisted the intent model through explicit JSON brain-state storage.
- Added benchmark tasks `cross-modal binding` and `intent persistence`.
- Added evidence criteria for cross-modal binding and intent persistence.
- Added `MilestoneM2LockEvaluator` and `python -m kishsyn_core.tools.run_milestone_m2_lock`.
- Updated the Observatory to display cross-modal binding span/count and intent continuity/completion.
- Added `docs/MILESTONE_M2_CROSS_MODAL_INTENT.md`.
- Raised active scope budget to 68 Python files and 13 markdown docs for the M2 milestone surface.

Validation:

```text
[KishSyn Core] dev gates OK
[KishSyn Core] active_python_files=66 markdown_docs=13
[KishSyn Core] M2 LOCKED score=1.0 verdict='M2 locked: cross-modal binding and intent persistence are controlled and repeatable'
```


## v029 - M4 sensory adapter / expression / neural atlas

- Added `sensory.py` with a universal `SensoryAdapterHub` for console, math, screen, image, audio, and generic sensor packets.
- Added `expression.py` with graph-grounded console expression as a motor surface.
- Added `atlas.py` as the standard GUI-facing projection of neural/synaptic activity across all touched surfaces.
- Wired sensory adapters into the living loop before FocusGate and wired expression after action consequence.
- Added M4 benchmark/evidence/milestone lock surfaces and the `run_milestone_m4_lock` command.
- Updated persistence, Observatory endpoint `/api/sensory/input`, docs, tests, and dev gates.


## v030 - M5 neural atlas inspector and clickable synapse introspection

- Added `atlas_inspector.py` as the read-only neuron/synapse inspection contract.
- Added standardized node inspection with surface, kind, label, activation, age, inbound/outbound pathways, connected nodes, and recent plasticity.
- Added standardized synapse inspection with source/target provenance, weight, update count, polarity, connected endpoints, and recent plasticity.
- Added Observatory APIs `/api/atlas/index`, `/api/atlas/node`, and `/api/atlas/synapse`.
- Updated the graph canvas so nodes and synapses can be clicked and inspected in the GUI.
- Added benchmark/evidence coverage for neural atlas inspection.
- Added `MilestoneM5LockEvaluator` and `python -m kishsyn_core.tools.run_milestone_m5_lock`.
- Added `docs/MILESTONE_M5_ATLAS_INSPECTOR.md`.
- Raised the markdown scope budget to 16 for the new milestone doctrine document.

Validation:

```text
[KishSyn Core] dev gates OK
[KishSyn Core] benchmark suite verdict='controlled benchmark evidence present' score=1.0 tasks=pass:14/watch:0/fail:0 consciousness_claimed=False
[KishSyn Core] verdict='primitive adaptive intelligence evidence' score=1.0 criteria=pass:18/watch:0/fail:0 consciousness_claimed=False
[KishSyn Core] M5 LOCKED score=1.0 verdict='M5 locked: neural atlas inspector and synapse introspection are controlled and repeatable'
```


## v031 - M6 emotional regulation field

- Added `emotion.py` with `EmotionalRegulationField`, replayable `EmotionSample`, and slow `EmotionTrait` accumulation.
- Wired emotional regulation into the completed organism tick after action consequence, expression, planning, and intent evidence are available.
- Added graph-visible `emotion` neurons and synapses for modes, dimensions, and trait tendencies.
- Persisted emotional regulation through explicit JSON brain-state storage.
- Updated the Observatory Focus / Action / Moment panel and atlas coloring for emotional regulation weather.
- Added benchmark/evidence coverage for the emotional regulation field.
- Added `MilestoneM6LockEvaluator` and `python -m kishsyn_core.tools.run_milestone_m6_lock`.
- Added `docs/MILESTONE_M6_EMOTIONAL_REGULATION.md`.
- Raised active scope budget to 80 Python files and 17 markdown docs for the M6 surface.

Validation target:

```text
[KishSyn Core] M6 LOCKED score=1.0 verdict='M6 locked: emotional regulation field is controlled and repeatable'
```

## v032 - M7 emotion-biased attention, memory economy, and patch gates

- Added `EmotionBiasContract` so the emotional regulation field may export a bounded previous-sample nudge into FocusGate and ExpressionSurface.
- Wired emotion bias into focus scoring as an explicit `emotion` component, not a hidden action override.
- Wired emotion bias into expression evidence so regulation can be surfaced without becoming a fake personality engine.
- Replaced durable tick-specific `plan:t...` nodes with reusable `plan_template:*` graph anatomy.
- Persisted plan-template statistics and emotion-bias state through the explicit JSON brain-state store.
- Added `MilestoneM7LockEvaluator` and `python -m kishsyn_core.tools.run_milestone_m7_lock`.
- Added `python -m kishsyn_core.tools.patch_gates` with quick/current/full per-patch gate profiles.
- Added M7 and patch-gate doctrine documents.
- Updated Constitution, README, COMMANDS, benchmark, milestone scoring, dev gates, and tests for the new path.

Validation performed in this sandbox:

```text
python -m py_compile kishsyn_core/planning.py kishsyn_core/emotion.py kishsyn_core/focus.py kishsyn_core/expression.py kishsyn_core/loop.py kishsyn_core/benchmark.py kishsyn_core/milestone.py kishsyn_core/tools/dev_gates.py kishsyn_core/tools/run_milestone_m7_lock.py kishsyn_core/tools/patch_gates.py
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest kishsyn_core/tests/test_milestone_m7_emotion_bias.py -q
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest kishsyn_core/tests/test_emotional_regulation_field.py -q
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest kishsyn_core/tests/test_milestone_m3_planning.py::test_counterfactual_replay_surface_runs_inside_loop kishsyn_core/tests/test_milestone_m3_planning.py::test_counterfactual_replay_persists_in_brain_state -q
```

Note: full dev gates and full milestone locks may still be slow. v032 adds per-patch gate profiles so unchanged expensive surfaces do not have to be rerun for every local patch.

## v033 - Contextual Affordance Cognition Started

- Added `kishsyn_core/contextual_affordance.py`, the first M8 layer for actor/body + world-context + object-kind + action + provenance + outcome memory.
- Added reusable `AffordanceRecord` storage so common-sense use differences are learned as context-bound evidence instead of universal concept commands.
- Added object-kind signatures that ignore object id, distance, quantity, cell, terrain, and other one-off noise so Apple A / Apple B style patterns can reuse anatomy while preserving context differences.
- Added weak transfer hypotheses with cross-context inhibition. Same-context evidence can transfer strongly; game-to-robot or avatar-to-robot transfer remains a hypothesis until local evidence confirms it.
- Integrated contextual affordance recording into the single organism loop after lived outcome and exposed it in snapshots, score metrics, state save/load, dev gates, and patch gates.
- Added `docs/MILESTONE_M8_CONTEXTUAL_AFFORDANCE_COGNITION.md` so future chats inherit the new course from the repo itself.
- Updated README, COMMANDS, ARCHITECTURE, PATCH_GATE_STRATEGY, and CONSTITUTION with the new doctrine.

Validation:

```text
python -m py_compile $(find kishsyn_core -name '*.py')
python -m pytest kishsyn_core/tests/test_contextual_affordance.py -q -> 3 passed
python -m pytest kishsyn_core/tests/test_milestone_m7_emotion_bias.py::test_emotion_bias_contract_reaches_focus_and_expression -q -> passed
python -m pytest kishsyn_core/tests/test_milestone_m7_emotion_bias.py::test_plan_instances_compress_into_reusable_templates -q -> passed
python -m pytest kishsyn_core/tests/test_dev_gates_inventory.py -q -> passed
python -m kishsyn_core.tools.patch_gates --profile current --run -> OK in 11.35s
loop probe 120 ticks -> contextual_records=24 contextual_updates=120 object_kinds=12 plan_templates=26 plan_template_updates=120 plan:t leaks=False
scope -> active_python_files=87 markdown_docs=20
```

Full `python -m kishsyn_core.tools.dev_gates` was attempted in this sandbox and timed out, so v033 relies on the successful per-patch gates plus focused tests above.

## v034 M8: Contextual Affordance Hardening and Apple Across Worlds Lock

- Added `AffordanceBiasContract` to `kishsyn_core/contextual_affordance.py`. Contextual affordance evidence can now report small governed ranking pressure without commanding action.
- Added Apple Across Worlds test coverage proving one apple-like object kind stays reusable while actor/body/world/action/outcome distinctions remain separate.
- Added Apple Across Worlds to the controlled benchmark suite.
- Added `kishsyn_core/tools/run_milestone_m8_lock.py` for M8 handoff validation.
- Updated README, COMMANDS, CONSTITUTION, M8 docs, and patch-gate doctrine with the v034 course lock.

Validation:

```text
python -m py_compile kishsyn_core/contextual_affordance.py kishsyn_core/benchmark.py kishsyn_core/tools/run_milestone_m8_lock.py
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python -m pytest kishsyn_core/tests/test_contextual_affordance.py -q
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python -m kishsyn_core.tools.run_milestone_m8_lock --steps 120 --seeds 337 --out stores/_demo/milestone_m8_lock_report.json
```

Result:

```text
4 passed
[KishSyn Core] M8 LOCK score=1.0 locked=True verdict='M8 locked: contextual affordance cognition is bounded and context-aware'
```


## v035 M9: Object-File Cortex

- Added `kishsyn_core/object_file.py`, a governed object-file cortex that separates persistent individual object identity from reusable object-kind anatomy.
- Added `ObjectFile`, `ObjectFileObservation`, and `ObjectFileCortex` so repeated sightings update one file instead of spawning new durable identities.
- Integrated object-file recording into the single organism loop after lived outcome and exposed it in snapshots, score metrics, state save/load, and patch gates.
- Added object transformation tracking for quantity/location/terrain-style changes without turning every observation into a durable graph node.
- Added object-file identity coverage to the benchmark suite and `kishsyn_core/tools/run_milestone_m9_lock.py`.
- Added `docs/MILESTONE_M9_OBJECT_FILE_CORTEX.md` and updated README, COMMANDS, CONSTITUTION, scope policy, and patch gates for the new milestone.

Validation:

```text
python -m py_compile kishsyn_core/object_file.py kishsyn_core/loop.py kishsyn_core/state.py kishsyn_core/benchmark.py kishsyn_core/tools/patch_gates.py kishsyn_core/tools/run_milestone_m9_lock.py
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest kishsyn_core/tests/test_object_file_cortex.py -q -> 3 passed
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest kishsyn_core/tests/test_contextual_affordance.py -q -> 4 passed
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest kishsyn_core/tests/test_milestone_m7_emotion_bias.py::test_plan_instances_compress_into_reusable_templates -q -> passed
python -m kishsyn_core.tools.run_milestone_m9_lock --steps 120 --seeds 337,171,23 --out stores/_demo/milestone_m9_lock_report.json -> LOCKED score=1.0
python -m kishsyn_core.tools.patch_gates --profile current --run -> OK in 12.63s
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest kishsyn_core/tests/test_milestone_m7_emotion_bias.py::test_plan_instances_compress_into_reusable_templates kishsyn_core/tests/test_dev_gates_inventory.py -q -> 2 passed
```

Note: patch gates were updated and scope caps were raised to match the governed M9 surface. Full expensive gates should still be run before a release-grade milestone handoff when local time allows.

## v036 M10: Retention Pressure, Memory Economy, and External Embodiment Contracts

- Added `kishsyn_core/memory_economy.py`, a governed M10 layer for trace retention pressure.
- Added `RetentionPressure`, `MemorySummary`, and `MemoryPressureGovernor` so completed traces are scored as transient, summarize, preserve, or consolidate.
- Integrated memory economy into the single organism loop after workspace evaluation and before trace persistence, so completed lived outcomes can compress into reusable `memory_summary:*` graph anatomy.
- Added memory-economy state save/load, snapshot exposure, and score metrics.
- Added `kishsyn_core/tools/run_milestone_m10_lock.py`.
- Added `kishsyn_core/tests/test_memory_economy.py` proving instruction/surprise pressure is preserved, repeated experience reuses one summary bucket, and loop state persists.
- Added `kishsyn_core/external_interface.py`, a non-actuating contract layer for future OS/program/game/API/hardware adapters.
- Added `kishsyn_core/tests/test_external_interface.py` proving write-like actions are blocked by default and require certified stage plus explicit grant.
- Added `docs/MILESTONE_M10_RETENTION_PRESSURE_MEMORY_ECONOMY.md` and `docs/EXTERNAL_EMBODIMENT_INTERFACE_DOCTRINE.md`.
- Updated README, COMMANDS, CONSTITUTION, PATCH_GATE_STRATEGY, patch gates, and package metadata.

Validation:

```text
python -m py_compile kishsyn_core/memory_economy.py kishsyn_core/external_interface.py kishsyn_core/loop.py kishsyn_core/state.py kishsyn_core/tools/run_milestone_m10_lock.py kishsyn_core/tools/patch_gates.py
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 pytest kishsyn_core/tests/test_memory_economy.py kishsyn_core/tests/test_external_interface.py -q -> 5 passed
python -m kishsyn_core.tools.run_milestone_m10_lock --steps 120 --seeds 337,171,23 --out stores/_demo/milestone_m10_lock_report.json -> LOCKED score=1.0
python -m kishsyn_core.tools.patch_gates --profile current --run -> OK
```

Note: full expensive `dev_gates` should still be run before release-grade handoff when local time allows. v036 used focused tests plus current patch gates.


## v037 - M11 Play and Intrinsic Experimentation

- Added `kishsyn_core/play.py` with `IntrinsicPlayDrive`, `PlayIntent`, `PlayRecord`, and reusable `PlayPattern` memory.
- Integrated intrinsic play into the organism loop as a bounded proposal surface.
- Added persistence for play state in the JSON brain store.
- Added M11 tests and lock command.
- Updated patch gates to guard play patterns, persistence, safety ratio, and no `play:t*` node leaks.
- Added `docs/MILESTONE_M11_PLAY_INTRINSIC_EXPERIMENTATION.md`.

Validation used for this patch:

```powershell
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python -m pytest kishsyn_core/tests/test_intrinsic_play.py kishsyn_core/tests/test_memory_economy.py kishsyn_core/tests/test_external_interface.py kishsyn_core/tests/test_object_file_cortex.py kishsyn_core/tests/test_contextual_affordance.py -q
python -m kishsyn_core.tools.run_milestone_m11_lock --steps 120 --seeds 337,171,23 --out stores/_demo/milestone_m11_lock_report.json
python -m kishsyn_core.tools.patch_gates --profile current --run
```


## v038 - M12 Grounded Language and Teaching

- Added `kishsyn_core/grounded_language.py` with `GroundedLanguageCortex`, `GroundedLexemeRecord`, and `LanguageGroundingContract`.
- Integrated grounded language into the organism loop after lived outcome, workspace, retention pressure, and memory-economy scoring.
- Added state persistence, snapshot metrics, and score metrics for grounded-language records.
- Added `kishsyn_core/tools/run_milestone_m12_lock.py`.
- Added `kishsyn_core/tests/test_grounded_language.py`.
- Updated patch gates, README, COMMANDS, CONSTITUTION, PATCH_GATE_STRATEGY, and milestone docs.

Validation used for this patch:

```powershell
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python -m pytest kishsyn_core/tests/test_grounded_language.py -q
python -m kishsyn_core.tools.run_milestone_m12_lock --steps 120 --seeds 337,171,23 --out stores/_demo/milestone_m12_lock_report.json
python -m kishsyn_core.tools.patch_gates --profile current --run
```


## v039 - M13 Desktop/OS Observation and Runtime Portability

- Added `kishsyn_core/desktop_observation.py` with read-only desktop/program observation frames, elements, reports, sensory bridge, governed external-interface registration, and reusable UI graph anatomy.
- Added `kishsyn_core/runtime_shell.py` to keep the organism loop and `stores/` brain state shell-independent for web, CLI, and future official desktop `.exe` releases.
- Integrated OS observation, external-interface registry, and runtime-shell policy into `OrganismLoop` snapshots and JSON state persistence.
- Added `kishsyn_core/tools/run_milestone_m13_lock.py` and `kishsyn_core/tests/test_milestone_m13_os_observation.py`.
- Updated patch gates, docs, constitution, README, and command surface for M13.
- Safety: no mouse, keyboard, file, browser, API, shell, or process actuation is introduced. Write-like affordances are proposed only as blocked audit evidence under read-only telemetry.


## v040 - M14 Interface Affordance Discovery

- Added `kishsyn_core/interface_affordance.py` for UI element signatures, reusable interface affordance records, proposal-only contracts, graph anatomy, and state persistence.
- Integrated M14 into `OSObservationSubstrate.observe(..., interface_affordance=...)` without breaking existing M13 calls.
- Added `interface_affordance` snapshots, score metrics, and JSON save/load support.
- Added `kishsyn_core/tools/run_milestone_m14_lock.py` and `kishsyn_core/tests/test_milestone_m14_interface_affordance.py`.
- Updated `patch_gates` to guard M14 formation, persistence, blocked write-like candidates, desktop portability, and no `ui:t*` node leaks.
- Updated README, COMMANDS, CONSTITUTION, ARCHITECTURE, PATCH_GATE_STRATEGY, and milestone docs.

Validation:

```text
python -m py_compile kishsyn_core/interface_affordance.py kishsyn_core/desktop_observation.py kishsyn_core/loop.py kishsyn_core/state.py kishsyn_core/tools/run_milestone_m14_lock.py kishsyn_core/tools/patch_gates.py
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python -m pytest kishsyn_core/tests/test_milestone_m14_interface_affordance.py -q -> 3 passed
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python -m pytest kishsyn_core/tests/test_milestone_m13_os_observation.py kishsyn_core/tests/test_external_interface.py kishsyn_core/tests/test_dev_gates_inventory.py -q -> 6 passed
python -m kishsyn_core.tools.run_milestone_m14_lock --steps 120 --seeds 337,171,23 --out stores/_demo/milestone_m14_lock_report.json -> LOCKED score=1.0
python -m kishsyn_core.tools.patch_gates --profile current --run -> OK
```

Note: no real OS actuation is introduced. M14 discovers and stores proposal-only affordances for future dummy benches.

## v041 - M14 hardening + synaptic viewport performance camera

- Added `kishsyn_core/graph_viewport.py` with `GraphViewportBudget` and `GraphViewportProjector`.
- Updated Observatory `/api/snapshot` to default web requests to a budgeted viewport graph while preserving `graph=full` diagnostics.
- Optimized `observatory/static/index.html` graph rendering with requestAnimationFrame throttling, canvas resize caching, edge/node draw budgets, hit-test caps, low-zoom weak-edge culling, and rendered/omitted count display.
- Added `docs/SYNAPTIC_VIEWPORT_PERFORMANCE_DOCTRINE.md`.
- Added `kishsyn_core/tests/test_graph_viewport_performance.py`.
- Updated patch gates so viewport projection becomes a guarded performance contract.

Rule reinforced: the graph is full brain anatomy; the viewport is a bounded camera.


## v042 - M15 Dummy Bench Actuation

- Added `kishsyn_core/dummy_bench.py` with sealed in-memory UI practice surface, dummy-only action proposals, contracts, outcomes, graph anatomy, and persistence.
- Added M15 tests and lock runner.
- Integrated dummy bench snapshot/state into the organism loop and brain-state JSON.
- Updated patch gates, commands, docs, and constitution to preserve the real-OS safety boundary.
