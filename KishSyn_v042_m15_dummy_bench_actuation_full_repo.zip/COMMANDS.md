# KishSyn Core Commands

Use these from the repo root in PowerShell.

## Required gate

```powershell
python -m kishsyn_core.tools.dev_gates
```


## Per-patch gates

List the active patch gate manifest:

```powershell
python -m kishsyn_core.tools.patch_gates --profile current
```

Run the active patch gate profile:

```powershell
python -m kishsyn_core.tools.patch_gates --profile current --run
```

Use `--profile quick` for docs-only/tiny changes and `--profile full` before milestone locks or release candidate zips.

## Full pytest inventory

```powershell
$env:PYTEST_DISABLE_PLUGIN_AUTOLOAD="1"; python -m pytest kishsyn_core/tests -q
```

## Milestone locks

```powershell
python -m kishsyn_core.tools.run_milestone_m1_lock --out stores/_demo/milestone_m1_lock_report.json
python -m kishsyn_core.tools.run_milestone_m2_lock --out stores/_demo/milestone_m2_lock_report.json
python -m kishsyn_core.tools.run_milestone_m3_lock --out stores/_demo/milestone_m3_lock_report.json
python -m kishsyn_core.tools.run_milestone_m4_lock --out stores/_demo/milestone_m4_lock_report.json
python -m kishsyn_core.tools.run_milestone_m5_lock --out stores/_demo/milestone_m5_lock_report.json
python -m kishsyn_core.tools.run_milestone_m6_lock --out stores/_demo/milestone_m6_lock_report.json
python -m kishsyn_core.tools.run_milestone_m7_lock --out stores/_demo/milestone_m7_lock_report.json
python -m kishsyn_core.tools.run_milestone_m8_lock --out stores/_demo/milestone_m8_lock_report.json
python -m kishsyn_core.tools.run_milestone_m9_lock --out stores/_demo/milestone_m9_lock_report.json
python -m kishsyn_core.tools.run_milestone_m10_lock --out stores/_demo/milestone_m10_lock_report.json
python -m kishsyn_core.tools.run_milestone_m11_lock --out stores/_demo/milestone_m11_lock_report.json
python -m kishsyn_core.tools.run_milestone_m12_lock --out stores/_demo/milestone_m12_lock_report.json
python -m kishsyn_core.tools.run_milestone_m13_lock --out stores/_demo/milestone_m13_lock_report.json
python -m kishsyn_core.tools.run_milestone_m14_lock --out stores/_demo/milestone_m14_lock_report.json
```

M1 is Focused Moment Substrate. M2 is Cross-Modal Binding and Intent Persistence. M3 is Counterfactual Replay and Proto-Planning. M4 is Sensory Adapter and Expression Surface. M5 is Neural Atlas Inspector. M6 is Emotional Regulation Field. M7 is Emotion-Biased Attention and Expression. M8 is Contextual Affordance Cognition. M9 is Object-File Cortex. M10 is Retention Pressure and Memory Economy. M11 is Play and Intrinsic Experimentation. M12 is Grounded Language and Teaching. M13 is Desktop/OS Observation Substrate. M14 is Interface Affordance Discovery.

## Observatory

```powershell
python -m kishsyn_core.observatory.server --port 8797 --hz 4
```

Open:

```text
http://127.0.0.1:8797/
```

Useful variants:

```powershell
python -m kishsyn_core.observatory.server --port 8797 --hz 8
python -m kishsyn_core.observatory.server --port 8797 --paused
python -m kishsyn_core.observatory.server --port 8797 --fresh-state
python -m kishsyn_core.observatory.server --port 8797 --autosave-every 0
```

## Headless organism run

```powershell
python -m kishsyn_core.tools.run_core_world --steps 300 --seed 337 --out stores/_demo/core_world_snapshot.json --state-out stores/_demo/persistent_brain_state.json
```

Continue from saved state:

```powershell
python -m kishsyn_core.tools.run_core_world --steps 120 --state-in stores/_demo/persistent_brain_state.json --out stores/_demo/core_world_snapshot.json
```

## Benchmark suite

```powershell
python -m kishsyn_core.tools.run_benchmark_suite --steps 240 --seeds 337,171,23 --out stores/_demo/benchmark_suite_report.json
```

## Evidence report

```powershell
python -m kishsyn_core.tools.run_evidence_report --steps 240 --seed 337 --ablation-steps 48 --benchmark-seeds 337,171,23 --out stores/_demo/intelligence_evidence_report.json
```

## Symbol probes

```powershell
python -m kishsyn_core.tools.run_symbol_choice_probe --steps 420 --seed 337 --out stores/_demo/symbol_choice_probe.json
python -m kishsyn_core.tools.run_symbol_goal_probe --steps 300 --seed 337 --out stores/_demo/symbol_goal_probe.json
```

## Observatory report APIs

```text
/api/reports/latest?reload=true
/api/reports/history?reload=true
/api/reports/benchmark/run?steps=240&seeds=337,171,23
/api/reports/evidence/run?steps=240&seed=337&ablation_steps=48&benchmark_seeds=337,171,23
```


## Milestone M4 lock

```powershell
python -m kishsyn_core.tools.run_milestone_m4_lock --steps 96 --seeds 337 --out stores/_demo/milestone_m4_lock_report.json
```

## Observatory sensory adapter endpoint

```text
/api/sensory/input?modality=math&payload=2%2B2%3D4&steps=4
/api/sensory/input?modality=screen&payload=screen%20red%20circle%20near%20cursor&steps=4
```


## Milestone M5 lock

```powershell
python -m kishsyn_core.tools.run_milestone_m5_lock --steps 128 --seeds 337 --out stores/_demo/milestone_m5_lock_report.json
```

## Observatory atlas inspection APIs

```text
/api/atlas/index?limit=120
/api/atlas/node?id=vision%3Acolor%3Dred
/api/atlas/synapse?source=vision%3Acolor%3Dred&target=concept%3Acolor%3Dred
```


## Milestone M6 lock

```powershell
python -m kishsyn_core.tools.run_milestone_m6_lock --steps 160 --seeds 337 --out stores/_demo/milestone_m6_lock_report.json
```


## Milestone M7 lock

```powershell
python -m kishsyn_core.tools.run_milestone_m7_lock --steps 160 --seeds 337 --out stores/_demo/milestone_m7_lock_report.json
```

## M8 contextual affordance tests

```powershell
python -m pytest kishsyn_core/tests/test_contextual_affordance.py -q
```

M8 is started but not locked. It currently records context-bound affordance evidence and persists it. It does not choose actions yet.

## Milestone M8 lock

```powershell
python -m kishsyn_core.tools.run_milestone_m8_lock --steps 180 --seeds 337,171,23 --out stores/_demo/milestone_m8_lock_report.json
```

## Apple Across Worlds benchmark path

```powershell
python -m pytest kishsyn_core/tests/test_contextual_affordance.py -q
python -m kishsyn_core.tools.run_benchmark_suite --steps 240 --seeds 337,171,23 --out stores/_demo/benchmark_suite_report.json
```



## Milestone M9 lock

```powershell
python -m kishsyn_core.tools.run_milestone_m9_lock --steps 180 --seeds 337,171,23 --out stores/_demo/milestone_m9_lock_report.json
```

M9 verifies that distinct object identities can share object-kind anatomy without being collapsed into one object, and that transformations update the same file instead of creating a new durable identity.

## Milestone M10 lock

```powershell
python -m kishsyn_core.tools.run_milestone_m10_lock --steps 180 --seeds 337,171,23 --out stores/_demo/milestone_m10_lock_report.json
```

M10 verifies retention pressure and memory economy: completed traces are scored as transient/summarize/preserve/consolidate, repeated experience compresses into reusable `memory_summary:*` anatomy, and no durable `memory:t...` tick-id nodes leak into the graph.

## M10 and external embodiment contract tests

```powershell
python -m pytest kishsyn_core/tests/test_memory_economy.py -q
python -m pytest kishsyn_core/tests/test_external_interface.py -q
```

`external_interface.py` is a future-facing contract only. It does not actuate the OS. It defines the safety envelope future desktop/game/console/API adapters must obey.


## M11 Play Lock

```powershell
python -m kishsyn_core.tools.run_milestone_m11_lock --steps 180 --seeds 337,171,23 --out stores/_demo/milestone_m11_lock_report.json
```

Fast patch gate after M11 changes:

```powershell
python -m kishsyn_core.tools.patch_gates --profile current --run
```


## M12 Grounded Language Lock

```powershell
python -m kishsyn_core.tools.run_milestone_m12_lock --steps 180 --seeds 337,171,23 --out stores/_demo/milestone_m12_lock_report.json
```

Focused tests:

```powershell
python -m pytest kishsyn_core/tests/test_grounded_language.py -q
python -m kishsyn_core.tools.patch_gates --profile current --run
```

M12 verifies that words bind to lived anchors, contracts stay non-commanding, grounded-language state persists, and no `language:t*` node leaks into durable graph anatomy.


## Milestone M13 lock

```powershell
python -m kishsyn_core.tools.run_milestone_m13_lock --steps 180 --seeds 337,171,23 --out stores/_demo/milestone_m13_lock_report.json
```

## M13 focused tests

```powershell
python -m pytest kishsyn_core/tests/test_milestone_m13_os_observation.py -q
python -m kishsyn_core.tools.patch_gates --profile current --run
```


## Milestone M14 lock

```powershell
python -m kishsyn_core.tools.run_milestone_m14_lock --steps 180 --seeds 337,171,23 --out stores/_demo/milestone_m14_lock_report.json
```


## Synaptic viewport performance

Budgeted Observatory snapshot, default for UI:

```powershell
python -m kishsyn_core.observatory.server --port 8797 --hz 4
# Browser uses /api/snapshot?graph=viewport&node_limit=420&edge_limit=760 by default.
```

Diagnostic full graph snapshot:

```text
http://127.0.0.1:8797/api/snapshot?graph=full
```

Viewport performance smoke:

```powershell
python -m pytest kishsyn_core/tests/test_graph_viewport_performance.py -q
```


### M15 dummy bench lock

```powershell
python -m kishsyn_core.tools.run_milestone_m15_lock --steps 180 --seeds 337,171,23 --out stores/_demo/milestone_m15_lock_report.json
python -m pytest kishsyn_core/tests/test_milestone_m15_dummy_bench.py -q
```
